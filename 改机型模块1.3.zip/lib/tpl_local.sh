#!/system/bin/sh

YJ_TL_HOME="${YJ_PREFIX}/data/adb/device_spoof"
YJ_TL_FILE="${YJ_TL_HOME}/templates_local.toml"

yj_tl_say() { command -v yj_say >/dev/null 2>&1 && yj_say "$*" || echo "$*"; }
yj_tl_warn() { command -v yj_warn >/dev/null 2>&1 && yj_warn "$*" || echo "! $*"; }

yj_tl_seed() {
  mkdir -p "$YJ_TL_HOME" 2>/dev/null
  _want="$YJ_TL_HOME/.tl_want.$$"
  cat > "$_want" <<'YJ_LOCAL_TPL_EOF'
[templates."xiaomi_mi_one_plus"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "MI-ONE PLUS"
device = "mione_plus"
product = "mione_plus"
name = "mione_plus"
marketname = "Xiaomi 1"
fingerprint = "Xiaomi/mione_plus/mione_plus:15/AP3A.241005.015.A1/mione_plus.241005.001:user/release-keys"

[templates."xiaomi_mi_one"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "MI-ONE"
device = "mione_plus"
product = "mione_plus"
name = "mione_plus"
marketname = "Xiaomi 1 青春版"
fingerprint = "Xiaomi/mione_plus/mione_plus:15/AP3A.241005.015.A1/mione_plus.241005.001:user/release-keys"

[templates."xiaomi_2012051"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2012051"
device = "mione_plus"
product = "mione_plus"
name = "mione_plus"
marketname = "Xiaomi 1S"
fingerprint = "Xiaomi/mione_plus/mione_plus:15/AP3A.241005.015.A1/mione_plus.241005.001:user/release-keys"

[templates."xiaomi_2012052"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2012052"
device = "mione_plus"
product = "mione_plus"
name = "mione_plus"
marketname = "Xiaomi 1S 青春版"
fingerprint = "Xiaomi/mione_plus/mione_plus:15/AP3A.241005.015.A1/mione_plus.241005.001:user/release-keys"

[templates."xiaomi_2012061"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2012061"
device = "aries"
product = "aries"
name = "aries"
marketname = "Xiaomi 2"
fingerprint = "Xiaomi/aries/aries:15/AP3A.241005.015.A1/aries.241005.001:user/release-keys"

[templates."xiaomi_2013012"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2013012"
device = "aries"
product = "aries"
name = "aries"
marketname = "Xiaomi 2S"
fingerprint = "Xiaomi/aries/aries:15/AP3A.241005.015.A1/aries.241005.001:user/release-keys"

[templates."xiaomi_2012121"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2012121"
device = "taurus"
product = "taurus"
name = "taurus"
marketname = "Xiaomi 2A"
fingerprint = "Xiaomi/taurus/taurus:15/AP3A.241005.015.A1/taurus.241005.001:user/release-keys"

[templates."xiaomi_2013061"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2013061"
device = "pisces"
product = "pisces"
name = "pisces"
marketname = "Xiaomi 3"
fingerprint = "Xiaomi/pisces/pisces:15/AP3A.241005.015.A1/pisces.241005.001:user/release-keys"

[templates."xiaomi_2014215"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2014215"
device = "cancro"
product = "cancro"
name = "cancro"
marketname = "Xiaomi 4"
fingerprint = "Xiaomi/cancro/cancro:15/AP3A.241005.015.A1/cancro.241005.001:user/release-keys"

[templates."xiaomi_2015561"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2015561"
device = "libra"
product = "libra"
name = "libra"
marketname = "Xiaomi 4c"
fingerprint = "Xiaomi/libra/libra:15/AP3A.241005.015.A1/libra.241005.001:user/release-keys"

[templates."xiaomi_2015911"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2015911"
device = "aqua"
product = "aqua"
name = "aqua"
marketname = "Xiaomi 4S"
fingerprint = "Xiaomi/aqua/aqua:15/AP3A.241005.015.A1/aqua.241005.001:user/release-keys"

[templates."xiaomi_2015201"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2015201"
device = "gemini"
product = "gemini"
name = "gemini"
marketname = "Xiaomi 5"
fingerprint = "Xiaomi/gemini/gemini:15/AP3A.241005.015.A1/gemini.241005.001:user/release-keys"

[templates."xiaomi_2015711"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2015711"
device = "capricorn"
product = "capricorn"
name = "capricorn"
marketname = "Xiaomi 5s"
fingerprint = "Xiaomi/capricorn/capricorn:15/AP3A.241005.015.A1/capricorn.241005.001:user/release-keys"

[templates."xiaomi_2016070"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2016070"
device = "natrium"
product = "natrium"
name = "natrium"
marketname = "Xiaomi 5s Plus"
fingerprint = "Xiaomi/natrium/natrium:15/AP3A.241005.015.A1/natrium.241005.001:user/release-keys"

[templates."xiaomi_2016089"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2016089"
device = "meri"
product = "meri"
name = "meri"
marketname = "Xiaomi 5c"
fingerprint = "Xiaomi/meri/meri:15/AP3A.241005.015.A1/meri.241005.001:user/release-keys"

[templates."xiaomi_mde2"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "MDE2"
device = "tiffany"
product = "tiffany"
name = "tiffany"
marketname = "Xiaomi 5X"
fingerprint = "Xiaomi/tiffany/tiffany:15/AP3A.241005.015.A1/tiffany.241005.001:user/release-keys"

[templates."xiaomi_mce16"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "MCE16"
device = "sagit"
product = "sagit"
name = "sagit"
marketname = "Xiaomi 6"
fingerprint = "Xiaomi/sagit/sagit:15/AP3A.241005.015.A1/sagit.241005.001:user/release-keys"

[templates."xiaomi_m1804d2se"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1804D2SE"
device = "wayne"
product = "wayne"
name = "wayne"
marketname = "Xiaomi 6X"
fingerprint = "Xiaomi/wayne/wayne:15/AP3A.241005.015.A1/wayne.241005.001:user/release-keys"

[templates."xiaomi_m1803e1a"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1803E1A"
device = "dipper"
product = "dipper"
name = "dipper"
marketname = "Xiaomi 8"
fingerprint = "Xiaomi/dipper/dipper:15/AP3A.241005.015.A1/dipper.241005.001:user/release-keys"

[templates."xiaomi_m1807e8s"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1807E8S"
device = "ursa"
product = "ursa"
name = "ursa"
marketname = "Xiaomi 8 透明探索版"
fingerprint = "Xiaomi/ursa/ursa:15/AP3A.241005.015.A1/ursa.241005.001:user/release-keys"

[templates."xiaomi_m1807e8a"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1807E8A"
device = "equuleus"
product = "equuleus"
name = "equuleus"
marketname = "Xiaomi 8 屏幕指纹版"
fingerprint = "Xiaomi/equuleus/equuleus:15/AP3A.241005.015.A1/equuleus.241005.001:user/release-keys"

[templates."xiaomi_m1805e2a"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1805E2A"
device = "sirius"
product = "sirius"
name = "sirius"
marketname = "Xiaomi 8 SE"
fingerprint = "Xiaomi/sirius/sirius:15/AP3A.241005.015.A1/sirius.241005.001:user/release-keys"

[templates."xiaomi_m1808d2te"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1808D2TE"
device = "platina"
product = "platina"
name = "platina"
marketname = "Xiaomi 8 青春版"
fingerprint = "Xiaomi/platina/platina:15/AP3A.241005.015.A1/platina.241005.001:user/release-keys"

[templates."xiaomi_m1902f1a"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1902F1A"
device = "cepheus"
product = "cepheus"
name = "cepheus"
marketname = "Xiaomi 9"
fingerprint = "Xiaomi/cepheus/cepheus:15/AP3A.241005.015.A1/cepheus.241005.001:user/release-keys"

[templates."xiaomi_m1908f1xe"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1908F1XE"
device = "crux"
product = "crux"
name = "crux"
marketname = "Xiaomi 9 Pro 5G"
fingerprint = "Xiaomi/crux/crux:15/AP3A.241005.015.A1/crux.241005.001:user/release-keys"

[templates."xiaomi_m1903f2a"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1903F2A"
device = "grus"
product = "grus"
name = "grus"
marketname = "Xiaomi 9 SE"
fingerprint = "Xiaomi/grus/grus:15/AP3A.241005.015.A1/grus.241005.001:user/release-keys"

[templates."xiaomi_m2001j2e"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M2001J2E"
device = "umi"
product = "umi"
name = "umi"
marketname = "Xiaomi 10"
fingerprint = "Xiaomi/umi/umi:15/AP3A.241005.015.A1/umi.241005.001:user/release-keys"

[templates."xiaomi_m2001j1e"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M2001J1E"
device = "cmi"
product = "cmi"
name = "cmi"
marketname = "Xiaomi 10 Pro"
fingerprint = "Xiaomi/cmi/cmi:15/AP3A.241005.015.A1/cmi.241005.001:user/release-keys"

[templates."xiaomi_m2002j9e"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M2002J9E"
device = "vangogh"
product = "vangogh"
name = "vangogh"
marketname = "Xiaomi 10 青春版"
fingerprint = "Xiaomi/vangogh/vangogh:15/AP3A.241005.015.A1/vangogh.241005.001:user/release-keys"

[templates."xiaomi_m2007j1sc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M2007J1SC"
device = "cas"
product = "cas"
name = "cas"
marketname = "Xiaomi 10 至尊纪念版"
fingerprint = "Xiaomi/cas/cas:15/AP3A.241005.015.A1/cas.241005.001:user/release-keys"

[templates."xiaomi_m2102j2sc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M2102J2SC"
device = "thyme"
product = "thyme"
name = "thyme"
marketname = "Xiaomi 10S"
fingerprint = "Xiaomi/thyme/thyme:15/AP3A.241005.015.A1/thyme.241005.001:user/release-keys"

[templates."xiaomi_m2011k2c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M2011K2C"
device = "venus"
product = "venus"
name = "venus"
marketname = "Xiaomi 11"
fingerprint = "Xiaomi/venus/venus:15/AP3A.241005.015.A1/venus.241005.001:user/release-keys"

[templates."xiaomi_m2102k1ac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M2102K1AC"
device = "star"
product = "star"
name = "star"
marketname = "Xiaomi 11 Pro"
fingerprint = "Xiaomi/star/star:15/AP3A.241005.015.A1/star.241005.001:user/release-keys"

[templates."xiaomi_m2102k1c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M2102K1C"
device = "star"
product = "star"
name = "star"
marketname = "Xiaomi 11 Ultra"
fingerprint = "Xiaomi/star/star:15/AP3A.241005.015.A1/star.241005.001:user/release-keys"

[templates."xiaomi_m2101k9c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M2101K9C"
device = "renoir"
product = "renoir"
name = "renoir"
marketname = "Xiaomi 11 青春版"
fingerprint = "Xiaomi/renoir/renoir:15/AP3A.241005.015.A1/renoir.241005.001:user/release-keys"

[templates."xiaomi_2107119dc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2107119DC"
device = "lisa"
product = "lisa"
name = "lisa"
marketname = "Xiaomi 11 青春活力版"
fingerprint = "Xiaomi/lisa/lisa:15/AP3A.241005.015.A1/lisa.241005.001:user/release-keys"

[templates."xiaomi_2201123c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2201123C"
device = "cupid"
product = "cupid"
name = "cupid"
marketname = "Xiaomi 12"
fingerprint = "Xiaomi/cupid/cupid:15/AP3A.241005.015.A1/cupid.241005.001:user/release-keys"

[templates."xiaomi_2112123ac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2112123AC"
device = "psyche"
product = "psyche"
name = "psyche"
marketname = "Xiaomi 12X"
fingerprint = "Xiaomi/psyche/psyche:15/AP3A.241005.015.A1/psyche.241005.001:user/release-keys"

[templates."xiaomi_2201122c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2201122C"
device = "zeus"
product = "zeus"
name = "zeus"
marketname = "Xiaomi 12 Pro"
fingerprint = "Xiaomi/zeus/zeus:15/AP3A.241005.015.A1/zeus.241005.001:user/release-keys"

[templates."xiaomi_2207122mc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2207122MC"
device = "daumier"
product = "daumier"
name = "daumier"
marketname = "Xiaomi 12 Pro 天玑版"
fingerprint = "Xiaomi/daumier/daumier:15/AP3A.241005.015.A1/daumier.241005.001:user/release-keys"

[templates."xiaomi_2206123sc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2206123SC"
device = "mayfly"
product = "mayfly"
name = "mayfly"
marketname = "Xiaomi 12S"
fingerprint = "Xiaomi/mayfly/mayfly:15/AP3A.241005.015.A1/mayfly.241005.001:user/release-keys"

[templates."xiaomi_2206122sc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2206122SC"
device = "unicorn"
product = "unicorn"
name = "unicorn"
marketname = "Xiaomi 12S Pro"
fingerprint = "Xiaomi/unicorn/unicorn:15/AP3A.241005.015.A1/unicorn.241005.001:user/release-keys"

[templates."xiaomi_2203121c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2203121C"
device = "thor"
product = "thor"
name = "thor"
marketname = "Xiaomi 12S Ultra"
fingerprint = "Xiaomi/thor/thor:15/AP3A.241005.015.A1/thor.241005.001:user/release-keys"

[templates."xiaomi_2211133c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2211133C"
device = "fuxi"
product = "fuxi"
name = "fuxi"
marketname = "Xiaomi 13"
fingerprint = "Xiaomi/fuxi/fuxi:15/AP3A.241005.015.A1/fuxi.241005.001:user/release-keys"

[templates."xiaomi_2210132c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2210132C"
device = "nuwa"
product = "nuwa"
name = "nuwa"
marketname = "Xiaomi 13 Pro"
fingerprint = "Xiaomi/nuwa/nuwa:15/AP3A.241005.015.A1/nuwa.241005.001:user/release-keys"

[templates."xiaomi_2304fpn6dc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2304FPN6DC"
device = "ishtar"
product = "ishtar"
name = "ishtar"
marketname = "Xiaomi 13 Ultra"
fingerprint = "Xiaomi/ishtar/ishtar:15/AP3A.241005.015.A1/ishtar.241005.001:user/release-keys"

[templates."xiaomi_23127pn0cc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "23127PN0CC"
device = "houji"
product = "houji"
name = "houji"
marketname = "Xiaomi 14"
fingerprint = "Xiaomi/houji/houji:15/AP3A.241005.015.A1/houji.241005.001:user/release-keys"

[templates."xiaomi_23116pn5bc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "23116PN5BC"
device = "shennong"
product = "shennong"
name = "shennong"
marketname = "Xiaomi 14 Pro"
fingerprint = "Xiaomi/shennong/shennong:15/AP3A.241005.015.A1/shennong.241005.001:user/release-keys"

[templates."xiaomi_2311bpn23c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2311BPN23C"
device = "shennong"
product = "shennong"
name = "shennong"
marketname = "Xiaomi 14 Pro 钛金属版"
fingerprint = "Xiaomi/shennong/shennong:15/AP3A.241005.015.A1/shennong.241005.001:user/release-keys"

[templates."xiaomi_24031pn0dc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "24031PN0DC"
device = "aurora"
product = "aurora"
name = "aurora"
marketname = "Xiaomi 14 Ultra"
fingerprint = "Xiaomi/aurora/aurora:15/AP3A.241005.015.A1/aurora.241005.001:user/release-keys"

[templates."xiaomi_24129pn74c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "24129PN74C"
device = "dada"
product = "dada"
name = "dada"
marketname = "Xiaomi 15"
fingerprint = "Xiaomi/dada/dada:15/AP3A.241005.015.A1/dada.241005.001:user/release-keys"

[templates."xiaomi_2410dpn6cc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2410DPN6CC"
device = "haotian"
product = "haotian"
name = "haotian"
marketname = "Xiaomi 15 Pro"
fingerprint = "Xiaomi/haotian/haotian:15/AP3A.241005.015.A1/haotian.241005.001:user/release-keys"

[templates."xiaomi_25019pnf3c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "25019PNF3C"
device = "xuanyuan"
product = "xuanyuan"
name = "xuanyuan"
marketname = "Xiaomi 15 Ultra"
fingerprint = "Xiaomi/xuanyuan/xuanyuan:15/AP3A.241005.015.A1/xuanyuan.241005.001:user/release-keys"

[templates."xiaomi_25010pn30c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "25010PN30C"
device = "xuanyuan"
product = "xuanyuan"
name = "xuanyuan"
marketname = "Xiaomi 15 Ultra 双卫星版"
fingerprint = "Xiaomi/xuanyuan/xuanyuan:15/AP3A.241005.015.A1/xuanyuan.241005.001:user/release-keys"

[templates."xiaomi_25042pn24c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "25042PN24C"
device = "dijun"
product = "dijun"
name = "dijun"
marketname = "Xiaomi 15S Pro"
fingerprint = "Xiaomi/dijun/dijun:15/AP3A.241005.015.A1/dijun.241005.001:user/release-keys"

[templates."xiaomi_25113pn0ec"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "25113PN0EC"
device = "pudding"
product = "pudding"
name = "pudding"
marketname = "Xiaomi 17"
fingerprint = "Xiaomi/pudding/pudding:15/AP3A.241005.015.A1/pudding.241005.001:user/release-keys"

[templates."xiaomi_25098pn5ac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "25098PN5AC"
device = "pandora"
product = "pandora"
name = "pandora"
marketname = "Xiaomi 17 Pro"
fingerprint = "Xiaomi/pandora/pandora:15/AP3A.241005.015.A1/pandora.241005.001:user/release-keys"

[templates."xiaomi_2509fpn0bc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2509FPN0BC"
device = "popsicle"
product = "popsicle"
name = "popsicle"
marketname = "Xiaomi 17 Pro Max"
fingerprint = "Xiaomi/popsicle/popsicle:15/AP3A.241005.015.A1/popsicle.241005.001:user/release-keys"

[templates."xiaomi_2512bpndac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2512BPNDAC"
device = "nezha"
product = "nezha"
name = "nezha"
marketname = "Xiaomi 17 Ultra"
fingerprint = "Xiaomi/nezha/nezha:15/AP3A.241005.015.A1/nezha.241005.001:user/release-keys"

[templates."xiaomi_25128pna1c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "25128PNA1C"
device = "nezha"
product = "nezha"
name = "nezha"
marketname = "Xiaomi 17 Ultra by Leica"
fingerprint = "Xiaomi/nezha/nezha:15/AP3A.241005.015.A1/nezha.241005.001:user/release-keys"

[templates."xiaomi_2605epn8ec"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2605EPN8EC"
device = "byron"
product = "byron"
name = "byron"
marketname = "Xiaomi 17 Max"
fingerprint = "Xiaomi/byron/byron:15/AP3A.241005.015.A1/byron.241005.001:user/release-keys"

[templates."xiaomi_m531da"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M531DA"
device = "chagall"
product = "chagall"
name = "chagall"
marketname = "Xiaomi 17T"
fingerprint = "Xiaomi/chagall/chagall:15/AP3A.241005.015.A1/chagall.241005.001:user/release-keys"

[templates."xiaomi_m025ec"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M025EC"
device = "warhol"
product = "warhol"
name = "warhol"
marketname = "Xiaomi 17T Pro"
fingerprint = "Xiaomi/warhol/warhol:15/AP3A.241005.015.A1/warhol.241005.001:user/release-keys"

[templates."xiaomi_m610bb"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M610BB"
device = "hongkong"
product = "hongkong"
name = "hongkong"
marketname = "Xiaomi 18 Pro"
fingerprint = "Xiaomi/hongkong/hongkong:15/AP3A.241005.015.A1/hongkong.241005.001:user/release-keys"

[templates."xiaomi_m154ff"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M154FF"
device = "madrid"
product = "madrid"
name = "madrid"
marketname = "Xiaomi 18 Pro Max"
fingerprint = "Xiaomi/madrid/madrid:15/AP3A.241005.015.A1/madrid.241005.001:user/release-keys"

[templates."xiaomi_2608bpx34c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2608BPX34C"
device = "lhasa"
product = "lhasa"
name = "lhasa"
marketname = "Xiaomi 18 Fold"
fingerprint = "Xiaomi/lhasa/lhasa:15/AP3A.241005.015.A1/lhasa.241005.001:user/release-keys"

[templates."xiaomi_2014616"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2014616"
device = "virgo"
product = "virgo"
name = "virgo"
marketname = "Xiaomi Note 双网通版"
fingerprint = "Xiaomi/virgo/virgo:15/AP3A.241005.015.A1/virgo.241005.001:user/release-keys"

[templates."xiaomi_2014619"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2014619"
device = "virgo"
product = "virgo"
name = "virgo"
marketname = "Xiaomi Note"
fingerprint = "Xiaomi/virgo/virgo:15/AP3A.241005.015.A1/virgo.241005.001:user/release-keys"

[templates."xiaomi_2015021"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2015021"
device = "leo"
product = "leo"
name = "leo"
marketname = "Xiaomi Note 顶配版 双网通版"
fingerprint = "Xiaomi/leo/leo:15/AP3A.241005.015.A1/leo.241005.001:user/release-keys"

[templates."xiaomi_2015211"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2015211"
device = "scorpio"
product = "scorpio"
name = "scorpio"
marketname = "Xiaomi Note 2"
fingerprint = "Xiaomi/scorpio/scorpio:15/AP3A.241005.015.A1/scorpio.241005.001:user/release-keys"

[templates."xiaomi_mce8"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "MCE8"
device = "jason"
product = "jason"
name = "jason"
marketname = "Xiaomi Note 3"
fingerprint = "Xiaomi/jason/jason:15/AP3A.241005.015.A1/jason.241005.001:user/release-keys"

[templates."xiaomi_2016080"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2016080"
device = "lithium"
product = "lithium"
name = "lithium"
marketname = "Xiaomi MIX"
fingerprint = "Xiaomi/lithium/lithium:15/AP3A.241005.015.A1/lithium.241005.001:user/release-keys"

[templates."xiaomi_mde5"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "MDE5"
device = "chiron"
product = "chiron"
name = "chiron"
marketname = "Xiaomi MIX 2 黑色陶瓷版"
fingerprint = "Xiaomi/chiron/chiron:15/AP3A.241005.015.A1/chiron.241005.001:user/release-keys"

[templates."xiaomi_mde5s"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "MDE5S"
device = "chiron"
product = "chiron"
name = "chiron"
marketname = "Xiaomi MIX 2 全陶瓷"
fingerprint = "Xiaomi/chiron/chiron:15/AP3A.241005.015.A1/chiron.241005.001:user/release-keys"

[templates."xiaomi_m1803d5xe"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1803D5XE"
device = "polaris"
product = "polaris"
name = "polaris"
marketname = "Xiaomi MIX 2S"
fingerprint = "Xiaomi/polaris/polaris:15/AP3A.241005.015.A1/polaris.241005.001:user/release-keys"

[templates."xiaomi_m1810e5e"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1810E5E"
device = "perseus"
product = "perseus"
name = "perseus"
marketname = "Xiaomi MIX 3"
fingerprint = "Xiaomi/perseus/perseus:15/AP3A.241005.015.A1/perseus.241005.001:user/release-keys"

[templates."xiaomi_m1810e5gg"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1810E5GG"
device = "andromeda"
product = "andromeda"
name = "andromeda"
marketname = "Xiaomi MIX 3 5G"
fingerprint = "Xiaomi/andromeda/andromeda:15/AP3A.241005.015.A1/andromeda.241005.001:user/release-keys"

[templates."xiaomi_2106118c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2106118C"
device = "odin"
product = "odin"
name = "odin"
marketname = "Xiaomi MIX 4"
fingerprint = "Xiaomi/odin/odin:15/AP3A.241005.015.A1/odin.241005.001:user/release-keys"

[templates."xiaomi_m2011j18c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M2011J18C"
device = "cetus"
product = "cetus"
name = "cetus"
marketname = "Xiaomi MIX FOLD 小米折叠屏手机"
fingerprint = "Xiaomi/cetus/cetus:15/AP3A.241005.015.A1/cetus.241005.001:user/release-keys"

[templates."xiaomi_22061218c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "22061218C"
device = "zizhan"
product = "zizhan"
name = "zizhan"
marketname = "Xiaomi MIX Fold 2"
fingerprint = "Xiaomi/zizhan/zizhan:15/AP3A.241005.015.A1/zizhan.241005.001:user/release-keys"

[templates."xiaomi_2308cpxd0c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2308CPXD0C"
device = "babylon"
product = "babylon"
name = "babylon"
marketname = "Xiaomi MIX Fold 3"
fingerprint = "Xiaomi/babylon/babylon:15/AP3A.241005.015.A1/babylon.241005.001:user/release-keys"

[templates."xiaomi_24072px77c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "24072PX77C"
device = "goku"
product = "goku"
name = "goku"
marketname = "Xiaomi MIX Fold 4"
fingerprint = "Xiaomi/goku/goku:15/AP3A.241005.015.A1/goku.241005.001:user/release-keys"

[templates."xiaomi_2405cpx3dc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2405CPX3DC"
device = "ruyi"
product = "ruyi"
name = "ruyi"
marketname = "Xiaomi MIX Flip"
fingerprint = "Xiaomi/ruyi/ruyi:15/AP3A.241005.015.A1/ruyi.241005.001:user/release-keys"

[templates."xiaomi_2505apx7bc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2505APX7BC"
device = "bixi"
product = "bixi"
name = "bixi"
marketname = "Xiaomi MIX Flip 2"
fingerprint = "Xiaomi/bixi/bixi:15/AP3A.241005.015.A1/bixi.241005.001:user/release-keys"

[templates."xiaomi_2016001"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2016001"
device = "hydrogen"
product = "hydrogen"
name = "hydrogen"
marketname = "Xiaomi Max"
fingerprint = "Xiaomi/hydrogen/hydrogen:15/AP3A.241005.015.A1/hydrogen.241005.001:user/release-keys"

[templates."xiaomi_mde40"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "MDE40"
device = "oxygen"
product = "oxygen"
name = "oxygen"
marketname = "Xiaomi Max 2"
fingerprint = "Xiaomi/oxygen/oxygen:15/AP3A.241005.015.A1/oxygen.241005.001:user/release-keys"

[templates."xiaomi_m1804e4a"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1804E4A"
device = "nitrogen"
product = "nitrogen"
name = "nitrogen"
marketname = "Xiaomi Max 3"
fingerprint = "Xiaomi/nitrogen/nitrogen:15/AP3A.241005.015.A1/nitrogen.241005.001:user/release-keys"

[templates."xiaomi_m1904f3bc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1904F3BC"
device = "pyxis"
product = "pyxis"
name = "pyxis"
marketname = "Xiaomi CC9"
fingerprint = "Xiaomi/pyxis/pyxis:15/AP3A.241005.015.A1/pyxis.241005.001:user/release-keys"

[templates."xiaomi_m1904f3bt"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1904F3BT"
device = "vela"
product = "vela"
name = "vela"
marketname = "Xiaomi CC9 美图"
fingerprint = "Xiaomi/vela/vela:15/AP3A.241005.015.A1/vela.241005.001:user/release-keys"

[templates."xiaomi_m1906f9sc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1906F9SC"
device = "laurus"
product = "laurus"
name = "laurus"
marketname = "Xiaomi CC9e"
fingerprint = "Xiaomi/laurus/laurus:15/AP3A.241005.015.A1/laurus.241005.001:user/release-keys"

[templates."xiaomi_m1910f4e"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1910F4E"
device = "tucana"
product = "tucana"
name = "tucana"
marketname = "Xiaomi CC9 Pro"
fingerprint = "Xiaomi/tucana/tucana:15/AP3A.241005.015.A1/tucana.241005.001:user/release-keys"

[templates."xiaomi_2109119bc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2109119BC"
device = "zijin"
product = "zijin"
name = "zijin"
marketname = "Xiaomi Civi"
fingerprint = "Xiaomi/zijin/zijin:15/AP3A.241005.015.A1/zijin.241005.001:user/release-keys"

[templates."xiaomi_2209129sc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2209129SC"
device = "ziyi"
product = "ziyi"
name = "ziyi"
marketname = "Xiaomi Civi 2"
fingerprint = "Xiaomi/ziyi/ziyi:15/AP3A.241005.015.A1/ziyi.241005.001:user/release-keys"

[templates."xiaomi_23046pnc9c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "23046PNC9C"
device = "yuechu"
product = "yuechu"
name = "yuechu"
marketname = "Xiaomi Civi 3"
fingerprint = "Xiaomi/yuechu/yuechu:15/AP3A.241005.015.A1/yuechu.241005.001:user/release-keys"

[templates."xiaomi_24053py09c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "24053PY09C"
device = "chenfeng"
product = "chenfeng"
name = "chenfeng"
marketname = "Xiaomi Civi 4 Pro"
fingerprint = "Xiaomi/chenfeng/chenfeng:15/AP3A.241005.015.A1/chenfeng.241005.001:user/release-keys"

[templates."xiaomi_25067pye3c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "25067PYE3C"
device = "luming"
product = "luming"
name = "luming"
marketname = "Xiaomi Civi 5 Pro"
fingerprint = "Xiaomi/luming/luming:15/AP3A.241005.015.A1/luming.241005.001:user/release-keys"

[templates."xiaomi_m1901f9e"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1901F9E"
device = "lotus"
product = "lotus"
name = "lotus"
marketname = "Xiaomi Play"
fingerprint = "Xiaomi/lotus/lotus:15/AP3A.241005.015.A1/lotus.241005.001:user/release-keys"

[templates."xiaomi_a0101"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "A0101"
device = "mocha"
product = "mocha"
name = "mocha"
marketname = "Xiaomi 平板"
fingerprint = "Xiaomi/mocha/mocha:15/AP3A.241005.015.A1/mocha.241005.001:user/release-keys"

[templates."xiaomi_2015716"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2015716"
device = "latte"
product = "latte"
name = "latte"
marketname = "Xiaomi 平板 2"
fingerprint = "Xiaomi/latte/latte:15/AP3A.241005.015.A1/latte.241005.001:user/release-keys"

[templates."xiaomi_mce91"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "MCE91"
device = "cappu"
product = "cappu"
name = "cappu"
marketname = "Xiaomi 平板 3"
fingerprint = "Xiaomi/cappu/cappu:15/AP3A.241005.015.A1/cappu.241005.001:user/release-keys"

[templates."xiaomi_m1806d9w"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1806D9W"
device = "clover"
product = "clover"
name = "clover"
marketname = "Xiaomi 平板 4"
fingerprint = "Xiaomi/clover/clover:15/AP3A.241005.015.A1/clover.241005.001:user/release-keys"

[templates."xiaomi_m1806d9pe"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M1806D9PE"
device = "clover"
product = "clover"
name = "clover"
marketname = "Xiaomi 平板 4 Plus"
fingerprint = "Xiaomi/clover/clover:15/AP3A.241005.015.A1/clover.241005.001:user/release-keys"

[templates."xiaomi_21051182c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "21051182C"
device = "nabu"
product = "nabu"
name = "nabu"
marketname = "Xiaomi 平板 5"
fingerprint = "Xiaomi/nabu/nabu:15/AP3A.241005.015.A1/nabu.241005.001:user/release-keys"

[templates."xiaomi_m2105k81ac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M2105K81AC"
device = "elish"
product = "elish"
name = "elish"
marketname = "Xiaomi 平板 5 Pro"
fingerprint = "Xiaomi/elish/elish:15/AP3A.241005.015.A1/elish.241005.001:user/release-keys"

[templates."xiaomi_m2105k81c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M2105K81C"
device = "enuma"
product = "enuma"
name = "enuma"
marketname = "Xiaomi 平板 5 Pro 5G"
fingerprint = "Xiaomi/enuma/enuma:15/AP3A.241005.015.A1/enuma.241005.001:user/release-keys"

[templates."xiaomi_22081281ac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "22081281AC"
device = "dagu"
product = "dagu"
name = "dagu"
marketname = "Xiaomi 平板 5 Pro 12.4 英寸"
fingerprint = "Xiaomi/dagu/dagu:15/AP3A.241005.015.A1/dagu.241005.001:user/release-keys"

[templates."xiaomi_23043rp34c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "23043RP34C"
device = "pipa"
product = "pipa"
name = "pipa"
marketname = "Xiaomi Pad 6"
fingerprint = "Xiaomi/pipa/pipa:15/AP3A.241005.015.A1/pipa.241005.001:user/release-keys"

[templates."xiaomi_23046rp50c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "23046RP50C"
device = "liuqin"
product = "liuqin"
name = "liuqin"
marketname = "Xiaomi Pad 6 Pro"
fingerprint = "Xiaomi/liuqin/liuqin:15/AP3A.241005.015.A1/liuqin.241005.001:user/release-keys"

[templates."xiaomi_2307brpdcc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2307BRPDCC"
device = "yudi"
product = "yudi"
name = "yudi"
marketname = "Xiaomi Pad 6 Max 14"
fingerprint = "Xiaomi/yudi/yudi:15/AP3A.241005.015.A1/yudi.241005.001:user/release-keys"

[templates."xiaomi_24018rpacc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "24018RPACC"
device = "sheng"
product = "sheng"
name = "sheng"
marketname = "Xiaomi Pad 6S Pro 12.4"
fingerprint = "Xiaomi/sheng/sheng:15/AP3A.241005.015.A1/sheng.241005.001:user/release-keys"

[templates."xiaomi_2410crp4cc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2410CRP4CC"
device = "uke"
product = "uke"
name = "uke"
marketname = "Xiaomi Pad 7"
fingerprint = "Xiaomi/uke/uke:15/AP3A.241005.015.A1/uke.241005.001:user/release-keys"

[templates."xiaomi_24091rpadc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "24091RPADC"
device = "muyu"
product = "muyu"
name = "muyu"
marketname = "Xiaomi Pad 7 Pro"
fingerprint = "Xiaomi/muyu/muyu:15/AP3A.241005.015.A1/muyu.241005.001:user/release-keys"

[templates."xiaomi_25032rp42c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "25032RP42C"
device = "jinghu"
product = "jinghu"
name = "jinghu"
marketname = "Xiaomi Pad 7 Ultra"
fingerprint = "Xiaomi/jinghu/jinghu:15/AP3A.241005.015.A1/jinghu.241005.001:user/release-keys"

[templates."xiaomi_25053rp5cc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "25053RP5CC"
device = "violin"
product = "violin"
name = "violin"
marketname = "Xiaomi Pad 7S Pro 12.5"
fingerprint = "Xiaomi/violin/violin:15/AP3A.241005.015.A1/violin.241005.001:user/release-keys"

[templates."xiaomi_25097rp43c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "25097RP43C"
device = "yupei"
product = "yupei"
name = "yupei"
marketname = "Xiaomi Pad 8"
fingerprint = "Xiaomi/yupei/yupei:15/AP3A.241005.015.A1/yupei.241005.001:user/release-keys"

[templates."xiaomi_25091rp04c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "25091RP04C"
device = "piano"
product = "piano"
name = "piano"
marketname = "Xiaomi Pad 8 Pro"
fingerprint = "Xiaomi/piano/piano:15/AP3A.241005.015.A1/piano.241005.001:user/release-keys"

[templates."xiaomi_m656ba"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M656BA"
device = "yupei"
product = "yupei"
name = "yupei"
marketname = "Xiaomi Pad 9"
fingerprint = "Xiaomi/yupei/yupei:15/AP3A.241005.015.A1/yupei.241005.001:user/release-keys"

[templates."xiaomi_2612crpffc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2612CRPFFC"
device = "shuntian"
product = "shuntian"
name = "shuntian"
marketname = "Xiaomi Pad 9 Pro"
fingerprint = "Xiaomi/shuntian/shuntian:15/AP3A.241005.015.A1/shuntian.241005.001:user/release-keys"

[templates."xiaomi_m367fc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "M367FC"
device = "yingtian"
product = "yingtian"
name = "yingtian"
marketname = "Xiaomi Pad 9 Pro Max"
fingerprint = "Xiaomi/yingtian/yingtian:15/AP3A.241005.015.A1/yingtian.241005.001:user/release-keys"

[templates."redmi_2013022"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2013022"
device = "wt93007"
product = "wt93007"
name = "wt93007"
marketname = "Redmi 手机"
fingerprint = "Xiaomi/wt93007/wt93007:15/AP3A.241005.015.A1/wt93007.241005.001:user/release-keys"

[templates."redmi_2013029"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2013029"
device = "armani"
product = "armani"
name = "armani"
marketname = "Redmi 1S"
fingerprint = "Xiaomi/armani/armani:15/AP3A.241005.015.A1/armani.241005.001:user/release-keys"

[templates."redmi_2014813"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2014813"
device = "wt86047"
product = "wt86047"
name = "wt86047"
marketname = "Redmi 2"
fingerprint = "Xiaomi/wt86047/wt86047:15/AP3A.241005.015.A1/wt86047.241005.001:user/release-keys"

[templates."redmi_2014502"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2014502"
device = "LC"
product = "LC"
name = "LC"
marketname = "Redmi 2A"
fingerprint = "Xiaomi/LC/LC:15/AP3A.241005.015.A1/LC.241005.001:user/release-keys"

[templates."redmi_2014512"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2014512"
device = "LC"
product = "LC"
name = "LC"
marketname = "Redmi 2A 增强版"
fingerprint = "Xiaomi/LC/LC:15/AP3A.241005.015.A1/LC.241005.001:user/release-keys"

[templates."redmi_2015811"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2015811"
device = "ido_xhdpi"
product = "ido_xhdpi"
name = "ido_xhdpi"
marketname = "Redmi 3"
fingerprint = "Xiaomi/ido_xhdpi/ido_xhdpi:15/AP3A.241005.015.A1/ido_xhdpi.241005.001:user/release-keys"

[templates."redmi_2015812"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2015812"
device = "ido_xhdpi"
product = "ido_xhdpi"
name = "ido_xhdpi"
marketname = "Redmi 3 移动合约"
fingerprint = "Xiaomi/ido_xhdpi/ido_xhdpi:15/AP3A.241005.015.A1/ido_xhdpi.241005.001:user/release-keys"

[templates."redmi_2015810"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2015810"
device = "ido_xhdpi"
product = "ido_xhdpi"
name = "ido_xhdpi"
marketname = "Redmi 3 联通合约"
fingerprint = "Xiaomi/ido_xhdpi/ido_xhdpi:15/AP3A.241005.015.A1/ido_xhdpi.241005.001:user/release-keys"

[templates."redmi_2016030"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2016030"
device = "land"
product = "land"
name = "land"
marketname = "Redmi 3S"
fingerprint = "Xiaomi/land/land:15/AP3A.241005.015.A1/land.241005.001:user/release-keys"

[templates."redmi_2016036"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2016036"
device = "land"
product = "land"
name = "land"
marketname = "Redmi 3X"
fingerprint = "Xiaomi/land/land:15/AP3A.241005.015.A1/land.241005.001:user/release-keys"

[templates."redmi_2016090"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2016090"
device = "prada"
product = "prada"
name = "prada"
marketname = "Redmi 4"
fingerprint = "Xiaomi/prada/prada:15/AP3A.241005.015.A1/prada.241005.001:user/release-keys"

[templates."redmi_2016111"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2016111"
device = "rolex"
product = "rolex"
name = "rolex"
marketname = "Redmi 4A"
fingerprint = "Xiaomi/rolex/rolex:15/AP3A.241005.015.A1/rolex.241005.001:user/release-keys"

[templates."redmi_mae136"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "MAE136"
device = "santoni"
product = "santoni"
name = "santoni"
marketname = "Redmi 4X"
fingerprint = "Xiaomi/santoni/santoni:15/AP3A.241005.015.A1/santoni.241005.001:user/release-keys"

[templates."redmi_mde1"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "MDE1"
device = "rosy"
product = "rosy"
name = "rosy"
marketname = "Redmi 5"
fingerprint = "Xiaomi/rosy/rosy:15/AP3A.241005.015.A1/rosy.241005.001:user/release-keys"

[templates."redmi_mee7"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "MEE7"
device = "vince"
product = "vince"
name = "vince"
marketname = "Redmi 5 Plus"
fingerprint = "Xiaomi/vince/vince:15/AP3A.241005.015.A1/vince.241005.001:user/release-keys"

[templates."redmi_mce3b"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "MCE3B"
device = "riva"
product = "riva"
name = "riva"
marketname = "Redmi 5A"
fingerprint = "Xiaomi/riva/riva:15/AP3A.241005.015.A1/riva.241005.001:user/release-keys"

[templates."redmi_m1804c3de"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1804C3DE"
device = "cereus"
product = "cereus"
name = "cereus"
marketname = "Redmi 6"
fingerprint = "Xiaomi/cereus/cereus:15/AP3A.241005.015.A1/cereus.241005.001:user/release-keys"

[templates."redmi_m1805d1se"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1805D1SE"
device = "sakura"
product = "sakura"
name = "sakura"
marketname = "Redmi 6 Pro"
fingerprint = "Xiaomi/sakura/sakura:15/AP3A.241005.015.A1/sakura.241005.001:user/release-keys"

[templates."redmi_m1804c3ce"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1804C3CE"
device = "cactus"
product = "cactus"
name = "cactus"
marketname = "Redmi 6A"
fingerprint = "Xiaomi/cactus/cactus:15/AP3A.241005.015.A1/cactus.241005.001:user/release-keys"

[templates."redmi_m1810f6le"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1810F6LE"
device = "onclite"
product = "onclite"
name = "onclite"
marketname = "Redmi 7"
fingerprint = "Xiaomi/onclite/onclite:15/AP3A.241005.015.A1/onclite.241005.001:user/release-keys"

[templates."redmi_m1810f6lt"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1810F6LT"
device = "onclite"
product = "onclite"
name = "onclite"
marketname = "Redmi 7 运营商"
fingerprint = "Xiaomi/onclite/onclite:15/AP3A.241005.015.A1/onclite.241005.001:user/release-keys"

[templates."redmi_m1903c3ee"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1903C3EE"
device = "pine"
product = "pine"
name = "pine"
marketname = "Redmi 7A"
fingerprint = "Xiaomi/pine/pine:15/AP3A.241005.015.A1/pine.241005.001:user/release-keys"

[templates."redmi_m1908c3ie"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1908C3IE"
device = "olive"
product = "olive"
name = "olive"
marketname = "Redmi 8"
fingerprint = "Xiaomi/olive/olive:15/AP3A.241005.015.A1/olive.241005.001:user/release-keys"

[templates."redmi_m1908c3ic"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1908C3IC"
device = "olive"
product = "olive"
name = "olive"
marketname = "Redmi 8 运营商"
fingerprint = "Xiaomi/olive/olive:15/AP3A.241005.015.A1/olive.241005.001:user/release-keys"

[templates."redmi_m1908c3ke"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1908C3KE"
device = "olivelite"
product = "olivelite"
name = "olivelite"
marketname = "Redmi 8A"
fingerprint = "Xiaomi/olivelite/olivelite:15/AP3A.241005.015.A1/olivelite.241005.001:user/release-keys"

[templates."redmi_m2004j19c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2004J19C"
device = "lancelot"
product = "lancelot"
name = "lancelot"
marketname = "Redmi 9"
fingerprint = "Xiaomi/lancelot/lancelot:15/AP3A.241005.015.A1/lancelot.241005.001:user/release-keys"

[templates."redmi_m2006c3lc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2006C3LC"
device = "dandelion"
product = "dandelion"
name = "dandelion"
marketname = "Redmi 9A"
fingerprint = "Xiaomi/dandelion/dandelion:15/AP3A.241005.015.A1/dandelion.241005.001:user/release-keys"

[templates."redmi_220233l2c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "220233L2C"
device = "dandelion_c3l2"
product = "dandelion_c3l2"
name = "dandelion_c3l2"
marketname = "Redmi 10A"
fingerprint = "Xiaomi/dandelion_c3l2/dandelion_c3l2:15/AP3A.241005.015.A1/dandelion_c3l2.241005.001:user/release-keys"

[templates."redmi_23077rabdc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "23077RABDC"
device = "sky"
product = "sky"
name = "sky"
marketname = "Redmi 12 5G"
fingerprint = "Xiaomi/sky/sky:15/AP3A.241005.015.A1/sky.241005.001:user/release-keys"

[templates."redmi_23076ra4bc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "23076RA4BC"
device = "sky"
product = "sky"
name = "sky"
marketname = "Redmi 12R"
fingerprint = "Xiaomi/sky/sky:15/AP3A.241005.015.A1/sky.241005.001:user/release-keys"

[templates."redmi_22120rn86c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22120RN86C"
device = "earth"
product = "earth"
name = "earth"
marketname = "Redmi 12C"
fingerprint = "Xiaomi/earth/earth:15/AP3A.241005.015.A1/earth.241005.001:user/release-keys"

[templates."redmi_23124rn87c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "23124RN87C"
device = "air"
product = "air"
name = "air"
marketname = "Redmi 13C 5G"
fingerprint = "Xiaomi/air/air:15/AP3A.241005.015.A1/air.241005.001:user/release-keys"

[templates."redmi_2409brn2cc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2409BRN2CC"
device = "lake"
product = "lake"
name = "lake"
marketname = "Redmi 14C"
fingerprint = "Xiaomi/lake/lake:15/AP3A.241005.015.A1/lake.241005.001:user/release-keys"

[templates."redmi_2411drn47c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2411DRN47C"
device = "flame"
product = "flame"
name = "flame"
marketname = "Redmi 14R 5G"
fingerprint = "Xiaomi/flame/flame:15/AP3A.241005.015.A1/flame.241005.001:user/release-keys"

[templates."redmi_25082rnc1c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "25082RNC1C"
device = "tornado"
product = "tornado"
name = "tornado"
marketname = "REDMI 15R 5G"
fingerprint = "Xiaomi/tornado/tornado:15/AP3A.241005.015.A1/tornado.241005.001:user/release-keys"

[templates."redmi_2602brna4c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2602BRNA4C"
device = "somalia"
product = "somalia"
name = "somalia"
marketname = "REDMI 17 5G"
fingerprint = "Xiaomi/somalia/somalia:15/AP3A.241005.015.A1/somalia.241005.001:user/release-keys"

[templates."redmi_2014018"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2014018"
device = "lcsh92_wet_gb9"
product = "lcsh92_wet_gb9"
name = "lcsh92_wet_gb9"
marketname = "Redmi Note 联通 3G"
fingerprint = "Xiaomi/lcsh92_wet_gb9/lcsh92_wet_gb9:15/AP3A.241005.015.A1/lcsh92_wet_gb9.241005.001:user/release-keys"

[templates."redmi_2013121"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2013121"
device = "lcsh92_wet_gb9"
product = "lcsh92_wet_gb9"
name = "lcsh92_wet_gb9"
marketname = "Redmi Note 联通 3G 增强版"
fingerprint = "Xiaomi/lcsh92_wet_gb9/lcsh92_wet_gb9:15/AP3A.241005.015.A1/lcsh92_wet_gb9.241005.001:user/release-keys"

[templates."redmi_2014017"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2014017"
device = "lcsh92_wet_xm_td"
product = "lcsh92_wet_xm_td"
name = "lcsh92_wet_xm_td"
marketname = "Redmi Note 移动 3G"
fingerprint = "Xiaomi/lcsh92_wet_xm_td/lcsh92_wet_xm_td:15/AP3A.241005.015.A1/lcsh92_wet_xm_td.241005.001:user/release-keys"

[templates."redmi_2013122"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2013122"
device = "lcsh92_wet_xm_td"
product = "lcsh92_wet_xm_td"
name = "lcsh92_wet_xm_td"
marketname = "Redmi Note 移动 3G 增强版"
fingerprint = "Xiaomi/lcsh92_wet_xm_td/lcsh92_wet_xm_td:15/AP3A.241005.015.A1/lcsh92_wet_xm_td.241005.001:user/release-keys"

[templates."redmi_2014022"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2014022"
device = "dior"
product = "dior"
name = "dior"
marketname = "Redmi Note 移动 4G 增强版"
fingerprint = "Xiaomi/dior/dior:15/AP3A.241005.015.A1/dior.241005.001:user/release-keys"

[templates."redmi_2014021"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2014021"
device = "dior"
product = "dior"
name = "dior"
marketname = "Redmi Note 联通 4G 增强版"
fingerprint = "Xiaomi/dior/dior:15/AP3A.241005.015.A1/dior.241005.001:user/release-keys"

[templates."redmi_2014915"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2014915"
device = "gucci"
product = "gucci"
name = "gucci"
marketname = "Redmi Note"
fingerprint = "Xiaomi/gucci/gucci:15/AP3A.241005.015.A1/gucci.241005.001:user/release-keys"

[templates."redmi_2014911"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2014911"
device = "gucci"
product = "gucci"
name = "gucci"
marketname = "Redmi Note 移动 4G 双卡"
fingerprint = "Xiaomi/gucci/gucci:15/AP3A.241005.015.A1/gucci.241005.001:user/release-keys"

[templates."redmi_2014910"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2014910"
device = "gucci"
product = "gucci"
name = "gucci"
marketname = "Redmi Note 电信 4G 双卡"
fingerprint = "Xiaomi/gucci/gucci:15/AP3A.241005.015.A1/gucci.241005.001:user/release-keys"

[templates."redmi_2015052"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2015052"
device = "hermes"
product = "hermes"
name = "hermes"
marketname = "Redmi Note 2"
fingerprint = "Xiaomi/hermes/hermes:15/AP3A.241005.015.A1/hermes.241005.001:user/release-keys"

[templates."redmi_2015051"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2015051"
device = "hermes"
product = "hermes"
name = "hermes"
marketname = "Redmi Note 2 双网通版"
fingerprint = "Xiaomi/hermes/hermes:15/AP3A.241005.015.A1/hermes.241005.001:user/release-keys"

[templates."redmi_2015712"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2015712"
device = "hermes"
product = "hermes"
name = "hermes"
marketname = "Redmi Note 2 双网通"
fingerprint = "Xiaomi/hermes/hermes:15/AP3A.241005.015.A1/hermes.241005.001:user/release-keys"

[templates."redmi_2015056"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2015056"
device = "hermes"
product = "hermes"
name = "hermes"
marketname = "Redmi Note 2 移动合约"
fingerprint = "Xiaomi/hermes/hermes:15/AP3A.241005.015.A1/hermes.241005.001:user/release-keys"

[templates."redmi_2015617"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2015617"
device = "hennessy"
product = "hennessy"
name = "hennessy"
marketname = "Redmi Note 3 双网通版"
fingerprint = "Xiaomi/hennessy/hennessy:15/AP3A.241005.015.A1/hennessy.241005.001:user/release-keys"

[templates."redmi_2015611"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2015611"
device = "hennessy"
product = "hennessy"
name = "hennessy"
marketname = "Redmi Note 3"
fingerprint = "Xiaomi/hennessy/hennessy:15/AP3A.241005.015.A1/hennessy.241005.001:user/release-keys"

[templates."redmi_2016050"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2016050"
device = "nikel"
product = "nikel"
name = "nikel"
marketname = "Redmi Note 4"
fingerprint = "Xiaomi/nikel/nikel:15/AP3A.241005.015.A1/nikel.241005.001:user/release-keys"

[templates."redmi_2016101"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2016101"
device = "mido"
product = "mido"
name = "mido"
marketname = "Redmi Note 4X 高通"
fingerprint = "Xiaomi/mido/mido:15/AP3A.241005.015.A1/mido.241005.001:user/release-keys"

[templates."redmi_mbe6a5"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "MBE6A5"
device = "nikel"
product = "nikel"
name = "nikel"
marketname = "Redmi Note 4X MTK"
fingerprint = "Xiaomi/nikel/nikel:15/AP3A.241005.015.A1/nikel.241005.001:user/release-keys"

[templates."redmi_mee7s"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "MEE7S"
device = "whyred"
product = "whyred"
name = "whyred"
marketname = "Redmi Note 5"
fingerprint = "Xiaomi/whyred/whyred:15/AP3A.241005.015.A1/whyred.241005.001:user/release-keys"

[templates."redmi_mde6"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "MDE6"
device = "ugglite"
product = "ugglite"
name = "ugglite"
marketname = "Redmi Note 5A"
fingerprint = "Xiaomi/ugglite/ugglite:15/AP3A.241005.015.A1/ugglite.241005.001:user/release-keys"

[templates."redmi_mdt6"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "MDT6"
device = "ugglite"
product = "ugglite"
name = "ugglite"
marketname = "Redmi Note 5A 移动 4G+"
fingerprint = "Xiaomi/ugglite/ugglite:15/AP3A.241005.015.A1/ugglite.241005.001:user/release-keys"

[templates."redmi_m1901f7e"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1901F7E"
device = "lavender"
product = "lavender"
name = "lavender"
marketname = "Redmi Note 7"
fingerprint = "Xiaomi/lavender/lavender:15/AP3A.241005.015.A1/lavender.241005.001:user/release-keys"

[templates."redmi_m1901f7be"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1901F7BE"
device = "violet"
product = "violet"
name = "violet"
marketname = "Redmi Note 7 Pro"
fingerprint = "Xiaomi/violet/violet:15/AP3A.241005.015.A1/violet.241005.001:user/release-keys"

[templates."redmi_m1908c3je"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1908C3JE"
device = "ginkgo"
product = "ginkgo"
name = "ginkgo"
marketname = "Redmi Note 8"
fingerprint = "Xiaomi/ginkgo/ginkgo:15/AP3A.241005.015.A1/ginkgo.241005.001:user/release-keys"

[templates."redmi_m1908c3jc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1908C3JC"
device = "ginkgo"
product = "ginkgo"
name = "ginkgo"
marketname = "Redmi Note 8 运营商"
fingerprint = "Xiaomi/ginkgo/ginkgo:15/AP3A.241005.015.A1/ginkgo.241005.001:user/release-keys"

[templates."redmi_m1906g7e"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1906G7E"
device = "begonia"
product = "begonia"
name = "begonia"
marketname = "Redmi Note 8 Pro"
fingerprint = "Xiaomi/begonia/begonia:15/AP3A.241005.015.A1/begonia.241005.001:user/release-keys"

[templates."redmi_m1906g7t"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1906G7T"
device = "begonia"
product = "begonia"
name = "begonia"
marketname = "Redmi Note 8 Pro 运营商"
fingerprint = "Xiaomi/begonia/begonia:15/AP3A.241005.015.A1/begonia.241005.001:user/release-keys"

[templates."redmi_m2010j19sc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2010J19SC"
device = "lime"
product = "lime"
name = "lime"
marketname = "Redmi Note 9 4G"
fingerprint = "Xiaomi/lime/lime:15/AP3A.241005.015.A1/lime.241005.001:user/release-keys"

[templates."redmi_m2007j22c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2007J22C"
device = "cannon"
product = "cannon"
name = "cannon"
marketname = "Redmi Note 9 5G"
fingerprint = "Xiaomi/cannon/cannon:15/AP3A.241005.015.A1/cannon.241005.001:user/release-keys"

[templates."redmi_m2007j17c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2007J17C"
device = "gauguin"
product = "gauguin"
name = "gauguin"
marketname = "Redmi Note 9 Pro 5G"
fingerprint = "Xiaomi/gauguin/gauguin:15/AP3A.241005.015.A1/gauguin.241005.001:user/release-keys"

[templates."redmi_m2103k19c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2103K19C"
device = "camellia"
product = "camellia"
name = "camellia"
marketname = "Redmi Note 10 5G"
fingerprint = "Xiaomi/camellia/camellia:15/AP3A.241005.015.A1/camellia.241005.001:user/release-keys"

[templates."redmi_m2104k10ac"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2104K10AC"
device = "chopin"
product = "chopin"
name = "chopin"
marketname = "Redmi Note 10 Pro"
fingerprint = "Xiaomi/chopin/chopin:15/AP3A.241005.015.A1/chopin.241005.001:user/release-keys"

[templates."redmi_21121119sc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "21121119SC"
device = "selene"
product = "selene"
name = "selene"
marketname = "Redmi Note 11 4G"
fingerprint = "Xiaomi/selene/selene:15/AP3A.241005.015.A1/selene.241005.001:user/release-keys"

[templates."redmi_21091116ac"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "21091116AC"
device = "evergo"
product = "evergo"
name = "evergo"
marketname = "Redmi Note 11 5G"
fingerprint = "Xiaomi/evergo/evergo:15/AP3A.241005.015.A1/evergo.241005.001:user/release-keys"

[templates."redmi_22041219c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22041219C"
device = "light"
product = "light"
name = "light"
marketname = "Redmi Note 11E 5G"
fingerprint = "Xiaomi/light/light:15/AP3A.241005.015.A1/light.241005.001:user/release-keys"

[templates."redmi_21091116c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "21091116C"
device = "pissarro"
product = "pissarro"
name = "pissarro"
marketname = "Redmi Note 11 Pro"
fingerprint = "Xiaomi/pissarro/pissarro:15/AP3A.241005.015.A1/pissarro.241005.001:user/release-keys"

[templates."redmi_2201116sc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2201116SC"
device = "veux"
product = "veux"
name = "veux"
marketname = "Redmi Note 11E Pro"
fingerprint = "Xiaomi/veux/veux:15/AP3A.241005.015.A1/veux.241005.001:user/release-keys"

[templates."redmi_21091116uc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "21091116UC"
device = "pissarro"
product = "pissarro"
name = "pissarro"
marketname = "Redmi Note 11 Pro+"
fingerprint = "Xiaomi/pissarro/pissarro:15/AP3A.241005.015.A1/pissarro.241005.001:user/release-keys"

[templates."redmi_22041216c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22041216C"
device = "xaga"
product = "xaga"
name = "xaga"
marketname = "Redmi Note 11T Pro"
fingerprint = "Xiaomi/xaga/xaga:15/AP3A.241005.015.A1/xaga.241005.001:user/release-keys"

[templates."redmi_22041216uc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22041216UC"
device = "xaga"
product = "xaga"
name = "xaga"
marketname = "Redmi Note 11T Pro+"
fingerprint = "Xiaomi/xaga/xaga:15/AP3A.241005.015.A1/xaga.241005.001:user/release-keys"

[templates."redmi_22095ra98c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22095RA98C"
device = "lightcm"
product = "lightcm"
name = "lightcm"
marketname = "Redmi Note 11R 5G"
fingerprint = "Xiaomi/lightcm/lightcm:15/AP3A.241005.015.A1/lightcm.241005.001:user/release-keys"

[templates."redmi_22101317c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22101317C"
device = "sunstone"
product = "sunstone"
name = "sunstone"
marketname = "Redmi Note 12 5G"
fingerprint = "Xiaomi/sunstone/sunstone:15/AP3A.241005.015.A1/sunstone.241005.001:user/release-keys"

[templates."redmi_22101316c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22101316C"
device = "ruby"
product = "ruby"
name = "ruby"
marketname = "Redmi Note 12 Pro"
fingerprint = "Xiaomi/ruby/ruby:15/AP3A.241005.015.A1/ruby.241005.001:user/release-keys"

[templates."redmi_22101316ucp"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22101316UCP"
device = "ruby"
product = "ruby"
name = "ruby"
marketname = "Redmi Note 12 Pro+"
fingerprint = "Xiaomi/ruby/ruby:15/AP3A.241005.015.A1/ruby.241005.001:user/release-keys"

[templates."redmi_22101316uc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22101316UC"
device = "ruby"
product = "ruby"
name = "ruby"
marketname = "Redmi Note 12 探索版"
fingerprint = "Xiaomi/ruby/ruby:15/AP3A.241005.015.A1/ruby.241005.001:user/release-keys"

[templates."redmi_22101320c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22101320C"
device = "redwood"
product = "redwood"
name = "redwood"
marketname = "Redmi Note 12 Pro 极速版"
fingerprint = "Xiaomi/redwood/redwood:15/AP3A.241005.015.A1/redwood.241005.001:user/release-keys"

[templates."redmi_23054ra19c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "23054RA19C"
device = "pearl"
product = "pearl"
name = "pearl"
marketname = "Redmi Note 12T Pro"
fingerprint = "Xiaomi/pearl/pearl:15/AP3A.241005.015.A1/pearl.241005.001:user/release-keys"

[templates."redmi_23049rad8c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "23049RAD8C"
device = "marble"
product = "marble"
name = "marble"
marketname = "Redmi Note 12 Turbo"
fingerprint = "Xiaomi/marble/marble:15/AP3A.241005.015.A1/marble.241005.001:user/release-keys"

[templates."redmi_2312draabc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2312DRAABC"
device = "gold"
product = "gold"
name = "gold"
marketname = "Redmi Note 13 5G"
fingerprint = "Xiaomi/gold/gold:15/AP3A.241005.015.A1/gold.241005.001:user/release-keys"

[templates."redmi_2312dra50c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2312DRA50C"
device = "garnet"
product = "garnet"
name = "garnet"
marketname = "Redmi Note 13 Pro"
fingerprint = "Xiaomi/garnet/garnet:15/AP3A.241005.015.A1/garnet.241005.001:user/release-keys"

[templates."redmi_23090ra98c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "23090RA98C"
device = "zircon"
product = "zircon"
name = "zircon"
marketname = "Redmi Note 13 Pro+"
fingerprint = "Xiaomi/zircon/zircon:15/AP3A.241005.015.A1/zircon.241005.001:user/release-keys"

[templates."redmi_2406ern9cc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2406ERN9CC"
device = "breeze"
product = "breeze"
name = "breeze"
marketname = "Redmi Note 13R"
fingerprint = "Xiaomi/breeze/breeze:15/AP3A.241005.015.A1/breeze.241005.001:user/release-keys"

[templates."redmi_2311frafdc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2311FRAFDC"
device = "gold"
product = "gold"
name = "gold"
marketname = "Redmi Note 13R Pro"
fingerprint = "Xiaomi/gold/gold:15/AP3A.241005.015.A1/gold.241005.001:user/release-keys"

[templates."redmi_24094rad4c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "24094RAD4C"
device = "beryl"
product = "beryl"
name = "beryl"
marketname = "Redmi Note 14 5G"
fingerprint = "Xiaomi/beryl/beryl:15/AP3A.241005.015.A1/beryl.241005.001:user/release-keys"

[templates."redmi_24090ra29c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "24090RA29C"
device = "malachite"
product = "malachite"
name = "malachite"
marketname = "Redmi Note 14 Pro"
fingerprint = "Xiaomi/malachite/malachite:15/AP3A.241005.015.A1/malachite.241005.001:user/release-keys"

[templates."redmi_24115ra8ec"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "24115RA8EC"
device = "amethyst"
product = "amethyst"
name = "amethyst"
marketname = "Redmi Note 14 Pro+"
fingerprint = "Xiaomi/amethyst/amethyst:15/AP3A.241005.015.A1/amethyst.241005.001:user/release-keys"

[templates."redmi_25098ra98c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "25098RA98C"
device = "kunzite"
product = "kunzite"
name = "kunzite"
marketname = "REDMI Note 15"
fingerprint = "Xiaomi/kunzite/kunzite:15/AP3A.241005.015.A1/kunzite.241005.001:user/release-keys"

[templates."redmi_25080rabdc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "25080RABDC"
device = "lapis"
product = "lapis"
name = "lapis"
marketname = "REDMI Note 15 Pro"
fingerprint = "Xiaomi/lapis/lapis:15/AP3A.241005.015.A1/lapis.241005.001:user/release-keys"

[templates."redmi_2510era8bc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2510ERA8BC"
device = "flourite"
product = "flourite"
name = "flourite"
marketname = "REDMI Note 15 Pro+"
fingerprint = "Xiaomi/flourite/flourite:15/AP3A.241005.015.A1/flourite.241005.001:user/release-keys"

[templates."redmi_25104radac"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "25104RADAC"
device = "flourite"
product = "flourite"
name = "flourite"
marketname = "REDMI Note 15 Pro+ 卫星消息版"
fingerprint = "Xiaomi/flourite/flourite:15/AP3A.241005.015.A1/flourite.241005.001:user/release-keys"

[templates."redmi_25057ra09c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "25057RA09C"
device = "spring"
product = "spring"
name = "spring"
marketname = "REDMI Note 15R"
fingerprint = "Xiaomi/spring/spring:15/AP3A.241005.015.A1/spring.241005.001:user/release-keys"

[templates."redmi_26021rn18c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "26021RN18C"
device = "mist"
product = "mist"
name = "mist"
marketname = "REDMI Note 17"
fingerprint = "Xiaomi/mist/mist:15/AP3A.241005.015.A1/mist.241005.001:user/release-keys"

[templates."redmi_2607dra18c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2607DRA18C"
device = "iolite"
product = "iolite"
name = "iolite"
marketname = "REDMI Note 17 Pro"
fingerprint = "Xiaomi/iolite/iolite:15/AP3A.241005.015.A1/iolite.241005.001:user/release-keys"

[templates."redmi_m2004j7ac"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2004J7AC"
device = "atom"
product = "atom"
name = "atom"
marketname = "Redmi 10X 5G"
fingerprint = "Xiaomi/atom/atom:15/AP3A.241005.015.A1/atom.241005.001:user/release-keys"

[templates."redmi_m2004j7bc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2004J7BC"
device = "bomb"
product = "bomb"
name = "bomb"
marketname = "Redmi 10X Pro 5G"
fingerprint = "Xiaomi/bomb/bomb:15/AP3A.241005.015.A1/bomb.241005.001:user/release-keys"

[templates."redmi_m2003j15sc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2003J15SC"
device = "merlin"
product = "merlin"
name = "merlin"
marketname = "Redmi 10X 4G"
fingerprint = "Xiaomi/merlin/merlin:15/AP3A.241005.015.A1/merlin.241005.001:user/release-keys"

[templates."redmi_24069ra21c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "24069RA21C"
device = "peridot"
product = "peridot"
name = "peridot"
marketname = "Redmi Turbo 3"
fingerprint = "Xiaomi/peridot/peridot:15/AP3A.241005.015.A1/peridot.241005.001:user/release-keys"

[templates."redmi_24129rt7cc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "24129RT7CC"
device = "rodin"
product = "rodin"
name = "rodin"
marketname = "REDMI Turbo 4"
fingerprint = "Xiaomi/rodin/rodin:15/AP3A.241005.015.A1/rodin.241005.001:user/release-keys"

[templates."redmi_25053rt47c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "25053RT47C"
device = "onyx"
product = "onyx"
name = "onyx"
marketname = "REDMI Turbo 4 Pro"
fingerprint = "Xiaomi/onyx/onyx:15/AP3A.241005.015.A1/onyx.241005.001:user/release-keys"

[templates."redmi_2511frt34c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2511FRT34C"
device = "klee"
product = "klee"
name = "klee"
marketname = "REDMI Turbo 5"
fingerprint = "Xiaomi/klee/klee:15/AP3A.241005.015.A1/klee.241005.001:user/release-keys"

[templates."redmi_2602brt18c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2602BRT18C"
device = "dash"
product = "dash"
name = "dash"
marketname = "REDMI Turbo 5 Max"
fingerprint = "Xiaomi/dash/dash:15/AP3A.241005.015.A1/dash.241005.001:user/release-keys"

[templates."redmi_m1903f10a"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1903F10A"
device = "davinci"
product = "davinci"
name = "davinci"
marketname = "Redmi K20"
fingerprint = "Xiaomi/davinci/davinci:15/AP3A.241005.015.A1/davinci.241005.001:user/release-keys"

[templates."redmi_m1903f10c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1903F10C"
device = "davinci"
product = "davinci"
name = "davinci"
marketname = "Redmi K20 运营商"
fingerprint = "Xiaomi/davinci/davinci:15/AP3A.241005.015.A1/davinci.241005.001:user/release-keys"

[templates."redmi_m1903f11a"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1903F11A"
device = "raphael"
product = "raphael"
name = "raphael"
marketname = "Redmi K20 Pro"
fingerprint = "Xiaomi/raphael/raphael:15/AP3A.241005.015.A1/raphael.241005.001:user/release-keys"

[templates."redmi_m1903f11c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1903F11C"
device = "raphael"
product = "raphael"
name = "raphael"
marketname = "Redmi K20 Pro 运营商"
fingerprint = "Xiaomi/raphael/raphael:15/AP3A.241005.015.A1/raphael.241005.001:user/release-keys"

[templates."redmi_m2001g7ae"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2001G7AE"
device = "picasso"
product = "picasso"
name = "picasso"
marketname = "Redmi K30 5G"
fingerprint = "Xiaomi/picasso/picasso:15/AP3A.241005.015.A1/picasso.241005.001:user/release-keys"

[templates."redmi_m1912g7be"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1912G7BE"
device = "phoenix"
product = "phoenix"
name = "phoenix"
marketname = "Redmi K30 4G"
fingerprint = "Xiaomi/phoenix/phoenix:15/AP3A.241005.015.A1/phoenix.241005.001:user/release-keys"

[templates."redmi_m1912g7bc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1912G7BC"
device = "phoenix"
product = "phoenix"
name = "phoenix"
marketname = "Redmi K30 4G 运营商"
fingerprint = "Xiaomi/phoenix/phoenix:15/AP3A.241005.015.A1/phoenix.241005.001:user/release-keys"

[templates."redmi_m2001j11c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2001J11C"
device = "lmi"
product = "lmi"
name = "lmi"
marketname = "Redmi K30 Pro"
fingerprint = "Xiaomi/lmi/lmi:15/AP3A.241005.015.A1/lmi.241005.001:user/release-keys"

[templates."redmi_m2006j10c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2006J10C"
device = "cezanne"
product = "cezanne"
name = "cezanne"
marketname = "Redmi K30 至尊纪念版"
fingerprint = "Xiaomi/cezanne/cezanne:15/AP3A.241005.015.A1/cezanne.241005.001:user/release-keys"

[templates."redmi_m2007j3sc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2007J3SC"
device = "apollo"
product = "apollo"
name = "apollo"
marketname = "Redmi K30S 至尊纪念版"
fingerprint = "Xiaomi/apollo/apollo:15/AP3A.241005.015.A1/apollo.241005.001:user/release-keys"

[templates."redmi_m2012k11ac"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2012K11AC"
device = "alioth"
product = "alioth"
name = "alioth"
marketname = "Redmi K40"
fingerprint = "Xiaomi/alioth/alioth:15/AP3A.241005.015.A1/alioth.241005.001:user/release-keys"

[templates."redmi_m2012k11c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2012K11C"
device = "haydn"
product = "haydn"
name = "haydn"
marketname = "Redmi K40 Pro"
fingerprint = "Xiaomi/haydn/haydn:15/AP3A.241005.015.A1/haydn.241005.001:user/release-keys"

[templates."redmi_m2012k10c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M2012K10C"
device = "ares"
product = "ares"
name = "ares"
marketname = "Redmi K40 游戏增强版"
fingerprint = "Xiaomi/ares/ares:15/AP3A.241005.015.A1/ares.241005.001:user/release-keys"

[templates."redmi_22021211rc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22021211RC"
device = "munch"
product = "munch"
name = "munch"
marketname = "Redmi K40S"
fingerprint = "Xiaomi/munch/munch:15/AP3A.241005.015.A1/munch.241005.001:user/release-keys"

[templates."redmi_22041211ac"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22041211AC"
device = "rubens"
product = "rubens"
name = "rubens"
marketname = "Redmi K50"
fingerprint = "Xiaomi/rubens/rubens:15/AP3A.241005.015.A1/rubens.241005.001:user/release-keys"

[templates."redmi_22011211c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22011211C"
device = "matisse"
product = "matisse"
name = "matisse"
marketname = "Redmi K50 Pro"
fingerprint = "Xiaomi/matisse/matisse:15/AP3A.241005.015.A1/matisse.241005.001:user/release-keys"

[templates."redmi_21121210c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "21121210C"
device = "ingres"
product = "ingres"
name = "ingres"
marketname = "Redmi K50 电竞版"
fingerprint = "Xiaomi/ingres/ingres:15/AP3A.241005.015.A1/ingres.241005.001:user/release-keys"

[templates."redmi_22081212c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22081212C"
device = "diting"
product = "diting"
name = "diting"
marketname = "Redmi K50 至尊版"
fingerprint = "Xiaomi/diting/diting:15/AP3A.241005.015.A1/diting.241005.001:user/release-keys"

[templates."redmi_23013rk75c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "23013RK75C"
device = "mondrian"
product = "mondrian"
name = "mondrian"
marketname = "Redmi K60"
fingerprint = "Xiaomi/mondrian/mondrian:15/AP3A.241005.015.A1/mondrian.241005.001:user/release-keys"

[templates."redmi_22127rk46c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22127RK46C"
device = "socrates"
product = "socrates"
name = "socrates"
marketname = "Redmi K60 Pro"
fingerprint = "Xiaomi/socrates/socrates:15/AP3A.241005.015.A1/socrates.241005.001:user/release-keys"

[templates."redmi_22122rk93c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22122RK93C"
device = "rembrandt"
product = "rembrandt"
name = "rembrandt"
marketname = "Redmi K60E"
fingerprint = "Xiaomi/rembrandt/rembrandt:15/AP3A.241005.015.A1/rembrandt.241005.001:user/release-keys"

[templates."redmi_23078rkd5c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "23078RKD5C"
device = "corot"
product = "corot"
name = "corot"
marketname = "Redmi K60 至尊版"
fingerprint = "Xiaomi/corot/corot:15/AP3A.241005.015.A1/corot.241005.001:user/release-keys"

[templates."redmi_23113rkc6c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "23113RKC6C"
device = "vermeer"
product = "vermeer"
name = "vermeer"
marketname = "Redmi K70"
fingerprint = "Xiaomi/vermeer/vermeer:15/AP3A.241005.015.A1/vermeer.241005.001:user/release-keys"

[templates."redmi_23117rk66c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "23117RK66C"
device = "manet"
product = "manet"
name = "manet"
marketname = "Redmi K70 Pro"
fingerprint = "Xiaomi/manet/manet:15/AP3A.241005.015.A1/manet.241005.001:user/release-keys"

[templates."redmi_2311drk48c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2311DRK48C"
device = "duchamp"
product = "duchamp"
name = "duchamp"
marketname = "Redmi K70E"
fingerprint = "Xiaomi/duchamp/duchamp:15/AP3A.241005.015.A1/duchamp.241005.001:user/release-keys"

[templates."redmi_2407frk8ec"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2407FRK8EC"
device = "rothko"
product = "rothko"
name = "rothko"
marketname = "Redmi K70 至尊版"
fingerprint = "Xiaomi/rothko/rothko:15/AP3A.241005.015.A1/rothko.241005.001:user/release-keys"

[templates."redmi_24117rk2cc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "24117RK2CC"
device = "zorn"
product = "zorn"
name = "zorn"
marketname = "REDMI K80"
fingerprint = "Xiaomi/zorn/zorn:15/AP3A.241005.015.A1/zorn.241005.001:user/release-keys"

[templates."redmi_24122rkc7c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "24122RKC7C"
device = "miro"
product = "miro"
name = "miro"
marketname = "REDMI K80 Pro"
fingerprint = "Xiaomi/miro/miro:15/AP3A.241005.015.A1/miro.241005.001:user/release-keys"

[templates."redmi_24127rk2cc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "24127RK2CC"
device = "miro"
product = "miro"
name = "miro"
marketname = "REDMI K80 Pro 冠军版"
fingerprint = "Xiaomi/miro/miro:15/AP3A.241005.015.A1/miro.241005.001:user/release-keys"

[templates."redmi_25060rk16c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "25060RK16C"
device = "dali"
product = "dali"
name = "dali"
marketname = "REDMI K80 至尊版"
fingerprint = "Xiaomi/dali/dali:15/AP3A.241005.015.A1/dali.241005.001:user/release-keys"

[templates."redmi_2510drk44c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2510DRK44C"
device = "annibale"
product = "annibale"
name = "annibale"
marketname = "REDMI K90"
fingerprint = "Xiaomi/annibale/annibale:15/AP3A.241005.015.A1/annibale.241005.001:user/release-keys"

[templates."redmi_25102rkbec"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "25102RKBEC"
device = "myron"
product = "myron"
name = "myron"
marketname = "REDMI K90 Pro Max"
fingerprint = "Xiaomi/myron/myron:15/AP3A.241005.015.A1/myron.241005.001:user/release-keys"

[templates."redmi_25102rk69c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "25102RK69C"
device = "myron"
product = "myron"
name = "myron"
marketname = "REDMI K90 Pro Max 冠军版"
fingerprint = "Xiaomi/myron/myron:15/AP3A.241005.015.A1/myron.241005.001:user/release-keys"

[templates."redmi_2604frk1ec"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2604FRK1EC"
device = "prague"
product = "prague"
name = "prague"
marketname = "REDMI K90 Max"
fingerprint = "Xiaomi/prague/prague:15/AP3A.241005.015.A1/prague.241005.001:user/release-keys"

[templates."redmi_m332bf"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M332BF"
device = "warsaw"
product = "warsaw"
name = "warsaw"
marketname = "REDMI K90 至尊版"
fingerprint = "Xiaomi/warsaw/warsaw:15/AP3A.241005.015.A1/warsaw.241005.001:user/release-keys"

[templates."redmi_m786bc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M786BC"
device = "warsaw"
product = "warsaw"
name = "warsaw"
marketname = "REDMI K100"
fingerprint = "Xiaomi/warsaw/warsaw:15/AP3A.241005.015.A1/warsaw.241005.001:user/release-keys"

[templates."redmi_m511cd"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M511CD"
device = "athens"
product = "athens"
name = "athens"
marketname = "REDMI K100 Pro"
fingerprint = "Xiaomi/athens/athens:15/AP3A.241005.015.A1/athens.241005.001:user/release-keys"

[templates."redmi_m098fe"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M098FE"
device = "songyuan"
product = "songyuan"
name = "songyuan"
marketname = "REDMI K100 Pro Max"
fingerprint = "Xiaomi/songyuan/songyuan:15/AP3A.241005.015.A1/songyuan.241005.001:user/release-keys"

[templates."redmi_2016020"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2016020"
device = "omega"
product = "omega"
name = "omega"
marketname = "Redmi Pro"
fingerprint = "Xiaomi/omega/omega:15/AP3A.241005.015.A1/omega.241005.001:user/release-keys"

[templates."redmi_m1803e6e"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "M1803E6E"
device = "ysl"
product = "ysl"
name = "ysl"
marketname = "Redmi S2"
fingerprint = "Xiaomi/ysl/ysl:15/AP3A.241005.015.A1/ysl.241005.001:user/release-keys"

[templates."redmi_26020rn1ac"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "26020RN1AC"
device = "somalia"
product = "somalia"
name = "somalia"
marketname = "REDMI R70 5G"
fingerprint = "Xiaomi/somalia/somalia:15/AP3A.241005.015.A1/somalia.241005.001:user/release-keys"

[templates."redmi_26062rn92c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "26062RN92C"
device = "steppe"
product = "steppe"
name = "steppe"
marketname = "REDMI M100"
fingerprint = "Xiaomi/steppe/steppe:15/AP3A.241005.015.A1/steppe.241005.001:user/release-keys"

[templates."redmi_22081283c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "22081283C"
device = "yunluo"
product = "yunluo"
name = "yunluo"
marketname = "Redmi Pad"
fingerprint = "Xiaomi/yunluo/yunluo:15/AP3A.241005.015.A1/yunluo.241005.001:user/release-keys"

[templates."redmi_23073rpbfc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "23073RPBFC"
device = "xun"
product = "xun"
name = "xun"
marketname = "Redmi Pad SE"
fingerprint = "Xiaomi/xun/xun:15/AP3A.241005.015.A1/xun.241005.001:user/release-keys"

[templates."redmi_2405crpfdc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2405CRPFDC"
device = "dizi"
product = "dizi"
name = "dizi"
marketname = "Redmi Pad Pro"
fingerprint = "Xiaomi/dizi/dizi:15/AP3A.241005.015.A1/dizi.241005.001:user/release-keys"

[templates."redmi_24074rpd2c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "24074RPD2C"
device = "ruan"
product = "ruan"
name = "ruan"
marketname = "Redmi Pad Pro 5G"
fingerprint = "Xiaomi/ruan/ruan:15/AP3A.241005.015.A1/ruan.241005.001:user/release-keys"

[templates."redmi_25040rp0ac"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "25040RP0AC"
device = "taiko"
product = "taiko"
name = "taiko"
marketname = "REDMI Pad 2"
fingerprint = "Xiaomi/taiko/taiko:15/AP3A.241005.015.A1/taiko.241005.001:user/release-keys"

[templates."redmi_25099rp13c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "25099RP13C"
device = "flute"
product = "flute"
name = "flute"
marketname = "REDMI Pad 2 Pro"
fingerprint = "Xiaomi/flute/flute:15/AP3A.241005.015.A1/flute.241005.001:user/release-keys"

[templates."redmi_2509brp2dc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2509BRP2DC"
device = "organ"
product = "organ"
name = "organ"
marketname = "REDMI Pad 2 Pro 5G"
fingerprint = "Xiaomi/organ/organ:15/AP3A.241005.015.A1/organ.241005.001:user/release-keys"

[templates."redmi_2603arp14c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2603ARP14C"
device = "guitar"
product = "guitar"
name = "guitar"
marketname = "REDMI Pad 2 SE"
fingerprint = "Xiaomi/guitar/guitar:15/AP3A.241005.015.A1/guitar.241005.001:user/release-keys"

[templates."redmi_2604erp4dc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "2604ERP4DC"
device = "erhu"
product = "erhu"
name = "erhu"
marketname = "REDMI Pad 2 SE 4G"
fingerprint = "Xiaomi/erhu/erhu:15/AP3A.241005.015.A1/erhu.241005.001:user/release-keys"

[templates."redmi_25079rpdcc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "25079RPDCC"
device = "turner"
product = "turner"
name = "turner"
marketname = "REDMI K Pad"
fingerprint = "Xiaomi/turner/turner:15/AP3A.241005.015.A1/turner.241005.001:user/release-keys"

[templates."redmi_26048rp6ac"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "26048RP6AC"
device = "yili"
product = "yili"
name = "yili"
marketname = "REDMI K Pad 2"
fingerprint = "Xiaomi/yili/yili:15/AP3A.241005.015.A1/yili.241005.001:user/release-keys"

[templates."xiaomi_fyj01qp"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "FYJ01QP"
device = "Babel"
product = "Babel"
name = "Babel"
marketname = "Xiaomi 米家翻译机"
fingerprint = "Xiaomi/Babel/Babel:15/AP3A.241005.015.A1/Babel.241005.001:user/release-keys"

[templates."xiaomi_21051191c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "21051191C"
device = "21051191C"
product = "21051191C"
marketname = "Xiaomi CyberDog 仿生四足机器人"
fingerprint = "Xiaomi/21051191C/21051191C:15/AP3A.241005.015.A1/21051191C.241005.001:user/release-keys"

[templates."xiaomi_2405avpb7c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2405AVPB7C"
device = "2405AVPB7C"
product = "2405AVPB7C"
marketname = "Xiaomi 澎湃智能座舱"
fingerprint = "Xiaomi/2405AVPB7C/2405AVPB7C:15/AP3A.241005.015.A1/2405AVPB7C.241005.001:user/release-keys"

[templates."xiaomi_2503cvpc6c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "2503CVPC6C"
device = "konghou"
product = "konghou"
name = "konghou"
marketname = "Xiaomi 汽车后排移动控制屏"
fingerprint = "Xiaomi/konghou/konghou:15/AP3A.241005.015.A1/konghou.241005.001:user/release-keys"

[templates."honor_nts_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "NTS-AL00"
device = "Natasha"
product = "Natasha"
name = "Natasha"
marketname = "HONOR Magic"
fingerprint = "HONOR/Natasha/Natasha:15/AP3A.241005.015.A1/Natasha.241005.001:user/release-keys"

[templates."honor_tny_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "TNY-AL00"
device = "Tony"
product = "Tony"
name = "Tony"
marketname = "HONOR Magic2"
fingerprint = "HONOR/Tony/Tony:15/AP3A.241005.015.A1/Tony.241005.001:user/release-keys"

[templates."honor_tny_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "TNY-AL10"
device = "Tony"
product = "Tony"
name = "Tony"
marketname = "HONOR Magic2 3D 感光版"
fingerprint = "HONOR/Tony/Tony:15/AP3A.241005.015.A1/Tony.241005.001:user/release-keys"

[templates."honor_elz_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ELZ-AN00"
device = "Elizabeth"
product = "Elizabeth"
name = "Elizabeth"
marketname = "HONOR Magic3"
fingerprint = "HONOR/Elizabeth/Elizabeth:15/AP3A.241005.015.A1/Elizabeth.241005.001:user/release-keys"

[templates."honor_elz_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ELZ-AN10"
device = "Elizabeth"
product = "Elizabeth"
name = "Elizabeth"
marketname = "HONOR Magic3 Pro"
fingerprint = "HONOR/Elizabeth/Elizabeth:15/AP3A.241005.015.A1/Elizabeth.241005.001:user/release-keys"

[templates."honor_elz_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ELZ-AN20"
device = "Elizabeth"
product = "Elizabeth"
name = "Elizabeth"
marketname = "HONOR Magic3 至臻版"
fingerprint = "HONOR/Elizabeth/Elizabeth:15/AP3A.241005.015.A1/Elizabeth.241005.001:user/release-keys"

[templates."honor_mgi_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "MGI-AN00"
device = "Maggie"
product = "Maggie"
name = "Maggie"
marketname = "HONOR Magic V"
fingerprint = "HONOR/Maggie/Maggie:15/AP3A.241005.015.A1/Maggie.241005.001:user/release-keys"

[templates."honor_lge_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LGE-AN00"
device = "Lange"
product = "Lange"
name = "Lange"
marketname = "HONOR Magic4"
fingerprint = "HONOR/Lange/Lange:15/AP3A.241005.015.A1/Lange.241005.001:user/release-keys"

[templates."honor_lge_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LGE-AN10"
device = "Lange"
product = "Lange"
name = "Lange"
marketname = "HONOR Magic4 Pro"
fingerprint = "HONOR/Lange/Lange:15/AP3A.241005.015.A1/Lange.241005.001:user/release-keys"

[templates."honor_lge_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LGE-AN20"
device = "Lange"
product = "Lange"
name = "Lange"
marketname = "HONOR Magic4 至臻版"
fingerprint = "HONOR/Lange/Lange:15/AP3A.241005.015.A1/Lange.241005.001:user/release-keys"

[templates."honor_fri_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "FRI-AN00"
device = "Ferrari"
product = "Ferrari"
name = "Ferrari"
marketname = "HONOR Magic Vs"
fingerprint = "HONOR/Ferrari/Ferrari:15/AP3A.241005.015.A1/Ferrari.241005.001:user/release-keys"

[templates."honor_fri_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "FRI-AN10"
device = "Ferrari"
product = "Ferrari"
name = "Ferrari"
marketname = "HONOR Magic Vs 至臻版"
fingerprint = "HONOR/Ferrari/Ferrari:15/AP3A.241005.015.A1/Ferrari.241005.001:user/release-keys"

[templates."honor_pgt_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PGT-AN00"
device = "Piaget"
product = "Piaget"
name = "Piaget"
marketname = "HONOR Magic5"
fingerprint = "HONOR/Piaget/Piaget:15/AP3A.241005.015.A1/Piaget.241005.001:user/release-keys"

[templates."honor_pgt_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PGT-AN10"
device = "Piaget"
product = "Piaget"
name = "Piaget"
marketname = "HONOR Magic5 Pro"
fingerprint = "HONOR/Piaget/Piaget:15/AP3A.241005.015.A1/Piaget.241005.001:user/release-keys"

[templates."honor_pgt_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PGT-AN20"
device = "Piaget"
product = "Piaget"
name = "Piaget"
marketname = "HONOR Magic5 至臻版"
fingerprint = "HONOR/Piaget/Piaget:15/AP3A.241005.015.A1/Piaget.241005.001:user/release-keys"

[templates."honor_ver_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "VER-AN10"
device = "Veyron"
product = "Veyron"
name = "Veyron"
marketname = "HONOR Magic V2"
fingerprint = "HONOR/Veyron/Veyron:15/AP3A.241005.015.A1/Veyron.241005.001:user/release-keys"

[templates."honor_ver_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "VER-AN00"
device = "VeyronS"
product = "VeyronS"
name = "VeyronS"
marketname = "HONOR Magic Vs2"
fingerprint = "HONOR/VeyronS/VeyronS:15/AP3A.241005.015.A1/VeyronS.241005.001:user/release-keys"

[templates."honor_bvl_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BVL-AN00"
device = "Bvlgari"
product = "Bvlgari"
name = "Bvlgari"
marketname = "HONOR Magic6"
fingerprint = "HONOR/Bvlgari/Bvlgari:15/AP3A.241005.015.A1/Bvlgari.241005.001:user/release-keys"

[templates."honor_bvl_an16"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BVL-AN16"
device = "Bvlgari"
product = "Bvlgari"
name = "Bvlgari"
marketname = "HONOR Magic6 Pro"
fingerprint = "HONOR/Bvlgari/Bvlgari:15/AP3A.241005.015.A1/Bvlgari.241005.001:user/release-keys"

[templates."honor_bvl_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BVL-AN20"
device = "Bvlgari"
product = "Bvlgari"
name = "Bvlgari"
marketname = "HONOR Magic6 至臻版"
fingerprint = "HONOR/Bvlgari/Bvlgari:15/AP3A.241005.015.A1/Bvlgari.241005.001:user/release-keys"

[templates."honor_lra_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LRA-AN00"
device = "Lyra"
product = "Lyra"
name = "Lyra"
marketname = "HONOR Magic V Flip"
fingerprint = "HONOR/Lyra/Lyra:15/AP3A.241005.015.A1/Lyra.241005.001:user/release-keys"

[templates."honor_fcp_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "FCP-AN10"
device = "FalconP"
product = "FalconP"
name = "FalconP"
marketname = "HONOR Magic V3"
fingerprint = "HONOR/FalconP/FalconP:15/AP3A.241005.015.A1/FalconP.241005.001:user/release-keys"

[templates."honor_fcp_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "FCP-AN20"
device = "FalconP"
product = "FalconP"
name = "FalconP"
marketname = "HONOR Magic V3 双卫星版"
fingerprint = "HONOR/FalconP/FalconP:15/AP3A.241005.015.A1/FalconP.241005.001:user/release-keys"

[templates."honor_flc_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "FLC-AN00"
device = "Falcon"
product = "Falcon"
name = "Falcon"
marketname = "HONOR Magic Vs3"
fingerprint = "HONOR/Falcon/Falcon:15/AP3A.241005.015.A1/Falcon.241005.001:user/release-keys"

[templates."honor_ptp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PTP-AN00"
device = "Philippe"
product = "Philippe"
name = "Philippe"
marketname = "HONOR Magic7"
fingerprint = "HONOR/Philippe/Philippe:15/AP3A.241005.015.A1/Philippe.241005.001:user/release-keys"

[templates."honor_ptp_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PTP-AN10"
device = "Patek"
product = "Patek"
name = "Patek"
marketname = "HONOR Magic7 Pro"
fingerprint = "HONOR/Patek/Patek:15/AP3A.241005.015.A1/Patek.241005.001:user/release-keys"

[templates."honor_ptp_an70"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PTP-AN70"
device = "Patek"
product = "Patek"
name = "Patek"
marketname = "HONOR Magic7 Pro 卫星通信版"
fingerprint = "HONOR/Patek/Patek:15/AP3A.241005.015.A1/Patek.241005.001:user/release-keys"

[templates."honor_ptp_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PTP-AN20"
device = "Patek"
product = "Patek"
name = "Patek"
marketname = "HONOR Magic7 RSR 保时捷设计"
fingerprint = "HONOR/Patek/Patek:15/AP3A.241005.015.A1/Patek.241005.001:user/release-keys"

[templates."honor_mbh_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "MBH-AN10"
device = "Maybach"
product = "Maybach"
name = "Maybach"
marketname = "HONOR Magic V5"
fingerprint = "HONOR/Maybach/Maybach:15/AP3A.241005.015.A1/Maybach.241005.001:user/release-keys"

[templates."honor_cle_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CLE-AN00"
device = "Celine"
product = "Celine"
name = "Celine"
marketname = "HONOR Magic V Flip2"
fingerprint = "HONOR/Celine/Celine:15/AP3A.241005.015.A1/Celine.241005.001:user/release-keys"

[templates."honor_bkq_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BKQ-AN00"
device = "Birkin"
product = "Birkin"
name = "Birkin"
marketname = "HONOR Magic8"
fingerprint = "HONOR/Birkin/Birkin:15/AP3A.241005.015.A1/Birkin.241005.001:user/release-keys"

[templates."honor_bkq_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BKQ-AN10"
device = "Birkin"
product = "Birkin"
name = "Birkin"
marketname = "HONOR Magic8 Pro"
fingerprint = "HONOR/Birkin/Birkin:15/AP3A.241005.015.A1/Birkin.241005.001:user/release-keys"

[templates."honor_ldy_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LDY-AN00"
device = "Lindy"
product = "Lindy"
name = "Lindy"
marketname = "HONOR Magic8 Pro Air"
fingerprint = "HONOR/Lindy/Lindy:15/AP3A.241005.015.A1/Lindy.241005.001:user/release-keys"

[templates."honor_bkq_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BKQ-AN20"
device = "Birkin"
product = "Birkin"
name = "Birkin"
marketname = "HONOR Magic8 RSR 保时捷设计"
fingerprint = "HONOR/Birkin/Birkin:15/AP3A.241005.015.A1/Birkin.241005.001:user/release-keys"

[templates."honor_pnm_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PNM-AN10"
device = "Phenom"
product = "Phenom"
name = "Phenom"
marketname = "HONOR Magic V6"
fingerprint = "HONOR/Phenom/Phenom:15/AP3A.241005.015.A1/Phenom.241005.001:user/release-keys"

[templates."honor_mly_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "MLY-AN00"
device = "Molly"
product = "Molly"
name = "Molly"
marketname = "HONOR Magic9"
fingerprint = "HONOR/Molly/Molly:15/AP3A.241005.015.A1/Molly.241005.001:user/release-keys"

[templates."honor_mlm_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "MLM-AN00"
device = "MollyM"
product = "MollyM"
name = "MollyM"
marketname = "HONOR Magic9 超能版"
fingerprint = "HONOR/MollyM/MollyM:15/AP3A.241005.015.A1/MollyM.241005.001:user/release-keys"

[templates."honor_wkl_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "WKL-AN20"
device = "Twinkle"
product = "Twinkle"
name = "Twinkle"
marketname = "HONOR Magic9 Pro Max"
fingerprint = "HONOR/Twinkle/Twinkle:15/AP3A.241005.015.A1/Twinkle.241005.001:user/release-keys"

[templates."honor_aph_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "APH-AN00"
device = "Alpha"
product = "Alpha"
name = "Alpha"
marketname = "HONOR Robot Phone"
fingerprint = "HONOR/Alpha/Alpha:15/AP3A.241005.015.A1/Alpha.241005.001:user/release-keys"

[templates."honor_h60_l01"]
manufacturer = "HONOR"
brand = "HONOR"
model = "H60-L01"
device = "Mogolia"
product = "Mogolia"
name = "Mogolia"
marketname = "HONOR 6"
fingerprint = "HONOR/Mogolia/Mogolia:15/AP3A.241005.015.A1/Mogolia.241005.001:user/release-keys"

[templates."honor_h60_l21"]
manufacturer = "HONOR"
brand = "HONOR"
model = "H60-L21"
device = "Mogolia"
product = "Mogolia"
name = "Mogolia"
marketname = "HONOR 6 至尊版"
fingerprint = "HONOR/Mogolia/Mogolia:15/AP3A.241005.015.A1/Mogolia.241005.001:user/release-keys"

[templates."honor_pe_tl00m"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PE-TL00M"
device = "Pine"
product = "Pine"
name = "Pine"
marketname = "HONOR 6 Plus"
fingerprint = "HONOR/Pine/Pine:15/AP3A.241005.015.A1/Pine.241005.001:user/release-keys"

[templates."honor_pe_tl10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PE-TL10"
device = "Pine"
product = "Pine"
name = "Pine"
marketname = "HONOR 6 Plus 双 4G"
fingerprint = "HONOR/Pine/Pine:15/AP3A.241005.015.A1/Pine.241005.001:user/release-keys"

[templates."honor_pe_tl20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PE-TL20"
device = "Pine"
product = "Pine"
name = "Pine"
marketname = "HONOR 6 Plus 移动渠道版"
fingerprint = "HONOR/Pine/Pine:15/AP3A.241005.015.A1/Pine.241005.001:user/release-keys"

[templates."honor_plk_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PLK-AL10"
device = "Plank"
product = "Plank"
name = "Plank"
marketname = "HONOR 7"
fingerprint = "HONOR/Plank/Plank:15/AP3A.241005.015.A1/Plank.241005.001:user/release-keys"

[templates."honor_plk_tl01h"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PLK-TL01H"
device = "Plank"
product = "Plank"
name = "Plank"
marketname = "HONOR 7 移动渠道版"
fingerprint = "HONOR/Plank/Plank:15/AP3A.241005.015.A1/Plank.241005.001:user/release-keys"

[templates."honor_plk_tl11h"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PLK-TL11H"
device = "Plank"
product = "Plank"
name = "Plank"
marketname = "HONOR 7 移动增强版"
fingerprint = "HONOR/Plank/Plank:15/AP3A.241005.015.A1/Plank.241005.001:user/release-keys"

[templates."honor_ath_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ATH-AL00"
device = "ATH-AL00"
product = "ATH-AL00"
marketname = "HONOR 7i"
fingerprint = "HONOR/ATH-AL00/ATH-AL00:15/AP3A.241005.015.A1/ATH-AL00.241005.001:user/release-keys"

[templates."honor_ath_tl00h"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ATH-TL00H"
device = "ATH-TL00H"
product = "ATH-TL00H"
marketname = "HONOR 7i 移动渠道版"
fingerprint = "HONOR/ATH-TL00H/ATH-TL00H:15/AP3A.241005.015.A1/ATH-TL00H.241005.001:user/release-keys"

[templates."honor_frd_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "FRD-AL00"
device = "Faraday"
product = "Faraday"
name = "Faraday"
marketname = "HONOR 8"
fingerprint = "HONOR/Faraday/Faraday:15/AP3A.241005.015.A1/Faraday.241005.001:user/release-keys"

[templates."honor_pra_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PRA-AL00"
device = "Prague"
product = "Prague"
name = "Prague"
marketname = "HONOR 8 青春版"
fingerprint = "HONOR/Prague/Prague:15/AP3A.241005.015.A1/Prague.241005.001:user/release-keys"

[templates."honor_stf_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "STF-AL00"
device = "Stanford"
product = "Stanford"
name = "Stanford"
marketname = "HONOR 9"
fingerprint = "HONOR/Stanford/Stanford:15/AP3A.241005.015.A1/Stanford.241005.001:user/release-keys"

[templates."honor_lld_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LLD-AL00"
device = "Leland"
product = "Leland"
name = "Leland"
marketname = "HONOR 9 青春版"
fingerprint = "HONOR/Leland/Leland:15/AP3A.241005.015.A1/Leland.241005.001:user/release-keys"

[templates."honor_lld_al20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LLD-AL20"
device = "LelandP"
product = "LelandP"
name = "LelandP"
marketname = "HONOR 9i"
fingerprint = "HONOR/LelandP/LelandP:15/AP3A.241005.015.A1/LelandP.241005.001:user/release-keys"

[templates."honor_col_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "COL-AL00"
device = "Columbia"
product = "Columbia"
name = "Columbia"
marketname = "HONOR 10"
fingerprint = "HONOR/Columbia/Columbia:15/AP3A.241005.015.A1/Columbia.241005.001:user/release-keys"

[templates."honor_col_tl00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "COL-TL00"
device = "Columbia"
product = "Columbia"
name = "Columbia"
marketname = "HONOR 10 移动 4G+"
fingerprint = "HONOR/Columbia/Columbia:15/AP3A.241005.015.A1/Columbia.241005.001:user/release-keys"

[templates."honor_hry_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HRY-AL00"
device = "Harry"
product = "Harry"
name = "Harry"
marketname = "HONOR 10 青春版"
fingerprint = "HONOR/Harry/Harry:15/AP3A.241005.015.A1/Harry.241005.001:user/release-keys"

[templates."honor_hry_al00t"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HRY-AL00T"
device = "Harrypro"
product = "Harrypro"
name = "Harrypro"
marketname = "HONOR 20i"
fingerprint = "HONOR/Harrypro/Harrypro:15/AP3A.241005.015.A1/Harrypro.241005.001:user/release-keys"

[templates."honor_yal_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "YAL-AL00"
device = "Yale"
product = "Yale"
name = "Yale"
marketname = "HONOR 20"
fingerprint = "HONOR/Yale/Yale:15/AP3A.241005.015.A1/Yale.241005.001:user/release-keys"

[templates."honor_yal_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "YAL-AL10"
device = "Yale"
product = "Yale"
name = "Yale"
marketname = "HONOR 20 PRO"
fingerprint = "HONOR/Yale/Yale:15/AP3A.241005.015.A1/Yale.241005.001:user/release-keys"

[templates."honor_yal_al50"]
manufacturer = "HONOR"
brand = "HONOR"
model = "YAL-AL50"
device = "Yalese"
product = "Yalese"
name = "Yalese"
marketname = "HONOR 20S"
fingerprint = "HONOR/Yalese/Yalese:15/AP3A.241005.015.A1/Yalese.241005.001:user/release-keys"

[templates."honor_lra_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LRA-AL00"
device = "Laura"
product = "Laura"
name = "Laura"
marketname = "HONOR 20 青春版"
fingerprint = "HONOR/Laura/Laura:15/AP3A.241005.015.A1/Laura.241005.001:user/release-keys"

[templates."honor_bmh_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BMH-AN10"
device = "Birmingham"
product = "Birmingham"
name = "Birmingham"
marketname = "HONOR 30 5G"
fingerprint = "HONOR/Birmingham/Birmingham:15/AP3A.241005.015.A1/Birmingham.241005.001:user/release-keys"

[templates."honor_ebg_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "EBG-AN00"
device = "Edinburgh"
product = "Edinburgh"
name = "Edinburgh"
marketname = "HONOR 30 Pro 5G"
fingerprint = "HONOR/Edinburgh/Edinburgh:15/AP3A.241005.015.A1/Edinburgh.241005.001:user/release-keys"

[templates."honor_ebg_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "EBG-AN10"
device = "Edinburgh"
product = "Edinburgh"
name = "Edinburgh"
marketname = "HONOR 30 Pro+ 5G"
fingerprint = "HONOR/Edinburgh/Edinburgh:15/AP3A.241005.015.A1/Edinburgh.241005.001:user/release-keys"

[templates."honor_cdy_an90"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CDY-AN90"
device = "CindyH"
product = "CindyH"
name = "CindyH"
marketname = "HONOR 30S 5G"
fingerprint = "HONOR/CindyH/CindyH:15/AP3A.241005.015.A1/CindyH.241005.001:user/release-keys"

[templates."honor_mxw_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "MXW-AN00"
device = "Maxwell"
product = "Maxwell"
name = "Maxwell"
marketname = "HONOR 30 青春版 5G"
fingerprint = "HONOR/Maxwell/Maxwell:15/AP3A.241005.015.A1/Maxwell.241005.001:user/release-keys"

[templates."honor_nth_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "NTH-AN00"
device = "Nottingham"
product = "Nottingham"
name = "Nottingham"
marketname = "HONOR 50 5G"
fingerprint = "HONOR/Nottingham/Nottingham:15/AP3A.241005.015.A1/Nottingham.241005.001:user/release-keys"

[templates."honor_rna_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "RNA-AN00"
device = "Rena"
product = "Rena"
name = "Rena"
marketname = "HONOR 50 Pro 5G"
fingerprint = "HONOR/Rena/Rena:15/AP3A.241005.015.A1/Rena.241005.001:user/release-keys"

[templates."honor_jlh_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "JLH-AN00"
device = "JuliaH"
product = "JuliaH"
name = "JuliaH"
marketname = "HONOR 50 SE 5G"
fingerprint = "HONOR/JuliaH/JuliaH:15/AP3A.241005.015.A1/JuliaH.241005.001:user/release-keys"

[templates."honor_lsa_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LSA-AN00"
device = "Lisa"
product = "Lisa"
name = "Lisa"
marketname = "HONOR 60 5G"
fingerprint = "HONOR/Lisa/Lisa:15/AP3A.241005.015.A1/Lisa.241005.001:user/release-keys"

[templates."honor_tna_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "TNA-AN00"
device = "Tina"
product = "Tina"
name = "Tina"
marketname = "HONOR 60 Pro 5G"
fingerprint = "HONOR/Tina/Tina:15/AP3A.241005.015.A1/Tina.241005.001:user/release-keys"

[templates."honor_gia_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "GIA-AN00"
device = "Gina"
product = "Gina"
name = "Gina"
marketname = "HONOR 60 SE 5G"
fingerprint = "HONOR/Gina/Gina:15/AP3A.241005.015.A1/Gina.241005.001:user/release-keys"

[templates."honor_fne_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "FNE-AN00"
device = "Fennie"
product = "Fennie"
name = "Fennie"
marketname = "HONOR 70"
fingerprint = "HONOR/Fennie/Fennie:15/AP3A.241005.015.A1/Fennie.241005.001:user/release-keys"

[templates."honor_sdy_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "SDY-AN00"
device = "Sandy"
product = "Sandy"
name = "Sandy"
marketname = "HONOR 70 Pro"
fingerprint = "HONOR/Sandy/Sandy:15/AP3A.241005.015.A1/Sandy.241005.001:user/release-keys"

[templates."honor_hpb_tn00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HPB-TN00"
device = "Hepburn"
product = "Hepburn"
name = "Hepburn"
marketname = "HONOR 70 Pro+"
fingerprint = "HONOR/Hepburn/Hepburn:15/AP3A.241005.015.A1/Hepburn.241005.001:user/release-keys"

[templates."honor_ann_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ANN-AN00"
device = "Anna"
product = "Anna"
name = "Anna"
marketname = "HONOR 80"
fingerprint = "HONOR/Anna/Anna:15/AP3A.241005.015.A1/Anna.241005.001:user/release-keys"

[templates."honor_anp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ANP-AN00"
device = "AnnaP"
product = "AnnaP"
name = "AnnaP"
marketname = "HONOR 80 Pro"
fingerprint = "HONOR/AnnaP/AnnaP:15/AP3A.241005.015.A1/AnnaP.241005.001:user/release-keys"

[templates."honor_anb_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ANB-AN00"
device = "AnnaB"
product = "AnnaB"
name = "AnnaB"
marketname = "HONOR 80 Pro 直屏版"
fingerprint = "HONOR/AnnaB/AnnaB:15/AP3A.241005.015.A1/AnnaB.241005.001:user/release-keys"

[templates."honor_gia_an80"]
manufacturer = "HONOR"
brand = "HONOR"
model = "GIA-AN80"
device = "Gina"
product = "Gina"
name = "Gina"
marketname = "HONOR 80 SE"
fingerprint = "HONOR/Gina/Gina:15/AP3A.241005.015.A1/Gina.241005.001:user/release-keys"

[templates."honor_agt_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AGT-AN00"
device = "AnnaGT"
product = "AnnaGT"
name = "AnnaGT"
marketname = "HONOR 80 GT"
fingerprint = "HONOR/AnnaGT/AnnaGT:15/AP3A.241005.015.A1/AnnaGT.241005.001:user/release-keys"

[templates."honor_rea_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "REA-AN00"
device = "Rhea"
product = "Rhea"
name = "Rhea"
marketname = "HONOR 90"
fingerprint = "HONOR/Rhea/Rhea:15/AP3A.241005.015.A1/Rhea.241005.001:user/release-keys"

[templates."honor_rep_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "REP-AN00"
device = "RheaP"
product = "RheaP"
name = "RheaP"
marketname = "HONOR 90 Pro"
fingerprint = "HONOR/RheaP/RheaP:15/AP3A.241005.015.A1/RheaP.241005.001:user/release-keys"

[templates."honor_mag_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "MAG-AN00"
device = "MiaGT"
product = "MiaGT"
name = "MiaGT"
marketname = "HONOR 90 GT"
fingerprint = "HONOR/MiaGT/MiaGT:15/AP3A.241005.015.A1/MiaGT.241005.001:user/release-keys"

[templates."honor_maa_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "MAA-AN00"
device = "Mia"
product = "Mia"
name = "Mia"
marketname = "HONOR 100"
fingerprint = "HONOR/Mia/Mia:15/AP3A.241005.015.A1/Mia.241005.001:user/release-keys"

[templates."honor_maa_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "MAA-AN10"
device = "MiaP"
product = "MiaP"
name = "MiaP"
marketname = "HONOR 100 Pro"
fingerprint = "HONOR/MiaP/MiaP:15/AP3A.241005.015.A1/MiaP.241005.001:user/release-keys"

[templates."honor_eli_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ELI-AN00"
device = "Ellie"
product = "Ellie"
name = "Ellie"
marketname = "HONOR 200"
fingerprint = "HONOR/Ellie/Ellie:15/AP3A.241005.015.A1/Ellie.241005.001:user/release-keys"

[templates."honor_elp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ELP-AN00"
device = "EllieP"
product = "EllieP"
name = "EllieP"
marketname = "HONOR 200 Pro"
fingerprint = "HONOR/EllieP/EllieP:15/AP3A.241005.015.A1/EllieP.241005.001:user/release-keys"

[templates."honor_amm_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AMM-AN00"
device = "Mina"
product = "Mina"
name = "Mina"
marketname = "HONOR 300"
fingerprint = "HONOR/Mina/Mina:15/AP3A.241005.015.A1/Mina.241005.001:user/release-keys"

[templates."honor_amp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AMP-AN00"
device = "MinaP"
product = "MinaP"
name = "MinaP"
marketname = "HONOR 300 Pro"
fingerprint = "HONOR/MinaP/MinaP:15/AP3A.241005.015.A1/MinaP.241005.001:user/release-keys"

[templates."honor_amp_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AMP-AN10"
device = "MinaP"
product = "MinaP"
name = "MinaP"
marketname = "HONOR 300 Ultra"
fingerprint = "HONOR/MinaP/MinaP:15/AP3A.241005.015.A1/MinaP.241005.001:user/release-keys"

[templates."honor_dnn_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "DNN-AN00"
device = "Danny"
product = "Danny"
name = "Danny"
marketname = "HONOR 400"
fingerprint = "HONOR/Danny/Danny:15/AP3A.241005.015.A1/Danny.241005.001:user/release-keys"

[templates."honor_dnp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "DNP-AN00"
device = "DannyP"
product = "DannyP"
name = "DannyP"
marketname = "HONOR 400 Pro"
fingerprint = "HONOR/DannyP/DannyP:15/AP3A.241005.015.A1/DannyP.241005.001:user/release-keys"

[templates."honor_mey_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "MEY-AN00"
device = "Merry"
product = "Merry"
name = "Merry"
marketname = "HONOR 500"
fingerprint = "HONOR/Merry/Merry:15/AP3A.241005.015.A1/Merry.241005.001:user/release-keys"

[templates."honor_mep_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "MEP-AN00"
device = "MerryP"
product = "MerryP"
name = "MerryP"
marketname = "HONOR 500 Pro"
fingerprint = "HONOR/MerryP/MerryP:15/AP3A.241005.015.A1/MerryP.241005.001:user/release-keys"

[templates."honor_vkj_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "VKJ-AN00"
device = "Vicky"
product = "Vicky"
name = "Vicky"
marketname = "HONOR 600 超级版"
fingerprint = "HONOR/Vicky/Vicky:15/AP3A.241005.015.A1/Vicky.241005.001:user/release-keys"

[templates."honor_vkj_an90"]
manufacturer = "HONOR"
brand = "HONOR"
model = "VKJ-AN90"
device = "Vicky"
product = "Vicky"
name = "Vicky"
marketname = "HONOR 600 元气版"
fingerprint = "HONOR/Vicky/Vicky:15/AP3A.241005.015.A1/Vicky.241005.001:user/release-keys"

[templates."honor_vki_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "VKI-AN00"
device = "Vicky"
product = "Vicky"
name = "Vicky"
marketname = "HONOR 600 Pro"
fingerprint = "HONOR/Vicky/Vicky:15/AP3A.241005.015.A1/Vicky.241005.001:user/release-keys"

[templates."honor_faa_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "FAA-AN00"
device = "Flora"
product = "Flora"
name = "Flora"
marketname = "HONOR 700"
fingerprint = "HONOR/Flora/Flora:15/AP3A.241005.015.A1/Flora.241005.001:user/release-keys"

[templates."honor_fas_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "FAS-AN00"
device = "FloraS"
product = "FloraS"
name = "FloraS"
marketname = "HONOR 700S"
fingerprint = "HONOR/FloraS/FloraS:15/AP3A.241005.015.A1/FloraS.241005.001:user/release-keys"

[templates."honor_fap_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "FAP-AN00"
device = "FloraP"
product = "FloraP"
name = "FloraP"
marketname = "HONOR 700 Pro"
fingerprint = "HONOR/FloraP/FloraP:15/AP3A.241005.015.A1/FloraP.241005.001:user/release-keys"

[templates."honor_knt_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "KNT-AL10"
device = "Knight"
product = "Knight"
name = "Knight"
marketname = "HONOR V8"
fingerprint = "HONOR/Knight/Knight:15/AP3A.241005.015.A1/Knight.241005.001:user/release-keys"

[templates."honor_duk_al20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "DUK-AL20"
device = "Duke"
product = "Duke"
name = "Duke"
marketname = "HONOR V9"
fingerprint = "HONOR/Duke/Duke:15/AP3A.241005.015.A1/Duke.241005.001:user/release-keys"

[templates."honor_bkl_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BKL-AL00"
device = "Berkeley"
product = "Berkeley"
name = "Berkeley"
marketname = "HONOR V10"
fingerprint = "HONOR/Berkeley/Berkeley:15/AP3A.241005.015.A1/Berkeley.241005.001:user/release-keys"

[templates."honor_pct_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PCT-AL10"
device = "Princeton"
product = "Princeton"
name = "Princeton"
marketname = "HONOR V20"
fingerprint = "HONOR/Princeton/Princeton:15/AP3A.241005.015.A1/Princeton.241005.001:user/release-keys"

[templates."honor_oxf_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "OXF-AN00"
device = "OxfordS"
product = "OxfordS"
name = "OxfordS"
marketname = "HONOR V30 5G"
fingerprint = "HONOR/OxfordS/OxfordS:15/AP3A.241005.015.A1/OxfordS.241005.001:user/release-keys"

[templates."honor_oxf_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "OXF-AN10"
device = "OxfordP"
product = "OxfordP"
name = "OxfordP"
marketname = "HONOR V30 PRO 5G"
fingerprint = "HONOR/OxfordP/OxfordP:15/AP3A.241005.015.A1/OxfordP.241005.001:user/release-keys"

[templates."honor_yok_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "YOK-AN10"
device = "York"
product = "York"
name = "York"
marketname = "HONOR V40 5G"
fingerprint = "HONOR/York/York:15/AP3A.241005.015.A1/York.241005.001:user/release-keys"

[templates."honor_ala_an70"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ALA-AN70"
device = "ALA-AN70"
product = "ALA-AN70"
marketname = "HONOR V40 轻奢版 5G"
fingerprint = "HONOR/ALA-AN70/ALA-AN70:15/AP3A.241005.015.A1/ALA-AN70.241005.001:user/release-keys"

[templates."honor_vca_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "VCA-AN00"
device = "Victoria"
product = "Victoria"
name = "Victoria"
marketname = "HONOR V Purse"
fingerprint = "HONOR/Victoria/Victoria:15/AP3A.241005.015.A1/Victoria.241005.001:user/release-keys"

[templates."honor_amg_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AMG-AN00"
device = "MinaGT"
product = "MinaGT"
name = "MinaGT"
marketname = "HONOR GT"
fingerprint = "HONOR/MinaGT/MinaGT:15/AP3A.241005.015.A1/MinaGT.241005.001:user/release-keys"

[templates."honor_ppg_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "PPG-AN00"
device = "PhilippeGT"
product = "PhilippeGT"
name = "PhilippeGT"
marketname = "HONOR GT Pro"
fingerprint = "HONOR/PhilippeGT/PhilippeGT:15/AP3A.241005.015.A1/PhilippeGT.241005.001:user/release-keys"

[templates."honor_aap_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AAP-AN00"
device = "AAP-AN00"
product = "AAP-AN00"
marketname = "HONOR WIN"
fingerprint = "HONOR/AAP-AN00/AAP-AN00:15/AP3A.241005.015.A1/AAP-AN00.241005.001:user/release-keys"

[templates."honor_aak_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AAK-AN00"
device = "AAK-AN00"
product = "AAK-AN00"
marketname = "HONOR WIN RT"
fingerprint = "HONOR/AAK-AN00/AAK-AN00:15/AP3A.241005.015.A1/AAK-AN00.241005.001:user/release-keys"

[templates."honor_ser_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "SER-AN00"
device = "Saber"
product = "Saber"
name = "Saber"
marketname = "HONOR WIN Turbo"
fingerprint = "HONOR/Saber/Saber:15/AP3A.241005.015.A1/Saber.241005.001:user/release-keys"

[templates."honor_brm_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BRM-AN00"
device = "BarrettM"
product = "BarrettM"
name = "BarrettM"
marketname = "HONOR WIN2"
fingerprint = "HONOR/BarrettM/BarrettM:15/AP3A.241005.015.A1/BarrettM.241005.001:user/release-keys"

[templates."honor_brt_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BRT-AN00"
device = "Barrett"
product = "Barrett"
name = "Barrett"
marketname = "HONOR WIN RT2"
fingerprint = "HONOR/Barrett/Barrett:15/AP3A.241005.015.A1/Barrett.241005.001:user/release-keys"

[templates."honor_brs_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BRS-AN00"
device = "BarrettS"
product = "BarrettS"
name = "BarrettS"
marketname = "HONOR WIN Turbo2"
fingerprint = "HONOR/BarrettS/BarrettS:15/AP3A.241005.015.A1/BarrettS.241005.001:user/release-keys"

[templates."honor_g750_t00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "G750-T00"
device = "G750-T00"
product = "G750-T00"
marketname = "HONOR 3X 双"
fingerprint = "HONOR/G750-T00/G750-T00:15/AP3A.241005.015.A1/G750-T00.241005.001:user/release-keys"

[templates."honor_g750_u00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "G750-U00"
device = "G750-U00"
product = "G750-U00"
marketname = "HONOR 3X"
fingerprint = "HONOR/G750-U00/G750-U00:15/AP3A.241005.015.A1/G750-U00.241005.001:user/release-keys"

[templates."honor_g750_t20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "G750-T20"
device = "G750-T20"
product = "G750-T20"
marketname = "HONOR 3X Pro"
fingerprint = "HONOR/G750-T20/G750-T20:15/AP3A.241005.015.A1/G750-T20.241005.001:user/release-keys"

[templates."honor_g750_t01"]
manufacturer = "HONOR"
brand = "HONOR"
model = "G750-T01"
device = "G750-T01"
product = "G750-T01"
marketname = "HONOR 真八核畅玩版"
fingerprint = "HONOR/G750-T01/G750-T01:15/AP3A.241005.015.A1/G750-T01.241005.001:user/release-keys"

[templates."honor_che1_cl20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CHE1-CL20"
device = "Cherry"
product = "Cherry"
name = "Cherry"
marketname = "HONOR 畅玩 4X"
fingerprint = "HONOR/Cherry/Cherry:15/AP3A.241005.015.A1/Cherry.241005.001:user/release-keys"

[templates."honor_che2_tl00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CHE2-TL00"
device = "Cherryplus"
product = "Cherryplus"
name = "Cherryplus"
marketname = "HONOR 畅玩 4X 移动渠道版"
fingerprint = "HONOR/Cherryplus/Cherryplus:15/AP3A.241005.015.A1/Cherryplus.241005.001:user/release-keys"

[templates."honor_kiw_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "KIW-AL10"
device = "Kiwi"
product = "Kiwi"
name = "Kiwi"
marketname = "HONOR 畅玩 5X"
fingerprint = "HONOR/Kiwi/Kiwi:15/AP3A.241005.015.A1/Kiwi.241005.001:user/release-keys"

[templates."honor_bln_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BLN-AL10"
device = "Berlin"
product = "Berlin"
name = "Berlin"
marketname = "HONOR 畅玩 6X"
fingerprint = "HONOR/Berlin/Berlin:15/AP3A.241005.015.A1/Berlin.241005.001:user/release-keys"

[templates."honor_bnd_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BND-AL00"
device = "Bond"
product = "Bond"
name = "Bond"
marketname = "HONOR 畅玩 7X"
fingerprint = "HONOR/Bond/Bond:15/AP3A.241005.015.A1/Bond.241005.001:user/release-keys"

[templates."honor_jsn_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "JSN-AL00"
device = "Johnson"
product = "Johnson"
name = "Johnson"
marketname = "HONOR 8X"
fingerprint = "HONOR/Johnson/Johnson:15/AP3A.241005.015.A1/Johnson.241005.001:user/release-keys"

[templates."honor_are_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ARE-AL00"
device = "Ares"
product = "Ares"
name = "Ares"
marketname = "HONOR 8X Max"
fingerprint = "HONOR/Ares/Ares:15/AP3A.241005.015.A1/Ares.241005.001:user/release-keys"

[templates."honor_hlk_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HLK-AL00"
device = "Hulk"
product = "Hulk"
name = "Hulk"
marketname = "HONOR 9X"
fingerprint = "HONOR/Hulk/Hulk:15/AP3A.241005.015.A1/Hulk.241005.001:user/release-keys"

[templates."honor_hlk_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HLK-AL10"
device = "Hulk"
product = "Hulk"
name = "Hulk"
marketname = "HONOR 9X PRO"
fingerprint = "HONOR/Hulk/Hulk:15/AP3A.241005.015.A1/Hulk.241005.001:user/release-keys"

[templates."honor_tel_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "TEL-AN00"
device = "Teller"
product = "Teller"
name = "Teller"
marketname = "HONOR X10 5G"
fingerprint = "HONOR/Teller/Teller:15/AP3A.241005.015.A1/Teller.241005.001:user/release-keys"

[templates."honor_kkg_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "KKG-AN00"
device = "Kingkong"
product = "Kingkong"
name = "Kingkong"
marketname = "HONOR X10 Max 5G"
fingerprint = "HONOR/Kingkong/Kingkong:15/AP3A.241005.015.A1/Kingkong.241005.001:user/release-keys"

[templates."honor_ntn_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "NTN-AN20"
device = "NewtonH"
product = "NewtonH"
name = "NewtonH"
marketname = "HONOR X20 5G"
fingerprint = "HONOR/NewtonH/NewtonH:15/AP3A.241005.015.A1/NewtonH.241005.001:user/release-keys"

[templates."honor_chl_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CHL-AN00"
device = "Chanel"
product = "Chanel"
name = "Chanel"
marketname = "HONOR X20 SE 5G"
fingerprint = "HONOR/Chanel/Chanel:15/AP3A.241005.015.A1/Chanel.241005.001:user/release-keys"

[templates."honor_any_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ANY-AN00"
device = "Andy"
product = "Andy"
name = "Andy"
marketname = "HONOR X30 5G"
fingerprint = "HONOR/Andy/Andy:15/AP3A.241005.015.A1/Andy.241005.001:user/release-keys"

[templates."honor_tfy_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "TFY-AN00"
device = "Tiffany"
product = "Tiffany"
name = "Tiffany"
marketname = "HONOR X30i 5G"
fingerprint = "HONOR/Tiffany/Tiffany:15/AP3A.241005.015.A1/Tiffany.241005.001:user/release-keys"

[templates."honor_kkg_an70"]
manufacturer = "HONOR"
brand = "HONOR"
model = "KKG-AN70"
device = "Kingkong"
product = "Kingkong"
name = "Kingkong"
marketname = "HONOR X30 Max 5G"
fingerprint = "HONOR/Kingkong/Kingkong:15/AP3A.241005.015.A1/Kingkong.241005.001:user/release-keys"

[templates."honor_rmo_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "RMO-AN00"
device = "Rambo"
product = "Rambo"
name = "Rambo"
marketname = "HONOR X40"
fingerprint = "HONOR/Rambo/Rambo:15/AP3A.241005.015.A1/Rambo.241005.001:user/release-keys"

[templates."honor_dio_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "DIO-AN00"
device = "Dior"
product = "Dior"
name = "Dior"
marketname = "HONOR X40i"
fingerprint = "HONOR/Dior/Dior:15/AP3A.241005.015.A1/Dior.241005.001:user/release-keys"

[templates."honor_adt_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ADT-AN00"
device = "AndyGT"
product = "AndyGT"
name = "AndyGT"
marketname = "HONOR X40 GT"
fingerprint = "HONOR/AndyGT/AndyGT:15/AP3A.241005.015.A1/AndyGT.241005.001:user/release-keys"

[templates."honor_ali_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ALI-AN00"
device = "Ali"
product = "Ali"
name = "Ali"
marketname = "HONOR X50"
fingerprint = "HONOR/Ali/Ali:15/AP3A.241005.015.A1/Ali.241005.001:user/release-keys"

[templates."honor_alp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ALP-AN00"
device = "AliP"
product = "AliP"
name = "AliP"
marketname = "HONOR X50 Pro"
fingerprint = "HONOR/AliP/AliP:15/AP3A.241005.015.A1/AliP.241005.001:user/release-keys"

[templates."honor_crt_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CRT-AN00"
device = "Cartier"
product = "Cartier"
name = "Cartier"
marketname = "HONOR X50i"
fingerprint = "HONOR/Cartier/Cartier:15/AP3A.241005.015.A1/Cartier.241005.001:user/release-keys"

[templates."honor_lly_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LLY-AN00"
device = "Lily"
product = "Lily"
name = "Lily"
marketname = "HONOR X50i+"
fingerprint = "HONOR/Lily/Lily:15/AP3A.241005.015.A1/Lily.241005.001:user/release-keys"

[templates."honor_brc_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BRC-AN00"
device = "Bruce"
product = "Bruce"
name = "Bruce"
marketname = "HONOR X60"
fingerprint = "HONOR/Bruce/Bruce:15/AP3A.241005.015.A1/Bruce.241005.001:user/release-keys"

[templates."honor_brp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BRP-AN00"
device = "BruceP"
product = "BruceP"
name = "BruceP"
marketname = "HONOR X60 Pro"
fingerprint = "HONOR/BruceP/BruceP:15/AP3A.241005.015.A1/BruceP.241005.001:user/release-keys"

[templates."honor_brp_an80"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BRP-AN80"
device = "BruceP"
product = "BruceP"
name = "BruceP"
marketname = "HONOR X60 Pro 卫星版"
fingerprint = "HONOR/BruceP/BruceP:15/AP3A.241005.015.A1/BruceP.241005.001:user/release-keys"

[templates."honor_lyn_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LYN-AN00"
device = "LilyN"
product = "LilyN"
name = "LilyN"
marketname = "HONOR X60i"
fingerprint = "HONOR/LilyN/LilyN:15/AP3A.241005.015.A1/LilyN.241005.001:user/release-keys"

[templates."honor_agi_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AGI-AN00"
device = "MinaGTI"
product = "MinaGTI"
name = "MinaGTI"
marketname = "HONOR X60 GT"
fingerprint = "HONOR/MinaGTI/MinaGTI:15/AP3A.241005.015.A1/MinaGTI.241005.001:user/release-keys"

[templates."honor_mtn_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "MTN-AN00"
device = "MTN-AN00"
product = "MTN-AN00"
marketname = "HONOR X70"
fingerprint = "HONOR/MTN-AN00/MTN-AN00:15/AP3A.241005.015.A1/MTN-AN00.241005.001:user/release-keys"

[templates."honor_abr_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ABR-AN00"
device = "Amber"
product = "Amber"
name = "Amber"
marketname = "HONOR X70i"
fingerprint = "HONOR/Amber/Amber:15/AP3A.241005.015.A1/Amber.241005.001:user/release-keys"

[templates."honor_bsn_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BSN-AN00"
device = "BSN-AN00"
product = "BSN-AN00"
marketname = "HONOR X80 Pro Max"
fingerprint = "HONOR/BSN-AN00/BSN-AN00:15/AP3A.241005.015.A1/BSN-AN00.241005.001:user/release-keys"

[templates."honor_lna_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LNA-AN00"
device = "Luna"
product = "Luna"
name = "Luna"
marketname = "HONOR X80i"
fingerprint = "HONOR/Luna/Luna:15/AP3A.241005.015.A1/Luna.241005.001:user/release-keys"

[templates."honor_jmm_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "JMM-AL00"
device = "Jimmy"
product = "Jimmy"
name = "Jimmy"
marketname = "HONOR V9 Play"
fingerprint = "HONOR/Jimmy/Jimmy:15/AP3A.241005.015.A1/Jimmy.241005.001:user/release-keys"

[templates."honor_jmm_tl00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "JMM-TL00"
device = "Jimmy"
product = "Jimmy"
name = "Jimmy"
marketname = "HONOR V9 Play 移动定制"
fingerprint = "HONOR/Jimmy/Jimmy:15/AP3A.241005.015.A1/Jimmy.241005.001:user/release-keys"

[templates."honor_cor_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "COR-AL00"
device = "Cornell"
product = "Cornell"
name = "Cornell"
marketname = "HONOR Play"
fingerprint = "HONOR/Cornell/Cornell:15/AP3A.241005.015.A1/Cornell.241005.001:user/release-keys"

[templates."honor_cor_tl10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "COR-TL10"
device = "Cornell"
product = "Cornell"
name = "Cornell"
marketname = "HONOR Play 移动 4G+"
fingerprint = "HONOR/Cornell/Cornell:15/AP3A.241005.015.A1/Cornell.241005.001:user/release-keys"

[templates."honor_ask_al00x"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ASK-AL00X"
device = "Asoka"
product = "Asoka"
name = "Asoka"
marketname = "HONOR Play3"
fingerprint = "HONOR/Asoka/Asoka:15/AP3A.241005.015.A1/Asoka.241005.001:user/release-keys"

[templates."honor_ksa_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "KSA-AL10"
device = "Katyusha"
product = "Katyusha"
name = "Katyusha"
marketname = "HONOR Play3e"
fingerprint = "HONOR/Katyusha/Katyusha:15/AP3A.241005.015.A1/Katyusha.241005.001:user/release-keys"

[templates."honor_aka_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AKA-AL10"
device = "Asoka"
product = "Asoka"
name = "Asoka"
marketname = "HONOR Play4T"
fingerprint = "HONOR/Asoka/Asoka:15/AP3A.241005.015.A1/Asoka.241005.001:user/release-keys"

[templates."honor_aqm_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AQM-AL10"
device = "Aquaman"
product = "Aquaman"
name = "Aquaman"
marketname = "HONOR Play4T Pro"
fingerprint = "HONOR/Aquaman/Aquaman:15/AP3A.241005.015.A1/Aquaman.241005.001:user/release-keys"

[templates."honor_tnnh_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "TNNH-AN00"
device = "TianshanH"
product = "TianshanH"
name = "TianshanH"
marketname = "HONOR Play4 5G"
fingerprint = "HONOR/TianshanH/TianshanH:15/AP3A.241005.015.A1/TianshanH.241005.001:user/release-keys"

[templates."honor_oxp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "OXP-AN00"
device = "OxfordPL"
product = "OxfordPL"
name = "OxfordPL"
marketname = "HONOR Play4 Pro 5G"
fingerprint = "HONOR/OxfordPL/OxfordPL:15/AP3A.241005.015.A1/OxfordPL.241005.001:user/release-keys"

[templates."honor_hjc_an90"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HJC-AN90"
device = "JessicaH"
product = "JessicaH"
name = "JessicaH"
marketname = "HONOR Play5 5G"
fingerprint = "HONOR/JessicaH/JessicaH:15/AP3A.241005.015.A1/JessicaH.241005.001:user/release-keys"

[templates."honor_new_an90"]
manufacturer = "HONOR"
brand = "HONOR"
model = "NEW-AN90"
device = "NewtonH"
product = "NewtonH"
name = "NewtonH"
marketname = "HONOR Play5 活力版 5G"
fingerprint = "HONOR/NewtonH/NewtonH:15/AP3A.241005.015.A1/NewtonH.241005.001:user/release-keys"

[templates."honor_koz_al40"]
manufacturer = "HONOR"
brand = "HONOR"
model = "KOZ-AL40"
device = "KonanZ"
product = "KonanZ"
name = "KonanZ"
marketname = "HONOR Play5T"
fingerprint = "HONOR/KonanZ/KonanZ:15/AP3A.241005.015.A1/KonanZ.241005.001:user/release-keys"

[templates."honor_nza_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "NZA-AL00"
device = "Nezha"
product = "Nezha"
name = "Nezha"
marketname = "HONOR Play5T 活力版"
fingerprint = "HONOR/Nezha/Nezha:15/AP3A.241005.015.A1/Nezha.241005.001:user/release-keys"

[templates."honor_chl_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CHL-AL00"
device = "Chanel"
product = "Chanel"
name = "Chanel"
marketname = "HONOR Play5T Pro"
fingerprint = "HONOR/Chanel/Chanel:15/AP3A.241005.015.A1/Chanel.241005.001:user/release-keys"

[templates."honor_cma_an40"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CMA-AN40"
device = "Carmella"
product = "Carmella"
name = "Carmella"
marketname = "HONOR Play6T 5G"
fingerprint = "HONOR/Carmella/Carmella:15/AP3A.241005.015.A1/Carmella.241005.001:user/release-keys"

[templates."honor_tfy_an40"]
manufacturer = "HONOR"
brand = "HONOR"
model = "TFY-AN40"
device = "Tiffany"
product = "Tiffany"
name = "Tiffany"
marketname = "HONOR Play6T Pro 5G"
fingerprint = "HONOR/Tiffany/Tiffany:15/AP3A.241005.015.A1/Tiffany.241005.001:user/release-keys"

[templates."honor_vne_an40"]
manufacturer = "HONOR"
brand = "HONOR"
model = "VNE-AN40"
device = "Vinnie"
product = "Vinnie"
name = "Vinnie"
marketname = "HONOR Play6C 5G"
fingerprint = "HONOR/Vinnie/Vinnie:15/AP3A.241005.015.A1/Vinnie.241005.001:user/release-keys"

[templates."honor_rky_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "RKY-AN10"
device = "Rocky"
product = "Rocky"
name = "Rocky"
marketname = "HONOR Play7T 5G"
fingerprint = "HONOR/Rocky/Rocky:15/AP3A.241005.015.A1/Rocky.241005.001:user/release-keys"

[templates."honor_clk_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CLK-AN00"
device = "Clark"
product = "Clark"
name = "Clark"
marketname = "HONOR Play8T 5G"
fingerprint = "HONOR/Clark/Clark:15/AP3A.241005.015.A1/Clark.241005.001:user/release-keys"

[templates."honor_alt_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ALT-AN00"
device = "Alita"
product = "Alita"
name = "Alita"
marketname = "HONOR Play9T 5G"
fingerprint = "HONOR/Alita/Alita:15/AP3A.241005.015.A1/Alita.241005.001:user/release-keys"

[templates."honor_jdy_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "JDY-AN00"
device = "Judy"
product = "Judy"
name = "Judy"
marketname = "HONOR Play9C 5G"
fingerprint = "HONOR/Judy/Judy:15/AP3A.241005.015.A1/Judy.241005.001:user/release-keys"

[templates."honor_log_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LOG-AN10"
device = "Logan"
product = "Logan"
name = "Logan"
marketname = "HONOR Play10 5G"
fingerprint = "HONOR/Logan/Logan:15/AP3A.241005.015.A1/Logan.241005.001:user/release-keys"

[templates."honor_nic_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "NIC-AN00"
device = "Nick"
product = "Nick"
name = "Nick"
marketname = "HONOR Play10C 5G"
fingerprint = "HONOR/Nick/Nick:15/AP3A.241005.015.A1/Nick.241005.001:user/release-keys"

[templates."honor_nla_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "NLA-AN00"
device = "Nala"
product = "Nala"
name = "Nala"
marketname = "HONOR Play10A 5G"
fingerprint = "HONOR/Nala/Nala:15/AP3A.241005.015.A1/Nala.241005.001:user/release-keys"

[templates."honor_mrk_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "MRK-AN00"
device = "Mark"
product = "Mark"
name = "Mark"
marketname = "HONOR Play11 5G"
fingerprint = "HONOR/Mark/Mark:15/AP3A.241005.015.A1/Mark.241005.001:user/release-keys"

[templates."honor_lab_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LAB-AN00"
device = "Labu"
product = "Labu"
name = "Labu"
marketname = "HONOR Play11T 5G"
fingerprint = "HONOR/Labu/Labu:15/AP3A.241005.015.A1/Labu.241005.001:user/release-keys"

[templates."honor_dvd_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "DVD-AN00"
device = "David"
product = "David"
name = "David"
marketname = "HONOR Power"
fingerprint = "HONOR/David/David:15/AP3A.241005.015.A1/David.241005.001:user/release-keys"

[templates."honor_dvd_an80"]
manufacturer = "HONOR"
brand = "HONOR"
model = "DVD-AN80"
device = "David"
product = "David"
name = "David"
marketname = "HONOR Power 卫星版"
fingerprint = "HONOR/David/David:15/AP3A.241005.015.A1/David.241005.001:user/release-keys"

[templates."honor_edi_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "EDI-AL10"
device = "Edison"
product = "Edison"
name = "Edison"
marketname = "HONOR Note8"
fingerprint = "HONOR/Edison/Edison:15/AP3A.241005.015.A1/Edison.241005.001:user/release-keys"

[templates."honor_rvl_al09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "RVL-AL09"
device = "Ravel"
product = "Ravel"
name = "Ravel"
marketname = "HONOR Note10"
fingerprint = "HONOR/Ravel/Ravel:15/AP3A.241005.015.A1/Ravel.241005.001:user/release-keys"

[templates."honor_h30_t00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "H30-T00"
device = "H30-T00"
product = "H30-T00"
marketname = "HONOR 3C"
fingerprint = "HONOR/H30-T00/H30-T00:15/AP3A.241005.015.A1/H30-T00.241005.001:user/release-keys"

[templates."honor_hol_t00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HOL-T00"
device = "Holly"
product = "Holly"
name = "Holly"
marketname = "HONOR 3C 畅玩版"
fingerprint = "HONOR/Holly/Holly:15/AP3A.241005.015.A1/Holly.241005.001:user/release-keys"

[templates."honor_chm_tl00h"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CHM-TL00H"
device = "Cherrymini"
product = "Cherrymini"
name = "Cherrymini"
marketname = "HONOR 畅玩 4C 移动渠道版"
fingerprint = "HONOR/Cherrymini/Cherrymini:15/AP3A.241005.015.A1/Cherrymini.241005.001:user/release-keys"

[templates."honor_chm_tl00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CHM-TL00"
device = "Cherrymini"
product = "Cherrymini"
name = "Cherrymini"
marketname = "HONOR 畅玩 4C"
fingerprint = "HONOR/Cherrymini/Cherrymini:15/AP3A.241005.015.A1/Cherrymini.241005.001:user/release-keys"

[templates."honor_scl_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "SCL-AL00"
device = "Scale"
product = "Scale"
name = "Scale"
marketname = "HONOR 4A"
fingerprint = "HONOR/Scale/Scale:15/AP3A.241005.015.A1/Scale.241005.001:user/release-keys"

[templates."honor_scl_tl00h"]
manufacturer = "HONOR"
brand = "HONOR"
model = "SCL-TL00H"
device = "Scale"
product = "Scale"
name = "Scale"
marketname = "HONOR 4A 移动渠道版"
fingerprint = "HONOR/Scale/Scale:15/AP3A.241005.015.A1/Scale.241005.001:user/release-keys"

[templates."honor_g621_tl00m"]
manufacturer = "HONOR"
brand = "HONOR"
model = "G621-TL00M"
device = "G621-TL00M"
product = "G621-TL00M"
marketname = "HONOR 畅玩 4 移动渠道版"
fingerprint = "HONOR/G621-TL00M/G621-TL00M:15/AP3A.241005.015.A1/G621-TL00M.241005.001:user/release-keys"

[templates."honor_g621_tl00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "G621-TL00"
device = "G621-TL00"
product = "G621-TL00"
marketname = "HONOR 畅玩 4"
fingerprint = "HONOR/G621-TL00/G621-TL00:15/AP3A.241005.015.A1/G621-TL00.241005.001:user/release-keys"

[templates."honor_nem_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "NEM-AL10"
device = "Nemo"
product = "Nemo"
name = "Nemo"
marketname = "HONOR 畅玩 5C"
fingerprint = "HONOR/Nemo/Nemo:15/AP3A.241005.015.A1/Nemo.241005.001:user/release-keys"

[templates."honor_cam_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CAM-AL00"
device = "Cambodia"
product = "Cambodia"
name = "Cambodia"
marketname = "HONOR 畅玩 5A"
fingerprint = "HONOR/Cambodia/Cambodia:15/AP3A.241005.015.A1/Cambodia.241005.001:user/release-keys"

[templates."honor_cam_tl00h"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CAM-TL00H"
device = "Cambodia"
product = "Cambodia"
name = "Cambodia"
marketname = "HONOR 畅玩 5A 移动渠道版"
fingerprint = "HONOR/Cambodia/Cambodia:15/AP3A.241005.015.A1/Cambodia.241005.001:user/release-keys"

[templates."honor_cam_tl00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CAM-TL00"
device = "Cambodia"
product = "Cambodia"
name = "Cambodia"
marketname = "HONOR 畅玩 5A 移动增强版"
fingerprint = "HONOR/Cambodia/Cambodia:15/AP3A.241005.015.A1/Cambodia.241005.001:user/release-keys"

[templates."honor_cun_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CUN-AL00"
device = "Cancun"
product = "Cancun"
name = "Cancun"
marketname = "HONOR 畅玩 5"
fingerprint = "HONOR/Cancun/Cancun:15/AP3A.241005.015.A1/Cancun.241005.001:user/release-keys"

[templates."honor_dli_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "DLI-AL10"
device = "Delhi"
product = "Delhi"
name = "Delhi"
marketname = "HONOR 畅玩 6A"
fingerprint = "HONOR/Delhi/Delhi:15/AP3A.241005.015.A1/Delhi.241005.001:user/release-keys"

[templates."honor_mya_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "MYA-AL10"
device = "Maya"
product = "Maya"
name = "Maya"
marketname = "HONOR 畅玩 6"
fingerprint = "HONOR/Maya/Maya:15/AP3A.241005.015.A1/Maya.241005.001:user/release-keys"

[templates."honor_lnd_al30"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LND-AL30"
device = "London"
product = "London"
name = "London"
marketname = "HONOR 畅玩 7C"
fingerprint = "HONOR/London/London:15/AP3A.241005.015.A1/London.241005.001:user/release-keys"

[templates."honor_lnd_tl30"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LND-TL30"
device = "London"
product = "London"
name = "London"
marketname = "HONOR 畅玩 7C 移动 4G+"
fingerprint = "HONOR/London/London:15/AP3A.241005.015.A1/London.241005.001:user/release-keys"

[templates."honor_aum_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AUM-AL00"
device = "Atomu"
product = "Atomu"
name = "Atomu"
marketname = "HONOR 畅玩 7A"
fingerprint = "HONOR/Atomu/Atomu:15/AP3A.241005.015.A1/Atomu.241005.001:user/release-keys"

[templates."honor_aum_tl00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AUM-TL00"
device = "Atomu"
product = "Atomu"
name = "Atomu"
marketname = "HONOR 畅玩 7A 移动 4G+"
fingerprint = "HONOR/Atomu/Atomu:15/AP3A.241005.015.A1/Atomu.241005.001:user/release-keys"

[templates."honor_dua_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "DUA-AL00"
device = "Dura"
product = "Dura"
name = "Dura"
marketname = "HONOR 畅玩 7"
fingerprint = "HONOR/Dura/Dura:15/AP3A.241005.015.A1/Dura.241005.001:user/release-keys"

[templates."honor_bkk_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BKK-AL00"
device = "Bangkok"
product = "Bangkok"
name = "Bangkok"
marketname = "HONOR 畅玩 8C"
fingerprint = "HONOR/Bangkok/Bangkok:15/AP3A.241005.015.A1/Bangkok.241005.001:user/release-keys"

[templates."honor_jat_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "JAT-AL00"
device = "Jakarta"
product = "Jakarta"
name = "Jakarta"
marketname = "HONOR 畅玩 8A"
fingerprint = "HONOR/Jakarta/Jakarta:15/AP3A.241005.015.A1/Jakarta.241005.001:user/release-keys"

[templates."honor_ksa_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "KSA-AL00"
device = "Katyusha"
product = "Katyusha"
name = "Katyusha"
marketname = "HONOR 畅玩 8"
fingerprint = "HONOR/Katyusha/Katyusha:15/AP3A.241005.015.A1/Katyusha.241005.001:user/release-keys"

[templates."honor_moa_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "MOA-AL00"
device = "Moana"
product = "Moana"
name = "Moana"
marketname = "HONOR 畅玩 9A"
fingerprint = "HONOR/Moana/Moana:15/AP3A.241005.015.A1/Moana.241005.001:user/release-keys"

[templates."honor_koz_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "KOZ-AL00"
device = "KonanZ"
product = "KonanZ"
name = "KonanZ"
marketname = "HONOR 畅玩 20"
fingerprint = "HONOR/KonanZ/KonanZ:15/AP3A.241005.015.A1/KonanZ.241005.001:user/release-keys"

[templates."honor_koz_al00cm"]
manufacturer = "HONOR"
brand = "HONOR"
model = "KOZ-AL00CM"
device = "KonanZ"
product = "KonanZ"
name = "KonanZ"
marketname = "HONOR 畅玩 20a"
fingerprint = "HONOR/KonanZ/KonanZ:15/AP3A.241005.015.A1/KonanZ.241005.001:user/release-keys"

[templates."honor_hjc_lx9"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HJC-LX9"
device = "JessicaH"
product = "JessicaH"
name = "JessicaH"
marketname = "HONOR 畅玩 20 Pro"
fingerprint = "HONOR/JessicaH/JessicaH:15/AP3A.241005.015.A1/JessicaH.241005.001:user/release-keys"

[templates."honor_vne_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "VNE-AN00"
device = "Vinnie"
product = "Vinnie"
name = "Vinnie"
marketname = "HONOR 畅玩 30 5G"
fingerprint = "HONOR/Vinnie/Vinnie:15/AP3A.241005.015.A1/Vinnie.241005.001:user/release-keys"

[templates."honor_cma_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CMA-AN00"
device = "Carmella"
product = "Carmella"
name = "Carmella"
marketname = "HONOR 畅玩 30 Plus 5G"
fingerprint = "HONOR/Carmella/Carmella:15/AP3A.241005.015.A1/Carmella.241005.001:user/release-keys"

[templates."honor_wdy_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "WDY-AN00"
device = "Woody"
product = "Woody"
name = "Woody"
marketname = "HONOR 畅玩 40 5G"
fingerprint = "HONOR/Woody/Woody:15/AP3A.241005.015.A1/Woody.241005.001:user/release-keys"

[templates."honor_rky_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "RKY-AN00"
device = "Rocky"
product = "Rocky"
name = "Rocky"
marketname = "HONOR 畅玩 40 Plus 5G"
fingerprint = "HONOR/Rocky/Rocky:15/AP3A.241005.015.A1/Rocky.241005.001:user/release-keys"

[templates."honor_log_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "LOG-AN00"
device = "Logan"
product = "Logan"
name = "Logan"
marketname = "HONOR 畅玩 70 Plus 5G"
fingerprint = "HONOR/Logan/Logan:15/AP3A.241005.015.A1/Logan.241005.001:user/release-keys"

[templates."honor_nla_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "NLA-AL00"
device = "Nala"
product = "Nala"
name = "Nala"
marketname = "HONOR 畅玩 70C"
fingerprint = "HONOR/Nala/Nala:15/AP3A.241005.015.A1/Nala.241005.001:user/release-keys"

[templates."honor_s8_701w"]
manufacturer = "HONOR"
brand = "HONOR"
model = "S8-701w"
device = "S8-701w"
product = "S8-701w"
marketname = "HONOR 平板"
fingerprint = "HONOR/S8-701w/S8-701w:15/AP3A.241005.015.A1/S8-701w.241005.001:user/release-keys"

[templates."honor_t1_821w"]
manufacturer = "HONOR"
brand = "HONOR"
model = "T1-821w"
device = "T1-821w"
product = "T1-821w"
marketname = "HONOR 平板优享版"
fingerprint = "HONOR/T1-821w/T1-821w:15/AP3A.241005.015.A1/T1-821w.241005.001:user/release-keys"

[templates."honor_jdn_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "JDN-W09"
device = "Jordan"
product = "Jordan"
name = "Jordan"
marketname = "HONOR 平板 2"
fingerprint = "HONOR/Jordan/Jordan:15/AP3A.241005.015.A1/Jordan.241005.001:user/release-keys"

[templates."honor_ags2_w09hn"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AGS2-W09HN"
device = "Agassi2"
product = "Agassi2"
name = "Agassi2"
marketname = "HONOR 平板 5 10.1 英寸"
fingerprint = "HONOR/Agassi2/Agassi2:15/AP3A.241005.015.A1/Agassi2.241005.001:user/release-keys"

[templates."honor_jdn2_w09hn"]
manufacturer = "HONOR"
brand = "HONOR"
model = "JDN2-W09HN"
device = "Jordan2"
product = "Jordan2"
name = "Jordan2"
marketname = "HONOR 平板 5 8 英寸"
fingerprint = "HONOR/Jordan2/Jordan2:15/AP3A.241005.015.A1/Jordan2.241005.001:user/release-keys"

[templates."honor_ags3_w09hn"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AGS3-W09HN"
device = "Agassi3"
product = "Agassi3"
name = "Agassi3"
marketname = "HONOR 平板 6 10.1 英寸"
fingerprint = "HONOR/Agassi3/Agassi3:15/AP3A.241005.015.A1/Agassi3.241005.001:user/release-keys"

[templates."honor_agm3_w09hn"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AGM3-W09HN"
device = "Agassi3M"
product = "Agassi3M"
name = "Agassi3M"
marketname = "HONOR 平板 7 10.1 英寸"
fingerprint = "HONOR/Agassi3M/Agassi3M:15/AP3A.241005.015.A1/Agassi3M.241005.001:user/release-keys"

[templates."honor_hey_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HEY-W09"
device = "Hendry"
product = "Hendry"
name = "Hendry"
marketname = "HONOR 平板 8 12 英寸"
fingerprint = "HONOR/Hendry/Hendry:15/AP3A.241005.015.A1/Hendry.241005.001:user/release-keys"

[templates."honor_hey2_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HEY2-W09"
device = "Hendry2"
product = "Hendry2"
name = "Hendry2"
marketname = "HONOR 平板 9 12.1 英寸"
fingerprint = "HONOR/Hendry2/Hendry2:15/AP3A.241005.015.A1/Hendry2.241005.001:user/release-keys"

[templates."honor_hey2_w19"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HEY2-W19"
device = "Hendry2"
product = "Hendry2"
name = "Hendry2"
marketname = "HONOR 平板 9 柔光版 12.1 英寸"
fingerprint = "HONOR/Hendry2/Hendry2:15/AP3A.241005.015.A1/Hendry2.241005.001:user/release-keys"

[templates."honor_rod_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ROD-W09"
device = "Rolland"
product = "Rolland"
name = "Rolland"
marketname = "HONOR 平板 9 Pro 12.1 英寸"
fingerprint = "HONOR/Rolland/Rolland:15/AP3A.241005.015.A1/Rolland.241005.001:user/release-keys"

[templates."honor_rod_w19"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ROD-W19"
device = "Rolland"
product = "Rolland"
name = "Rolland"
marketname = "HONOR 平板 9 Pro 柔光版 12.1 英寸"
fingerprint = "HONOR/Rolland/Rolland:15/AP3A.241005.015.A1/Rolland.241005.001:user/release-keys"

[templates."honor_hey3_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HEY3-W00"
device = "Hendry3"
product = "Hendry3"
name = "Hendry3"
marketname = "HONOR 平板 10 12.1 英寸"
fingerprint = "HONOR/Hendry3/Hendry3:15/AP3A.241005.015.A1/Hendry3.241005.001:user/release-keys"

[templates."honor_hey3_w10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HEY3-W10"
device = "Hendry3"
product = "Hendry3"
name = "Hendry3"
marketname = "HONOR 平板 10 柔光版 12.1 英寸"
fingerprint = "HONOR/Hendry3/Hendry3:15/AP3A.241005.015.A1/Hendry3.241005.001:user/release-keys"

[templates."honor_rol_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ROL-W00"
device = "Rowling"
product = "Rowling"
name = "Rowling"
marketname = "HONOR 平板 10 Pro 11.5 英寸"
fingerprint = "HONOR/Rowling/Rowling:15/AP3A.241005.015.A1/Rowling.241005.001:user/release-keys"

[templates."honor_rol_w10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ROL-W10"
device = "Rowling"
product = "Rowling"
name = "Rowling"
marketname = "HONOR 平板 10 Pro 柔光版 11.5 英寸"
fingerprint = "HONOR/Rowling/Rowling:15/AP3A.241005.015.A1/Rowling.241005.001:user/release-keys"

[templates."honor_hey4_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HEY4-W09"
device = "Hendry4"
product = "Hendry4"
name = "Hendry4"
marketname = "HONOR 平板 20 12.1 英寸"
fingerprint = "HONOR/Hendry4/Hendry4:15/AP3A.241005.015.A1/Hendry4.241005.001:user/release-keys"

[templates."honor_hey4_w19"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HEY4-W19"
device = "Hendry4"
product = "Hendry4"
name = "Hendry4"
marketname = "HONOR 平板 20 柔光版 12.1 英寸"
fingerprint = "HONOR/Hendry4/Hendry4:15/AP3A.241005.015.A1/Hendry4.241005.001:user/release-keys"

[templates."honor_krj_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "KRJ-W09"
device = "Karajan"
product = "Karajan"
name = "Karajan"
marketname = "HONOR 平板 V6 10.4 英寸"
fingerprint = "HONOR/Karajan/Karajan:15/AP3A.241005.015.A1/Karajan.241005.001:user/release-keys"

[templates."honor_krj2_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "KRJ2-W09"
device = "Karajan2"
product = "Karajan2"
name = "Karajan2"
marketname = "HONOR 平板 V7 10.4 英寸"
fingerprint = "HONOR/Karajan2/Karajan2:15/AP3A.241005.015.A1/Karajan2.241005.001:user/release-keys"

[templates."honor_brt_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BRT-W09"
device = "Britten"
product = "Britten"
name = "Britten"
marketname = "HONOR 平板 V7 Pro 11 英寸"
fingerprint = "HONOR/Britten/Britten:15/AP3A.241005.015.A1/Britten.241005.001:user/release-keys"

[templates."honor_gdi_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "GDI-W09"
device = "Gaudi"
product = "Gaudi"
name = "Gaudi"
marketname = "HONOR 平板 MagicPad 13 英寸"
fingerprint = "HONOR/Gaudi/Gaudi:15/AP3A.241005.015.A1/Gaudi.241005.001:user/release-keys"

[templates."honor_rod2_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ROD2-W09"
device = "Rolland2"
product = "Rolland2"
name = "Rolland2"
marketname = "HONOR 平板 MagicPad 2 12.3 英寸"
fingerprint = "HONOR/Rolland2/Rolland2:15/AP3A.241005.015.A1/Rolland2.241005.001:user/release-keys"

[templates."honor_cga_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CGA-W00"
device = "Changan"
product = "Changan"
name = "Changan"
marketname = "HONOR 平板 MagicPad 3 13.3 英寸"
fingerprint = "HONOR/Changan/Changan:15/AP3A.241005.015.A1/Changan.241005.001:user/release-keys"

[templates."honor_cgl_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CGL-W00"
device = "Changle"
product = "Changle"
name = "Changle"
marketname = "HONOR MagicPad 3 12.5 英寸"
fingerprint = "HONOR/Changle/Changle:15/AP3A.241005.015.A1/Changle.241005.001:user/release-keys"

[templates."honor_ylp_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "YLP-W00"
device = "YongleP"
product = "YongleP"
name = "YongleP"
marketname = "HONOR MagicPad 3 Pro 13.3 英寸"
fingerprint = "HONOR/YongleP/YongleP:15/AP3A.241005.015.A1/YongleP.241005.001:user/release-keys"

[templates."honor_yle_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "YLE-W09"
device = "Yongle"
product = "Yongle"
name = "Yongle"
marketname = "HONOR MagicPad 3 Pro 12.3 英寸"
fingerprint = "HONOR/Yongle/Yongle:15/AP3A.241005.015.A1/Yongle.241005.001:user/release-keys"

[templates."honor_mla_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "MLA-W09"
device = "Mulan"
product = "Mulan"
name = "Mulan"
marketname = "HONOR MagicPad 4 12.1 英寸"
fingerprint = "HONOR/Mulan/Mulan:15/AP3A.241005.015.A1/Mulan.241005.001:user/release-keys"

[templates."honor_rol_w60"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ROL-W60"
device = "Rowling"
product = "Rowling"
name = "Rowling"
marketname = "HONOR 平板 GT 11.5 英寸"
fingerprint = "HONOR/Rowling/Rowling:15/AP3A.241005.015.A1/Rowling.241005.001:user/release-keys"

[templates."honor_rod2_w69"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ROD2-W69"
device = "Rolland2"
product = "Rolland2"
name = "Rolland2"
marketname = "HONOR 平板 GT Pro 12.3 英寸"
fingerprint = "HONOR/Rolland2/Rolland2:15/AP3A.241005.015.A1/Rolland2.241005.001:user/release-keys"

[templates."honor_chg_w60"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CHG-W60"
device = "Changle"
product = "Changle"
name = "Changle"
marketname = "HONOR 平板 GT2 Pro 12.5 英寸"
fingerprint = "HONOR/Changle/Changle:15/AP3A.241005.015.A1/Changle.241005.001:user/release-keys"

[templates."honor_hes_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HES-W00"
device = "Hesse"
product = "Hesse"
name = "Hesse"
marketname = "HONOR WIN 平板"
fingerprint = "HONOR/Hesse/Hesse:15/AP3A.241005.015.A1/Hesse.241005.001:user/release-keys"

[templates."honor_7d_501u"]
manufacturer = "HONOR"
brand = "HONOR"
model = "7D-501u"
device = "7D-501u"
product = "7D-501u"
marketname = "HONOR X1"
fingerprint = "HONOR/7D-501u/7D-501u:15/AP3A.241005.015.A1/7D-501u.241005.001:user/release-keys"

[templates."honor_gem_703l"]
manufacturer = "HONOR"
brand = "HONOR"
model = "GEM-703L"
device = "GEM-703L"
product = "GEM-703L"
marketname = "HONOR X2"
fingerprint = "HONOR/GEM-703L/GEM-703L:15/AP3A.241005.015.A1/GEM-703L.241005.001:user/release-keys"

[templates."honor_t1_701u"]
manufacturer = "HONOR"
brand = "HONOR"
model = "T1-701u"
device = "T1-701u"
product = "T1-701u"
marketname = "HONOR 畅玩平板"
fingerprint = "HONOR/T1-701u/T1-701u:15/AP3A.241005.015.A1/T1-701u.241005.001:user/release-keys"

[templates."honor_t1_701ua"]
manufacturer = "HONOR"
brand = "HONOR"
model = "T1-701ua"
device = "T1-701ua"
product = "T1-701ua"
marketname = "HONOR 畅玩平板优享版"
fingerprint = "HONOR/T1-701ua/T1-701ua:15/AP3A.241005.015.A1/T1-701ua.241005.001:user/release-keys"

[templates."honor_t1_a21w"]
manufacturer = "HONOR"
brand = "HONOR"
model = "T1-A21w"
device = "T1-A21w"
product = "T1-A21w"
marketname = "HONOR 畅玩平板 note"
fingerprint = "HONOR/T1-A21w/T1-A21w:15/AP3A.241005.015.A1/T1-A21w.241005.001:user/release-keys"

[templates."honor_kob_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "KOB-W09"
device = "Kobe"
product = "Kobe"
name = "Kobe"
marketname = "HONOR 畅玩平板 2 8 英寸"
fingerprint = "HONOR/Kobe/Kobe:15/AP3A.241005.015.A1/Kobe.241005.001:user/release-keys"

[templates."honor_ags_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AGS-W09"
device = "Agassi"
product = "Agassi"
name = "Agassi"
marketname = "HONOR 畅玩平板 2 9.6 英寸"
fingerprint = "HONOR/Agassi/Agassi:15/AP3A.241005.015.A1/Agassi.241005.001:user/release-keys"

[templates."honor_bg2_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "BG2-W09"
device = "Baggio2"
product = "Baggio2"
name = "Baggio2"
marketname = "HONOR 畅玩平板 2 7 英寸"
fingerprint = "HONOR/Baggio2/Baggio2:15/AP3A.241005.015.A1/Baggio2.241005.001:user/release-keys"

[templates."honor_agr_w09hn"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AGR-W09HN"
device = "AgassiR"
product = "AgassiR"
name = "AgassiR"
marketname = "HONOR 平板 X6 9.7 英寸"
fingerprint = "HONOR/AgassiR/AgassiR:15/AP3A.241005.015.A1/AgassiR.241005.001:user/release-keys"

[templates."honor_kob2_w09hn"]
manufacturer = "HONOR"
brand = "HONOR"
model = "KOB2-W09HN"
device = "Kobe2"
product = "Kobe2"
name = "Kobe2"
marketname = "HONOR 平板 X7 8 英寸"
fingerprint = "HONOR/Kobe2/Kobe2:15/AP3A.241005.015.A1/Kobe2.241005.001:user/release-keys"

[templates."honor_eln_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ELN-W09"
device = "Eileen"
product = "Eileen"
name = "Eileen"
marketname = "HONOR 平板 X8 Pro 11.5 英寸"
fingerprint = "HONOR/Eileen/Eileen:15/AP3A.241005.015.A1/Eileen.241005.001:user/release-keys"

[templates."honor_ndl_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "NDL-W09"
device = "Nadal"
product = "Nadal"
name = "Nadal"
marketname = "HONOR 平板 X9 11 英寸"
fingerprint = "HONOR/Nadal/Nadal:15/AP3A.241005.015.A1/Nadal.241005.001:user/release-keys"

[templates."honor_eln2_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ELN2-W09"
device = "Eileen2"
product = "Eileen2"
name = "Eileen2"
marketname = "HONOR 平板 X9 Pro 11.5 英寸"
fingerprint = "HONOR/Eileen2/Eileen2:15/AP3A.241005.015.A1/Eileen2.241005.001:user/release-keys"

[templates."honor_ndl2_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "NDL2-W09"
device = "Nadal2"
product = "Nadal2"
name = "Nadal2"
marketname = "HONOR 平板 X10 11 英寸"
fingerprint = "HONOR/Nadal2/Nadal2:15/AP3A.241005.015.A1/Nadal2.241005.001:user/release-keys"

[templates."honor_ele2_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ELE2-W00"
device = "Eileen2"
product = "Eileen2"
name = "Eileen2"
marketname = "HONOR 平板 X10 Pro 11.5 英寸"
fingerprint = "HONOR/Eileen2/Eileen2:15/AP3A.241005.015.A1/Eileen2.241005.001:user/release-keys"

[templates."honor_ele2_w19"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ELE2-W19"
device = "Eileen2"
product = "Eileen2"
name = "Eileen2"
marketname = "HONOR 平板 X10 Pro 柔光版 11.5 英寸"
fingerprint = "HONOR/Eileen2/Eileen2:15/AP3A.241005.015.A1/Eileen2.241005.001:user/release-keys"

[templates."honor_yag_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "YAG-W09"
device = "Yaoming"
product = "Yaoming"
name = "Yaoming"
marketname = "HONOR 平板 X10 Pro Max 13 英寸"
fingerprint = "HONOR/Yaoming/Yaoming:15/AP3A.241005.015.A1/Yaoming.241005.001:user/release-keys"

[templates."honor_yag_w19"]
manufacturer = "HONOR"
brand = "HONOR"
model = "YAG-W19"
device = "Yaoming"
product = "Yaoming"
name = "Yaoming"
marketname = "HONOR 平板 X10 Pro Max 柔光版 13 英寸"
fingerprint = "HONOR/Yaoming/Yaoming:15/AP3A.241005.015.A1/Yaoming.241005.001:user/release-keys"

[templates."honor_onl_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "ONL-W09"
device = "Oneal"
product = "Oneal"
name = "Oneal"
marketname = "HONOR 平板 X10 Mini 9.7 英寸"
fingerprint = "HONOR/Oneal/Oneal:15/AP3A.241005.015.A1/Oneal.241005.001:user/release-keys"

[templates."honor_hdn_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HDN-W09"
device = "Haydn"
product = "Haydn"
name = "Haydn"
marketname = "HONOR Waterplay 10.1 英寸"
fingerprint = "HONOR/Haydn/Haydn:15/AP3A.241005.015.A1/Haydn.241005.001:user/release-keys"

[templates."honor_hdl_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HDL-W09"
device = "Handel"
product = "Handel"
name = "Handel"
marketname = "HONOR Waterplay 8 英寸"
fingerprint = "HONOR/Handel/Handel:15/AP3A.241005.015.A1/Handel.241005.001:user/release-keys"

[templates."honor_agm_w09hn"]
manufacturer = "HONOR"
brand = "HONOR"
model = "AGM-W09HN"
device = "AgassiRM"
product = "AgassiRM"
name = "AgassiRM"
marketname = "HONOR 平板 Z3 9.7 英寸"
fingerprint = "HONOR/AgassiRM/AgassiRM:15/AP3A.241005.015.A1/AgassiRM.241005.001:user/release-keys"

[templates."honor_ndl_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "NDL-W00"
device = "Nadal"
product = "Nadal"
name = "Nadal"
marketname = "HONOR 平板 Z5a 11 英寸"
fingerprint = "HONOR/Nadal/Nadal:15/AP3A.241005.015.A1/Nadal.241005.001:user/release-keys"

[templates."honor_hey2_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HEY2-AN00"
device = "Hendry2"
product = "Hendry2"
name = "Hendry2"
marketname = "HONOR 平板 Z7 12.1 英寸"
fingerprint = "HONOR/Hendry2/Hendry2:15/AP3A.241005.015.A1/Hendry2.241005.001:user/release-keys"

[templates."honor_frd_wdg9"]
manufacturer = "HONOR"
brand = "HONOR"
model = "FRD-WDG9"
device = "FRD-WDG9"
product = "FRD-WDG9"
marketname = "HONOR 猎人游戏本 V700 i5"
fingerprint = "HONOR/FRD-WDG9/FRD-WDG9:15/AP3A.241005.015.A1/FRD-WDG9.241005.001:user/release-keys"

[templates."honor_frd_wfd9"]
manufacturer = "HONOR"
brand = "HONOR"
model = "FRD-WFD9"
device = "FRD-WFD9"
product = "FRD-WFD9"
marketname = "HONOR 猎人游戏本 V700 i7"
fingerprint = "HONOR/FRD-WFD9/FRD-WFD9:15/AP3A.241005.015.A1/FRD-WFD9.241005.001:user/release-keys"

[templates."honor_nwb_g"]
manufacturer = "HONOR"
brand = "HONOR"
model = "NWB-G"
device = "NWB-G"
product = "NWB-G"
marketname = "HONOR WIN 游戏本 H7"
fingerprint = "HONOR/NWB-G/NWB-G:15/AP3A.241005.015.A1/NWB-G.241005.001:user/release-keys"

[templates."honor_nwc2_g"]
manufacturer = "HONOR"
brand = "HONOR"
model = "NWC2-G"
device = "NWC2-G"
product = "NWC2-G"
marketname = "HONOR WIN 游戏本 H9"
fingerprint = "HONOR/NWC2-G/NWC2-G:15/AP3A.241005.015.A1/NWC2-G.241005.001:user/release-keys"

[templates."honor_cgn_a00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "CGN-A00"
device = "CGN-A00"
product = "CGN-A00"
marketname = "HONOR 观影眼镜"
fingerprint = "HONOR/CGN-A00/CGN-A00:15/AP3A.241005.015.A1/CGN-A00.241005.001:user/release-keys"

[templates."honor_u8860"]
manufacturer = "HONOR"
brand = "HONOR"
model = "U8860"
device = "U8860"
product = "U8860"
marketname = "HONOR 1"
fingerprint = "HONOR/U8860/U8860:15/AP3A.241005.015.A1/U8860.241005.001:user/release-keys"

[templates."honor_t8950"]
manufacturer = "HONOR"
brand = "HONOR"
model = "T8950"
device = "T8950"
product = "T8950"
marketname = "HONOR 1 Plus"
fingerprint = "HONOR/T8950/T8950:15/AP3A.241005.015.A1/T8950.241005.001:user/release-keys"

[templates."honor_u9508"]
manufacturer = "HONOR"
brand = "HONOR"
model = "U9508"
device = "U9508"
product = "U9508"
marketname = "HONOR 四核爱享版"
fingerprint = "HONOR/U9508/U9508:15/AP3A.241005.015.A1/U9508.241005.001:user/release-keys"

[templates."honor_hn3_u01"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HN3-U01"
device = "HN3-U01"
product = "HN3-U01"
marketname = "HONOR 3 outdoor"
fingerprint = "HONOR/HN3-U01/HN3-U01:15/AP3A.241005.015.A1/HN3-U01.241005.001:user/release-keys"

[templates."huawei_huawei_mt1_t00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MT1-T00"
device = "HUAWEI MT1-T00"
product = "HUAWEI MT1-T00"
marketname = "HUAWEI Ascend Mate"
fingerprint = "HUAWEI/HUAWEI MT1-T00/HUAWEI MT1-T00:15/AP3A.241005.015.A1/HUAWEIMT1-T00.241005.001:user/release-keys"

[templates."huawei_huawei_mt2_u071"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MT2-U071"
device = "HUAWEI MT2-U071"
product = "HUAWEI MT2-U071"
marketname = "HUAWEI Ascend Mate 2"
fingerprint = "HUAWEI/HUAWEI MT2-U071/HUAWEI MT2-U071:15/AP3A.241005.015.A1/HUAWEIMT2-U071.241005.001:user/release-keys"

[templates."huawei_huawei_mt7_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MT7-TL00"
device = "Jazz"
product = "Jazz"
name = "Jazz"
marketname = "HUAWEI Ascend Mate 7"
fingerprint = "HUAWEI/Jazz/Jazz:15/AP3A.241005.015.A1/Jazz.241005.001:user/release-keys"

[templates."huawei_huawei_crr_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI CRR-TL00"
device = "Carrera"
product = "Carrera"
name = "Carrera"
marketname = "HUAWEI Mate S 移动臻享版"
fingerprint = "HUAWEI/Carrera/Carrera:15/AP3A.241005.015.A1/Carrera.241005.001:user/release-keys"

[templates."huawei_huawei_crr_ul00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI CRR-UL00"
device = "Carrera"
product = "Carrera"
name = "Carrera"
marketname = "HUAWEI Mate S 双 4G 臻享版"
fingerprint = "HUAWEI/Carrera/Carrera:15/AP3A.241005.015.A1/Carrera.241005.001:user/release-keys"

[templates."huawei_huawei_crr_ul20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI CRR-UL20"
device = "Carrera"
product = "Carrera"
name = "Carrera"
marketname = "HUAWEI Mate S 双 4G 臻逸版"
fingerprint = "HUAWEI/Carrera/Carrera:15/AP3A.241005.015.A1/Carrera.241005.001:user/release-keys"

[templates."huawei_huawei_crr_cl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI CRR-CL00"
device = "Carrera"
product = "Carrera"
name = "Carrera"
marketname = "HUAWEI Mate S 电信臻享版"
fingerprint = "HUAWEI/Carrera/Carrera:15/AP3A.241005.015.A1/Carrera.241005.001:user/release-keys"

[templates."huawei_huawei_crr_cl20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI CRR-CL20"
device = "Carrera"
product = "Carrera"
name = "Carrera"
marketname = "HUAWEI Mate S 电信臻逸版"
fingerprint = "HUAWEI/Carrera/Carrera:15/AP3A.241005.015.A1/Carrera.241005.001:user/release-keys"

[templates."huawei_huawei_nxt_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI NXT-AL10"
device = "Next"
product = "Next"
name = "Next"
marketname = "HUAWEI Mate 8"
fingerprint = "HUAWEI/Next/Next:15/AP3A.241005.015.A1/Next.241005.001:user/release-keys"

[templates."huawei_mha_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MHA-AL00"
device = "Manhattan"
product = "Manhattan"
name = "Manhattan"
marketname = "HUAWEI Mate 9"
fingerprint = "HUAWEI/Manhattan/Manhattan:15/AP3A.241005.015.A1/Manhattan.241005.001:user/release-keys"

[templates."huawei_lon_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LON-AL00"
device = "Longland"
product = "Longland"
name = "Longland"
marketname = "HUAWEI Mate 9 Pro"
fingerprint = "HUAWEI/Longland/Longland:15/AP3A.241005.015.A1/Longland.241005.001:user/release-keys"

[templates."huawei_alp_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ALP-AL00"
device = "Alps"
product = "Alps"
name = "Alps"
marketname = "HUAWEI Mate 10"
fingerprint = "HUAWEI/Alps/Alps:15/AP3A.241005.015.A1/Alps.241005.001:user/release-keys"

[templates."huawei_bla_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BLA-AL00"
device = "Blanc"
product = "Blanc"
name = "Blanc"
marketname = "HUAWEI Mate 10 Pro"
fingerprint = "HUAWEI/Blanc/Blanc:15/AP3A.241005.015.A1/Blanc.241005.001:user/release-keys"

[templates."huawei_neo_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "NEO-AL00"
device = "Neo"
product = "Neo"
name = "Neo"
marketname = "HUAWEI Mate RS 保时捷设计"
fingerprint = "HUAWEI/Neo/Neo:15/AP3A.241005.015.A1/Neo.241005.001:user/release-keys"

[templates."huawei_hma_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HMA-AL00"
device = "Hima"
product = "Hima"
name = "Hima"
marketname = "HUAWEI Mate 20"
fingerprint = "HUAWEI/Hima/Hima:15/AP3A.241005.015.A1/Hima.241005.001:user/release-keys"

[templates."huawei_lya_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LYA-AL00"
device = "Laya"
product = "Laya"
name = "Laya"
marketname = "HUAWEI Mate 20 Pro"
fingerprint = "HUAWEI/Laya/Laya:15/AP3A.241005.015.A1/Laya.241005.001:user/release-keys"

[templates."huawei_evr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "EVR-AL00"
device = "Ever"
product = "Ever"
name = "Ever"
marketname = "HUAWEI Mate 20 X"
fingerprint = "HUAWEI/Ever/Ever:15/AP3A.241005.015.A1/Ever.241005.001:user/release-keys"

[templates."huawei_evr_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "EVR-AN00"
device = "Ever"
product = "Ever"
name = "Ever"
marketname = "HUAWEI Mate 20 X 5G"
fingerprint = "HUAWEI/Ever/Ever:15/AP3A.241005.015.A1/Ever.241005.001:user/release-keys"

[templates."huawei_lya_al00p"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LYA-AL00P"
device = "Laya"
product = "Laya"
name = "Laya"
marketname = "HUAWEI Mate 20 RS 保时捷设计"
fingerprint = "HUAWEI/Laya/Laya:15/AP3A.241005.015.A1/Laya.241005.001:user/release-keys"

[templates."huawei_tas_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "TAS-AL00"
device = "Taurus"
product = "Taurus"
name = "Taurus"
marketname = "HUAWEI Mate 30"
fingerprint = "HUAWEI/Taurus/Taurus:15/AP3A.241005.015.A1/Taurus.241005.001:user/release-keys"

[templates."huawei_tas_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "TAS-AN00"
device = "Taurus"
product = "Taurus"
name = "Taurus"
marketname = "HUAWEI Mate 30 5G"
fingerprint = "HUAWEI/Taurus/Taurus:15/AP3A.241005.015.A1/Taurus.241005.001:user/release-keys"

[templates."huawei_lio_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LIO-AL00"
device = "Lion"
product = "Lion"
name = "Lion"
marketname = "HUAWEI Mate 30 Pro"
fingerprint = "HUAWEI/Lion/Lion:15/AP3A.241005.015.A1/Lion.241005.001:user/release-keys"

[templates."huawei_lio_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LIO-AN00"
device = "Lion"
product = "Lion"
name = "Lion"
marketname = "HUAWEI Mate 30 Pro 5G"
fingerprint = "HUAWEI/Lion/Lion:15/AP3A.241005.015.A1/Lion.241005.001:user/release-keys"

[templates."huawei_lio_an00m"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LIO-AN00M"
device = "Lion"
product = "Lion"
name = "Lion"
marketname = "HUAWEI Mate 30E Pro 5G"
fingerprint = "HUAWEI/Lion/Lion:15/AP3A.241005.015.A1/Lion.241005.001:user/release-keys"

[templates."huawei_lio_an00p"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LIO-AN00P"
device = "Lion"
product = "Lion"
name = "Lion"
marketname = "HUAWEI Mate 30 RS 保时捷设计"
fingerprint = "HUAWEI/Lion/Lion:15/AP3A.241005.015.A1/Lion.241005.001:user/release-keys"

[templates."huawei_oce_an10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "OCE-AN10"
device = "Ocean"
product = "Ocean"
name = "Ocean"
marketname = "HUAWEI Mate 40 5G"
fingerprint = "HUAWEI/Ocean/Ocean:15/AP3A.241005.015.A1/Ocean.241005.001:user/release-keys"

[templates."huawei_oce_an50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "OCE-AN50"
device = "Ocean"
product = "Ocean"
name = "Ocean"
marketname = "HUAWEI Mate 40E 5G"
fingerprint = "HUAWEI/Ocean/Ocean:15/AP3A.241005.015.A1/Ocean.241005.001:user/release-keys"

[templates."huawei_oce_al50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "OCE-AL50"
device = "Ocean"
product = "Ocean"
name = "Ocean"
marketname = "HUAWEI Mate 40E 4G"
fingerprint = "HUAWEI/Ocean/Ocean:15/AP3A.241005.015.A1/Ocean.241005.001:user/release-keys"

[templates."huawei_noh_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "NOH-AN00"
device = "Noah"
product = "Noah"
name = "Noah"
marketname = "HUAWEI Mate 40 Pro 5G"
fingerprint = "HUAWEI/Noah/Noah:15/AP3A.241005.015.A1/Noah.241005.001:user/release-keys"

[templates."huawei_noh_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "NOH-AL00"
device = "Noah"
product = "Noah"
name = "Noah"
marketname = "HUAWEI Mate 40 Pro 4G"
fingerprint = "HUAWEI/Noah/Noah:15/AP3A.241005.015.A1/Noah.241005.001:user/release-keys"

[templates."huawei_noh_an50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "NOH-AN50"
device = "Noah"
product = "Noah"
name = "Noah"
marketname = "HUAWEI Mate 40E Pro 5G"
fingerprint = "HUAWEI/Noah/Noah:15/AP3A.241005.015.A1/Noah.241005.001:user/release-keys"

[templates."huawei_nop_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "NOP-AN00"
device = "NoahP"
product = "NoahP"
name = "NoahP"
marketname = "HUAWEI Mate 40 Pro+ 5G"
fingerprint = "HUAWEI/NoahP/NoahP:15/AP3A.241005.015.A1/NoahP.241005.001:user/release-keys"

[templates."huawei_cet_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CET-AL00"
device = "Cetus"
product = "Cetus"
name = "Cetus"
marketname = "HUAWEI Mate 50"
fingerprint = "HUAWEI/Cetus/Cetus:15/AP3A.241005.015.A1/Cetus.241005.001:user/release-keys"

[templates."huawei_cet_al60"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CET-AL60"
device = "Cetus-"
product = "Cetus-"
name = "Cetus-"
marketname = "HUAWEI Mate 50E"
fingerprint = "HUAWEI/Cetus-/Cetus-:15/AP3A.241005.015.A1/Cetus-.241005.001:user/release-keys"

[templates."huawei_dco_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DCO-AL00"
device = "Draco"
product = "Draco"
name = "Draco"
marketname = "HUAWEI Mate 50 Pro"
fingerprint = "HUAWEI/Draco/Draco:15/AP3A.241005.015.A1/Draco.241005.001:user/release-keys"

[templates."huawei_bra_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BRA-AL00"
device = "Barry"
product = "Barry"
name = "Barry"
marketname = "HUAWEI Mate 60"
fingerprint = "HUAWEI/Barry/Barry:15/AP3A.241005.015.A1/Barry.241005.001:user/release-keys"

[templates."huawei_aln_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ALN-AL00"
device = "Allen"
product = "Allen"
name = "Allen"
marketname = "HUAWEI Mate 60 Pro"
fingerprint = "HUAWEI/Allen/Allen:15/AP3A.241005.015.A1/Allen.241005.001:user/release-keys"

[templates."huawei_aln_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ALN-AL10"
device = "Allen"
product = "Allen"
name = "Allen"
marketname = "HUAWEI Mate 60 Pro+"
fingerprint = "HUAWEI/Allen/Allen:15/AP3A.241005.015.A1/Allen.241005.001:user/release-keys"

[templates."huawei_cls_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CLS-AL00"
device = "Celestial"
product = "Celestial"
name = "Celestial"
marketname = "HUAWEI Mate 70"
fingerprint = "HUAWEI/Celestial/Celestial:15/AP3A.241005.015.A1/Celestial.241005.001:user/release-keys"

[templates."huawei_plr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PLR-AL00"
device = "Pillar"
product = "Pillar"
name = "Pillar"
marketname = "HUAWEI Mate 70 Pro"
fingerprint = "HUAWEI/Pillar/Pillar:15/AP3A.241005.015.A1/Pillar.241005.001:user/release-keys"

[templates."huawei_plr_al50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PLR-AL50"
device = "Pillar"
product = "Pillar"
name = "Pillar"
marketname = "HUAWEI Mate 70 Pro 优享版"
fingerprint = "HUAWEI/Pillar/Pillar:15/AP3A.241005.015.A1/Pillar.241005.001:user/release-keys"

[templates."huawei_pla_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PLA-AL10"
device = "PLA-AL10"
product = "PLA-AL10"
marketname = "HUAWEI Mate 70 Pro+"
fingerprint = "HUAWEI/PLA-AL10/PLA-AL10:15/AP3A.241005.015.A1/PLA-AL10.241005.001:user/release-keys"

[templates."huawei_plu_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PLU-AL10"
device = "PillarU"
product = "PillarU"
name = "PillarU"
marketname = "HUAWEI Mate 70 RS 非凡大师"
fingerprint = "HUAWEI/PillarU/PillarU:15/AP3A.241005.015.A1/PillarU.241005.001:user/release-keys"

[templates."huawei_sup_al90"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SUP-AL90"
device = "Superman"
product = "Superman"
name = "Superman"
marketname = "HUAWEI Mate 70 Air"
fingerprint = "HUAWEI/Superman/Superman:15/AP3A.241005.015.A1/Superman.241005.001:user/release-keys"

[templates."huawei_vyg_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "VYG-AL00"
device = "Voyager"
product = "Voyager"
name = "Voyager"
marketname = "HUAWEI Mate 80"
fingerprint = "HUAWEI/Voyager/Voyager:15/AP3A.241005.015.A1/Voyager.241005.001:user/release-keys"

[templates."huawei_sgt_al50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SGT-AL50"
device = "Sagittarius"
product = "Sagittarius"
name = "Sagittarius"
marketname = "HUAWEI Mate 80 Pro"
fingerprint = "HUAWEI/Sagittarius/Sagittarius:15/AP3A.241005.015.A1/Sagittarius.241005.001:user/release-keys"

[templates."huawei_sgt_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SGT-AL10"
device = "Sagittarius"
product = "Sagittarius"
name = "Sagittarius"
marketname = "HUAWEI Mate 80 Pro Max"
fingerprint = "HUAWEI/Sagittarius/Sagittarius:15/AP3A.241005.015.A1/Sagittarius.241005.001:user/release-keys"

[templates."huawei_sgu_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SGU-AL10"
device = "SagittariusU"
product = "SagittariusU"
name = "SagittariusU"
marketname = "HUAWEI Mate 80 RS 非凡大师"
fingerprint = "HUAWEI/SagittariusU/SagittariusU:15/AP3A.241005.015.A1/SagittariusU.241005.001:user/release-keys"

[templates."huawei_hls_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HLS-AL00"
device = "Halos"
product = "Halos"
name = "Halos"
marketname = "HUAWEI Mate 90"
fingerprint = "HUAWEI/Halos/Halos:15/AP3A.241005.015.A1/Halos.241005.001:user/release-keys"

[templates."huawei_cms_al20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CMS-AL20"
device = "Cosmos"
product = "Cosmos"
name = "Cosmos"
marketname = "HUAWEI Mate 90 Pro"
fingerprint = "HUAWEI/Cosmos/Cosmos:15/AP3A.241005.015.A1/Cosmos.241005.001:user/release-keys"

[templates."huawei_cmm_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CMM-AL00"
device = "CosmosM"
product = "CosmosM"
name = "CosmosM"
marketname = "HUAWEI Mate 90 Pro Max"
fingerprint = "HUAWEI/CosmosM/CosmosM:15/AP3A.241005.015.A1/CosmosM.241005.001:user/release-keys"

[templates."huawei_cmu_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CMU-AL10"
device = "CosmosU"
product = "CosmosU"
name = "CosmosU"
marketname = "HUAWEI Mate 90 RS 非凡大师"
fingerprint = "HUAWEI/CosmosU/CosmosU:15/AP3A.241005.015.A1/CosmosU.241005.001:user/release-keys"

[templates."huawei_tah_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "TAH-AN00"
device = "Tahiti"
product = "Tahiti"
name = "Tahiti"
marketname = "HUAWEI Mate X"
fingerprint = "HUAWEI/Tahiti/Tahiti:15/AP3A.241005.015.A1/Tahiti.241005.001:user/release-keys"

[templates."huawei_tah_an00m"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "TAH-AN00M"
device = "Tahiti"
product = "Tahiti"
name = "Tahiti"
marketname = "HUAWEI Mate Xs"
fingerprint = "HUAWEI/Tahiti/Tahiti:15/AP3A.241005.015.A1/Tahiti.241005.001:user/release-keys"

[templates."huawei_tet_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "TET-AN00"
device = "Teton"
product = "Teton"
name = "Teton"
marketname = "HUAWEI Mate X2 5G"
fingerprint = "HUAWEI/Teton/Teton:15/AP3A.241005.015.A1/Teton.241005.001:user/release-keys"

[templates."huawei_tet_an50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "TET-AN50"
device = "Teton"
product = "Teton"
name = "Teton"
marketname = "HUAWEI Mate X2 典藏版 5G"
fingerprint = "HUAWEI/Teton/Teton:15/AP3A.241005.015.A1/Teton.241005.001:user/release-keys"

[templates."huawei_tet_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "TET-AL00"
device = "Teton"
product = "Teton"
name = "Teton"
marketname = "HUAWEI Mate X2 4G"
fingerprint = "HUAWEI/Teton/Teton:15/AP3A.241005.015.A1/Teton.241005.001:user/release-keys"

[templates."huawei_pal_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PAL-AL00"
device = "Palau"
product = "Palau"
name = "Palau"
marketname = "HUAWEI Mate Xs 2"
fingerprint = "HUAWEI/Palau/Palau:15/AP3A.241005.015.A1/Palau.241005.001:user/release-keys"

[templates."huawei_alt_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ALT-AL00"
device = "Alta"
product = "Alta"
name = "Alta"
marketname = "HUAWEI Mate X3"
fingerprint = "HUAWEI/Alta/Alta:15/AP3A.241005.015.A1/Alta.241005.001:user/release-keys"

[templates."huawei_alt_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ALT-AL10"
device = "Alta"
product = "Alta"
name = "Alta"
marketname = "HUAWEI Mate X5"
fingerprint = "HUAWEI/Alta/Alta:15/AP3A.241005.015.A1/Alta.241005.001:user/release-keys"

[templates."huawei_grl_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "GRL-AL10"
device = "Greenlan"
product = "Greenlan"
name = "Greenlan"
marketname = "HUAWEI Mate XT 非凡大师"
fingerprint = "HUAWEI/Greenlan/Greenlan:15/AP3A.241005.015.A1/Greenlan.241005.001:user/release-keys"

[templates."huawei_icl_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ICL-AL10"
device = "Icelan"
product = "Icelan"
name = "Icelan"
marketname = "HUAWEI Mate X6"
fingerprint = "HUAWEI/Icelan/Icelan:15/AP3A.241005.015.A1/Icelan.241005.001:user/release-keys"

[templates."huawei_icl_al20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ICL-AL20"
device = "Icelan"
product = "Icelan"
name = "Icelan"
marketname = "HUAWEI Mate X6 典藏版"
fingerprint = "HUAWEI/Icelan/Icelan:15/AP3A.241005.015.A1/Icelan.241005.001:user/release-keys"

[templates."huawei_grl_al20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "GRL-AL20"
device = "Greenlan"
product = "Greenlan"
name = "Greenlan"
marketname = "HUAWEI Mate XTs 非凡大师"
fingerprint = "HUAWEI/Greenlan/Greenlan:15/AP3A.241005.015.A1/Greenlan.241005.001:user/release-keys"

[templates."huawei_del_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DEL-AL10"
device = "Delphi"
product = "Delphi"
name = "Delphi"
marketname = "HUAWEI Mate X7"
fingerprint = "HUAWEI/Delphi/Delphi:15/AP3A.241005.015.A1/Delphi.241005.001:user/release-keys"

[templates."huawei_del_al20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DEL-AL20"
device = "Delphi"
product = "Delphi"
name = "Delphi"
marketname = "HUAWEI Mate X7 典藏版"
fingerprint = "HUAWEI/Delphi/Delphi:15/AP3A.241005.015.A1/Delphi.241005.001:user/release-keys"

[templates."huawei_lap_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LAP-AL10"
device = "Laptua"
product = "Laptua"
name = "Laptua"
marketname = "HUAWEI Mate XT 2 非凡大师"
fingerprint = "HUAWEI/Laptua/Laptua:15/AP3A.241005.015.A1/Laptua.241005.001:user/release-keys"

[templates."huawei_huawei_u9200"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI U9200"
device = "HUAWEI U9200"
product = "HUAWEI U9200"
marketname = "HUAWEI Ascend P1"
fingerprint = "HUAWEI/HUAWEI U9200/HUAWEI U9200:15/AP3A.241005.015.A1/HUAWEIU9200.241005.001:user/release-keys"

[templates."huawei_huawei_u9200e"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI U9200E"
device = "HUAWEI U9200E"
product = "HUAWEI U9200E"
marketname = "HUAWEI Ascend P1 XL"
fingerprint = "HUAWEI/HUAWEI U9200E/HUAWEI U9200E:15/AP3A.241005.015.A1/HUAWEIU9200E.241005.001:user/release-keys"

[templates."huawei_huawei_u9200s"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI U9200S"
device = "HUAWEI U9200S"
product = "HUAWEI U9200S"
marketname = "HUAWEI Ascend P1 S"
fingerprint = "HUAWEI/HUAWEI U9200S/HUAWEI U9200S:15/AP3A.241005.015.A1/HUAWEIU9200S.241005.001:user/release-keys"

[templates."huawei_huawei_p2_0000"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P2-0000"
device = "HUAWEI P2-0000"
product = "HUAWEI P2-0000"
marketname = "HUAWEI Ascend P2"
fingerprint = "HUAWEI/HUAWEI P2-0000/HUAWEI P2-0000:15/AP3A.241005.015.A1/HUAWEIP2-0000.241005.001:user/release-keys"

[templates."huawei_huawei_p6_t00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P6-T00"
device = "Edge"
product = "Edge"
name = "Edge"
marketname = "HUAWEI Ascend P6 移动渠道版"
fingerprint = "HUAWEI/Edge/Edge:15/AP3A.241005.015.A1/Edge.241005.001:user/release-keys"

[templates."huawei_huawei_p6_t00v"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P6-T00V"
device = "Edge"
product = "Edge"
name = "Edge"
marketname = "HUAWEI Ascend P6"
fingerprint = "HUAWEI/Edge/Edge:15/AP3A.241005.015.A1/Edge.241005.001:user/release-keys"

[templates."huawei_huawei_p6_s_u06"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P6 S-U06"
device = "HUAWEI P6 S-U06"
product = "HUAWEI P6 S-U06"
marketname = "HUAWEI Ascend P6S"
fingerprint = "HUAWEI/HUAWEI P6 S-U06/HUAWEI P6 S-U06:15/AP3A.241005.015.A1/HUAWEIP6S-U06.241005.001:user/release-keys"

[templates."huawei_huawei_p7_l00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P7-L00"
device = "Sophia"
product = "Sophia"
name = "Sophia"
marketname = "HUAWEI Ascend P7"
fingerprint = "HUAWEI/Sophia/Sophia:15/AP3A.241005.015.A1/Sophia.241005.001:user/release-keys"

[templates."huawei_huawei_p7_l05"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P7-L05"
device = "Sophia"
product = "Sophia"
name = "Sophia"
marketname = "HUAWEI Ascend P7 移动渠道版"
fingerprint = "HUAWEI/Sophia/Sophia:15/AP3A.241005.015.A1/Sophia.241005.001:user/release-keys"

[templates."huawei_huawei_gra_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI GRA-TL00"
device = "Grace"
product = "Grace"
name = "Grace"
marketname = "HUAWEI P8"
fingerprint = "HUAWEI/Grace/Grace:15/AP3A.241005.015.A1/Grace.241005.001:user/release-keys"

[templates."huawei_huawei_gra_ul00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI GRA-UL00"
device = "Grace"
product = "Grace"
name = "Grace"
marketname = "HUAWEI P8 双 4G"
fingerprint = "HUAWEI/Grace/Grace:15/AP3A.241005.015.A1/Grace.241005.001:user/release-keys"

[templates."huawei_huawei_ale_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI ALE-TL00"
device = "Alice"
product = "Alice"
name = "Alice"
marketname = "HUAWEI P8 青春版"
fingerprint = "HUAWEI/Alice/Alice:15/AP3A.241005.015.A1/Alice.241005.001:user/release-keys"

[templates."huawei_dav_703l"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DAV-703L"
device = "DAV-703L"
product = "DAV-703L"
marketname = "HUAWEI P8 Max"
fingerprint = "HUAWEI/DAV-703L/DAV-703L:15/AP3A.241005.015.A1/DAV-703L.241005.001:user/release-keys"

[templates."huawei_eva_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "EVA-AL00"
device = "Eva"
product = "Eva"
name = "Eva"
marketname = "HUAWEI P9"
fingerprint = "HUAWEI/Eva/Eva:15/AP3A.241005.015.A1/Eva.241005.001:user/release-keys"

[templates."huawei_vie_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "VIE-AL10"
device = "Vienna"
product = "Vienna"
name = "Vienna"
marketname = "HUAWEI P9 Plus"
fingerprint = "HUAWEI/Vienna/Vienna:15/AP3A.241005.015.A1/Vienna.241005.001:user/release-keys"

[templates."huawei_vtr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "VTR-AL00"
device = "Victoria"
product = "Victoria"
name = "Victoria"
marketname = "HUAWEI P10"
fingerprint = "HUAWEI/Victoria/Victoria:15/AP3A.241005.015.A1/Victoria.241005.001:user/release-keys"

[templates."huawei_vky_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "VKY-AL00"
device = "Vicky"
product = "Vicky"
name = "Vicky"
marketname = "HUAWEI P10 Plus"
fingerprint = "HUAWEI/Vicky/Vicky:15/AP3A.241005.015.A1/Vicky.241005.001:user/release-keys"

[templates."huawei_eml_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "EML-AL00"
device = "Emily"
product = "Emily"
name = "Emily"
marketname = "HUAWEI P20"
fingerprint = "HUAWEI/Emily/Emily:15/AP3A.241005.015.A1/Emily.241005.001:user/release-keys"

[templates."huawei_clt_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CLT-AL00"
device = "Charlotte"
product = "Charlotte"
name = "Charlotte"
marketname = "HUAWEI P20 Pro"
fingerprint = "HUAWEI/Charlotte/Charlotte:15/AP3A.241005.015.A1/Charlotte.241005.001:user/release-keys"

[templates."huawei_clt_al00l"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CLT-AL00L"
device = "Charlotte"
product = "Charlotte"
name = "Charlotte"
marketname = "HUAWEI P20 Pro 真皮限量版"
fingerprint = "HUAWEI/Charlotte/Charlotte:15/AP3A.241005.015.A1/Charlotte.241005.001:user/release-keys"

[templates."huawei_ele_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ELE-AL00"
device = "Elle"
product = "Elle"
name = "Elle"
marketname = "HUAWEI P30"
fingerprint = "HUAWEI/Elle/Elle:15/AP3A.241005.015.A1/Elle.241005.001:user/release-keys"

[templates."huawei_vog_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "VOG-AL00"
device = "Vogue"
product = "Vogue"
name = "Vogue"
marketname = "HUAWEI P30 Pro"
fingerprint = "HUAWEI/Vogue/Vogue:15/AP3A.241005.015.A1/Vogue.241005.001:user/release-keys"

[templates."huawei_ana_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ANA-AL00"
device = "Anna"
product = "Anna"
name = "Anna"
marketname = "HUAWEI P40 4G"
fingerprint = "HUAWEI/Anna/Anna:15/AP3A.241005.015.A1/Anna.241005.001:user/release-keys"

[templates."huawei_ana_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ANA-AN00"
device = "Anna"
product = "Anna"
name = "Anna"
marketname = "HUAWEI P40 5G"
fingerprint = "HUAWEI/Anna/Anna:15/AP3A.241005.015.A1/Anna.241005.001:user/release-keys"

[templates."huawei_els_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ELS-AN00"
device = "Elsa"
product = "Elsa"
name = "Elsa"
marketname = "HUAWEI P40 Pro 5G"
fingerprint = "HUAWEI/Elsa/Elsa:15/AP3A.241005.015.A1/Elsa.241005.001:user/release-keys"

[templates."huawei_els_an10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ELS-AN10"
device = "ElsaP"
product = "ElsaP"
name = "ElsaP"
marketname = "HUAWEI P40 Pro+ 5G"
fingerprint = "HUAWEI/ElsaP/ElsaP:15/AP3A.241005.015.A1/ElsaP.241005.001:user/release-keys"

[templates."huawei_abr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ABR-AL00"
device = "Amber"
product = "Amber"
name = "Amber"
marketname = "HUAWEI P50"
fingerprint = "HUAWEI/Amber/Amber:15/AP3A.241005.015.A1/Amber.241005.001:user/release-keys"

[templates."huawei_abr_al60"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ABR-AL60"
device = "Amber"
product = "Amber"
name = "Amber"
marketname = "HUAWEI P50E"
fingerprint = "HUAWEI/Amber/Amber:15/AP3A.241005.015.A1/Amber.241005.001:user/release-keys"

[templates."huawei_jad_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "JAD-AL00"
device = "Jade"
product = "Jade"
name = "Jade"
marketname = "HUAWEI P50 Pro"
fingerprint = "HUAWEI/Jade/Jade:15/AP3A.241005.015.A1/Jade.241005.001:user/release-keys"

[templates."huawei_bal_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BAL-AL00"
device = "Bali"
product = "Bali"
name = "Bali"
marketname = "HUAWEI P50 Pocket"
fingerprint = "HUAWEI/Bali/Bali:15/AP3A.241005.015.A1/Bali.241005.001:user/release-keys"

[templates."huawei_lna_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LNA-AL00"
device = "Leona"
product = "Leona"
name = "Leona"
marketname = "HUAWEI P60"
fingerprint = "HUAWEI/Leona/Leona:15/AP3A.241005.015.A1/Leona.241005.001:user/release-keys"

[templates."huawei_mna_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MNA-AL00"
device = "Mona"
product = "Mona"
name = "Mona"
marketname = "HUAWEI P60 Pro"
fingerprint = "HUAWEI/Mona/Mona:15/AP3A.241005.015.A1/Mona.241005.001:user/release-keys"

[templates."huawei_ady_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ADY-AL00"
device = "Audrey"
product = "Audrey"
name = "Audrey"
marketname = "HUAWEI Pura 70"
fingerprint = "HUAWEI/Audrey/Audrey:15/AP3A.241005.015.A1/Audrey.241005.001:user/release-keys"

[templates."huawei_ady_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ADY-AL10"
device = "Audrey"
product = "Audrey"
name = "Audrey"
marketname = "HUAWEI Pura 70 北斗卫星消息版"
fingerprint = "HUAWEI/Audrey/Audrey:15/AP3A.241005.015.A1/Audrey.241005.001:user/release-keys"

[templates."huawei_hbn_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HBN-AL00"
device = "Hepburn"
product = "Hepburn"
name = "Hepburn"
marketname = "HUAWEI Pura 70 Pro"
fingerprint = "HUAWEI/Hepburn/Hepburn:15/AP3A.241005.015.A1/Hepburn.241005.001:user/release-keys"

[templates."huawei_hbn_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HBN-AL10"
device = "Hepburn"
product = "Hepburn"
name = "Hepburn"
marketname = "HUAWEI Pura 70 Pro+"
fingerprint = "HUAWEI/Hepburn/Hepburn:15/AP3A.241005.015.A1/Hepburn.241005.001:user/release-keys"

[templates."huawei_hbp_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HBP-AL00"
device = "HepburnP"
product = "HepburnP"
name = "HepburnP"
marketname = "HUAWEI Pura 70 Ultra"
fingerprint = "HUAWEI/HepburnP/HepburnP:15/AP3A.241005.015.A1/HepburnP.241005.001:user/release-keys"

[templates."huawei_hed_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HED-AL00"
device = "Hedy"
product = "Hedy"
name = "Hedy"
marketname = "HUAWEI Pura 80"
fingerprint = "HUAWEI/Hedy/Hedy:15/AP3A.241005.015.A1/Hedy.241005.001:user/release-keys"

[templates."huawei_lmr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LMR-AL00"
device = "Lamarr"
product = "Lamarr"
name = "Lamarr"
marketname = "HUAWEI Pura 80 Pro"
fingerprint = "HUAWEI/Lamarr/Lamarr:15/AP3A.241005.015.A1/Lamarr.241005.001:user/release-keys"

[templates."huawei_lmr_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LMR-AL10"
device = "LamarrU"
product = "LamarrU"
name = "LamarrU"
marketname = "HUAWEI Pura 80 Pro+"
fingerprint = "HUAWEI/LamarrU/LamarrU:15/AP3A.241005.015.A1/LamarrU.241005.001:user/release-keys"

[templates."huawei_kee_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "KEE-AL00"
device = "Klee"
product = "Klee"
name = "Klee"
marketname = "HUAWEI Pura 90"
fingerprint = "HUAWEI/Klee/Klee:15/AP3A.241005.015.A1/Klee.241005.001:user/release-keys"

[templates."huawei_mln_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MLN-AL00"
device = "Malena"
product = "Malena"
name = "Malena"
marketname = "HUAWEI Pura 90 Pro"
fingerprint = "HUAWEI/Malena/Malena:15/AP3A.241005.015.A1/Malena.241005.001:user/release-keys"

[templates."huawei_sca_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SCA-AL00"
device = "Sicilia"
product = "Sicilia"
name = "Sicilia"
marketname = "HUAWEI Pura 90 Pro Max"
fingerprint = "HUAWEI/Sicilia/Sicilia:15/AP3A.241005.015.A1/Sicilia.241005.001:user/release-keys"

[templates."huawei_lci_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LCI-AL00"
device = "Lucia"
product = "Lucia"
name = "Lucia"
marketname = "HUAWEI Pura 90 Plus"
fingerprint = "HUAWEI/Lucia/Lucia:15/AP3A.241005.015.A1/Lucia.241005.001:user/release-keys"

[templates."huawei_vde_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "VDE-AL00"
device = "Verde"
product = "Verde"
name = "Verde"
marketname = "HUAWEI Pura X"
fingerprint = "HUAWEI/Verde/Verde:15/AP3A.241005.015.A1/Verde.241005.001:user/release-keys"

[templates."huawei_vde_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "VDE-AL10"
device = "Verde"
product = "Verde"
name = "Verde"
marketname = "HUAWEI Pura X 典藏版"
fingerprint = "HUAWEI/Verde/Verde:15/AP3A.241005.015.A1/Verde.241005.001:user/release-keys"

[templates."huawei_hop_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HOP-AL00"
device = "Hope"
product = "Hope"
name = "Hope"
marketname = "HUAWEI Pura X Max"
fingerprint = "HUAWEI/Hope/Hope:15/AP3A.241005.015.A1/Hope.241005.001:user/release-keys"

[templates."huawei_hop_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HOP-AL10"
device = "Hope"
product = "Hope"
name = "Hope"
marketname = "HUAWEI Pura X Max 典藏版"
fingerprint = "HUAWEI/Hope/Hope:15/AP3A.241005.015.A1/Hope.241005.001:user/release-keys"

[templates."huawei_vol_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "VOL-AL00"
device = "Volcano"
product = "Volcano"
name = "Volcano"
marketname = "HUAWEI Pura X View"
fingerprint = "HUAWEI/Volcano/Volcano:15/AP3A.241005.015.A1/Volcano.241005.001:user/release-keys"

[templates."huawei_bal_al60"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BAL-AL60"
device = "Bali"
product = "Bali"
name = "Bali"
marketname = "HUAWEI Pocket S"
fingerprint = "HUAWEI/Bali/Bali:15/AP3A.241005.015.A1/Bali.241005.001:user/release-keys"

[templates."huawei_lem_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LEM-AL00"
device = "Lem"
product = "Lem"
name = "Lem"
marketname = "HUAWEI Pocket 2"
fingerprint = "HUAWEI/Lem/Lem:15/AP3A.241005.015.A1/Lem.241005.001:user/release-keys"

[templates."huawei_lem_al50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LEM-AL50"
device = "Lem"
product = "Lem"
name = "Lem"
marketname = "HUAWEI Pocket 2 优享版"
fingerprint = "HUAWEI/Lem/Lem:15/AP3A.241005.015.A1/Lem.241005.001:user/release-keys"

[templates."huawei_huawei_caz_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI CAZ-AL00"
device = "Cannes"
product = "Cannes"
name = "Cannes"
marketname = "HUAWEI nova"
fingerprint = "HUAWEI/Cannes/Cannes:15/AP3A.241005.015.A1/Cannes.241005.001:user/release-keys"

[templates."huawei_huawei_caz_tl10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI CAZ-TL10"
device = "Cannes"
product = "Cannes"
name = "Cannes"
marketname = "HUAWEI nova 移动定制"
fingerprint = "HUAWEI/Cannes/Cannes:15/AP3A.241005.015.A1/Cannes.241005.001:user/release-keys"

[templates."huawei_was_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "WAS-AL00"
device = "Warsaw"
product = "Warsaw"
name = "Warsaw"
marketname = "HUAWEI nova 青春版"
fingerprint = "HUAWEI/Warsaw/Warsaw:15/AP3A.241005.015.A1/Warsaw.241005.001:user/release-keys"

[templates."huawei_pic_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PIC-AL00"
device = "Picasso"
product = "Picasso"
name = "Picasso"
marketname = "HUAWEI nova 2"
fingerprint = "HUAWEI/Picasso/Picasso:15/AP3A.241005.015.A1/Picasso.241005.001:user/release-keys"

[templates."huawei_bac_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BAC-AL00"
device = "Barca"
product = "Barca"
name = "Barca"
marketname = "HUAWEI nova 2 Plus"
fingerprint = "HUAWEI/Barca/Barca:15/AP3A.241005.015.A1/Barca.241005.001:user/release-keys"

[templates."huawei_hwi_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HWI-AL00"
device = "Hawaii"
product = "Hawaii"
name = "Hawaii"
marketname = "HUAWEI nova 2s"
fingerprint = "HUAWEI/Hawaii/Hawaii:15/AP3A.241005.015.A1/Hawaii.241005.001:user/release-keys"

[templates."huawei_ane_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ANE-AL00"
device = "Anne"
product = "Anne"
name = "Anne"
marketname = "HUAWEI nova 3e"
fingerprint = "HUAWEI/Anne/Anne:15/AP3A.241005.015.A1/Anne.241005.001:user/release-keys"

[templates."huawei_par_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PAR-AL00"
device = "Paris"
product = "Paris"
name = "Paris"
marketname = "HUAWEI nova 3"
fingerprint = "HUAWEI/Paris/Paris:15/AP3A.241005.015.A1/Paris.241005.001:user/release-keys"

[templates."huawei_ine_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "INE-AL00"
device = "Sydneyi"
product = "Sydneyi"
name = "Sydneyi"
marketname = "HUAWEI nova 3i"
fingerprint = "HUAWEI/Sydneyi/Sydneyi:15/AP3A.241005.015.A1/Sydneyi.241005.001:user/release-keys"

[templates."huawei_vce_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "VCE-AL00"
device = "Venice"
product = "Venice"
name = "Venice"
marketname = "HUAWEI nova 4"
fingerprint = "HUAWEI/Venice/Venice:15/AP3A.241005.015.A1/Venice.241005.001:user/release-keys"

[templates."huawei_mar_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MAR-AL00"
device = "Marie"
product = "Marie"
name = "Marie"
marketname = "HUAWEI nova 4e"
fingerprint = "HUAWEI/Marie/Marie:15/AP3A.241005.015.A1/Marie.241005.001:user/release-keys"

[templates."huawei_sea_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SEA-AL00"
device = "Seattle"
product = "Seattle"
name = "Seattle"
marketname = "HUAWEI nova 5"
fingerprint = "HUAWEI/Seattle/Seattle:15/AP3A.241005.015.A1/Seattle.241005.001:user/release-keys"

[templates."huawei_sea_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SEA-AL10"
device = "Seattle"
product = "Seattle"
name = "Seattle"
marketname = "HUAWEI nova 5 Pro"
fingerprint = "HUAWEI/Seattle/Seattle:15/AP3A.241005.015.A1/Seattle.241005.001:user/release-keys"

[templates."huawei_glk_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "GLK-AL00"
device = "Gelk"
product = "Gelk"
name = "Gelk"
marketname = "HUAWEI nova 5i"
fingerprint = "HUAWEI/Gelk/Gelk:15/AP3A.241005.015.A1/Gelk.241005.001:user/release-keys"

[templates."huawei_spn_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SPN-AL00"
device = "Saipan"
product = "Saipan"
name = "Saipan"
marketname = "HUAWEI nova 5i Pro"
fingerprint = "HUAWEI/Saipan/Saipan:15/AP3A.241005.015.A1/Saipan.241005.001:user/release-keys"

[templates."huawei_wlz_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "WLZ-AL10"
device = "Waltz"
product = "Waltz"
name = "Waltz"
marketname = "HUAWEI nova 6 4G"
fingerprint = "HUAWEI/Waltz/Waltz:15/AP3A.241005.015.A1/Waltz.241005.001:user/release-keys"

[templates."huawei_wlz_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "WLZ-AN00"
device = "WaltzS"
product = "WaltzS"
name = "WaltzS"
marketname = "HUAWEI nova 6 5G"
fingerprint = "HUAWEI/WaltzS/WaltzS:15/AP3A.241005.015.A1/WaltzS.241005.001:user/release-keys"

[templates."huawei_jny_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "JNY-AL10"
device = "Jenny"
product = "Jenny"
name = "Jenny"
marketname = "HUAWEI nova 6 SE"
fingerprint = "HUAWEI/Jenny/Jenny:15/AP3A.241005.015.A1/Jenny.241005.001:user/release-keys"

[templates."huawei_jef_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "JEF-AN00"
device = "Jennifer"
product = "Jennifer"
name = "Jennifer"
marketname = "HUAWEI nova 7 5G"
fingerprint = "HUAWEI/Jennifer/Jennifer:15/AP3A.241005.015.A1/Jennifer.241005.001:user/release-keys"

[templates."huawei_jer_an10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "JER-AN10"
device = "JenniferR"
product = "JenniferR"
name = "JenniferR"
marketname = "HUAWEI nova 7 Pro 5G"
fingerprint = "HUAWEI/JenniferR/JenniferR:15/AP3A.241005.015.A1/JenniferR.241005.001:user/release-keys"

[templates."huawei_cdy_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CDY-AN00"
device = "CindyN"
product = "CindyN"
name = "CindyN"
marketname = "HUAWEI nova 7 SE 5G"
fingerprint = "HUAWEI/CindyN/CindyN:15/AP3A.241005.015.A1/CindyN.241005.001:user/release-keys"

[templates."huawei_cnd_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CND-AN00"
device = "CindyMN"
product = "CindyMN"
name = "CindyMN"
marketname = "HUAWEI nova 7 SE 5G 活力版"
fingerprint = "HUAWEI/CindyMN/CindyMN:15/AP3A.241005.015.A1/CindyMN.241005.001:user/release-keys"

[templates."huawei_cdl_an50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CDL-AN50"
device = "CindyL"
product = "CindyL"
name = "CindyL"
marketname = "HUAWEI nova 7 SE 5G 乐活版"
fingerprint = "HUAWEI/CindyL/CindyL:15/AP3A.241005.015.A1/CindyL.241005.001:user/release-keys"

[templates."huawei_ang_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ANG-AN00"
device = "Angela"
product = "Angela"
name = "Angela"
marketname = "HUAWEI nova 8 5G"
fingerprint = "HUAWEI/Angela/Angela:15/AP3A.241005.015.A1/Angela.241005.001:user/release-keys"

[templates."huawei_brq_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BRQ-AN00"
device = "Barbie"
product = "Barbie"
name = "Barbie"
marketname = "HUAWEI nova 8 Pro 5G"
fingerprint = "HUAWEI/Barbie/Barbie:15/AP3A.241005.015.A1/Barbie.241005.001:user/release-keys"

[templates."huawei_brq_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BRQ-AL00"
device = "Barbie"
product = "Barbie"
name = "Barbie"
marketname = "HUAWEI nova 8 Pro 4G"
fingerprint = "HUAWEI/Barbie/Barbie:15/AP3A.241005.015.A1/Barbie.241005.001:user/release-keys"

[templates."huawei_jsc_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "JSC-AN00"
device = "Jessica"
product = "Jessica"
name = "Jessica"
marketname = "HUAWEI nova 8 SE 5G"
fingerprint = "HUAWEI/Jessica/Jessica:15/AP3A.241005.015.A1/Jessica.241005.001:user/release-keys"

[templates."huawei_jsc_al50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "JSC-AL50"
device = "Jessica"
product = "Jessica"
name = "Jessica"
marketname = "HUAWEI nova 8 SE 4G"
fingerprint = "HUAWEI/Jessica/Jessica:15/AP3A.241005.015.A1/Jessica.241005.001:user/release-keys"

[templates."huawei_chl_al60"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CHL-AL60"
device = "Chanel"
product = "Chanel"
name = "Chanel"
marketname = "HUAWEI nova 8 SE 活力版"
fingerprint = "HUAWEI/Chanel/Chanel:15/AP3A.241005.015.A1/Chanel.241005.001:user/release-keys"

[templates."huawei_nam_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "NAM-AL00"
device = "NottinghamN"
product = "NottinghamN"
name = "NottinghamN"
marketname = "HUAWEI nova 9"
fingerprint = "HUAWEI/NottinghamN/NottinghamN:15/AP3A.241005.015.A1/NottinghamN.241005.001:user/release-keys"

[templates."huawei_rte_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "RTE-AL00"
device = "Rena"
product = "Rena"
name = "Rena"
marketname = "HUAWEI nova 9 Pro"
fingerprint = "HUAWEI/Rena/Rena:15/AP3A.241005.015.A1/Rena.241005.001:user/release-keys"

[templates."huawei_jln_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "JLN-AL00"
device = "JuliaQN"
product = "JuliaQN"
name = "JuliaQN"
marketname = "HUAWEI nova 9 SE"
fingerprint = "HUAWEI/JuliaQN/JuliaQN:15/AP3A.241005.015.A1/JuliaQN.241005.001:user/release-keys"

[templates."huawei_nco_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "NCO-AL00"
device = "Nicole"
product = "Nicole"
name = "Nicole"
marketname = "HUAWEI nova 10"
fingerprint = "HUAWEI/Nicole/Nicole:15/AP3A.241005.015.A1/Nicole.241005.001:user/release-keys"

[templates."huawei_gla_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "GLA-AL00"
device = "Gloria"
product = "Gloria"
name = "Gloria"
marketname = "HUAWEI nova 10 Pro"
fingerprint = "HUAWEI/Gloria/Gloria:15/AP3A.241005.015.A1/Gloria.241005.001:user/release-keys"

[templates."huawei_cha_al80"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CHA-AL80"
device = "Chanel"
product = "Chanel"
name = "Chanel"
marketname = "HUAWEI nova 10z"
fingerprint = "HUAWEI/Chanel/Chanel:15/AP3A.241005.015.A1/Chanel.241005.001:user/release-keys"

[templates."huawei_bne_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BNE-AL00"
device = "Bonnie"
product = "Bonnie"
name = "Bonnie"
marketname = "HUAWEI nova 10 SE"
fingerprint = "HUAWEI/Bonnie/Bonnie:15/AP3A.241005.015.A1/Bonnie.241005.001:user/release-keys"

[templates."huawei_foa_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "FOA-AL00"
device = "Fiona"
product = "Fiona"
name = "Fiona"
marketname = "HUAWEI nova 11"
fingerprint = "HUAWEI/Fiona/Fiona:15/AP3A.241005.015.A1/Fiona.241005.001:user/release-keys"

[templates."huawei_goa_al80"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "GOA-AL80"
device = "Gloria"
product = "Gloria"
name = "Gloria"
marketname = "HUAWEI nova 11 Pro"
fingerprint = "HUAWEI/Gloria/Gloria:15/AP3A.241005.015.A1/Gloria.241005.001:user/release-keys"

[templates."huawei_goa_al80u"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "GOA-AL80U"
device = "Gloria"
product = "Gloria"
name = "Gloria"
marketname = "HUAWEI nova 11 Ultra"
fingerprint = "HUAWEI/Gloria/Gloria:15/AP3A.241005.015.A1/Gloria.241005.001:user/release-keys"

[templates."huawei_bon_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BON-AL00"
device = "Bonnie"
product = "Bonnie"
name = "Bonnie"
marketname = "HUAWEI nova 11 SE"
fingerprint = "HUAWEI/Bonnie/Bonnie:15/AP3A.241005.015.A1/Bonnie.241005.001:user/release-keys"

[templates."huawei_blk_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BLK-AL00"
device = "Blake"
product = "Blake"
name = "Blake"
marketname = "HUAWEI nova 12"
fingerprint = "HUAWEI/Blake/Blake:15/AP3A.241005.015.A1/Blake.241005.001:user/release-keys"

[templates."huawei_fin_al60"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "FIN-AL60"
device = "Fiona"
product = "Fiona"
name = "Fiona"
marketname = "HUAWEI nova 12 活力版"
fingerprint = "HUAWEI/Fiona/Fiona:15/AP3A.241005.015.A1/Fiona.241005.001:user/release-keys"

[templates."huawei_ada_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ADA-AL00"
device = "Adela"
product = "Adela"
name = "Adela"
marketname = "HUAWEI nova 12 Pro"
fingerprint = "HUAWEI/Adela/Adela:15/AP3A.241005.015.A1/Adela.241005.001:user/release-keys"

[templates."huawei_ada_al00u"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ADA-AL00U"
device = "Adela"
product = "Adela"
name = "Adela"
marketname = "HUAWEI nova 12 Ultra"
fingerprint = "HUAWEI/Adela/Adela:15/AP3A.241005.015.A1/Adela.241005.001:user/release-keys"

[templates."huawei_ada_al10u"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ADA-AL10U"
device = "Adela"
product = "Adela"
name = "Adela"
marketname = "HUAWEI nova 12 Ultra 星耀版"
fingerprint = "HUAWEI/Adela/Adela:15/AP3A.241005.015.A1/Adela.241005.001:user/release-keys"

[templates."huawei_psd_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PSD-AL00"
device = "Poseidon"
product = "Poseidon"
name = "Poseidon"
marketname = "HUAWEI nova Flip"
fingerprint = "HUAWEI/Poseidon/Poseidon:15/AP3A.241005.015.A1/Poseidon.241005.001:user/release-keys"

[templates."huawei_blk_al80"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BLK-AL80"
device = "Blake"
product = "Blake"
name = "Blake"
marketname = "HUAWEI nova 13"
fingerprint = "HUAWEI/Blake/Blake:15/AP3A.241005.015.A1/Blake.241005.001:user/release-keys"

[templates."huawei_mis_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MIS-AL00"
device = "MillaS"
product = "MillaS"
name = "MillaS"
marketname = "HUAWEI nova 13 Pro"
fingerprint = "HUAWEI/MillaS/MillaS:15/AP3A.241005.015.A1/MillaS.241005.001:user/release-keys"

[templates."huawei_tlr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "TLR-AL00"
device = "Taylor"
product = "Taylor"
name = "Taylor"
marketname = "HUAWEI nova 14"
fingerprint = "HUAWEI/Taylor/Taylor:15/AP3A.241005.015.A1/Taylor.241005.001:user/release-keys"

[templates."huawei_mia_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MIA-AL00"
device = "Milla"
product = "Milla"
name = "Milla"
marketname = "HUAWEI nova 14 Pro"
fingerprint = "HUAWEI/Milla/Milla:15/AP3A.241005.015.A1/Milla.241005.001:user/release-keys"

[templates."huawei_mrt_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MRT-AL10"
device = "Margaret"
product = "Margaret"
name = "Margaret"
marketname = "HUAWEI nova 14 Ultra"
fingerprint = "HUAWEI/Margaret/Margaret:15/AP3A.241005.015.A1/Margaret.241005.001:user/release-keys"

[templates."huawei_tyr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "TYR-AL00"
device = "Taylor"
product = "Taylor"
name = "Taylor"
marketname = "HUAWEI nova 14 活力版"
fingerprint = "HUAWEI/Taylor/Taylor:15/AP3A.241005.015.A1/Taylor.241005.001:user/release-keys"

[templates."huawei_psd_al80"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PSD-AL80"
device = "Poseidon"
product = "Poseidon"
name = "Poseidon"
marketname = "HUAWEI nova Flip S"
fingerprint = "HUAWEI/Poseidon/Poseidon:15/AP3A.241005.015.A1/Poseidon.241005.001:user/release-keys"

[templates."huawei_psn_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PSN-AL00"
device = "Pushkin"
product = "Pushkin"
name = "Pushkin"
marketname = "HUAWEI nova 15"
fingerprint = "HUAWEI/Pushkin/Pushkin:15/AP3A.241005.015.A1/Pushkin.241005.001:user/release-keys"

[templates."huawei_kle_al00u"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "KLE-AL00U"
device = "Klee"
product = "Klee"
name = "Klee"
marketname = "HUAWEI nova 15 Pro"
fingerprint = "HUAWEI/Klee/Klee:15/AP3A.241005.015.A1/Klee.241005.001:user/release-keys"

[templates."huawei_sly_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SLY-AL00"
device = "Shelley"
product = "Shelley"
name = "Shelley"
marketname = "HUAWEI nova 15 Ultra"
fingerprint = "HUAWEI/Shelley/Shelley:15/AP3A.241005.015.A1/Shelley.241005.001:user/release-keys"

[templates."huawei_ema_al00u"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "EMA-AL00U"
device = "Emilia"
product = "Emilia"
name = "Emilia"
marketname = "HUAWEI nova 16"
fingerprint = "HUAWEI/Emilia/Emilia:15/AP3A.241005.015.A1/Emilia.241005.001:user/release-keys"

[templates."huawei_crs_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CRS-AL00"
device = "Chris"
product = "Chris"
name = "Chris"
marketname = "HUAWEI nova 16 Pro"
fingerprint = "HUAWEI/Chris/Chris:15/AP3A.241005.015.A1/Chris.241005.001:user/release-keys"

[templates."huawei_hip_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HIP-AL00"
device = "ChrisP"
product = "ChrisP"
name = "ChrisP"
marketname = "HUAWEI nova 16 Ultra"
fingerprint = "HUAWEI/ChrisP/ChrisP:15/AP3A.241005.015.A1/ChrisP.241005.001:user/release-keys"

[templates."huawei_pkn_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PKN-AL00"
device = "Pushkin"
product = "Pushkin"
name = "Pushkin"
marketname = "HUAWEI nova 16z"
fingerprint = "HUAWEI/Pushkin/Pushkin:15/AP3A.241005.015.A1/Pushkin.241005.001:user/release-keys"

[templates."huawei_cas_al50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CAS-AL50"
device = "Cangshan"
product = "Cangshan"
name = "Cangshan"
marketname = "HUAWEI nova 16 SE"
fingerprint = "HUAWEI/Cangshan/Cangshan:15/AP3A.241005.015.A1/Cangshan.241005.001:user/release-keys"

[templates."huawei_huawei_g6_t00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI G6-T00"
device = "HUAWEI G6-T00"
product = "HUAWEI G6-T00"
marketname = "HUAWEI Ascend G6"
fingerprint = "HUAWEI/HUAWEI G6-T00/HUAWEI G6-T00:15/AP3A.241005.015.A1/HUAWEIG6-T00.241005.001:user/release-keys"

[templates."huawei_huawei_g7_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI G7-TL00"
device = "HUAWEI G7-TL00"
product = "HUAWEI G7-TL00"
marketname = "HUAWEI Ascend G7"
fingerprint = "HUAWEI/HUAWEI G7-TL00/HUAWEI G7-TL00:15/AP3A.241005.015.A1/HUAWEIG7-TL00.241005.001:user/release-keys"

[templates."huawei_huawei_rio_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI RIO-TL00"
device = "Rio"
product = "Rio"
name = "Rio"
marketname = "HUAWEI G7 Plus"
fingerprint = "HUAWEI/Rio/Rio:15/AP3A.241005.015.A1/Rio.241005.001:user/release-keys"

[templates."huawei_huawei_vns_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI VNS-AL00"
device = "Venus"
product = "Venus"
name = "Venus"
marketname = "HUAWEI G9 青春版"
fingerprint = "HUAWEI/Venus/Venus:15/AP3A.241005.015.A1/Venus.241005.001:user/release-keys"

[templates."huawei_huawei_mla_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MLA-TL00"
device = "Milan"
product = "Milan"
name = "Milan"
marketname = "HUAWEI G9 Plus"
fingerprint = "HUAWEI/Milan/Milan:15/AP3A.241005.015.A1/Milan.241005.001:user/release-keys"

[templates."huawei_huawei_a199"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI A199"
device = "HUAWEI A199"
product = "HUAWEI A199"
marketname = "HUAWEI 麦芒 A199"
fingerprint = "HUAWEI/HUAWEI A199/HUAWEI A199:15/AP3A.241005.015.A1/HUAWEIA199.241005.001:user/release-keys"

[templates."huawei_huawei_b199"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI B199"
device = "HUAWEI B199"
product = "HUAWEI B199"
marketname = "HUAWEI 麦芒 B199"
fingerprint = "HUAWEI/HUAWEI B199/HUAWEI B199:15/AP3A.241005.015.A1/HUAWEIB199.241005.001:user/release-keys"

[templates."huawei_huawei_c199"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI C199"
device = "HUAWEI C199"
product = "HUAWEI C199"
marketname = "HUAWEI 麦芒 C199"
fingerprint = "HUAWEI/HUAWEI C199/HUAWEI C199:15/AP3A.241005.015.A1/HUAWEIC199.241005.001:user/release-keys"

[templates."huawei_huawei_c199s"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI C199s"
device = "HUAWEI C199s"
product = "HUAWEI C199s"
marketname = "HUAWEI 麦芒 3S"
fingerprint = "HUAWEI/HUAWEI C199s/HUAWEI C199s:15/AP3A.241005.015.A1/HUAWEIC199s.241005.001:user/release-keys"

[templates."huawei_huawei_rio_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI RIO-AL00"
device = "Rio"
product = "Rio"
name = "Rio"
marketname = "HUAWEI 麦芒 4"
fingerprint = "HUAWEI/Rio/Rio:15/AP3A.241005.015.A1/Rio.241005.001:user/release-keys"

[templates."huawei_huawei_mla_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MLA-AL00"
device = "Milan"
product = "Milan"
name = "Milan"
marketname = "HUAWEI 麦芒 5"
fingerprint = "HUAWEI/Milan/Milan:15/AP3A.241005.015.A1/Milan.241005.001:user/release-keys"

[templates."huawei_rne_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "RNE-AL00"
device = "Rhone"
product = "Rhone"
name = "Rhone"
marketname = "HUAWEI 麦芒 6"
fingerprint = "HUAWEI/Rhone/Rhone:15/AP3A.241005.015.A1/Rhone.241005.001:user/release-keys"

[templates."huawei_sne_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SNE-AL00"
device = "SydneyM"
product = "SydneyM"
name = "SydneyM"
marketname = "HUAWEI 麦芒 7"
fingerprint = "HUAWEI/SydneyM/SydneyM:15/AP3A.241005.015.A1/SydneyM.241005.001:user/release-keys"

[templates."huawei_pot_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "POT-AL00"
device = "Potterpro"
product = "Potterpro"
name = "Potterpro"
marketname = "HUAWEI 麦芒 8"
fingerprint = "HUAWEI/Potterpro/Potterpro:15/AP3A.241005.015.A1/Potterpro.241005.001:user/release-keys"

[templates."huawei_tnn_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "TNN-AN00"
device = "Tianshan"
product = "Tianshan"
name = "Tianshan"
marketname = "HUAWEI 麦芒 9 5G"
fingerprint = "HUAWEI/Tianshan/Tianshan:15/AP3A.241005.015.A1/Tianshan.241005.001:user/release-keys"

[templates."huawei_huawei_tit_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI TIT-AL00"
device = "HUAWEI TIT-AL00"
product = "HUAWEI TIT-AL00"
marketname = "HUAWEI 畅享 5"
fingerprint = "HUAWEI/HUAWEI TIT-AL00/HUAWEI TIT-AL00:15/AP3A.241005.015.A1/HUAWEITIT-AL00.241005.001:user/release-keys"

[templates."huawei_huawei_tag_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI TAG-AL00"
device = "HUAWEI TAG-AL00"
product = "HUAWEI TAG-AL00"
marketname = "HUAWEI 畅享 5S"
fingerprint = "HUAWEI/HUAWEI TAG-AL00/HUAWEI TAG-AL00:15/AP3A.241005.015.A1/HUAWEITAG-AL00.241005.001:user/release-keys"

[templates."huawei_nce_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "NCE-AL00"
device = "Nice"
product = "Nice"
name = "Nice"
marketname = "HUAWEI 畅享 6"
fingerprint = "HUAWEI/Nice/Nice:15/AP3A.241005.015.A1/Nice.241005.001:user/release-keys"

[templates."huawei_dig_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DIG-AL00"
device = "Diego"
product = "Diego"
name = "Diego"
marketname = "HUAWEI 畅享 6S"
fingerprint = "HUAWEI/Diego/Diego:15/AP3A.241005.015.A1/Diego.241005.001:user/release-keys"

[templates."huawei_trt_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "TRT-AL00"
device = "Toronto"
product = "Toronto"
name = "Toronto"
marketname = "HUAWEI 畅享 7 Plus"
fingerprint = "HUAWEI/Toronto/Toronto:15/AP3A.241005.015.A1/Toronto.241005.001:user/release-keys"

[templates."huawei_sla_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SLA-AL00"
device = "Selina"
product = "Selina"
name = "Selina"
marketname = "HUAWEI 畅享 7"
fingerprint = "HUAWEI/Selina/Selina:15/AP3A.241005.015.A1/Selina.241005.001:user/release-keys"

[templates."huawei_fig_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "FIG-AL00"
device = "Figo"
product = "Figo"
name = "Figo"
marketname = "HUAWEI 畅享 7S"
fingerprint = "HUAWEI/Figo/Figo:15/AP3A.241005.015.A1/Figo.241005.001:user/release-keys"

[templates."huawei_fig_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "FIG-TL00"
device = "Figo"
product = "Figo"
name = "Figo"
marketname = "HUAWEI 畅享 7S 移动 4G+"
fingerprint = "HUAWEI/Figo/Figo:15/AP3A.241005.015.A1/Figo.241005.001:user/release-keys"

[templates."huawei_fla_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "FLA-AL00"
device = "Florida"
product = "Florida"
name = "Florida"
marketname = "HUAWEI 畅享 8 Plus"
fingerprint = "HUAWEI/Florida/Florida:15/AP3A.241005.015.A1/Florida.241005.001:user/release-keys"

[templates."huawei_ldn_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LDN-AL00"
device = "London"
product = "London"
name = "London"
marketname = "HUAWEI 畅享 8"
fingerprint = "HUAWEI/London/London:15/AP3A.241005.015.A1/London.241005.001:user/release-keys"

[templates."huawei_ldn_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LDN-TL00"
device = "London"
product = "London"
name = "London"
marketname = "HUAWEI 畅享 8 移动 4G+"
fingerprint = "HUAWEI/London/London:15/AP3A.241005.015.A1/London.241005.001:user/release-keys"

[templates."huawei_atu_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ATU-AL10"
device = "Atomu"
product = "Atomu"
name = "Atomu"
marketname = "HUAWEI 畅享 8e"
fingerprint = "HUAWEI/Atomu/Atomu:15/AP3A.241005.015.A1/Atomu.241005.001:user/release-keys"

[templates."huawei_dra_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DRA-AL00"
device = "Dura"
product = "Dura"
name = "Dura"
marketname = "HUAWEI 畅享 8e 青春"
fingerprint = "HUAWEI/Dura/Dura:15/AP3A.241005.015.A1/Dura.241005.001:user/release-keys"

[templates."huawei_jkm_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "JKM-AL00"
device = "Jackman"
product = "Jackman"
name = "Jackman"
marketname = "HUAWEI 畅享 9 Plus"
fingerprint = "HUAWEI/Jackman/Jackman:15/AP3A.241005.015.A1/Jackman.241005.001:user/release-keys"

[templates."huawei_ars_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ARS-AL00"
device = "Ares"
product = "Ares"
name = "Ares"
marketname = "HUAWEI 畅享 MAX"
fingerprint = "HUAWEI/Ares/Ares:15/AP3A.241005.015.A1/Ares.241005.001:user/release-keys"

[templates."huawei_dub_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DUB-AL00"
device = "Dubai"
product = "Dubai"
name = "Dubai"
marketname = "HUAWEI 畅享 9"
fingerprint = "HUAWEI/Dubai/Dubai:15/AP3A.241005.015.A1/Dubai.241005.001:user/release-keys"

[templates."huawei_dub_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DUB-TL00"
device = "Dubai"
product = "Dubai"
name = "Dubai"
marketname = "HUAWEI 畅享 9 移动 4G+"
fingerprint = "HUAWEI/Dubai/Dubai:15/AP3A.241005.015.A1/Dubai.241005.001:user/release-keys"

[templates."huawei_pot_al00a"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "POT-AL00A"
device = "Potter"
product = "Potter"
name = "Potter"
marketname = "HUAWEI 畅享 9S"
fingerprint = "HUAWEI/Potter/Potter:15/AP3A.241005.015.A1/Potter.241005.001:user/release-keys"

[templates."huawei_mrd_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MRD-AL00"
device = "Madrid"
product = "Madrid"
name = "Madrid"
marketname = "HUAWEI 畅享 9e"
fingerprint = "HUAWEI/Madrid/Madrid:15/AP3A.241005.015.A1/Madrid.241005.001:user/release-keys"

[templates."huawei_stk_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "STK-AL00"
device = "Stark"
product = "Stark"
name = "Stark"
marketname = "HUAWEI 畅享 10 Plus"
fingerprint = "HUAWEI/Stark/Stark:15/AP3A.241005.015.A1/Stark.241005.001:user/release-keys"

[templates."huawei_art_al00x"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ART-AL00X"
device = "Arthur"
product = "Arthur"
name = "Arthur"
marketname = "HUAWEI 畅享 10"
fingerprint = "HUAWEI/Arthur/Arthur:15/AP3A.241005.015.A1/Arthur.241005.001:user/release-keys"

[templates."huawei_aqm_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "AQM-AL00"
device = "Aquaman"
product = "Aquaman"
name = "Aquaman"
marketname = "HUAWEI 畅享 10S"
fingerprint = "HUAWEI/Aquaman/Aquaman:15/AP3A.241005.015.A1/Aquaman.241005.001:user/release-keys"

[templates."huawei_med_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MED-AL00"
device = "Merida"
product = "Merida"
name = "Merida"
marketname = "HUAWEI 畅享 10e"
fingerprint = "HUAWEI/Merida/Merida:15/AP3A.241005.015.A1/Merida.241005.001:user/release-keys"

[templates."huawei_dvc_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DVC-AN00"
device = "Davinci"
product = "Davinci"
name = "Davinci"
marketname = "HUAWEI 畅享 Z 5G"
fingerprint = "HUAWEI/Davinci/Davinci:15/AP3A.241005.015.A1/Davinci.241005.001:user/release-keys"

[templates."huawei_dvc_an20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DVC-AN20"
device = "Davinci"
product = "Davinci"
name = "Davinci"
marketname = "HUAWEI 畅享 20 Pro 5G"
fingerprint = "HUAWEI/Davinci/Davinci:15/AP3A.241005.015.A1/Davinci.241005.001:user/release-keys"

[templates."huawei_wkg_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "WKG-AN00"
device = "Wukong"
product = "Wukong"
name = "Wukong"
marketname = "HUAWEI 畅享 20 5G"
fingerprint = "HUAWEI/Wukong/Wukong:15/AP3A.241005.015.A1/Wukong.241005.001:user/release-keys"

[templates."huawei_frl_an00a"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "FRL-AN00A"
device = "Franklin"
product = "Franklin"
name = "Franklin"
marketname = "HUAWEI 畅享 20 Plus 5G"
fingerprint = "HUAWEI/Franklin/Franklin:15/AP3A.241005.015.A1/Franklin.241005.001:user/release-keys"

[templates."huawei_ppa_al20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PPA-AL20"
device = "Peppa"
product = "Peppa"
name = "Peppa"
marketname = "HUAWEI 畅享 20 SE"
fingerprint = "HUAWEI/Peppa/Peppa:15/AP3A.241005.015.A1/Peppa.241005.001:user/release-keys"

[templates."huawei_mld_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MLD-AL00"
device = "MLD-AL00"
product = "MLD-AL00"
marketname = "HUAWEI 畅享 20e"
fingerprint = "HUAWEI/MLD-AL00/MLD-AL00:15/AP3A.241005.015.A1/MLD-AL00.241005.001:user/release-keys"

[templates."huawei_mga_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MGA-AL00"
device = "Mega"
product = "Mega"
name = "Mega"
marketname = "HUAWEI 畅享 50"
fingerprint = "HUAWEI/Mega/Mega:15/AP3A.241005.015.A1/Mega.241005.001:user/release-keys"

[templates."huawei_ctr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CTR-AL00"
device = "Cartier"
product = "Cartier"
name = "Cartier"
marketname = "HUAWEI 畅享 50 Pro"
fingerprint = "HUAWEI/Cartier/Cartier:15/AP3A.241005.015.A1/Cartier.241005.001:user/release-keys"

[templates."huawei_eve_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "EVE-AL00"
device = "Eevee"
product = "Eevee"
name = "Eevee"
marketname = "HUAWEI 畅享 50z"
fingerprint = "HUAWEI/Eevee/Eevee:15/AP3A.241005.015.A1/Eevee.241005.001:user/release-keys"

[templates."huawei_mga_al40"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MGA-AL40"
device = "Mega"
product = "Mega"
name = "Mega"
marketname = "HUAWEI 畅享 60"
fingerprint = "HUAWEI/Mega/Mega:15/AP3A.241005.015.A1/Mega.241005.001:user/release-keys"

[templates."huawei_stg_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "STG-AL00"
device = "Santiago"
product = "Santiago"
name = "Santiago"
marketname = "HUAWEI 畅享 60X"
fingerprint = "HUAWEI/Santiago/Santiago:15/AP3A.241005.015.A1/Santiago.241005.001:user/release-keys"

[templates."huawei_mao_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MAO-AL00"
device = "Mario"
product = "Mario"
name = "Mario"
marketname = "HUAWEI 畅享 60 Pro"
fingerprint = "HUAWEI/Mario/Mario:15/AP3A.241005.015.A1/Mario.241005.001:user/release-keys"

[templates."huawei_fgd_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "FGD-AL00"
device = "Garfield"
product = "Garfield"
name = "Garfield"
marketname = "HUAWEI 畅享 70"
fingerprint = "HUAWEI/Garfield/Garfield:15/AP3A.241005.015.A1/Garfield.241005.001:user/release-keys"

[templates."huawei_ctr_al20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CTR-AL20"
device = "Cartier"
product = "Cartier"
name = "Cartier"
marketname = "HUAWEI 畅享 70 Pro"
fingerprint = "HUAWEI/Cartier/Cartier:15/AP3A.241005.015.A1/Cartier.241005.001:user/release-keys"

[templates."huawei_gfy_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "GFY-AL00"
device = "Goofy"
product = "Goofy"
name = "Goofy"
marketname = "HUAWEI 畅享 70S"
fingerprint = "HUAWEI/Goofy/Goofy:15/AP3A.241005.015.A1/Goofy.241005.001:user/release-keys"

[templates."huawei_bre_al80"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BRE-AL80"
device = "BRE-AL80"
product = "BRE-AL80"
marketname = "HUAWEI 畅享 70X"
fingerprint = "HUAWEI/BRE-AL80/BRE-AL80:15/AP3A.241005.015.A1/BRE-AL80.241005.001:user/release-keys"

[templates."huawei_bre_al00a"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BRE-AL00A"
device = "Bruce"
product = "Bruce"
name = "Bruce"
marketname = "HUAWEI 畅享 70X 活力版"
fingerprint = "HUAWEI/Bruce/Bruce:15/AP3A.241005.015.A1/Bruce.241005.001:user/release-keys"

[templates."huawei_juy_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "JUY-AL00"
device = "Judy"
product = "Judy"
name = "Judy"
marketname = "HUAWEI 畅享 80"
fingerprint = "HUAWEI/Judy/Judy:15/AP3A.241005.015.A1/Judy.241005.001:user/release-keys"

[templates."huawei_juy_al80"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "JUY-AL80"
device = "Judy"
product = "Judy"
name = "Judy"
marketname = "HUAWEI 畅享 90"
fingerprint = "HUAWEI/Judy/Judy:15/AP3A.241005.015.A1/Judy.241005.001:user/release-keys"

[templates."huawei_juy_al50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "JUY-AL50"
device = "Judy"
product = "Judy"
name = "Judy"
marketname = "HUAWEI 畅享 90 Plus"
fingerprint = "HUAWEI/Judy/Judy:15/AP3A.241005.015.A1/Judy.241005.001:user/release-keys"

[templates."huawei_chz_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CHZ-AL00"
device = "Chenzhen"
product = "Chenzhen"
name = "Chenzhen"
marketname = "HUAWEI 畅享 90 Pro Max"
fingerprint = "HUAWEI/Chenzhen/Chenzhen:15/AP3A.241005.015.A1/Chenzhen.241005.001:user/release-keys"

[templates."huawei_jal_al90"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "JAL-AL90"
device = "JAL-AL90"
product = "JAL-AL90"
marketname = "HUAWEI 畅享 100"
fingerprint = "HUAWEI/JAL-AL90/JAL-AL90:15/AP3A.241005.015.A1/JAL-AL90.241005.001:user/release-keys"

[templates."huawei_chz_al60"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CHZ-AL60"
device = "Chenzhen"
product = "Chenzhen"
name = "Chenzhen"
marketname = "HUAWEI 畅享 100 Pro"
fingerprint = "HUAWEI/Chenzhen/Chenzhen:15/AP3A.241005.015.A1/Chenzhen.241005.001:user/release-keys"

[templates."huawei_yew_al80"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "YEW-AL80"
device = "Yewen"
product = "Yewen"
name = "Yewen"
marketname = "HUAWEI 畅享 100 Pro Max"
fingerprint = "HUAWEI/Yewen/Yewen:15/AP3A.241005.015.A1/Yewen.241005.001:user/release-keys"

[templates."huawei_s8_301w"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "S8-301W"
device = "S8-301W"
product = "S8-301W"
marketname = "HUAWEI MediaPad M1"
fingerprint = "HUAWEI/S8-301W/S8-301W:15/AP3A.241005.015.A1/S8-301W.241005.001:user/release-keys"

[templates."huawei_huawei_m2_801w"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI M2-801W"
device = "Mozart"
product = "Mozart"
name = "Mozart"
marketname = "HUAWEI 揽阅 M2 8.0"
fingerprint = "HUAWEI/Mozart/Mozart:15/AP3A.241005.015.A1/Mozart.241005.001:user/release-keys"

[templates."huawei_huawei_m2_a01w"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI M2-A01W"
device = "HUAWEI M2-A01W"
product = "HUAWEI M2-A01W"
marketname = "HUAWEI 揽阅 M2 10.0"
fingerprint = "HUAWEI/HUAWEI M2-A01W/HUAWEI M2-A01W:15/AP3A.241005.015.A1/HUAWEIM2-A01W.241005.001:user/release-keys"

[templates."huawei_ple_703l"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PLE-703L"
device = "PLE-703L"
product = "PLE-703L"
marketname = "HUAWEI 揽阅 M2 青春版 7.0 英寸"
fingerprint = "HUAWEI/PLE-703L/PLE-703L:15/AP3A.241005.015.A1/PLE-703L.241005.001:user/release-keys"

[templates."huawei_fdr_a01w"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "FDR-A01w"
device = "FDR-A01w"
product = "FDR-A01w"
marketname = "HUAWEI 揽阅 M2 青春版 10.1 英寸"
fingerprint = "HUAWEI/FDR-A01w/FDR-A01w:15/AP3A.241005.015.A1/FDR-A01w.241005.001:user/release-keys"

[templates."huawei_btv_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BTV-W09"
device = "Beethoven"
product = "Beethoven"
name = "Beethoven"
marketname = "HUAWEI 平板 M3"
fingerprint = "HUAWEI/Beethoven/Beethoven:15/AP3A.241005.015.A1/Beethoven.241005.001:user/release-keys"

[templates."huawei_cpn_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CPN-W09"
device = "Chopin"
product = "Chopin"
name = "Chopin"
marketname = "HUAWEI 平板 M3 青春版 8.0 英寸"
fingerprint = "HUAWEI/Chopin/Chopin:15/AP3A.241005.015.A1/Chopin.241005.001:user/release-keys"

[templates."huawei_bah_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BAH-W09"
device = "Bach"
product = "Bach"
name = "Bach"
marketname = "HUAWEI 平板 M3 青春版 10.1 英寸"
fingerprint = "HUAWEI/Bach/Bach:15/AP3A.241005.015.A1/Bach.241005.001:user/release-keys"

[templates."huawei_sht_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SHT-W09"
device = "Schubert"
product = "Schubert"
name = "Schubert"
marketname = "HUAWEI 平板 M5 8.4 英寸"
fingerprint = "HUAWEI/Schubert/Schubert:15/AP3A.241005.015.A1/Schubert.241005.001:user/release-keys"

[templates."huawei_cmr_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CMR-W09"
device = "Cameron"
product = "Cameron"
name = "Cameron"
marketname = "HUAWEI 平板 M5 10.8 英寸"
fingerprint = "HUAWEI/Cameron/Cameron:15/AP3A.241005.015.A1/Cameron.241005.001:user/release-keys"

[templates."huawei_cmr_w19"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CMR-W19"
device = "Cameron"
product = "Cameron"
name = "Cameron"
marketname = "HUAWEI 平板 M5 Pro"
fingerprint = "HUAWEI/Cameron/Cameron:15/AP3A.241005.015.A1/Cameron.241005.001:user/release-keys"

[templates."huawei_bah2_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BAH2-W09"
device = "Bach2"
product = "Bach2"
name = "Bach2"
marketname = "HUAWEI 平板 M5 青春版 10.1 英寸"
fingerprint = "HUAWEI/Bach2/Bach2:15/AP3A.241005.015.A1/Bach2.241005.001:user/release-keys"

[templates."huawei_jdn2_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "JDN2-W09"
device = "Jordan2"
product = "Jordan2"
name = "Jordan2"
marketname = "HUAWEI 平板 M5 青春版 8 英寸"
fingerprint = "HUAWEI/Jordan2/Jordan2:15/AP3A.241005.015.A1/Jordan2.241005.001:user/release-keys"

[templates."huawei_vrd_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "VRD-W09"
device = "Verdi"
product = "Verdi"
name = "Verdi"
marketname = "HUAWEI 平板 M6 8.4 英寸"
fingerprint = "HUAWEI/Verdi/Verdi:15/AP3A.241005.015.A1/Verdi.241005.001:user/release-keys"

[templates."huawei_vrd_w10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "VRD-W10"
device = "Verdi"
product = "Verdi"
name = "Verdi"
marketname = "HUAWEI 平板 M6 高能版 8.4 英寸"
fingerprint = "HUAWEI/Verdi/Verdi:15/AP3A.241005.015.A1/Verdi.241005.001:user/release-keys"

[templates."huawei_scm_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SCM-W09"
device = "Schumann"
product = "Schumann"
name = "Schumann"
marketname = "HUAWEI 平板 M6 10.8 英寸"
fingerprint = "HUAWEI/Schumann/Schumann:15/AP3A.241005.015.A1/Schumann.241005.001:user/release-keys"

[templates."huawei_mrx_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MRX-W09"
device = "Marx"
product = "Marx"
name = "Marx"
marketname = "HUAWEI MatePad Pro 10.8 英寸"
fingerprint = "HUAWEI/Marx/Marx:15/AP3A.241005.015.A1/Marx.241005.001:user/release-keys"

[templates."huawei_mrr_w29"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MRR-W29"
device = "MarxR"
product = "MarxR"
name = "MarxR"
marketname = "HUAWEI MatePad Pro 10.8 英寸 2021"
fingerprint = "HUAWEI/MarxR/MarxR:15/AP3A.241005.015.A1/MarxR.241005.001:user/release-keys"

[templates."huawei_got_w29"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "GOT-W29"
device = "Goethe"
product = "Goethe"
name = "Goethe"
marketname = "HUAWEI MatePad Pro 11 英寸"
fingerprint = "HUAWEI/Goethe/Goethe:15/AP3A.241005.015.A1/Goethe.241005.001:user/release-keys"

[templates."huawei_got_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "GOT-W09"
device = "Goethe"
product = "Goethe"
name = "Goethe"
marketname = "HUAWEI MatePad Pro 11 英寸 性能版"
fingerprint = "HUAWEI/Goethe/Goethe:15/AP3A.241005.015.A1/Goethe.241005.001:user/release-keys"

[templates."huawei_xyao_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "XYAO-W00"
device = "Xiaoyao"
product = "Xiaoyao"
name = "Xiaoyao"
marketname = "HUAWEI MatePad Pro 11 英寸 2024"
fingerprint = "HUAWEI/Xiaoyao/Xiaoyao:15/AP3A.241005.015.A1/Xiaoyao.241005.001:user/release-keys"

[templates."huawei_wgr_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "WGR-W09"
device = "Wagner"
product = "Wagner"
name = "Wagner"
marketname = "HUAWEI MatePad Pro 12.6 英寸 2021"
fingerprint = "HUAWEI/Wagner/Wagner:15/AP3A.241005.015.A1/Wagner.241005.001:user/release-keys"

[templates."huawei_wgrr_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "WGRR-W09"
device = "WagnerR"
product = "WagnerR"
name = "WagnerR"
marketname = "HUAWEI MatePad Pro 12.6 英寸 2022"
fingerprint = "HUAWEI/WagnerR/WagnerR:15/AP3A.241005.015.A1/WagnerR.241005.001:user/release-keys"

[templates."huawei_pce_w30"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PCE-W30"
device = "Poincare"
product = "Poincare"
name = "Poincare"
marketname = "HUAWEI MatePad Pro 13.2 英寸"
fingerprint = "HUAWEI/Poincare/Poincare:15/AP3A.241005.015.A1/Poincare.241005.001:user/release-keys"

[templates."huawei_pce_al30"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PCE-AL30"
device = "Poincare"
product = "Poincare"
name = "Poincare"
marketname = "HUAWEI MatePad Pro 13.2 英寸 SIM 卡版"
fingerprint = "HUAWEI/Poincare/Poincare:15/AP3A.241005.015.A1/Poincare.241005.001:user/release-keys"

[templates."huawei_pce_al40"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PCE-AL40"
device = "Poincare"
product = "Poincare"
name = "Poincare"
marketname = "HUAWEI MatePad Pro 13.2 英寸 典藏版 SIM 卡版"
fingerprint = "HUAWEI/Poincare/Poincare:15/AP3A.241005.015.A1/Poincare.241005.001:user/release-keys"

[templates."huawei_mro_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MRO-W00"
device = "Miro"
product = "Miro"
name = "Miro"
marketname = "HUAWEI MatePad Pro 12.2 英寸"
fingerprint = "HUAWEI/Miro/Miro:15/AP3A.241005.015.A1/Miro.241005.001:user/release-keys"

[templates."huawei_mro_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MRO-AL10"
device = "Miro"
product = "Miro"
name = "Miro"
marketname = "HUAWEI MatePad Pro 12.2 英寸 SIM 卡版"
fingerprint = "HUAWEI/Miro/Miro:15/AP3A.241005.015.A1/Miro.241005.001:user/release-keys"

[templates."huawei_web_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "WEB-W00"
device = "Weber"
product = "Weber"
name = "Weber"
marketname = "HUAWEI MatePad Pro 13.2 英寸 2025"
fingerprint = "HUAWEI/Weber/Weber:15/AP3A.241005.015.A1/Weber.241005.001:user/release-keys"

[templates."huawei_web_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "WEB-AL00"
device = "Weber"
product = "Weber"
name = "Weber"
marketname = "HUAWEI MatePad Pro 13.2 英寸 2025 典藏版 SIM 卡版"
fingerprint = "HUAWEI/Weber/Weber:15/AP3A.241005.015.A1/Weber.241005.001:user/release-keys"

[templates."huawei_web_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "WEB-AL10"
device = "Weber"
product = "Weber"
name = "Weber"
marketname = "HUAWEI MatePad Pro 13.2 英寸 2025 SIM 卡版"
fingerprint = "HUAWEI/Weber/Weber:15/AP3A.241005.015.A1/Weber.241005.001:user/release-keys"

[templates."huawei_mrdi_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MRDI-W00"
device = "Morandi"
product = "Morandi"
name = "Morandi"
marketname = "HUAWEI MatePad Pro 12.2 英寸 2025"
fingerprint = "HUAWEI/Morandi/Morandi:15/AP3A.241005.015.A1/Morandi.241005.001:user/release-keys"

[templates."huawei_gem_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "GEM-W00"
device = "Gellmann"
product = "Gellmann"
name = "Gellmann"
marketname = "HUAWEI MatePad Pro Max 13.2 英寸"
fingerprint = "HUAWEI/Gellmann/Gellmann:15/AP3A.241005.015.A1/Gellmann.241005.001:user/release-keys"

[templates."huawei_gem_w40"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "GEM-W40"
device = "Gellmann"
product = "Gellmann"
name = "Gellmann"
marketname = "HUAWEI MatePad Pro Max 13.2 英寸 悦享款"
fingerprint = "HUAWEI/Gellmann/Gellmann:15/AP3A.241005.015.A1/Gellmann.241005.001:user/release-keys"

[templates."huawei_dal_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DAL-W00"
device = "Dali"
product = "Dali"
name = "Dali"
marketname = "HUAWEI MatePad Pro 12 英寸"
fingerprint = "HUAWEI/Dali/Dali:15/AP3A.241005.015.A1/Dali.241005.001:user/release-keys"

[templates."huawei_dal_w20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DAL-W20"
device = "Dali"
product = "Dali"
name = "Dali"
marketname = "HUAWEI MatePad Pro 12 英寸 悦享款"
fingerprint = "HUAWEI/Dali/Dali:15/AP3A.241005.015.A1/Dali.241005.001:user/release-keys"

[templates."huawei_qxs_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "QXS-W00"
device = "Qianxuesen"
product = "Qianxuesen"
name = "Qianxuesen"
marketname = "HUAWEI MatePad Edge"
fingerprint = "HUAWEI/Qianxuesen/Qianxuesen:15/AP3A.241005.015.A1/Qianxuesen.241005.001:user/release-keys"

[templates."huawei_qxs_w20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "QXS-W20"
device = "Qianxuesen"
product = "Qianxuesen"
name = "Qianxuesen"
marketname = "HUAWEI MatePad Edge 液冷版"
fingerprint = "HUAWEI/Qianxuesen/Qianxuesen:15/AP3A.241005.015.A1/Qianxuesen.241005.001:user/release-keys"

[templates."huawei_dby2_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DBY2-W00"
device = "Debussy2"
product = "Debussy2"
name = "Debussy2"
marketname = "HUAWEI MatePad Air 11.5 英寸"
fingerprint = "HUAWEI/Debussy2/Debussy2:15/AP3A.241005.015.A1/Debussy2.241005.001:user/release-keys"

[templates."huawei_bky_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BKY-W00"
device = "Banksy"
product = "Banksy"
name = "Banksy"
marketname = "HUAWEI MatePad Air 12 英寸"
fingerprint = "HUAWEI/Banksy/Banksy:15/AP3A.241005.015.A1/Banksy.241005.001:user/release-keys"

[templates."huawei_lrt_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LRT-W00"
device = "Laurent"
product = "Laurent"
name = "Laurent"
marketname = "HUAWEI MatePad Air 12 英寸 2025"
fingerprint = "HUAWEI/Laurent/Laurent:15/AP3A.241005.015.A1/Laurent.241005.001:user/release-keys"

[templates."huawei_wki_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "WKI-W00"
device = "WKI-W00"
product = "WKI-W00"
marketname = "HUAWEI MatePad Air 12 英寸 2026 悦享款"
fingerprint = "HUAWEI/WKI-W00/WKI-W00:15/AP3A.241005.015.A1/WKI-W00.241005.001:user/release-keys"

[templates."huawei_wki_w10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "WKI-W10"
device = "WKI-W10"
product = "WKI-W10"
marketname = "HUAWEI MatePad Air 12 英寸 2026"
fingerprint = "HUAWEI/WKI-W10/WKI-W10:15/AP3A.241005.015.A1/WKI-W10.241005.001:user/release-keys"

[templates."huawei_ast_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "AST-W00"
device = "AST-W00"
product = "AST-W00"
marketname = "HUAWEI MatePad Air Z 12 英寸"
fingerprint = "HUAWEI/AST-W00/AST-W00:15/AP3A.241005.015.A1/AST-W00.241005.001:user/release-keys"

[templates."huawei_ast_w30"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "AST-W30"
device = "AST-W30"
product = "AST-W30"
marketname = "HUAWEI MatePad Air Z 12 英寸 悦享款"
fingerprint = "HUAWEI/AST-W30/AST-W30:15/AP3A.241005.015.A1/AST-W30.241005.001:user/release-keys"

[templates."huawei_bah3_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BAH3-W09"
device = "Bach3"
product = "Bach3"
name = "Bach3"
marketname = "HUAWEI MatePad 10.4 英寸"
fingerprint = "HUAWEI/Bach3/Bach3:15/AP3A.241005.015.A1/Bach3.241005.001:user/release-keys"

[templates."huawei_bah3_an10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BAH3-AN10"
device = "Bach3"
product = "Bach3"
name = "Bach3"
marketname = "HUAWEI MatePad 5G 10.4 英寸"
fingerprint = "HUAWEI/Bach3/Bach3:15/AP3A.241005.015.A1/Bach3.241005.001:user/release-keys"

[templates."huawei_scmr_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SCMR-W09"
device = "SchumannR"
product = "SchumannR"
name = "SchumannR"
marketname = "HUAWEI MatePad 10.8 英寸"
fingerprint = "HUAWEI/SchumannR/SchumannR:15/AP3A.241005.015.A1/SchumannR.241005.001:user/release-keys"

[templates."huawei_bah4_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BAH4-W09"
device = "Bach4"
product = "Bach4"
name = "Bach4"
marketname = "HUAWEI MatePad 10.4 英寸 2022"
fingerprint = "HUAWEI/Bach4/Bach4:15/AP3A.241005.015.A1/Bach4.241005.001:user/release-keys"

[templates."huawei_bah4_w19"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BAH4-W19"
device = "Bach4"
product = "Bach4"
name = "Bach4"
marketname = "HUAWEI MatePad 10.4 英寸 2022 悦动版"
fingerprint = "HUAWEI/Bach4/Bach4:15/AP3A.241005.015.A1/Bach4.241005.001:user/release-keys"

[templates."huawei_dby_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DBY-W09"
device = "Debussy"
product = "Debussy"
name = "Debussy"
marketname = "HUAWEI MatePad 11 英寸"
fingerprint = "HUAWEI/Debussy/Debussy:15/AP3A.241005.015.A1/Debussy.241005.001:user/release-keys"

[templates."huawei_dbr_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DBR-W00"
device = "DebussyR"
product = "DebussyR"
name = "DebussyR"
marketname = "HUAWEI MatePad 11 英寸 2023"
fingerprint = "HUAWEI/DebussyR/DebussyR:15/AP3A.241005.015.A1/DebussyR.241005.001:user/release-keys"

[templates."huawei_btk_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BTK-W00"
device = "Bartok"
product = "Bartok"
name = "Bartok"
marketname = "HUAWEI MatePad 11.5 英寸 2023"
fingerprint = "HUAWEI/Bartok/Bartok:15/AP3A.241005.015.A1/Bartok.241005.001:user/release-keys"

[templates."huawei_btkr_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BTKR-W00"
device = "BartokR"
product = "BartokR"
name = "BartokR"
marketname = "HUAWEI MatePad 11.5 英寸 2024"
fingerprint = "HUAWEI/BartokR/BartokR:15/AP3A.241005.015.A1/BartokR.241005.001:user/release-keys"

[templates."huawei_tgr_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "TGR-W00"
device = "Tagore"
product = "Tagore"
name = "Tagore"
marketname = "HUAWEI MatePad 11.5 S"
fingerprint = "HUAWEI/Tagore/Tagore:15/AP3A.241005.015.A1/Tagore.241005.001:user/release-keys"

[templates."huawei_dmg_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DMG-W00"
device = "Domingo"
product = "Domingo"
name = "Domingo"
marketname = "HUAWEI MatePad 11.5 S 灵动款"
fingerprint = "HUAWEI/Domingo/Domingo:15/AP3A.241005.015.A1/Domingo.241005.001:user/release-keys"

[templates."huawei_slg_w10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SLG-W10"
device = "Salinger"
product = "Salinger"
name = "Salinger"
marketname = "HUAWEI MatePad 11.5 S 2025"
fingerprint = "HUAWEI/Salinger/Salinger:15/AP3A.241005.015.A1/Salinger.241005.001:user/release-keys"

[templates."huawei_slg_w50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SLG-W50"
device = "Salinger"
product = "Salinger"
name = "Salinger"
marketname = "HUAWEI MatePad 11.5 S 2025 灵动款"
fingerprint = "HUAWEI/Salinger/Salinger:15/AP3A.241005.015.A1/Salinger.241005.001:user/release-keys"

[templates."huawei_txz_w10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "TXZ-W10"
device = "Taoxingzhi"
product = "Taoxingzhi"
name = "Taoxingzhi"
marketname = "HUAWEI MatePad 11.5 英寸 2026"
fingerprint = "HUAWEI/Taoxingzhi/Taoxingzhi:15/AP3A.241005.015.A1/Taoxingzhi.241005.001:user/release-keys"

[templates."huawei_txz_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "TXZ-AL10"
device = "Taoxingzhi"
product = "Taoxingzhi"
name = "Taoxingzhi"
marketname = "HUAWEI MatePad 11.5 英寸 2026 SIM 卡版"
fingerprint = "HUAWEI/Taoxingzhi/Taoxingzhi:15/AP3A.241005.015.A1/Taoxingzhi.241005.001:user/release-keys"

[templates."huawei_mlr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MLR-AL00"
device = "Mclaren"
product = "Mclaren"
name = "Mclaren"
marketname = "HUAWEI MatePad Mini 悦读版 8.8 英寸"
fingerprint = "HUAWEI/Mclaren/Mclaren:15/AP3A.241005.015.A1/Mclaren.241005.001:user/release-keys"

[templates."huawei_mlr_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MLR-AL10"
device = "Mclaren"
product = "Mclaren"
name = "Mclaren"
marketname = "HUAWEI MatePad Mini 8.8 英寸"
fingerprint = "HUAWEI/Mclaren/Mclaren:15/AP3A.241005.015.A1/Mclaren.241005.001:user/release-keys"

[templates."huawei_ags2_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "AGS2-W09"
device = "Agassi2"
product = "Agassi2"
name = "Agassi2"
marketname = "HUAWEI 畅享平板 10.1 英寸"
fingerprint = "HUAWEI/Agassi2/Agassi2:15/AP3A.241005.015.A1/Agassi2.241005.001:user/release-keys"

[templates."huawei_ags3_w00d"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "AGS3-W00D"
device = "Agassi3"
product = "Agassi3"
name = "Agassi3"
marketname = "HUAWEI 畅享平板 2 10.1 英寸"
fingerprint = "HUAWEI/Agassi3/Agassi3:15/AP3A.241005.015.A1/Agassi3.241005.001:user/release-keys"

[templates."huawei_ags3k_w20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "AGS3K-W20"
device = "Agassi3K"
product = "Agassi3K"
name = "Agassi3K"
marketname = "HUAWEI MatePad SE 10.1 英寸"
fingerprint = "HUAWEI/Agassi3K/Agassi3K:15/AP3A.241005.015.A1/Agassi3K.241005.001:user/release-keys"

[templates."huawei_ags5_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "AGS5-W00"
device = "Agassi5"
product = "Agassi5"
name = "Agassi5"
marketname = "HUAWEI MatePad SE 10.4 英寸"
fingerprint = "HUAWEI/Agassi5/Agassi5:15/AP3A.241005.015.A1/Agassi5.241005.001:user/release-keys"

[templates."huawei_ags6_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "AGS6-W00"
device = "Agassi6"
product = "Agassi6"
name = "Agassi6"
marketname = "HUAWEI MatePad SE 11 英寸"
fingerprint = "HUAWEI/Agassi6/Agassi6:15/AP3A.241005.015.A1/Agassi6.241005.001:user/release-keys"

[templates."huawei_ags6_w10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "AGS6-W10"
device = "Agassi6R"
product = "Agassi6R"
name = "Agassi6R"
marketname = "HUAWEI MatePad SE 活力版 11 英寸"
fingerprint = "HUAWEI/Agassi6R/Agassi6R:15/AP3A.241005.015.A1/Agassi6R.241005.001:user/release-keys"

[templates."huawei_hmw_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HMW-W09"
device = "Hemingway"
product = "Hemingway"
name = "Hemingway"
marketname = "HUAWEI MatePad Paper 10.3 英寸"
fingerprint = "HUAWEI/Hemingway/Hemingway:15/AP3A.241005.015.A1/Hemingway.241005.001:user/release-keys"

[templates."huawei_hmw_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HMW-AL10"
device = "Hemingway"
product = "Hemingway"
name = "Hemingway"
marketname = "HUAWEI MatePad Paper 典藏版 10.3 英寸"
fingerprint = "HUAWEI/Hemingway/Hemingway:15/AP3A.241005.015.A1/Hemingway.241005.001:user/release-keys"

[templates."huawei_bzk_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BZK-W00"
device = "Kobe"
product = "Kobe"
name = "Kobe"
marketname = "HUAWEI 平板 C3 8 英寸"
fingerprint = "HUAWEI/Kobe/Kobe:15/AP3A.241005.015.A1/Kobe.241005.001:user/release-keys"

[templates."huawei_bza_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BZA-W00"
device = "Agassi"
product = "Agassi"
name = "Agassi"
marketname = "HUAWEI 平板 C3 9.6 英寸"
fingerprint = "HUAWEI/Agassi/Agassi:15/AP3A.241005.015.A1/Agassi.241005.001:user/release-keys"

[templates."huawei_bzd_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BZD-W00"
device = "BZD-W00"
product = "BZD-W00"
marketname = "HUAWEI 平板 C3 8 英寸 2020"
fingerprint = "HUAWEI/BZD-W00/BZD-W00:15/AP3A.241005.015.A1/BZD-W00.241005.001:user/release-keys"

[templates."huawei_bzc_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BZC-W00"
device = "BZC-W00"
product = "BZC-W00"
marketname = "HUAWEI 平板 C3 9.7 英寸 2020"
fingerprint = "HUAWEI/BZC-W00/BZC-W00:15/AP3A.241005.015.A1/BZC-W00.241005.001:user/release-keys"

[templates."huawei_bzh_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BZH-W00"
device = "BZH-W00"
product = "BZH-W00"
marketname = "HUAWEI 平板 C3 9.7 英寸 2022"
fingerprint = "HUAWEI/BZH-W00/BZH-W00:15/AP3A.241005.015.A1/BZH-W00.241005.001:user/release-keys"

[templates."huawei_bxe3_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BXE3-W00"
device = "BXE3-W00"
product = "BXE3-W00"
marketname = "HUAWEI 擎云 C3 10.4 英寸"
fingerprint = "HUAWEI/BXE3-W00/BXE3-W00:15/AP3A.241005.015.A1/BXE3-W00.241005.001:user/release-keys"

[templates."huawei_mon_w19"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "MON-W19"
device = "MON-W19"
product = "MON-W19"
marketname = "HUAWEI 平板 C5 8 英寸"
fingerprint = "HUAWEI/MON-W19/MON-W19:15/AP3A.241005.015.A1/MON-W19.241005.001:user/release-keys"

[templates."huawei_bzt_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BZT-W09"
device = "BZT-W09"
product = "BZT-W09"
marketname = "HUAWEI 平板 C5 10.1 英寸"
fingerprint = "HUAWEI/BZT-W09/BZT-W09:15/AP3A.241005.015.A1/BZT-W09.241005.001:user/release-keys"

[templates."huawei_bzw_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BZW-AL00"
device = "BZW-AL00"
product = "BZW-AL00"
marketname = "HUAWEI 平板 C5 8 英寸 2020"
fingerprint = "HUAWEI/BZW-AL00/BZW-AL00:15/AP3A.241005.015.A1/BZW-AL00.241005.001:user/release-keys"

[templates."huawei_bzt3_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BZT3-W09"
device = "BZT3-W09"
product = "BZT3-W09"
marketname = "HUAWEI 平板 C5 10.4 英寸 2020"
fingerprint = "HUAWEI/BZT3-W09/BZT3-W09:15/AP3A.241005.015.A1/BZT3-W09.241005.001:user/release-keys"

[templates."huawei_bzt3_w59"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BZT3-W59"
device = "BZT3-W59"
product = "BZT3-W59"
marketname = "HUAWEI 平板 C5 10.4 英寸 2021"
fingerprint = "HUAWEI/BZT3-W59/BZT3-W59:15/AP3A.241005.015.A1/BZT3-W59.241005.001:user/release-keys"

[templates."huawei_bzt4_w19"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BZT4-W19"
device = "BZT4-W19"
product = "BZT4-W19"
marketname = "HUAWEI 平板 C5 10.4 英寸 2022"
fingerprint = "HUAWEI/BZT4-W19/BZT4-W19:15/AP3A.241005.015.A1/BZT4-W19.241005.001:user/release-keys"

[templates."huawei_kob2kz_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "KOB2KZ-W09"
device = "Kobe2KZ"
product = "Kobe2KZ"
name = "Kobe2KZ"
marketname = "HUAWEI 擎云 C5 8 英寸"
fingerprint = "HUAWEI/Kobe2KZ/Kobe2KZ:15/AP3A.241005.015.A1/Kobe2KZ.241005.001:user/release-keys"

[templates."huawei_btkz_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BTKZ-W00"
device = "BartokZ"
product = "BartokZ"
name = "BartokZ"
marketname = "HUAWEI 擎云 C5 11.5 英寸"
fingerprint = "HUAWEI/BartokZ/BartokZ:15/AP3A.241005.015.A1/BartokZ.241005.001:user/release-keys"

[templates."huawei_byd5_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BYD5-AL10"
device = "Taoxingzhi"
product = "Taoxingzhi"
name = "Taoxingzhi"
marketname = "HUAWEI 擎云 C5 11.5 英寸 SIM 卡版"
fingerprint = "HUAWEI/Taoxingzhi/Taoxingzhi:15/AP3A.241005.015.A1/Taoxingzhi.241005.001:user/release-keys"

[templates."huawei_bzi_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BZI-W00"
device = "BZI-W00"
product = "BZI-W00"
marketname = "HUAWEI 平板 C5e 10.1 英寸 2022"
fingerprint = "HUAWEI/BZI-W00/BZI-W00:15/AP3A.241005.015.A1/BZI-W00.241005.001:user/release-keys"

[templates."huawei_ags5z_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "AGS5Z-W09"
device = "Agassi5Z"
product = "Agassi5Z"
name = "Agassi5Z"
marketname = "HUAWEI 擎云 C5e 10.4 英寸"
fingerprint = "HUAWEI/Agassi5Z/Agassi5Z:15/AP3A.241005.015.A1/Agassi5Z.241005.001:user/release-keys"

[templates."huawei_bzf5_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BZF5-W00"
device = "Agassi6"
product = "Agassi6"
name = "Agassi6"
marketname = "HUAWEI 擎云 C5e 11 英寸"
fingerprint = "HUAWEI/Agassi6/Agassi6:15/AP3A.241005.015.A1/Agassi6.241005.001:user/release-keys"

[templates."huawei_blf5_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BLF5-W00"
device = "Agassi6"
product = "Agassi6"
name = "Agassi6"
marketname = "HUAWEI 擎云 C5x 11 英寸"
fingerprint = "HUAWEI/Agassi6/Agassi6:15/AP3A.241005.015.A1/Agassi6.241005.001:user/release-keys"

[templates."huawei_bve_w10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "BVE-W10"
device = "BVE-W10"
product = "BVE-W10"
marketname = "HUAWEI 擎云 C5z 10.4 英寸"
fingerprint = "HUAWEI/BVE-W10/BVE-W10:15/AP3A.241005.015.A1/BVE-W10.241005.001:user/release-keys"

[templates."huawei_dby2z_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "DBY2Z-AL00"
device = "Debussy2Z"
product = "Debussy2Z"
name = "Debussy2Z"
marketname = "HUAWEI 擎云 C7 11.5 英寸"
fingerprint = "HUAWEI/Debussy2Z/Debussy2Z:15/AP3A.241005.015.A1/Debussy2Z.241005.001:user/release-keys"

[templates."huawei_ytsfz_5651tp"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "YTSFZ-5651TP"
device = "YutuFZ"
product = "YutuFZ"
name = "YutuFZ"
marketname = "HUAWEI 擎云 S520 i5"
fingerprint = "HUAWEI/YutuFZ/YutuFZ:15/AP3A.241005.015.A1/YutuFZ.241005.001:user/release-keys"

[templates."huawei_ytsfz_7611t"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "YTSFZ-7611T"
device = "YutuFZ"
product = "YutuFZ"
name = "YutuFZ"
marketname = "HUAWEI 擎云 S520 i7"
fingerprint = "HUAWEI/YutuFZ/YutuFZ:15/AP3A.241005.015.A1/YutuFZ.241005.001:user/release-keys"

[templates."huawei_ytgz_5651sp"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "YTGZ-5651SP"
device = "YutuGZ"
product = "YutuGZ"
name = "YutuGZ"
marketname = "HUAWEI 擎云 S520 Gen2 i5"
fingerprint = "HUAWEI/YutuGZ/YutuGZ:15/AP3A.241005.015.A1/YutuGZ.241005.001:user/release-keys"

[templates."huawei_ytgz_7611s"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "YTGZ-7611S"
device = "YutuGZ"
product = "YutuGZ"
name = "YutuGZ"
marketname = "HUAWEI 擎云 S520 Gen2 i7"
fingerprint = "HUAWEI/YutuGZ/YutuGZ:15/AP3A.241005.015.A1/YutuGZ.241005.001:user/release-keys"

[templates."huawei_ytfz_5851s"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "YTFZ-5851S"
device = "YutuFZ"
product = "YutuFZ"
name = "YutuFZ"
marketname = "HUAWEI 擎云 S540 i5"
fingerprint = "HUAWEI/YutuFZ/YutuFZ:15/AP3A.241005.015.A1/YutuFZ.241005.001:user/release-keys"

[templates."huawei_ytfz_7651s"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "YTFZ-7651S"
device = "YutuFZ"
product = "YutuFZ"
name = "YutuFZ"
marketname = "HUAWEI 擎云 S540 i7"
fingerprint = "HUAWEI/YutuFZ/YutuFZ:15/AP3A.241005.015.A1/YutuFZ.241005.001:user/release-keys"

[templates."huawei_ytsgz_5651tp"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "YTSGZ-5651TP"
device = "YutuGZ"
product = "YutuGZ"
name = "YutuGZ"
marketname = "HUAWEI 擎云 G540 Gen2 i5"
fingerprint = "HUAWEI/YutuGZ/YutuGZ:15/AP3A.241005.015.A1/YutuGZ.241005.001:user/release-keys"

[templates."huawei_klvg_16z3_xxx"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "KLVG-16Z3-XXX"
device = "KelvinG"
product = "KelvinG"
name = "KelvinG"
marketname = "HUAWEI 擎云 G740 i5"
fingerprint = "HUAWEI/KelvinG/KelvinG:15/AP3A.241005.015.A1/KelvinG.241005.001:user/release-keys"

[templates."huawei_klvg_16z1_xxx"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "KLVG-16Z1-XXX"
device = "KelvinG"
product = "KelvinG"
name = "KelvinG"
marketname = "HUAWEI 擎云 G740 i7"
fingerprint = "HUAWEI/KelvinG/KelvinG:15/AP3A.241005.015.A1/KelvinG.241005.001:user/release-keys"

[templates."huawei_klvu_wdu0"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "KLVU-WDU0"
device = "KelvinU"
product = "KelvinU"
name = "KelvinU"
marketname = "HUAWEI 擎云 L410"
fingerprint = "HUAWEI/KelvinU/KelvinU:15/AP3A.241005.015.A1/KelvinU.241005.001:user/release-keys"

[templates."huawei_klvv_w5821"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "KLVV-W5821"
device = "KelvinV"
product = "KelvinV"
name = "KelvinV"
marketname = "HUAWEI 擎云 L420"
fingerprint = "HUAWEI/KelvinV/KelvinV:15/AP3A.241005.015.A1/KelvinV.241005.001:user/release-keys"

[templates."huawei_had_w72_001"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HAD-W72-001"
device = "Harden"
product = "Harden"
name = "Harden"
marketname = "HUAWEI 擎云 HM940"
fingerprint = "HUAWEI/Harden/Harden:15/AP3A.241005.015.A1/Harden.241005.001:user/release-keys"

[templates."huawei_leo_dlxxu"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LEO-DLXXU"
device = "Leo"
product = "Leo"
name = "Leo"
marketname = "HUAWEI PORSCHE DESIGN HUAWEI Smartwatch"
fingerprint = "HUAWEI/Leo/Leo:15/AP3A.241005.015.A1/Leo.241005.001:user/release-keys"

[templates."huawei_sya_b19b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "SYA-B19B"
device = "Seiya"
product = "Seiya"
name = "Seiya"
marketname = "HUAWEI 擎云 H3540"
fingerprint = "HUAWEI/Seiya/Seiya:15/AP3A.241005.015.A1/Seiya.241005.001:user/release-keys"

[templates."huawei_nki_b19b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "NKI-B19B"
device = "NKI-B19B"
product = "NKI-B19B"
marketname = "HUAWEI 擎云 H3550"
fingerprint = "HUAWEI/NKI-B19B/NKI-B19B:15/AP3A.241005.015.A1/NKI-B19B.241005.001:user/release-keys"

[templates."huawei_pnx_b19b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "PNX-B19B"
device = "Phoinix"
product = "Phoinix"
name = "Phoinix"
marketname = "HUAWEI 擎云 H5546"
fingerprint = "HUAWEI/Phoinix/Phoinix:15/AP3A.241005.015.A1/Phoinix.241005.001:user/release-keys"

[templates."huawei_vli_b19b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "VLI-B19B"
device = "Vili"
product = "Vili"
name = "Vili"
marketname = "HUAWEI 擎云 H5556"
fingerprint = "HUAWEI/Vili/Vili:15/AP3A.241005.015.A1/Vili.241005.001:user/release-keys"

[templates."huawei_atm_b19b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ATM-B19B"
device = "Atum"
product = "Atum"
name = "Atum"
marketname = "HUAWEI 擎云 H5566"
fingerprint = "HUAWEI/Atum/Atum:15/AP3A.241005.015.A1/Atum.241005.001:user/release-keys"

[templates."huawei_vli_b29b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "VLI-B29B"
device = "Vilipro"
product = "Vilipro"
name = "Vilipro"
marketname = "HUAWEI 擎云 H5756"
fingerprint = "HUAWEI/Vilipro/Vilipro:15/AP3A.241005.015.A1/Vilipro.241005.001:user/release-keys"

[templates."huawei_arc_al2b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ARC-AL2B"
device = "Archi"
product = "Archi"
name = "Archi"
marketname = "HUAWEI 擎云 H7546"
fingerprint = "HUAWEI/Archi/Archi:15/AP3A.241005.015.A1/Archi.241005.001:user/release-keys"

[templates."huawei_rts_al2b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "RTS-AL2B"
device = "RTS-AL2B"
product = "RTS-AL2B"
marketname = "HUAWEI 擎云 H7556"
fingerprint = "HUAWEI/RTS-AL2B/RTS-AL2B:15/AP3A.241005.015.A1/RTS-AL2B.241005.001:user/release-keys"

[templates."huawei_lca_b12"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LCA-B12"
device = "Luca"
product = "Luca"
name = "Luca"
marketname = "HUAWEI 擎云 H9D20"
fingerprint = "HUAWEI/Luca/Luca:15/AP3A.241005.015.A1/Luca.241005.001:user/release-keys"

[templates."huawei_ask_b29b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ASK-B29B"
device = "ASK-B29B"
product = "ASK-B29B"
marketname = "HUAWEI 擎云 HA580"
fingerprint = "HUAWEI/ASK-B29B/ASK-B29B:15/AP3A.241005.015.A1/ASK-B29B.241005.001:user/release-keys"

[templates."huawei_kim_b19b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "KIM-B19B"
device = "Kimi"
product = "Kimi"
name = "Kimi"
marketname = "HUAWEI 擎云 HA590"
fingerprint = "HUAWEI/Kimi/Kimi:15/AP3A.241005.015.A1/Kimi.241005.001:user/release-keys"

[templates."huawei_nor_b39b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "NOR-B39B"
device = "NOR-B39B"
product = "NOR-B39B"
marketname = "HUAWEI 擎云 HA5A0"
fingerprint = "HUAWEI/NOR-B39B/NOR-B39B:15/AP3A.241005.015.A1/NOR-B39B.241005.001:user/release-keys"

[templates."huawei_cdy_b19b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CDY-B19B"
device = "CDY-B19B"
product = "CDY-B19B"
marketname = "HUAWEI 擎云 HA5B0"
fingerprint = "HUAWEI/CDY-B19B/CDY-B19B:15/AP3A.241005.015.A1/CDY-B19B.241005.001:user/release-keys"

[templates."huawei_cmg0_per"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "CMG0-PER"
device = "CMG0-PER"
product = "CMG0-PER"
marketname = "HUAWEI X GENTLE MONSTER Eyewear"
fingerprint = "HUAWEI/CMG0-PER/CMG0-PER:15/AP3A.241005.015.A1/CMG0-PER.241005.001:user/release-keys"

[templates."huawei_fij_cg020"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "FIJ-CG020"
device = "FIJ-CG020"
product = "FIJ-CG020"
marketname = "HUAWEI X GENTLE MONSTER Eyewear II"
fingerprint = "HUAWEI/FIJ-CG020/FIJ-CG020:15/AP3A.241005.015.A1/FIJ-CG020.241005.001:user/release-keys"

[templates."huawei_evi_cg010"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "EVI-CG010"
device = "EVI-CG010"
product = "EVI-CG010"
marketname = "HUAWEI 智能眼镜"
fingerprint = "HUAWEI/EVI-CG010/EVI-CG010:15/AP3A.241005.015.A1/EVI-CG010.241005.001:user/release-keys"

[templates."huawei_lft_g00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "LFT-G00"
device = "LFT-G00"
product = "LFT-G00"
marketname = "HUAWEI 智能眼镜 2"
fingerprint = "HUAWEI/LFT-G00/LFT-G00:15/AP3A.241005.015.A1/LFT-G00.241005.001:user/release-keys"

[templates."huawei_ali_cg01"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "ALI-CG01"
device = "ALI-CG01"
product = "ALI-CG01"
marketname = "HUAWEI Vision Glass"
fingerprint = "HUAWEI/ALI-CG01/ALI-CG01:15/AP3A.241005.015.A1/ALI-CG01.241005.001:user/release-keys"

[templates."huawei_ail_g01"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "AIL-G01"
device = "AIL-G01"
product = "AIL-G01"
marketname = "HUAWEI AI 眼镜"
fingerprint = "HUAWEI/AIL-G01/AIL-G01:15/AP3A.241005.015.A1/AIL-G01.241005.001:user/release-keys"

[templates."huawei_huawei_u9500"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI U9500"
device = "HUAWEI U9500"
product = "HUAWEI U9500"
marketname = "HUAWEI Ascend D1"
fingerprint = "HUAWEI/HUAWEI U9500/HUAWEI U9500:15/AP3A.241005.015.A1/HUAWEIU9500.241005.001:user/release-keys"

[templates."huawei_huawei_u9500e"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI U9500E"
device = "HUAWEI U9500E"
product = "HUAWEI U9500E"
marketname = "HUAWEI Ascend D1 XL"
fingerprint = "HUAWEI/HUAWEI U9500E/HUAWEI U9500E:15/AP3A.241005.015.A1/HUAWEIU9500E.241005.001:user/release-keys"

[templates."huawei_huawei_u9510"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI U9510"
device = "HUAWEI U9510"
product = "HUAWEI U9510"
marketname = "HUAWEI Ascend D1 四核"
fingerprint = "HUAWEI/HUAWEI U9510/HUAWEI U9510:15/AP3A.241005.015.A1/HUAWEIU9510.241005.001:user/release-keys"

[templates."huawei_huawei_u9510e"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI U9510E"
device = "HUAWEI U9510E"
product = "HUAWEI U9510E"
marketname = "HUAWEI Ascend D1 四核 XL"
fingerprint = "HUAWEI/HUAWEI U9510E/HUAWEI U9510E:15/AP3A.241005.015.A1/HUAWEIU9510E.241005.001:user/release-keys"

[templates."huawei_huawei_d2_5000"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI D2-5000"
device = "HUAWEI D2-5000"
product = "HUAWEI D2-5000"
marketname = "HUAWEI Ascend D2"
fingerprint = "HUAWEI/HUAWEI D2-5000/HUAWEI D2-5000:15/AP3A.241005.015.A1/HUAWEID2-5000.241005.001:user/release-keys"

[templates."lenovo_lenovo_l78011"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L78011"
device = "jd2018"
product = "jd2018"
name = "jd2018"
marketname = "Lenovo Z5"
fingerprint = "LENOVO/jd2018/jd2018:15/AP3A.241005.015.A1/jd2018.241005.001:user/release-keys"

[templates."lenovo_lenovo_l78031"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L78031"
device = "zap"
product = "zap"
name = "zap"
marketname = "Lenovo Z5 Pro"
fingerprint = "LENOVO/zap/zap:15/AP3A.241005.015.A1/zap.241005.001:user/release-keys"

[templates."lenovo_lenovo_l78032"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L78032"
device = "heart"
product = "heart"
name = "heart"
marketname = "Lenovo Z5 Pro GT"
fingerprint = "LENOVO/heart/heart:15/AP3A.241005.015.A1/heart.241005.001:user/release-keys"

[templates."lenovo_lenovo_l78071"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L78071"
device = "jd2019"
product = "jd2019"
name = "jd2019"
marketname = "Lenovo Z5s"
fingerprint = "LENOVO/jd2019/jd2019:15/AP3A.241005.015.A1/jd2019.241005.001:user/release-keys"

[templates."lenovo_lenovo_l78051"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L78051"
device = "zippo"
product = "zippo"
name = "zippo"
marketname = "Lenovo Z6 Pro"
fingerprint = "LENOVO/zippo/zippo:15/AP3A.241005.015.A1/zippo.241005.001:user/release-keys"

[templates."lenovo_lenovo_l79041"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L79041"
device = "cream"
product = "cream"
name = "cream"
marketname = "Lenovo Z6 Pro 5G"
fingerprint = "LENOVO/cream/cream:15/AP3A.241005.015.A1/cream.241005.001:user/release-keys"

[templates."lenovo_lenovo_l78121"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L78121"
device = "jd20"
product = "jd20"
name = "jd20"
marketname = "Lenovo Z6"
fingerprint = "LENOVO/jd20/jd20:15/AP3A.241005.015.A1/jd20.241005.001:user/release-keys"

[templates."lenovo_lenovo_l38111"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L38111"
device = "kunlun2"
product = "kunlun2"
name = "kunlun2"
marketname = "Lenovo Z6 青春版"
fingerprint = "LENOVO/kunlun2/kunlun2:15/AP3A.241005.015.A1/kunlun2.241005.001:user/release-keys"

[templates."lenovo_lenovo_k520"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO K520"
device = "seoul"
product = "seoul"
name = "seoul"
marketname = "Lenovo S5"
fingerprint = "LENOVO/seoul/seoul:15/AP3A.241005.015.A1/seoul.241005.001:user/release-keys"

[templates."lenovo_lenovo_l58041"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L58041"
device = "sprout"
product = "sprout"
name = "sprout"
marketname = "Lenovo S5 Pro"
fingerprint = "LENOVO/sprout/sprout:15/AP3A.241005.015.A1/sprout.241005.001:user/release-keys"

[templates."lenovo_lenovo_l58091"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L58091"
device = "sprout"
product = "sprout"
name = "sprout"
marketname = "Lenovo S5 Pro GT"
fingerprint = "LENOVO/sprout/sprout:15/AP3A.241005.015.A1/sprout.241005.001:user/release-keys"

[templates."lenovo_lenovo_k350t"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO K350T"
device = "k350t"
product = "k350t"
name = "k350t"
marketname = "Lenovo K5"
fingerprint = "LENOVO/k350t/k350t:15/AP3A.241005.015.A1/k350t.241005.001:user/release-keys"

[templates."lenovo_lenovo_l38012"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L38012"
device = "austin2018"
product = "austin2018"
name = "austin2018"
marketname = "Lenovo K5 Note"
fingerprint = "LENOVO/austin2018/austin2018:15/AP3A.241005.015.A1/austin2018.241005.001:user/release-keys"

[templates."lenovo_lenovo_l38011"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L38011"
device = "k5"
product = "k5"
name = "k5"
marketname = "Lenovo K5 Play"
fingerprint = "LENOVO/k5/k5:15/AP3A.241005.015.A1/k5.241005.001:user/release-keys"

[templates."lenovo_lenovo_l38031"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L38031"
device = "k5s"
product = "k5s"
name = "k5s"
marketname = "Lenovo K5s"
fingerprint = "LENOVO/k5s/k5s:15/AP3A.241005.015.A1/k5s.241005.001:user/release-keys"

[templates."lenovo_lenovo_l38041"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L38041"
device = "kunlun"
product = "kunlun"
name = "kunlun"
marketname = "Lenovo K5 Pro"
fingerprint = "LENOVO/kunlun/kunlun:15/AP3A.241005.015.A1/kunlun.241005.001:user/release-keys"

[templates."lenovo_lenovo_l38082"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L38082"
device = "l38082"
product = "l38082"
name = "l38082"
marketname = "Lenovo K6 畅享版"
fingerprint = "LENOVO/l38082/l38082:15/AP3A.241005.015.A1/l38082.241005.001:user/release-keys"

[templates."lenovo_lenovo_l18011"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L18011"
device = "l18011"
product = "l18011"
name = "l18011"
marketname = "Lenovo A5"
fingerprint = "LENOVO/l18011/l18011:15/AP3A.241005.015.A1/l18011.241005.001:user/release-keys"

[templates."lenovo_lenovo_k320t"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO K320T"
device = "lenovo_k320t"
product = "lenovo_k320t"
name = "lenovo_k320t"
marketname = "Lenovo K320t"
fingerprint = "LENOVO/lenovo_k320t/lenovo_k320t:15/AP3A.241005.015.A1/lenovo_k320t.241005.001:user/release-keys"

[templates."lenovo_lenovo_l79031"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L79031"
device = "moba"
product = "moba"
name = "moba"
marketname = "Lenovo 拯救者电竞手机 Pro"
fingerprint = "LENOVO/moba/moba:15/AP3A.241005.015.A1/moba.241005.001:user/release-keys"

[templates."lenovo_lenovo_l70081"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L70081"
device = "doom"
product = "doom"
name = "doom"
marketname = "Lenovo 拯救者电竞手机 2 Pro"
fingerprint = "LENOVO/doom/doom:15/AP3A.241005.015.A1/doom.241005.001:user/release-keys"

[templates."lenovo_lenovo_l71091"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L71091"
device = "halo"
product = "halo"
name = "halo"
marketname = "Lenovo 拯救者 Y70"
fingerprint = "LENOVO/halo/halo:15/AP3A.241005.015.A1/halo.241005.001:user/release-keys"

[templates."lenovo_lenovo_l71061"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO L71061"
device = "diablo"
product = "diablo"
name = "diablo"
marketname = "Lenovo 拯救者 Y90"
fingerprint = "LENOVO/diablo/diablo:15/AP3A.241005.015.A1/diablo.241005.001:user/release-keys"

[templates."lenovo_xt2611_1"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "XT2611-1"
device = "avr"
product = "avr"
name = "avr"
marketname = "Lenovo 拯救者 Y70 新一代"
fingerprint = "LENOVO/avr/avr:15/AP3A.241005.015.A1/avr.241005.001:user/release-keys"

[templates."lenovo_xt2081_4"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "XT2081-4"
device = "guam"
product = "guam"
name = "guam"
marketname = "Lenovo 乐檬 K12"
fingerprint = "LENOVO/guam/guam:15/AP3A.241005.015.A1/guam.241005.001:user/release-keys"

[templates."lenovo_xt2091_7"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "XT2091-7"
device = "cebu"
product = "cebu"
name = "cebu"
marketname = "Lenovo 乐檬 K12 Pro"
fingerprint = "LENOVO/cebu/cebu:15/AP3A.241005.015.A1/cebu.241005.001:user/release-keys"

[templates."lenovo_z1221"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Z1221"
device = "Z1221"
product = "Z1221"
marketname = "Lenovo ZUK Z1"
fingerprint = "LENOVO/Z1221/Z1221:15/AP3A.241005.015.A1/Z1221.241005.001:user/release-keys"

[templates."lenovo_z2131"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Z2131"
device = "Z2131"
product = "Z2131"
marketname = "Lenovo ZUK Z2"
fingerprint = "LENOVO/Z2131/Z2131:15/AP3A.241005.015.A1/Z2131.241005.001:user/release-keys"

[templates."lenovo_z2121"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Z2121"
device = "Z2121"
product = "Z2121"
marketname = "Lenovo ZUK Z2 Pro"
fingerprint = "LENOVO/Z2121/Z2121:15/AP3A.241005.015.A1/Z2121.241005.001:user/release-keys"

[templates."lenovo_z2151"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Z2151"
device = "Z2151"
product = "Z2151"
marketname = "Lenovo ZUK Edge"
fingerprint = "LENOVO/Z2151/Z2151:15/AP3A.241005.015.A1/Z2151.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_8804f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TB-8804F"
device = "Lenovo TB-8804F"
product = "Lenovo TB-8804F"
marketname = "Lenovo 小新平板 8 英寸"
fingerprint = "LENOVO/Lenovo TB-8804F/Lenovo TB-8804F:15/AP3A.241005.015.A1/LenovoTB-8804F.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_x804f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TB-X804F"
device = "Lenovo TB-X804F"
product = "Lenovo TB-X804F"
marketname = "Lenovo 小新平板 10 英寸"
fingerprint = "LENOVO/Lenovo TB-X804F/Lenovo TB-X804F:15/AP3A.241005.015.A1/LenovoTB-X804F.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_j606f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-J606F"
device = "m11"
product = "m11"
name = "m11"
marketname = "Lenovo 小新 Pad"
fingerprint = "LENOVO/m11/m11:15/AP3A.241005.015.A1/m11.241005.001:user/release-keys"

[templates."lenovo_tb128fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB128FU"
device = "oak"
product = "oak"
name = "oak"
marketname = "Lenovo 小新 Pad 2022"
fingerprint = "LENOVO/oak/oak:15/AP3A.241005.015.A1/oak.241005.001:user/release-keys"

[templates."lenovo_tb331fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB331FC"
device = "Balsa"
product = "Balsa"
name = "Balsa"
marketname = "Lenovo 小新 Pad 2024"
fingerprint = "LENOVO/Balsa/Balsa:15/AP3A.241005.015.A1/Balsa.241005.001:user/release-keys"

[templates."lenovo_tb335fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB335FC"
device = "sycamore"
product = "sycamore"
name = "sycamore"
marketname = "Lenovo 小新平板 11"
fingerprint = "LENOVO/sycamore/sycamore:15/AP3A.241005.015.A1/sycamore.241005.001:user/release-keys"

[templates."lenovo_tb335zc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB335ZC"
device = "sycamore"
product = "sycamore"
name = "sycamore"
marketname = "Lenovo 小新平板 11 5G"
fingerprint = "LENOVO/sycamore/sycamore:15/AP3A.241005.015.A1/sycamore.241005.001:user/release-keys"

[templates."lenovo_tb365fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB365FC"
device = "cava"
product = "cava"
name = "cava"
marketname = "Lenovo 小新平板 12.1"
fingerprint = "LENOVO/cava/cava:15/AP3A.241005.015.A1/cava.241005.001:user/release-keys"

[templates."lenovo_tb356fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB356FC"
device = "malibu"
product = "malibu"
name = "malibu"
marketname = "Lenovo AI 平板 小新 10.1"
fingerprint = "LENOVO/malibu/malibu:15/AP3A.241005.015.A1/malibu.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_j607f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-J607F"
device = "arnoz"
product = "arnoz"
name = "arnoz"
marketname = "Lenovo 小新 Pad Plus"
fingerprint = "LENOVO/arnoz/arnoz:15/AP3A.241005.015.A1/arnoz.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_j607z"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-J607Z"
device = "arnoz"
product = "arnoz"
name = "arnoz"
marketname = "Lenovo 小新 Pad Plus 5G"
fingerprint = "LENOVO/arnoz/arnoz:15/AP3A.241005.015.A1/arnoz.241005.001:user/release-keys"

[templates."lenovo_tb350fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB350FU"
device = "tulip"
product = "tulip"
name = "tulip"
marketname = "Lenovo 小新 Pad Plus 2023"
fingerprint = "LENOVO/tulip/tulip:15/AP3A.241005.015.A1/tulip.241005.001:user/release-keys"

[templates."lenovo_tb372fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB372FC"
device = "spruce"
product = "spruce"
name = "spruce"
marketname = "Lenovo 小新 Pad Plus 12.7 舒视版"
fingerprint = "LENOVO/spruce/spruce:15/AP3A.241005.015.A1/spruce.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_j706f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-J706F"
device = "pearl"
product = "pearl"
name = "pearl"
marketname = "Lenovo 小新 Pad Pro"
fingerprint = "LENOVO/pearl/pearl:15/AP3A.241005.015.A1/pearl.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_j716f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-J716F"
device = "p11_pro_plus"
product = "p11_pro_plus"
name = "p11_pro_plus"
marketname = "Lenovo 小新 Pad Pro 2021"
fingerprint = "LENOVO/p11_pro_plus/p11_pro_plus:15/AP3A.241005.015.A1/p11_pro_plus.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_q706f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-Q706F"
device = "paladin"
product = "paladin"
name = "paladin"
marketname = "Lenovo 小新 Pad Pro 12.6"
fingerprint = "LENOVO/paladin/paladin:15/AP3A.241005.015.A1/paladin.241005.001:user/release-keys"

[templates."lenovo_tb138fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB138FC"
device = "olivine"
product = "olivine"
name = "olivine"
marketname = "Lenovo 小新 Pad Pro 2022 骁龙版"
fingerprint = "LENOVO/olivine/olivine:15/AP3A.241005.015.A1/olivine.241005.001:user/release-keys"

[templates."lenovo_tb132fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB132FU"
device = "onyx"
product = "onyx"
name = "onyx"
marketname = "Lenovo 小新 Pad Pro 2022 迅鲲版"
fingerprint = "LENOVO/onyx/onyx:15/AP3A.241005.015.A1/onyx.241005.001:user/release-keys"

[templates."lenovo_tb371fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB371FC"
device = "spinel"
product = "spinel"
name = "spinel"
marketname = "Lenovo 小新 Pad Pro 12.7 骁龙版"
fingerprint = "LENOVO/spinel/spinel:15/AP3A.241005.015.A1/spinel.241005.001:user/release-keys"

[templates."lenovo_tb370fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB370FU"
device = "spruce"
product = "spruce"
name = "spruce"
marketname = "Lenovo 小新 Pad Pro 12.7 天玑版"
fingerprint = "LENOVO/spruce/spruce:15/AP3A.241005.015.A1/spruce.241005.001:user/release-keys"

[templates."lenovo_tb375fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB375FC"
device = "peridot"
product = "peridot"
name = "peridot"
marketname = "Lenovo 小新 Pad Pro 12.7 2025"
fingerprint = "LENOVO/peridot/peridot:15/AP3A.241005.015.A1/peridot.241005.001:user/release-keys"

[templates."lenovo_tb710fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB710FU"
device = "topaz"
product = "topaz"
name = "topaz"
marketname = "Lenovo 小新平板 Pro GT"
fingerprint = "LENOVO/topaz/topaz:15/AP3A.241005.015.A1/topaz.241005.001:user/release-keys"

[templates."lenovo_tb376fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB376FC"
device = "malbec"
product = "malbec"
name = "malbec"
marketname = "Lenovo AI 平板 小新 Pro 13"
fingerprint = "LENOVO/malbec/malbec:15/AP3A.241005.015.A1/malbec.241005.001:user/release-keys"

[templates."lenovo_tb378fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB378FC"
device = "zhiyu"
product = "zhiyu"
name = "zhiyu"
marketname = "Lenovo AI 平板 小新 Pro GT 13"
fingerprint = "LENOVO/zhiyu/zhiyu:15/AP3A.241005.015.A1/zhiyu.241005.001:user/release-keys"

[templates."lenovo_tb351fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB351FU"
device = "calla"
product = "calla"
name = "calla"
marketname = "Lenovo 小新 Pad Studio"
fingerprint = "LENOVO/calla/calla:15/AP3A.241005.015.A1/calla.241005.001:user/release-keys"

[templates."lenovo_lenovo_yt3_850f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo YT3-850F"
device = "Lenovo YT3-850F"
product = "Lenovo YT3-850F"
marketname = "Lenovo YOGA Tab 3 8”"
fingerprint = "LENOVO/Lenovo YT3-850F/Lenovo YT3-850F:15/AP3A.241005.015.A1/LenovoYT3-850F.241005.001:user/release-keys"

[templates."lenovo_lenovo_yt3_x50f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo YT3-X50F"
device = "Lenovo YT3-X50F"
product = "Lenovo YT3-X50F"
marketname = "Lenovo YOGA Tab 3 10”"
fingerprint = "LENOVO/Lenovo YT3-X50F/Lenovo YT3-X50F:15/AP3A.241005.015.A1/LenovoYT3-X50F.241005.001:user/release-keys"

[templates."lenovo_lenovo_yt_x703f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo YT-X703F"
device = "Lenovo YT-X703F"
product = "Lenovo YT-X703F"
marketname = "Lenovo YOGA Tab 3 Plus"
fingerprint = "LENOVO/Lenovo YT-X703F/Lenovo YT-X703F:15/AP3A.241005.015.A1/LenovoYT-X703F.241005.001:user/release-keys"

[templates."lenovo_lenovo_yt3_x90f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo YT3-X90F"
device = "Lenovo YT3-X90F"
product = "Lenovo YT3-X90F"
marketname = "Lenovo YOGA Tab 3 PRO 10”"
fingerprint = "LENOVO/Lenovo YT3-X90F/Lenovo YT3-X90F:15/AP3A.241005.015.A1/LenovoYT3-X90F.241005.001:user/release-keys"

[templates."lenovo_lenovo_yt_k606f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO YT-K606F"
device = "bladex"
product = "bladex"
name = "bladex"
marketname = "Lenovo YOGA Pad Pro"
fingerprint = "LENOVO/bladex/bladex:15/AP3A.241005.015.A1/bladex.241005.001:user/release-keys"

[templates."lenovo_tb520fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB520FU"
device = "lapis"
product = "lapis"
name = "lapis"
marketname = "Lenovo YOGA Pad Pro 12.7"
fingerprint = "LENOVO/lapis/lapis:15/AP3A.241005.015.A1/lapis.241005.001:user/release-keys"

[templates."lenovo_tb571fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB571FU"
device = "titans"
product = "titans"
name = "titans"
marketname = "Lenovo YOGA Pad Pro 14.5 AI 元启版"
fingerprint = "LENOVO/titans/titans:15/AP3A.241005.015.A1/titans.241005.001:user/release-keys"

[templates."lenovo_sp101fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "SP101FU"
device = "SP101FU"
product = "SP101FU"
marketname = "Lenovo YOGA Paper 墨水平板"
fingerprint = "LENOVO/SP101FU/SP101FU:15/AP3A.241005.015.A1/SP101FU.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_9707f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-9707F"
device = "p8"
product = "p8"
name = "p8"
marketname = "Lenovo 拯救者平板 Y700"
fingerprint = "LENOVO/p8/p8:15/AP3A.241005.015.A1/p8.241005.001:user/release-keys"

[templates."lenovo_tb320fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB320FC"
device = "asphalt"
product = "asphalt"
name = "asphalt"
marketname = "Lenovo 拯救者平板 Y700 2023"
fingerprint = "LENOVO/asphalt/asphalt:15/AP3A.241005.015.A1/asphalt.241005.001:user/release-keys"

[templates."lenovo_tb321fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB321FU"
device = "kirby"
product = "kirby"
name = "kirby"
marketname = "Lenovo 拯救者平板 Y700 2025"
fingerprint = "LENOVO/kirby/kirby:15/AP3A.241005.015.A1/kirby.241005.001:user/release-keys"

[templates."lenovo_tb322fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB322FC"
device = "elden"
product = "elden"
name = "elden"
marketname = "Lenovo 拯救者平板 Y700 四代"
fingerprint = "LENOVO/elden/elden:15/AP3A.241005.015.A1/elden.241005.001:user/release-keys"

[templates."lenovo_tb323fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB323FU"
device = "baldur"
product = "baldur"
name = "baldur"
marketname = "Lenovo AI 平板 拯救者 Y700 五代"
fingerprint = "LENOVO/baldur/baldur:15/AP3A.241005.015.A1/baldur.241005.001:user/release-keys"

[templates."lenovo_tb324zc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB324ZC"
device = "TB324ZC"
product = "TB324ZC"
name = "TB324ZC"
marketname = "Lenovo AI 平板 拯救者 Y700 无极"
fingerprint = "LENOVO/TB324ZC/TB324ZC:15/AP3A.241005.015.A1/TB324ZC.241005.001:user/release-keys"

[templates."lenovo_tb570fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB570FU"
device = "inception"
product = "inception"
name = "inception"
marketname = "Lenovo 拯救者平板 Y900"
fingerprint = "LENOVO/inception/inception:15/AP3A.241005.015.A1/inception.241005.001:user/release-keys"

[templates."lenovo_tb711fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB711FU"
device = "beryl"
product = "beryl"
name = "beryl"
marketname = "Lenovo AI 平板 拯救者 Y900 11"
fingerprint = "LENOVO/beryl/beryl:15/AP3A.241005.015.A1/beryl.241005.001:user/release-keys"

[templates."lenovo_tb522fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB522FU"
device = "mojito"
product = "mojito"
name = "mojito"
marketname = "Lenovo AI 平板 拯救者 Y900 13"
fingerprint = "LENOVO/mojito/mojito:15/AP3A.241005.015.A1/mojito.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_j616f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-J616F"
device = "p11_plus"
product = "p11_plus"
name = "p11_plus"
marketname = "Lenovo 天骄平板电脑"
fingerprint = "LENOVO/p11_plus/p11_plus:15/AP3A.241005.015.A1/p11_plus.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_8504f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TB-8504F"
device = "Lenovo TB-8504F"
product = "Lenovo TB-8504F"
marketname = "Lenovo TAB4 8 英寸"
fingerprint = "LENOVO/Lenovo TB-8504F/Lenovo TB-8504F:15/AP3A.241005.015.A1/LenovoTB-8504F.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_8604f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TB-8604F"
device = "Lenovo TB-8604F"
product = "Lenovo TB-8604F"
marketname = "Lenovo TAB4 8 英寸 REL"
fingerprint = "LENOVO/Lenovo TB-8604F/Lenovo TB-8604F:15/AP3A.241005.015.A1/LenovoTB-8604F.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_x304f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TB-X304F"
device = "Lenovo TB-X304F"
product = "Lenovo TB-X304F"
marketname = "Lenovo TAB4 10.1 英寸"
fingerprint = "LENOVO/Lenovo TB-X304F/Lenovo TB-X304F:15/AP3A.241005.015.A1/LenovoTB-X304F.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_x504f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TB-X504F"
device = "Lenovo TB-X504F"
product = "Lenovo TB-X504F"
marketname = "Lenovo TAB4 10.1 英寸 REL"
fingerprint = "LENOVO/Lenovo TB-X504F/Lenovo TB-X504F:15/AP3A.241005.015.A1/LenovoTB-X504F.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_8704f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TB-8704F"
device = "Lenovo TB-8704F"
product = "Lenovo TB-8704F"
marketname = "Lenovo TAB4 Plus 8 英寸"
fingerprint = "LENOVO/Lenovo TB-8704F/Lenovo TB-8704F:15/AP3A.241005.015.A1/LenovoTB-8704F.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_x704f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TB-X704F"
device = "Lenovo TB-X704F"
product = "Lenovo TB-X704F"
marketname = "Lenovo TAB4 Plus 10.1 英寸"
fingerprint = "LENOVO/Lenovo TB-X704F/Lenovo TB-X704F:15/AP3A.241005.015.A1/LenovoTB-X704F.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_8705f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-8705F"
device = "aaron"
product = "aaron"
name = "aaron"
marketname = "Lenovo M8 8 英寸"
fingerprint = "LENOVO/aaron/aaron:15/AP3A.241005.015.A1/aaron.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_x306fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-X306FC"
device = "amar"
product = "amar"
name = "amar"
marketname = "Lenovo M10 HD 10.1 英寸"
fingerprint = "LENOVO/amar/amar:15/AP3A.241005.015.A1/amar.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_x605fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-X605FC"
device = "achilles5"
product = "achilles5"
name = "achilles5"
marketname = "Lenovo M10 FHD-REL 10.1 英寸"
fingerprint = "LENOVO/achilles5/achilles5:15/AP3A.241005.015.A1/achilles5.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_x606f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-X606F"
device = "achilles6"
product = "achilles6"
name = "achilles6"
marketname = "Lenovo M10 PLUS 10.3 英寸"
fingerprint = "LENOVO/achilles6/achilles6:15/AP3A.241005.015.A1/achilles6.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_8506f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TB-8506F"
device = "Lenovo TB-8506F"
product = "Lenovo TB-8506F"
marketname = "Lenovo 启天 K8 8 英寸"
fingerprint = "LENOVO/Lenovo TB-8506F/Lenovo TB-8506F:15/AP3A.241005.015.A1/LenovoTB-8506F.241005.001:user/release-keys"

[templates."lenovo_tb310fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB310FU"
device = "pine"
product = "pine"
name = "pine"
marketname = "Lenovo 启天 K9 9 英寸"
fingerprint = "LENOVO/pine/pine:15/AP3A.241005.015.A1/pine.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_x6c6f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-X6C6F"
device = "asha"
product = "asha"
name = "asha"
marketname = "Lenovo 启天 K10 10.3 英寸"
fingerprint = "LENOVO/asha/asha:15/AP3A.241005.015.A1/asha.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_x6c6nbf"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-X6C6NBF"
device = "asha"
product = "asha"
name = "asha"
marketname = "Lenovo 启天 K10 10.3 英寸 无电池版本"
fingerprint = "LENOVO/asha/asha:15/AP3A.241005.015.A1/asha.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_x6e6f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TB-X6E6F"
device = "Lenovo TB-X6E6F"
product = "Lenovo TB-X6E6F"
marketname = "Lenovo 启天 K10c 10.3 英寸"
fingerprint = "LENOVO/Lenovo TB-X6E6F/Lenovo TB-X6E6F:15/AP3A.241005.015.A1/LenovoTB-X6E6F.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_x6e6fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TB-X6E6FC"
device = "Lenovo TB-X6E6FC"
product = "Lenovo TB-X6E6FC"
marketname = "Lenovo 启天 E10c 10.3 英寸"
fingerprint = "LENOVO/Lenovo TB-X6E6FC/Lenovo TB-X6E6FC:15/AP3A.241005.015.A1/LenovoTB-X6E6FC.241005.001:user/release-keys"

[templates."lenovo_tb223fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB223FC"
device = "maple"
product = "maple"
name = "maple"
marketname = "Lenovo 启天 K10 Pro 10.61 英寸"
fingerprint = "LENOVO/maple/maple:15/AP3A.241005.015.A1/maple.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_j6c6f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-J6C6F"
device = "p11"
product = "p11"
name = "p11"
marketname = "Lenovo 启天 K11 11 英寸"
fingerprint = "LENOVO/p11/p11:15/AP3A.241005.015.A1/p11.241005.001:user/release-keys"

[templates."lenovo_tb230fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB230FC"
device = "tulip"
product = "tulip"
name = "tulip"
marketname = "Lenovo 启天 K11 Gen2 11.5 英寸"
fingerprint = "LENOVO/tulip/tulip:15/AP3A.241005.015.A1/tulip.241005.001:user/release-keys"

[templates."lenovo_tb240fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB240FC"
device = "spruce"
product = "spruce"
name = "spruce"
marketname = "Lenovo 启天 K12 12.7 英寸"
fingerprint = "LENOVO/spruce/spruce:15/AP3A.241005.015.A1/spruce.241005.001:user/release-keys"

[templates."lenovo_sp523fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "SP523FC"
device = "SP523FC"
product = "SP523FC"
marketname = "Lenovo 启天 SmartPaper 10.3 英寸"
fingerprint = "LENOVO/SP523FC/SP523FC:15/AP3A.241005.015.A1/SP523FC.241005.001:user/release-keys"

[templates."lenovo_tb305fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB305FU"
device = "clove"
product = "clove"
name = "clove"
marketname = "Lenovo 昭阳 K9 8.7 英寸"
fingerprint = "LENOVO/clove/clove:15/AP3A.241005.015.A1/clove.241005.001:user/release-keys"

[templates."lenovo_tb330fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB330FU"
device = "barley"
product = "barley"
name = "barley"
marketname = "Lenovo 昭阳 K10 10.95 英寸"
fingerprint = "LENOVO/barley/barley:15/AP3A.241005.015.A1/barley.241005.001:user/release-keys"

[templates."lenovo_tb311fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB311FU"
device = "poplar"
product = "poplar"
name = "poplar"
marketname = "Lenovo 昭阳 K10c 10.1 英寸"
fingerprint = "LENOVO/poplar/poplar:15/AP3A.241005.015.A1/poplar.241005.001:user/release-keys"

[templates."lenovo_tb352fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB352FC"
device = "citrus"
product = "citrus"
name = "citrus"
marketname = "Lenovo 昭阳 K11 11.5 英寸"
fingerprint = "LENOVO/citrus/citrus:15/AP3A.241005.015.A1/citrus.241005.001:user/release-keys"

[templates."lenovo_tb336fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB336FU"
device = "sycamore"
product = "sycamore"
name = "sycamore"
marketname = "Lenovo 昭阳 K11 11 英寸"
fingerprint = "LENOVO/sycamore/sycamore:15/AP3A.241005.015.A1/sycamore.241005.001:user/release-keys"

[templates."lenovo_tb337fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB337FU"
device = "barley"
product = "barley"
name = "barley"
marketname = "Lenovo 昭阳 K11c 10.95 英寸"
fingerprint = "LENOVO/barley/barley:15/AP3A.241005.015.A1/barley.241005.001:user/release-keys"

[templates."lenovo_tb373fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB373FU"
device = "peridot"
product = "peridot"
name = "peridot"
marketname = "Lenovo 昭阳 K12 12.7 英寸"
fingerprint = "LENOVO/peridot/peridot:15/AP3A.241005.015.A1/peridot.241005.001:user/release-keys"

[templates."lenovo_tb361fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB361FU"
device = "cava"
product = "cava"
name = "cava"
marketname = "Lenovo 昭阳 K12c 12.1 英寸"
fingerprint = "LENOVO/cava/cava:15/AP3A.241005.015.A1/cava.241005.001:user/release-keys"

[templates."lenovo_tb391fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB391FC"
device = "malbec"
product = "malbec"
name = "malbec"
marketname = "Lenovo 昭阳 K13 13 英寸"
fingerprint = "LENOVO/malbec/malbec:15/AP3A.241005.015.A1/malbec.241005.001:user/release-keys"

[templates."lenovo_tb_x802f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB-X802F"
device = "barley"
product = "barley"
name = "barley"
marketname = "Lenovo 昭阳 G11 10.95 英寸"
fingerprint = "LENOVO/barley/barley:15/AP3A.241005.015.A1/barley.241005.001:user/release-keys"

[templates."lenovo_tb_x903f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB-X903F"
device = "citrus"
product = "citrus"
name = "citrus"
marketname = "Lenovo 昭阳 G12 11.5 英寸"
fingerprint = "LENOVO/citrus/citrus:15/AP3A.241005.015.A1/citrus.241005.001:user/release-keys"

[templates."lenovo_tby11"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TBY11"
device = "barley"
product = "barley"
name = "barley"
marketname = "Lenovo 昭阳 Y11 10.95 英寸"
fingerprint = "LENOVO/barley/barley:15/AP3A.241005.015.A1/barley.241005.001:user/release-keys"

[templates."lenovo_lenovo_tb_j606n"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "LENOVO TB-J606N"
device = "m11"
product = "m11"
name = "m11"
marketname = "Lenovo 平板电脑 K11 11 英寸"
fingerprint = "LENOVO/m11/m11:15/AP3A.241005.015.A1/m11.241005.001:user/release-keys"

[templates."lenovo_qbh10"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "QBH10"
device = "barley"
product = "barley"
name = "barley"
marketname = "Lenovo 平板电脑 S11 10.95 英寸"
fingerprint = "LENOVO/barley/barley:15/AP3A.241005.015.A1/barley.241005.001:user/release-keys"

[templates."lenovo_qbh11"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "QBH11"
device = "citrus"
product = "citrus"
name = "citrus"
marketname = "Lenovo 平板电脑 S11 Pro 11.5 英寸"
fingerprint = "LENOVO/citrus/citrus:15/AP3A.241005.015.A1/citrus.241005.001:user/release-keys"

[templates."lenovo_tb610fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB610FU"
device = "gem"
product = "gem"
name = "gem"
marketname = "Lenovo ThinkBook Plus Hybrid 2024"
fingerprint = "LENOVO/gem/gem:15/AP3A.241005.015.A1/gem.241005.001:user/release-keys"

[templates."lenovo_tb838"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "TB838"
device = "sycamore"
product = "sycamore"
name = "sycamore"
marketname = "Lenovo ThinkTab T11S 11 英寸"
fingerprint = "LENOVO/sycamore/sycamore:15/AP3A.241005.015.A1/sycamore.241005.001:user/release-keys"

[templates."meizu_m8"]
manufacturer = "meizu"
brand = "meizu"
model = "M8"
device = "M8"
product = "M8"
marketname = "Meizu M8"
fingerprint = "meizu/M8/M8:15/AP3A.241005.015.A1/M8.241005.001:user/release-keys"

[templates."meizu_m8se"]
manufacturer = "meizu"
brand = "meizu"
model = "M8SE"
device = "M8SE"
product = "M8SE"
marketname = "Meizu M8 SE"
fingerprint = "meizu/M8SE/M8SE:15/AP3A.241005.015.A1/M8SE.241005.001:user/release-keys"

[templates."meizu_m9"]
manufacturer = "meizu"
brand = "meizu"
model = "M9"
device = "M9"
product = "M9"
marketname = "Meizu M9"
fingerprint = "meizu/M9/M9:15/AP3A.241005.015.A1/M9.241005.001:user/release-keys"

[templates."meizu_m030"]
manufacturer = "meizu"
brand = "meizu"
model = "M030"
device = "M030"
product = "M030"
marketname = "Meizu MX 双核"
fingerprint = "meizu/M030/M030:15/AP3A.241005.015.A1/M030.241005.001:user/release-keys"

[templates."meizu_m031"]
manufacturer = "meizu"
brand = "meizu"
model = "M031"
device = "M031"
product = "M031"
marketname = "Meizu MX 双核新版"
fingerprint = "meizu/M031/M031:15/AP3A.241005.015.A1/M031.241005.001:user/release-keys"

[templates."meizu_m032"]
manufacturer = "meizu"
brand = "meizu"
model = "M032"
device = "m03"
product = "m03"
name = "m03"
marketname = "Meizu MX 四核"
fingerprint = "meizu/m03/m03:15/AP3A.241005.015.A1/m03.241005.001:user/release-keys"

[templates."meizu_m040"]
manufacturer = "meizu"
brand = "meizu"
model = "M040"
device = "m04"
product = "m04"
name = "m04"
marketname = "Meizu MX2"
fingerprint = "meizu/m04/m04:15/AP3A.241005.015.A1/m04.241005.001:user/release-keys"

[templates."meizu_m351"]
manufacturer = "meizu"
brand = "meizu"
model = "M351"
device = "m35"
product = "m35"
name = "m35"
marketname = "Meizu MX3"
fingerprint = "meizu/m35/m35:15/AP3A.241005.015.A1/m35.241005.001:user/release-keys"

[templates."meizu_m460"]
manufacturer = "meizu"
brand = "meizu"
model = "M460"
device = "m75"
product = "m75"
name = "m75"
marketname = "Meizu MX4"
fingerprint = "meizu/m75/m75:15/AP3A.241005.015.A1/m75.241005.001:user/release-keys"

[templates."meizu_m460a"]
manufacturer = "meizu"
brand = "meizu"
model = "M460A"
device = "m75"
product = "m75"
name = "m75"
marketname = "Meizu MX4 YunOS 版"
fingerprint = "meizu/m75/m75:15/AP3A.241005.015.A1/m75.241005.001:user/release-keys"

[templates."meizu_m462"]
manufacturer = "meizu"
brand = "meizu"
model = "M462"
device = "m76"
product = "m76"
name = "m76"
marketname = "Meizu MX4 Pro"
fingerprint = "meizu/m76/m76:15/AP3A.241005.015.A1/m76.241005.001:user/release-keys"

[templates."meizu_m575"]
manufacturer = "meizu"
brand = "meizu"
model = "M575"
device = "m85"
product = "m85"
name = "m85"
marketname = "Meizu MX5"
fingerprint = "meizu/m85/m85:15/AP3A.241005.015.A1/m85.241005.001:user/release-keys"

[templates."meizu_m685q"]
manufacturer = "meizu"
brand = "meizu"
model = "M685Q"
device = "m95"
product = "m95"
name = "m95"
marketname = "Meizu MX6"
fingerprint = "meizu/m95/m95:15/AP3A.241005.015.A1/m95.241005.001:user/release-keys"

[templates."meizu_m576"]
manufacturer = "meizu"
brand = "meizu"
model = "M576"
device = "m86"
product = "m86"
name = "m86"
marketname = "Meizu PRO 5"
fingerprint = "meizu/m86/m86:15/AP3A.241005.015.A1/m86.241005.001:user/release-keys"

[templates."meizu_m570q"]
manufacturer = "meizu"
brand = "meizu"
model = "M570Q"
device = "m80"
product = "m80"
name = "m80"
marketname = "Meizu PRO 6"
fingerprint = "meizu/m80/m80:15/AP3A.241005.015.A1/m80.241005.001:user/release-keys"

[templates."meizu_m570q_s"]
manufacturer = "meizu"
brand = "meizu"
model = "M570Q-S"
device = "m80"
product = "m80"
name = "m80"
marketname = "Meizu PRO 6s"
fingerprint = "meizu/m80/m80:15/AP3A.241005.015.A1/m80.241005.001:user/release-keys"

[templates."meizu_m686"]
manufacturer = "meizu"
brand = "meizu"
model = "M686"
device = "m96"
product = "m96"
name = "m96"
marketname = "Meizu PRO 6 Plus"
fingerprint = "meizu/m96/m96:15/AP3A.241005.015.A1/m96.241005.001:user/release-keys"

[templates."meizu_m792q_l"]
manufacturer = "meizu"
brand = "meizu"
model = "M792Q-L"
device = "m1792L"
product = "m1792L"
name = "m1792L"
marketname = "Meizu PRO 7"
fingerprint = "meizu/m1792L/m1792L:15/AP3A.241005.015.A1/m1792L.241005.001:user/release-keys"

[templates."meizu_m793q"]
manufacturer = "meizu"
brand = "meizu"
model = "M793Q"
device = "m1793"
product = "m1793"
name = "m1793"
marketname = "Meizu PRO 7 Plus"
fingerprint = "meizu/m1793/m1793:15/AP3A.241005.015.A1/m1793.241005.001:user/release-keys"

[templates."meizu_m881q"]
manufacturer = "meizu"
brand = "meizu"
model = "M881Q"
device = "m1881"
product = "m1881"
name = "m1881"
marketname = "Meizu 15"
fingerprint = "meizu/m1881/m1881:15/AP3A.241005.015.A1/m1881.241005.001:user/release-keys"

[templates."meizu_m891q"]
manufacturer = "meizu"
brand = "meizu"
model = "M891Q"
device = "m1891"
product = "m1891"
name = "m1891"
marketname = "Meizu 15 Plus"
fingerprint = "meizu/m1891/m1891:15/AP3A.241005.015.A1/m1891.241005.001:user/release-keys"

[templates."meizu_m871q"]
manufacturer = "meizu"
brand = "meizu"
model = "M871Q"
device = "m1871"
product = "m1871"
name = "m1871"
marketname = "Meizu M15"
fingerprint = "meizu/m1871/m1871:15/AP3A.241005.015.A1/m1871.241005.001:user/release-keys"

[templates."meizu_m871h"]
manufacturer = "meizu"
brand = "meizu"
model = "M871H"
device = "m1871"
product = "m1871"
name = "m1871"
marketname = "Meizu 15 Lite"
fingerprint = "meizu/m1871/m1871:15/AP3A.241005.015.A1/m1871.241005.001:user/release-keys"

[templates."meizu_m882q"]
manufacturer = "meizu"
brand = "meizu"
model = "M882Q"
device = "m1882"
product = "m1882"
name = "m1882"
marketname = "Meizu 16th"
fingerprint = "meizu/m1882/m1882:15/AP3A.241005.015.A1/m1882.241005.001:user/release-keys"

[templates."meizu_m892q"]
manufacturer = "meizu"
brand = "meizu"
model = "M892Q"
device = "m1892"
product = "m1892"
name = "m1892"
marketname = "Meizu 16th Plus"
fingerprint = "meizu/m1892/m1892:15/AP3A.241005.015.A1/m1892.241005.001:user/release-keys"

[templates."meizu_m872q"]
manufacturer = "meizu"
brand = "meizu"
model = "M872Q"
device = "m1872"
product = "m1872"
name = "m1872"
marketname = "Meizu 16 X"
fingerprint = "meizu/m1872/m1872:15/AP3A.241005.015.A1/m1872.241005.001:user/release-keys"

[templates."meizu_m872h"]
manufacturer = "meizu"
brand = "meizu"
model = "M872H"
device = "m1872"
product = "m1872"
name = "m1872"
marketname = "Meizu 16"
fingerprint = "meizu/m1872/m1872:15/AP3A.241005.015.A1/m1872.241005.001:user/release-keys"

[templates."meizu_m971q"]
manufacturer = "meizu"
brand = "meizu"
model = "M971Q"
device = "m1971"
product = "m1971"
name = "m1971"
marketname = "Meizu 16s"
fingerprint = "meizu/m1971/m1971:15/AP3A.241005.015.A1/m1971.241005.001:user/release-keys"

[templates."meizu_m926q"]
manufacturer = "meizu"
brand = "meizu"
model = "M926Q"
device = "m1926"
product = "m1926"
name = "m1926"
marketname = "Meizu 16Xs"
fingerprint = "meizu/m1926/m1926:15/AP3A.241005.015.A1/m1926.241005.001:user/release-keys"

[templates."meizu_m973q"]
manufacturer = "meizu"
brand = "meizu"
model = "M973Q"
device = "m1973"
product = "m1973"
name = "m1973"
marketname = "Meizu 16s Pro"
fingerprint = "meizu/m1973/m1973:15/AP3A.241005.015.A1/m1973.241005.001:user/release-keys"

[templates."meizu_m928q"]
manufacturer = "meizu"
brand = "meizu"
model = "M928Q"
device = "m1928"
product = "m1928"
name = "m1928"
marketname = "Meizu 16T"
fingerprint = "meizu/m1928/m1928:15/AP3A.241005.015.A1/m1928.241005.001:user/release-keys"

[templates."meizu_m081q"]
manufacturer = "meizu"
brand = "meizu"
model = "M081Q"
device = "m2081"
product = "m2081"
name = "m2081"
marketname = "Meizu 17"
fingerprint = "meizu/m2081/m2081:15/AP3A.241005.015.A1/m2081.241005.001:user/release-keys"

[templates."meizu_m091q"]
manufacturer = "meizu"
brand = "meizu"
model = "M091Q"
device = "m2091"
product = "m2091"
name = "m2091"
marketname = "Meizu 17 Pro"
fingerprint = "meizu/m2091/m2091:15/AP3A.241005.015.A1/m2091.241005.001:user/release-keys"

[templates."meizu_m181q"]
manufacturer = "meizu"
brand = "meizu"
model = "M181Q"
device = "m2181"
product = "m2181"
name = "m2181"
marketname = "Meizu 18"
fingerprint = "meizu/m2181/m2181:15/AP3A.241005.015.A1/m2181.241005.001:user/release-keys"

[templates."meizu_m191q"]
manufacturer = "meizu"
brand = "meizu"
model = "M191Q"
device = "m2191"
product = "m2191"
name = "m2191"
marketname = "Meizu 18 Pro"
fingerprint = "meizu/m2191/m2191:15/AP3A.241005.015.A1/m2191.241005.001:user/release-keys"

[templates."meizu_m172q"]
manufacturer = "meizu"
brand = "meizu"
model = "M172Q"
device = "m2172"
product = "m2172"
name = "m2172"
marketname = "Meizu 18X"
fingerprint = "meizu/m2172/m2172:15/AP3A.241005.015.A1/m2172.241005.001:user/release-keys"

[templates."meizu_m182q"]
manufacturer = "meizu"
brand = "meizu"
model = "M182Q"
device = "m2182"
product = "m2182"
name = "m2182"
marketname = "Meizu 18s"
fingerprint = "meizu/m2182/m2182:15/AP3A.241005.015.A1/m2182.241005.001:user/release-keys"

[templates."meizu_m381q"]
manufacturer = "meizu"
brand = "meizu"
model = "M381Q"
device = "m2381"
product = "m2381"
name = "m2381"
marketname = "Meizu 20"
fingerprint = "meizu/m2381/m2381:15/AP3A.241005.015.A1/m2381.241005.001:user/release-keys"

[templates."meizu_m391q"]
manufacturer = "meizu"
brand = "meizu"
model = "M391Q"
device = "m2391"
product = "m2391"
name = "m2391"
marketname = "Meizu 20 PRO"
fingerprint = "meizu/m2391/m2391:15/AP3A.241005.015.A1/m2391.241005.001:user/release-keys"

[templates."meizu_m392q"]
manufacturer = "meizu"
brand = "meizu"
model = "M392Q"
device = "m2392"
product = "m2392"
name = "m2392"
marketname = "Meizu 20 INFINITY 无界版"
fingerprint = "meizu/m2392/m2392:15/AP3A.241005.015.A1/m2392.241005.001:user/release-keys"

[templates."meizu_m461q"]
manufacturer = "meizu"
brand = "meizu"
model = "M461Q"
device = "m2461"
product = "m2461"
name = "m2461"
marketname = "Meizu 21"
fingerprint = "meizu/m2461/m2461:15/AP3A.241005.015.A1/m2461.241005.001:user/release-keys"

[templates."meizu_m481q"]
manufacturer = "meizu"
brand = "meizu"
model = "M481Q"
device = "m2481"
product = "m2481"
name = "m2481"
marketname = "Meizu 21 PRO"
fingerprint = "meizu/m2481/m2481:15/AP3A.241005.015.A1/m2481.241005.001:user/release-keys"

[templates."meizu_m481s"]
manufacturer = "meizu"
brand = "meizu"
model = "M481S"
device = "m2481s"
product = "m2481s"
name = "m2481s"
marketname = "Meizu 21 PRO Flyme 钛好用版"
fingerprint = "meizu/m2481s/m2481s:15/AP3A.241005.015.A1/m2481s.241005.001:user/release-keys"

[templates."meizu_m468q"]
manufacturer = "meizu"
brand = "meizu"
model = "M468Q"
device = "m2468l"
product = "m2468l"
name = "m2468l"
marketname = "Meizu 21 Note"
fingerprint = "meizu/m2468l/m2468l:15/AP3A.241005.015.A1/m2468l.241005.001:user/release-keys"

[templates."meizu_m582q"]
manufacturer = "meizu"
brand = "meizu"
model = "M582Q"
device = "m2582"
product = "m2582"
name = "m2582"
marketname = "Meizu 22"
fingerprint = "meizu/m2582/m2582:15/AP3A.241005.015.A1/m2582.241005.001:user/release-keys"

[templates."meizu_m431q"]
manufacturer = "meizu"
brand = "meizu"
model = "M431Q"
device = "m2431"
product = "m2431"
name = "m2431"
marketname = "Meizu Lucky 08"
fingerprint = "meizu/m2431/m2431:15/AP3A.241005.015.A1/m2431.241005.001:user/release-keys"

[templates."meizu_m852q"]
manufacturer = "meizu"
brand = "meizu"
model = "M852Q"
device = "m1852"
product = "m1852"
name = "m1852"
marketname = "Meizu X8"
fingerprint = "meizu/m1852/m1852:15/AP3A.241005.015.A1/m1852.241005.001:user/release-keys"

[templates."meizu_m813q"]
manufacturer = "meizu"
brand = "meizu"
model = "M813Q"
device = "m1813"
product = "m1813"
name = "m1813"
marketname = "Meizu V8"
fingerprint = "meizu/m1813/m1813:15/AP3A.241005.015.A1/m1813.241005.001:user/release-keys"

[templates."meizu_m816h"]
manufacturer = "meizu"
brand = "meizu"
model = "M816H"
device = "m1816"
product = "m1816"
name = "m1816"
marketname = "Meizu M8 Lite"
fingerprint = "meizu/m1816/m1816:15/AP3A.241005.015.A1/m1816.241005.001:user/release-keys"

[templates."meizu_m822q"]
manufacturer = "meizu"
brand = "meizu"
model = "M822Q"
device = "m1822"
product = "m1822"
name = "m1822"
marketname = "Meizu Note8"
fingerprint = "meizu/m1822/m1822:15/AP3A.241005.015.A1/m1822.241005.001:user/release-keys"

[templates."meizu_m923q"]
manufacturer = "meizu"
brand = "meizu"
model = "M923Q"
device = "m1923"
product = "m1923"
name = "m1923"
marketname = "Meizu Note9"
fingerprint = "meizu/m1923/m1923:15/AP3A.241005.015.A1/m1923.241005.001:user/release-keys"

[templates."meizu_m521q"]
manufacturer = "meizu"
brand = "meizu"
model = "M521Q"
device = "m2521"
product = "m2521"
name = "m2521"
marketname = "Meizu Note 16"
fingerprint = "meizu/m2521/m2521:15/AP3A.241005.015.A1/m2521.241005.001:user/release-keys"

[templates."meizu_m531q"]
manufacturer = "meizu"
brand = "meizu"
model = "M531Q"
device = "m2531"
product = "m2531"
name = "m2531"
marketname = "Meizu Note 16 Pro"
fingerprint = "meizu/m2531/m2531:15/AP3A.241005.015.A1/m2531.241005.001:user/release-keys"

[templates."meizu_m411h"]
manufacturer = "meizu"
brand = "meizu"
model = "M411H"
device = "m2411"
product = "m2411"
name = "m2411"
marketname = "Meizu Note 21"
fingerprint = "meizu/m2411/m2411:15/AP3A.241005.015.A1/m2411.241005.001:user/release-keys"

[templates."meizu_m412h"]
manufacturer = "meizu"
brand = "meizu"
model = "M412H"
device = "m2412"
product = "m2412"
name = "m2412"
marketname = "Meizu Note 21 Pro"
fingerprint = "meizu/m2412/m2412:15/AP3A.241005.015.A1/m2412.241005.001:user/release-keys"

[templates."meizu_m513h"]
manufacturer = "meizu"
brand = "meizu"
model = "M513H"
device = "m2513"
product = "m2513"
name = "m2513"
marketname = "Meizu Note 22"
fingerprint = "meizu/m2513/m2513:15/AP3A.241005.015.A1/m2513.241005.001:user/release-keys"

[templates."meizu_m810h"]
manufacturer = "meizu"
brand = "meizu"
model = "M810H"
device = "m1810"
product = "m1810"
name = "m1810"
marketname = "Meizu M8c"
fingerprint = "meizu/m1810/m1810:15/AP3A.241005.015.A1/m1810.241005.001:user/release-keys"

[templates."meizu_m818h"]
manufacturer = "meizu"
brand = "meizu"
model = "M818H"
device = "m1818"
product = "m1818"
name = "m1818"
marketname = "Meizu C9"
fingerprint = "meizu/m1818/m1818:15/AP3A.241005.015.A1/m1818.241005.001:user/release-keys"

[templates."meizu_m819h"]
manufacturer = "meizu"
brand = "meizu"
model = "M819H"
device = "m1819"
product = "m1819"
name = "m1819"
marketname = "Meizu C9 Pro"
fingerprint = "meizu/m1819/m1819:15/AP3A.241005.015.A1/m1819.241005.001:user/release-keys"

[templates."meizu_m918h"]
manufacturer = "meizu"
brand = "meizu"
model = "M918H"
device = "m1918"
product = "m1918"
name = "m1918"
marketname = "Meizu M10"
fingerprint = "meizu/m1918/m1918:15/AP3A.241005.015.A1/m1918.241005.001:user/release-keys"

[templates."meizu_m463m"]
manufacturer = "meizu"
brand = "meizu"
model = "M463M"
device = "m71"
product = "m71"
name = "m71"
marketname = "Meizu note"
fingerprint = "meizu/m71/m71:15/AP3A.241005.015.A1/m71.241005.001:user/release-keys"

[templates."meizu_m463h"]
manufacturer = "meizu"
brand = "meizu"
model = "M463H"
device = "m71"
product = "m71"
name = "m71"
marketname = "Meizu m1 note"
fingerprint = "meizu/m71/m71:15/AP3A.241005.015.A1/m71.241005.001:user/release-keys"

[templates."meizu_m571"]
manufacturer = "meizu"
brand = "meizu"
model = "M571"
device = "m81"
product = "m81"
name = "m81"
marketname = "Meizu note2"
fingerprint = "meizu/m81/m81:15/AP3A.241005.015.A1/m81.241005.001:user/release-keys"

[templates."meizu_m571h"]
manufacturer = "meizu"
brand = "meizu"
model = "M571H"
device = "m81"
product = "m81"
name = "m81"
marketname = "Meizu m2 note"
fingerprint = "meizu/m81/m81:15/AP3A.241005.015.A1/m81.241005.001:user/release-keys"

[templates."meizu_m681q"]
manufacturer = "meizu"
brand = "meizu"
model = "M681Q"
device = "m91"
product = "m91"
name = "m91"
marketname = "Meizu Note3"
fingerprint = "meizu/m91/m91:15/AP3A.241005.015.A1/m91.241005.001:user/release-keys"

[templates."meizu_m681h"]
manufacturer = "meizu"
brand = "meizu"
model = "M681H"
device = "m91"
product = "m91"
name = "m91"
marketname = "Meizu M3 note"
fingerprint = "meizu/m91/m91:15/AP3A.241005.015.A1/m91.241005.001:user/release-keys"

[templates."meizu_m621q"]
manufacturer = "meizu"
brand = "meizu"
model = "M621Q"
device = "m1621"
product = "m1621"
name = "m1621"
marketname = "Meizu Note5"
fingerprint = "meizu/m1621/m1621:15/AP3A.241005.015.A1/m1621.241005.001:user/release-keys"

[templates."meizu_m621h"]
manufacturer = "meizu"
brand = "meizu"
model = "M621H"
device = "m1621"
product = "m1621"
name = "m1621"
marketname = "Meizu M5 Note"
fingerprint = "meizu/m1621/m1621:15/AP3A.241005.015.A1/m1621.241005.001:user/release-keys"

[templates."meizu_m721q"]
manufacturer = "meizu"
brand = "meizu"
model = "M721Q"
device = "m1721"
product = "m1721"
name = "m1721"
marketname = "Meizu Note6"
fingerprint = "meizu/m1721/m1721:15/AP3A.241005.015.A1/m1721.241005.001:user/release-keys"

[templates."meizu_m721h"]
manufacturer = "meizu"
brand = "meizu"
model = "M721H"
device = "m1721"
product = "m1721"
name = "m1721"
marketname = "Meizu M6 Note"
fingerprint = "meizu/m1721/m1721:15/AP3A.241005.015.A1/m1721.241005.001:user/release-keys"

[templates."meizu_a680q"]
manufacturer = "meizu"
brand = "meizu"
model = "A680Q"
device = "a02"
product = "a02"
name = "a02"
marketname = "Meizu E"
fingerprint = "meizu/a02/a02:15/AP3A.241005.015.A1/a02.241005.001:user/release-keys"

[templates."meizu_a680h"]
manufacturer = "meizu"
brand = "meizu"
model = "A680H"
device = "a02"
product = "a02"
name = "a02"
marketname = "Meizu M3E"
fingerprint = "meizu/a02/a02:15/AP3A.241005.015.A1/a02.241005.001:user/release-keys"

[templates."meizu_m741a"]
manufacturer = "meizu"
brand = "meizu"
model = "M741A"
device = "m1741"
product = "m1741"
name = "m1741"
marketname = "Meizu E2"
fingerprint = "meizu/m1741/m1741:15/AP3A.241005.015.A1/m1741.241005.001:user/release-keys"

[templates."meizu_m851q"]
manufacturer = "meizu"
brand = "meizu"
model = "M851Q"
device = "m1851"
product = "m1851"
name = "m1851"
marketname = "Meizu E3"
fingerprint = "meizu/m1851/m1851:15/AP3A.241005.015.A1/m1851.241005.001:user/release-keys"

[templates."meizu_m682q"]
manufacturer = "meizu"
brand = "meizu"
model = "M682Q"
device = "m92"
product = "m92"
name = "m92"
marketname = "Meizu X"
fingerprint = "meizu/m92/m92:15/AP3A.241005.015.A1/m92.241005.001:user/release-keys"

[templates."meizu_m465m"]
manufacturer = "meizu"
brand = "meizu"
model = "M465M"
device = "m79"
product = "m79"
name = "m79"
marketname = "Meizu"
fingerprint = "meizu/m79/m79:15/AP3A.241005.015.A1/m79.241005.001:user/release-keys"

[templates."meizu_m465a"]
manufacturer = "meizu"
brand = "meizu"
model = "M465A"
device = "m79"
product = "m79"
name = "m79"
marketname = "Meizu YunOS 版"
fingerprint = "meizu/m79/m79:15/AP3A.241005.015.A1/m79.241005.001:user/release-keys"

[templates."meizu_m578"]
manufacturer = "meizu"
brand = "meizu"
model = "M578"
device = "m88"
product = "m88"
name = "m88"
marketname = "Meizu 2"
fingerprint = "meizu/m88/m88:15/AP3A.241005.015.A1/m88.241005.001:user/release-keys"

[templates."meizu_m578a"]
manufacturer = "meizu"
brand = "meizu"
model = "M578A"
device = "m88"
product = "m88"
name = "m88"
marketname = "Meizu 2 YunOS"
fingerprint = "meizu/m88/m88:15/AP3A.241005.015.A1/m88.241005.001:user/release-keys"

[templates."meizu_m578h"]
manufacturer = "meizu"
brand = "meizu"
model = "M578H"
device = "m88"
product = "m88"
name = "m88"
marketname = "Meizu m2"
fingerprint = "meizu/m88/m88:15/AP3A.241005.015.A1/m88.241005.001:user/release-keys"

[templates."meizu_m688q"]
manufacturer = "meizu"
brand = "meizu"
model = "M688Q"
device = "m98"
product = "m98"
name = "m98"
marketname = "Meizu 3"
fingerprint = "meizu/m98/m98:15/AP3A.241005.015.A1/m98.241005.001:user/release-keys"

[templates."meizu_y685q"]
manufacturer = "meizu"
brand = "meizu"
model = "Y685Q"
device = "y15"
product = "y15"
name = "y15"
marketname = "Meizu 3s"
fingerprint = "meizu/y15/y15:15/AP3A.241005.015.A1/y15.241005.001:user/release-keys"

[templates."meizu_y685h"]
manufacturer = "meizu"
brand = "meizu"
model = "Y685H"
device = "y15"
product = "y15"
name = "y15"
marketname = "Meizu M3s"
fingerprint = "meizu/y15/y15:15/AP3A.241005.015.A1/y15.241005.001:user/release-keys"

[templates."meizu_m611a"]
manufacturer = "meizu"
brand = "meizu"
model = "M611A"
device = "m1611"
product = "m1611"
name = "m1611"
marketname = "Meizu 5"
fingerprint = "meizu/m1611/m1611:15/AP3A.241005.015.A1/m1611.241005.001:user/release-keys"

[templates."meizu_m611h"]
manufacturer = "meizu"
brand = "meizu"
model = "M611H"
device = "m1611"
product = "m1611"
name = "m1611"
marketname = "Meizu M5"
fingerprint = "meizu/m1611/m1611:15/AP3A.241005.015.A1/m1611.241005.001:user/release-keys"

[templates."meizu_m612q"]
manufacturer = "meizu"
brand = "meizu"
model = "M612Q"
device = "m1612"
product = "m1612"
name = "m1612"
marketname = "Meizu 5s"
fingerprint = "meizu/m1612/m1612:15/AP3A.241005.015.A1/m1612.241005.001:user/release-keys"

[templates."meizu_m612h"]
manufacturer = "meizu"
brand = "meizu"
model = "M612H"
device = "m1612"
product = "m1612"
name = "m1612"
marketname = "Meizu M5s"
fingerprint = "meizu/m1612/m1612:15/AP3A.241005.015.A1/m1612.241005.001:user/release-keys"

[templates."meizu_m711q"]
manufacturer = "meizu"
brand = "meizu"
model = "M711Q"
device = "m1711"
product = "m1711"
name = "m1711"
marketname = "Meizu 6"
fingerprint = "meizu/m1711/m1711:15/AP3A.241005.015.A1/m1711.241005.001:user/release-keys"

[templates."meizu_m711h"]
manufacturer = "meizu"
brand = "meizu"
model = "M711H"
device = "m1711"
product = "m1711"
name = "m1711"
marketname = "Meizu M6"
fingerprint = "meizu/m1711/m1711:15/AP3A.241005.015.A1/m1711.241005.001:user/release-keys"

[templates."meizu_m712q"]
manufacturer = "meizu"
brand = "meizu"
model = "M712Q"
device = "m1712"
product = "m1712"
name = "m1712"
marketname = "Meizu S6"
fingerprint = "meizu/m1712/m1712:15/AP3A.241005.015.A1/m1712.241005.001:user/release-keys"

[templates."meizu_m712h"]
manufacturer = "meizu"
brand = "meizu"
model = "M712H"
device = "m1712"
product = "m1712"
name = "m1712"
marketname = "Meizu M6s"
fingerprint = "meizu/m1712/m1712:15/AP3A.241005.015.A1/m1712.241005.001:user/release-keys"

[templates."meizu_m811q"]
manufacturer = "meizu"
brand = "meizu"
model = "M811Q"
device = "m1811"
product = "m1811"
name = "m1811"
marketname = "Meizu 6T"
fingerprint = "meizu/m1811/m1811:15/AP3A.241005.015.A1/m1811.241005.001:user/release-keys"

[templates."meizu_m811h"]
manufacturer = "meizu"
brand = "meizu"
model = "M811H"
device = "m1811"
product = "m1811"
name = "m1811"
marketname = "Meizu M6T"
fingerprint = "meizu/m1811/m1811:15/AP3A.241005.015.A1/m1811.241005.001:user/release-keys"

[templates."meizu_m2112"]
manufacturer = "meizu"
brand = "meizu"
model = "M2112"
device = "m2112"
product = "m2112"
name = "m2112"
marketname = "Meizu 10"
fingerprint = "meizu/m2112/m2112:15/AP3A.241005.015.A1/m2112.241005.001:user/release-keys"

[templates."meizu_m2111"]
manufacturer = "meizu"
brand = "meizu"
model = "M2111"
device = "m2111"
product = "m2111"
name = "m2111"
marketname = "Meizu 10s"
fingerprint = "meizu/m2111/m2111:15/AP3A.241005.015.A1/m2111.241005.001:user/release-keys"

[templates."meizu_m416h"]
manufacturer = "meizu"
brand = "meizu"
model = "M416H"
device = "m2416"
product = "m2416"
name = "m2416"
marketname = "Meizu Mblu 21"
fingerprint = "meizu/m2416/m2416:15/AP3A.241005.015.A1/m2416.241005.001:user/release-keys"

[templates."meizu_m511h"]
manufacturer = "meizu"
brand = "meizu"
model = "M511H"
device = "m2511"
product = "m2511"
name = "m2511"
marketname = "Meizu Mblu 22"
fingerprint = "meizu/m2511/m2511:15/AP3A.241005.015.A1/m2511.241005.001:user/release-keys"

[templates."meizu_m512h"]
manufacturer = "meizu"
brand = "meizu"
model = "M512H"
device = "m2512"
product = "m2512"
name = "m2512"
marketname = "Meizu Mblu 22 Pro"
fingerprint = "meizu/m2512/m2512:15/AP3A.241005.015.A1/m2512.241005.001:user/release-keys"

[templates."meizu_s685q"]
manufacturer = "meizu"
brand = "meizu"
model = "S685Q"
device = "s25"
product = "s25"
name = "s25"
marketname = "Meizu Max"
fingerprint = "meizu/s25/s25:15/AP3A.241005.015.A1/s25.241005.001:user/release-keys"

[templates."meizu_s685h"]
manufacturer = "meizu"
brand = "meizu"
model = "S685H"
device = "s25"
product = "s25"
name = "s25"
marketname = "Meizu M3 Max"
fingerprint = "meizu/s25/s25:15/AP3A.241005.015.A1/s25.241005.001:user/release-keys"

[templates."meizu_u680a"]
manufacturer = "meizu"
brand = "meizu"
model = "U680A"
device = "u10"
product = "u10"
name = "u10"
marketname = "Meizu U10"
fingerprint = "meizu/u10/u10:15/AP3A.241005.015.A1/u10.241005.001:user/release-keys"

[templates."meizu_u685q"]
manufacturer = "meizu"
brand = "meizu"
model = "U685Q"
device = "u15"
product = "u15"
name = "u15"
marketname = "Meizu U20"
fingerprint = "meizu/u15/u15:15/AP3A.241005.015.A1/u15.241005.001:user/release-keys"

[templates."meizu_m57a"]
manufacturer = "meizu"
brand = "meizu"
model = "M57A"
device = "ma01"
product = "ma01"
name = "ma01"
marketname = "Meizu metal"
fingerprint = "meizu/ma01/ma01:15/AP3A.241005.015.A1/ma01.241005.001:user/release-keys"

[templates."meizu_m710m"]
manufacturer = "meizu"
brand = "meizu"
model = "M710M"
device = "m1710"
product = "m1710"
name = "m1710"
marketname = "Meizu A5"
fingerprint = "meizu/m1710/m1710:15/AP3A.241005.015.A1/m1710.241005.001:user/release-keys"

[templates."meizu_m710h"]
manufacturer = "meizu"
brand = "meizu"
model = "M710H"
device = "m1710"
product = "m1710"
name = "m1710"
marketname = "Meizu M5c"
fingerprint = "meizu/m1710/m1710:15/AP3A.241005.015.A1/m1710.241005.001:user/release-keys"

[templates."meizu_m481r"]
manufacturer = "meizu"
brand = "meizu"
model = "M481R"
device = "m2481r"
product = "m2481r"
name = "m2481r"
marketname = "Meizu HongQi Wonder"
fingerprint = "meizu/m2481r/m2481r:15/AP3A.241005.015.A1/m2481r.241005.001:user/release-keys"

[templates."motorola_xt1085"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1085"
device = "victara"
product = "victara"
name = "victara"
marketname = "Moto X"
fingerprint = "motorola/victara/victara:15/AP3A.241005.015.A1/victara.241005.001:user/release-keys"

[templates."motorola_xt1079"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1079"
device = "thea_ds"
product = "thea_ds"
name = "thea_ds"
marketname = "Moto G"
fingerprint = "motorola/thea_ds/thea_ds:15/AP3A.241005.015.A1/thea_ds.241005.001:user/release-keys"

[templates."motorola_xt1115"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1115"
device = "shamu_t"
product = "shamu_t"
name = "shamu_t"
marketname = "Moto X Pro"
fingerprint = "motorola/shamu_t/shamu_t:15/AP3A.241005.015.A1/shamu_t.241005.001:user/release-keys"

[templates."motorola_xt1570"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1570"
device = "clark_ds"
product = "clark_ds"
name = "clark_ds"
marketname = "Moto X Style"
fingerprint = "motorola/clark_ds/clark_ds:15/AP3A.241005.015.A1/clark_ds.241005.001:user/release-keys"

[templates."motorola_xt1561"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1561"
device = "lux_uds"
product = "lux_uds"
name = "lux_uds"
marketname = "Moto X Play"
fingerprint = "motorola/lux_uds/lux_uds:15/AP3A.241005.015.A1/lux_uds.241005.001:user/release-keys"

[templates."motorola_xt1581"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1581"
device = "kinzie_uds"
product = "kinzie_uds"
name = "kinzie_uds"
marketname = "Moto X 极"
fingerprint = "motorola/kinzie_uds/kinzie_uds:15/AP3A.241005.015.A1/kinzie_uds.241005.001:user/release-keys"

[templates."motorola_xt1635_03"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1635-03"
device = "addison"
product = "addison"
name = "addison"
marketname = "Moto Z Play"
fingerprint = "motorola/addison/addison:15/AP3A.241005.015.A1/addison.241005.001:user/release-keys"

[templates."motorola_xt1662"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1662"
device = "kungfu_m"
product = "kungfu_m"
name = "kungfu_m"
marketname = "Moto M"
fingerprint = "motorola/kungfu_m/kungfu_m:15/AP3A.241005.015.A1/kungfu_m.241005.001:user/release-keys"

[templates."motorola_xt1650_05"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1650-05"
device = "griffin"
product = "griffin"
name = "griffin"
marketname = "Moto Z"
fingerprint = "motorola/griffin/griffin:15/AP3A.241005.015.A1/griffin.241005.001:user/release-keys"

[templates."motorola_xt1710_08"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1710-08"
device = "albus"
product = "albus"
name = "albus"
marketname = "Moto Z2 Play"
fingerprint = "motorola/albus/albus:15/AP3A.241005.015.A1/albus.241005.001:user/release-keys"

[templates."motorola_xt1799_1"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1799-1"
device = "montana"
product = "montana"
name = "montana"
marketname = "moto 青柚"
fingerprint = "motorola/montana/montana:15/AP3A.241005.015.A1/montana.241005.001:user/release-keys"

[templates."motorola_xt1789_05"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1789-05"
device = "nash"
product = "nash"
name = "nash"
marketname = "moto Z 2018"
fingerprint = "motorola/nash/nash:15/AP3A.241005.015.A1/nash.241005.001:user/release-keys"

[templates."motorola_xt1925_10"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1925-10"
device = "ali"
product = "ali"
name = "ali"
marketname = "moto 青柚 1s"
fingerprint = "motorola/ali/ali:15/AP3A.241005.015.A1/ali.241005.001:user/release-keys"

[templates."motorola_xt1929_15"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1929-15"
device = "messi"
product = "messi"
name = "messi"
marketname = "motorola Z3"
fingerprint = "motorola/messi/messi:15/AP3A.241005.015.A1/messi.241005.001:user/release-keys"

[templates."motorola_xt1924_9"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1924-9"
device = "ahannah"
product = "ahannah"
name = "ahannah"
marketname = "motorola e5 plus"
fingerprint = "motorola/ahannah/ahannah:15/AP3A.241005.015.A1/ahannah.241005.001:user/release-keys"

[templates."motorola_xt1943_1"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1943-1"
device = "robusta"
product = "robusta"
name = "robusta"
marketname = "motorola p30"
fingerprint = "motorola/robusta/robusta:15/AP3A.241005.015.A1/robusta.241005.001:user/release-keys"

[templates."motorola_xt1942_1"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1942-1"
device = "chef"
product = "chef"
name = "chef"
marketname = "motorola p30 note"
fingerprint = "motorola/chef/chef:15/AP3A.241005.015.A1/chef.241005.001:user/release-keys"

[templates."motorola_xt1941_2"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1941-2"
device = "deen"
product = "deen"
name = "deen"
marketname = "motorola p30 play"
fingerprint = "motorola/deen/deen:15/AP3A.241005.015.A1/deen.241005.001:user/release-keys"

[templates."motorola_xt1965_6"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1965-6"
device = "lake"
product = "lake"
name = "lake"
marketname = "motorola g7 plus"
fingerprint = "motorola/lake/lake:15/AP3A.241005.015.A1/lake.241005.001:user/release-keys"

[templates."motorola_xt1970_5"]
manufacturer = "motorola"
brand = "motorola"
model = "XT1970-5"
device = "kane"
product = "kane"
name = "kane"
marketname = "motorola p50"
fingerprint = "motorola/kane/kane:15/AP3A.241005.015.A1/kane.241005.001:user/release-keys"

[templates."motorola_xt2071_4"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2071-4"
device = "smith"
product = "smith"
name = "smith"
marketname = "motorola razr 5G"
fingerprint = "motorola/smith/smith:15/AP3A.241005.015.A1/smith.241005.001:user/release-keys"

[templates."motorola_xt2125_4"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2125-4"
device = "nio"
product = "nio"
name = "nio"
marketname = "motorola edge s"
fingerprint = "motorola/nio/nio:15/AP3A.241005.015.A1/nio.241005.001:user/release-keys"

[templates."motorola_xt2143_1"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2143-1"
device = "berlin"
product = "berlin"
name = "berlin"
marketname = "motorola edge 轻奢版"
fingerprint = "motorola/berlin/berlin:15/AP3A.241005.015.A1/berlin.241005.001:user/release-keys"

[templates."motorola_xt2153_1"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2153-1"
device = "pstar"
product = "pstar"
name = "pstar"
marketname = "motorola edge s pro"
fingerprint = "motorola/pstar/pstar:15/AP3A.241005.015.A1/pstar.241005.001:user/release-keys"

[templates."motorola_xt2137_2"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2137-2"
device = "ibiza"
product = "ibiza"
name = "ibiza"
marketname = "motorola g50"
fingerprint = "motorola/ibiza/ibiza:15/AP3A.241005.015.A1/ibiza.241005.001:user/release-keys"

[templates."motorola_xt2171_3"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2171-3"
device = "cypfq"
product = "cypfq"
name = "cypfq"
marketname = "moto g51"
fingerprint = "motorola/cypfq/cypfq:15/AP3A.241005.015.A1/cypfq.241005.001:user/release-keys"

[templates."motorola_xt2169_2"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2169-2"
device = "corfur"
product = "corfur"
name = "corfur"
marketname = "moto g71"
fingerprint = "motorola/corfur/corfur:15/AP3A.241005.015.A1/corfur.241005.001:user/release-keys"

[templates."motorola_xt2225_2"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2225-2"
device = "rhodep"
product = "rhodep"
name = "rhodep"
marketname = "moto g71s"
fingerprint = "motorola/rhodep/rhodep:15/AP3A.241005.015.A1/rhodep.241005.001:user/release-keys"

[templates."motorola_xt2175_2"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2175-2"
device = "xpeng"
product = "xpeng"
name = "xpeng"
marketname = "moto edge S30"
fingerprint = "motorola/xpeng/xpeng:15/AP3A.241005.015.A1/xpeng.241005.001:user/release-keys"

[templates."motorola_xt2201_2"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2201-2"
device = "hiphic"
product = "hiphic"
name = "hiphic"
marketname = "moto edge X30"
fingerprint = "motorola/hiphic/hiphic:15/AP3A.241005.015.A1/hiphic.241005.001:user/release-keys"

[templates."motorola_xt2201_6"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2201-6"
device = "hiphid"
product = "hiphid"
name = "hiphid"
marketname = "moto edge X30 屏下摄像版"
fingerprint = "motorola/hiphid/hiphid:15/AP3A.241005.015.A1/hiphid.241005.001:user/release-keys"

[templates."motorola_xt2241_1"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2241-1"
device = "eqs"
product = "eqs"
name = "eqs"
marketname = "moto X30 Pro"
fingerprint = "motorola/eqs/eqs:15/AP3A.241005.015.A1/eqs.241005.001:user/release-keys"

[templates."motorola_xt2243_2"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2243-2"
device = "tundra"
product = "tundra"
name = "tundra"
marketname = "moto S30 Pro"
fingerprint = "motorola/tundra/tundra:15/AP3A.241005.015.A1/tundra.241005.001:user/release-keys"

[templates."motorola_xt2251_1"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2251-1"
device = "oneli"
product = "oneli"
name = "oneli"
marketname = "moto razr 2022"
fingerprint = "motorola/oneli/oneli:15/AP3A.241005.015.A1/oneli.241005.001:user/release-keys"

[templates."motorola_xt2301_5"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2301-5"
device = "rtwo"
product = "rtwo"
name = "rtwo"
marketname = "moto X40"
fingerprint = "motorola/rtwo/rtwo:15/AP3A.241005.015.A1/rtwo.241005.001:user/release-keys"

[templates."motorola_xt2335_3"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2335-3"
device = "penang"
product = "penang"
name = "penang"
marketname = "moto g53"
fingerprint = "motorola/penang/penang:15/AP3A.241005.015.A1/penang.241005.001:user/release-keys"

[templates."motorola_xt2323_3"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2323-3"
device = "lynkco"
product = "lynkco"
name = "lynkco"
marketname = "moto razr 40"
fingerprint = "motorola/lynkco/lynkco:15/AP3A.241005.015.A1/lynkco.241005.001:user/release-keys"

[templates."motorola_xt2321_2"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2321-2"
device = "zeekr"
product = "zeekr"
name = "zeekr"
marketname = "moto razr 40 Ultra"
fingerprint = "motorola/zeekr/zeekr:15/AP3A.241005.015.A1/zeekr.241005.001:user/release-keys"

[templates."motorola_xt2343_3"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2343-3"
device = "cancunf"
product = "cancunf"
name = "cancunf"
marketname = "moto g54"
fingerprint = "motorola/cancunf/cancunf:15/AP3A.241005.015.A1/cancunf.241005.001:user/release-keys"

[templates."motorola_xt2363_4"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2363-4"
device = "fogos"
product = "fogos"
name = "fogos"
marketname = "moto g34"
fingerprint = "motorola/fogos/fogos:15/AP3A.241005.015.A1/fogos.241005.001:user/release-keys"

[templates."motorola_xt2401_2"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2401-2"
device = "ctwo"
product = "ctwo"
name = "ctwo"
marketname = "moto X50 Ultra"
fingerprint = "motorola/ctwo/ctwo:15/AP3A.241005.015.A1/ctwo.241005.001:user/release-keys"

[templates."motorola_xt2409_5"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2409-5"
device = "vienna"
product = "vienna"
name = "vienna"
marketname = "moto S50"
fingerprint = "motorola/vienna/vienna:15/AP3A.241005.015.A1/vienna.241005.001:user/release-keys"

[templates."motorola_xt2427_4"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2427-4"
device = "malmo"
product = "malmo"
name = "malmo"
marketname = "moto S50 Neo"
fingerprint = "motorola/malmo/malmo:15/AP3A.241005.015.A1/malmo.241005.001:user/release-keys"

[templates."motorola_xt2453_2"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2453-2"
device = "aito"
product = "aito"
name = "aito"
marketname = "moto razr 50"
fingerprint = "motorola/aito/aito:15/AP3A.241005.015.A1/aito.241005.001:user/release-keys"

[templates."motorola_xt2451_4"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2451-4"
device = "arcfox"
product = "arcfox"
name = "arcfox"
marketname = "moto razr 50 Ultra"
fingerprint = "motorola/arcfox/arcfox:15/AP3A.241005.015.A1/arcfox.241005.001:user/release-keys"

[templates."motorola_xt2435_3"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2435-3"
device = "taipei"
product = "taipei"
name = "taipei"
marketname = "moto g55"
fingerprint = "motorola/taipei/taipei:15/AP3A.241005.015.A1/taipei.241005.001:user/release-keys"

[templates."motorola_xt2437_4"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2437-4"
device = "paros"
product = "paros"
name = "paros"
marketname = "moto g75"
fingerprint = "motorola/paros/paros:15/AP3A.241005.015.A1/paros.241005.001:user/release-keys"

[templates."motorola_xt2505_4"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2505-4"
device = "scout"
product = "scout"
name = "scout"
marketname = "moto edge 60"
fingerprint = "motorola/scout/scout:15/AP3A.241005.015.A1/scout.241005.001:user/release-keys"

[templates."motorola_xt2503_3"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2503-3"
device = "scout"
product = "scout"
name = "scout"
marketname = "moto edge 60s"
fingerprint = "motorola/scout/scout:15/AP3A.241005.015.A1/scout.241005.001:user/release-keys"

[templates."motorola_xt2507_5"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2507-5"
device = "cybert"
product = "cybert"
name = "cybert"
marketname = "moto edge 60 Pro"
fingerprint = "motorola/cybert/cybert:15/AP3A.241005.015.A1/cybert.241005.001:user/release-keys"

[templates."motorola_xt2553_2"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2553-2"
device = "aito"
product = "aito"
name = "aito"
marketname = "moto razr 60"
fingerprint = "motorola/aito/aito:15/AP3A.241005.015.A1/aito.241005.001:user/release-keys"

[templates."motorola_xt2557_1"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2557-1"
device = "arcfox"
product = "arcfox"
name = "arcfox"
marketname = "moto razr 60 Pro"
fingerprint = "motorola/arcfox/arcfox:15/AP3A.241005.015.A1/arcfox.241005.001:user/release-keys"

[templates."motorola_xt2551_3"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2551-3"
device = "leap"
product = "leap"
name = "leap"
marketname = "moto razr 60 Ultra"
fingerprint = "motorola/leap/leap:15/AP3A.241005.015.A1/leap.241005.001:user/release-keys"

[templates."motorola_xt2527_3"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2527-3"
device = "nice"
product = "nice"
name = "nice"
marketname = "moto g100 Pro"
fingerprint = "motorola/nice/nice:15/AP3A.241005.015.A1/nice.241005.001:user/release-keys"

[templates."motorola_xt2533_4"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2533-4"
device = "portov"
product = "portov"
name = "portov"
marketname = "moto g100"
fingerprint = "motorola/portov/portov:15/AP3A.241005.015.A1/portov.241005.001:user/release-keys"

[templates."motorola_xt2537_4"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2537-4"
device = "mumba"
product = "mumba"
name = "mumba"
marketname = "moto g100s"
fingerprint = "motorola/mumba/mumba:15/AP3A.241005.015.A1/mumba.241005.001:user/release-keys"

[templates."motorola_xt2601_1"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2601-1"
device = "roadstr"
product = "roadstr"
name = "roadstr"
marketname = "moto X70 Air"
fingerprint = "motorola/roadstr/roadstr:15/AP3A.241005.015.A1/roadstr.241005.001:user/release-keys"

[templates."motorola_xt2603_1"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2603-1"
device = "vantage"
product = "vantage"
name = "vantage"
marketname = "moto X70 Air Pro"
fingerprint = "motorola/vantage/vantage:15/AP3A.241005.015.A1/vantage.241005.001:user/release-keys"

[templates."motorola_xt2651_4"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2651-4"
device = "blanc"
product = "blanc"
name = "blanc"
marketname = "moto razr fold"
fingerprint = "motorola/blanc/blanc:15/AP3A.241005.015.A1/blanc.241005.001:user/release-keys"

[templates."motorola_xt2655_4"]
manufacturer = "motorola"
brand = "motorola"
model = "XT2655-4"
device = "lhotse"
product = "lhotse"
name = "lhotse"
marketname = "moto razr 70 Ultra"
fingerprint = "motorola/lhotse/lhotse:15/AP3A.241005.015.A1/lhotse.241005.001:user/release-keys"

[templates."oneplus_one_a0001"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "ONE A0001"
device = "bacon"
product = "bacon"
name = "bacon"
marketname = "OnePlus Phone"
fingerprint = "OnePlus/bacon/bacon:15/AP3A.241005.015.A1/bacon.241005.001:user/release-keys"

[templates."oneplus_one_a2001"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "ONE A2001"
device = "oneplus2"
product = "oneplus2"
name = "oneplus2"
marketname = "OnePlus Phone 2"
fingerprint = "OnePlus/oneplus2/oneplus2:15/AP3A.241005.015.A1/oneplus2.241005.001:user/release-keys"

[templates."oneplus_one_e1000"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "ONE E1000"
device = "onyx"
product = "onyx"
name = "onyx"
marketname = "OnePlus Phone X"
fingerprint = "OnePlus/onyx/onyx:15/AP3A.241005.015.A1/onyx.241005.001:user/release-keys"

[templates."oneplus_oneplus_a3000"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "ONEPLUS A3000"
device = "oneplus3"
product = "oneplus3"
name = "oneplus3"
marketname = "OnePlus Phone 3"
fingerprint = "OnePlus/oneplus3/oneplus3:15/AP3A.241005.015.A1/oneplus3.241005.001:user/release-keys"

[templates."oneplus_oneplus_a3010"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "ONEPLUS A3010"
device = "oneplus3t"
product = "oneplus3t"
name = "oneplus3t"
marketname = "OnePlus Phone 3T"
fingerprint = "OnePlus/oneplus3t/oneplus3t:15/AP3A.241005.015.A1/oneplus3t.241005.001:user/release-keys"

[templates."oneplus_oneplus_a5000"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "ONEPLUS A5000"
device = "cheeseburger"
product = "cheeseburger"
name = "cheeseburger"
marketname = "OnePlus 5"
fingerprint = "OnePlus/cheeseburger/cheeseburger:15/AP3A.241005.015.A1/cheeseburger.241005.001:user/release-keys"

[templates."oneplus_oneplus_a5010"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "ONEPLUS A5010"
device = "dumpling"
product = "dumpling"
name = "dumpling"
marketname = "OnePlus 5T"
fingerprint = "OnePlus/dumpling/dumpling:15/AP3A.241005.015.A1/dumpling.241005.001:user/release-keys"

[templates."oneplus_oneplus_a6000"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "ONEPLUS A6000"
device = "enchilada"
product = "enchilada"
name = "enchilada"
marketname = "OnePlus 6"
fingerprint = "OnePlus/enchilada/enchilada:15/AP3A.241005.015.A1/enchilada.241005.001:user/release-keys"

[templates."oneplus_oneplus_a6010"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "ONEPLUS A6010"
device = "fajita"
product = "fajita"
name = "fajita"
marketname = "OnePlus 6T"
fingerprint = "OnePlus/fajita/fajita:15/AP3A.241005.015.A1/fajita.241005.001:user/release-keys"

[templates."oneplus_gm1900"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "GM1900"
device = "guacamoleb"
product = "guacamoleb"
name = "guacamoleb"
marketname = "OnePlus 7"
fingerprint = "OnePlus/guacamoleb/guacamoleb:15/AP3A.241005.015.A1/guacamoleb.241005.001:user/release-keys"

[templates."oneplus_gm1910"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "GM1910"
device = "guacamole"
product = "guacamole"
name = "guacamole"
marketname = "OnePlus 7 Pro"
fingerprint = "OnePlus/guacamole/guacamole:15/AP3A.241005.015.A1/guacamole.241005.001:user/release-keys"

[templates."oneplus_gm1917"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "GM1917"
device = "guacamolet"
product = "guacamolet"
name = "guacamolet"
marketname = "OnePlus 7 Pro T-Mobile 版"
fingerprint = "OnePlus/guacamolet/guacamolet:15/AP3A.241005.015.A1/guacamolet.241005.001:user/release-keys"

[templates."oneplus_gm1920"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "GM1920"
device = "guacamoleg"
product = "guacamoleg"
name = "guacamoleg"
marketname = "OnePlus 7 Pro 5G"
fingerprint = "OnePlus/guacamoleg/guacamoleg:15/AP3A.241005.015.A1/guacamoleg.241005.001:user/release-keys"

[templates."oneplus_gm1925"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "GM1925"
device = "guacamoles"
product = "guacamoles"
name = "guacamoles"
marketname = "OnePlus 7 Pro 5G Sprint 版"
fingerprint = "OnePlus/guacamoles/guacamoles:15/AP3A.241005.015.A1/guacamoles.241005.001:user/release-keys"

[templates."oneplus_hd1900"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "HD1900"
device = "hotdogb"
product = "hotdogb"
name = "hotdogb"
marketname = "OnePlus 7T"
fingerprint = "OnePlus/hotdogb/hotdogb:15/AP3A.241005.015.A1/hotdogb.241005.001:user/release-keys"

[templates."oneplus_hd1907"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "HD1907"
device = "hotdogt"
product = "hotdogt"
name = "hotdogt"
marketname = "OnePlus 7T T-Mobile 版"
fingerprint = "OnePlus/hotdogt/hotdogt:15/AP3A.241005.015.A1/hotdogt.241005.001:user/release-keys"

[templates."oneplus_hd1910"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "HD1910"
device = "hotdog"
product = "hotdog"
name = "hotdog"
marketname = "OnePlus 7T Pro"
fingerprint = "OnePlus/hotdog/hotdog:15/AP3A.241005.015.A1/hotdog.241005.001:user/release-keys"

[templates."oneplus_hd1925"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "HD1925"
device = "hotdogg"
product = "hotdogg"
name = "hotdogg"
marketname = "OnePlus 7T Pro 5G T-Mobile 版"
fingerprint = "OnePlus/hotdogg/hotdogg:15/AP3A.241005.015.A1/hotdogg.241005.001:user/release-keys"

[templates."oneplus_in2010"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "IN2010"
device = "instantnoodle"
product = "instantnoodle"
name = "instantnoodle"
marketname = "OnePlus 8"
fingerprint = "OnePlus/instantnoodle/instantnoodle:15/AP3A.241005.015.A1/instantnoodle.241005.001:user/release-keys"

[templates."oneplus_in2017"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "IN2017"
device = "instantnoodlet"
product = "instantnoodlet"
name = "instantnoodlet"
marketname = "OnePlus 8 T-Mobile 版"
fingerprint = "OnePlus/instantnoodlet/instantnoodlet:15/AP3A.241005.015.A1/instantnoodlet.241005.001:user/release-keys"

[templates."oneplus_in2019"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "IN2019"
device = "instantnoodlevis"
product = "instantnoodlevis"
name = "instantnoodlevis"
marketname = "OnePlus 8 Visible 版"
fingerprint = "OnePlus/instantnoodlevis/instantnoodlevis:15/AP3A.241005.015.A1/instantnoodlevis.241005.001:user/release-keys"

[templates."oneplus_in2020"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "IN2020"
device = "instantnoodlep"
product = "instantnoodlep"
name = "instantnoodlep"
marketname = "OnePlus 8 Pro"
fingerprint = "OnePlus/instantnoodlep/instantnoodlep:15/AP3A.241005.015.A1/instantnoodlep.241005.001:user/release-keys"

[templates."oneplus_kb2000"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "KB2000"
device = "kebab"
product = "kebab"
name = "kebab"
marketname = "OnePlus 8T"
fingerprint = "OnePlus/kebab/kebab:15/AP3A.241005.015.A1/kebab.241005.001:user/release-keys"

[templates."oneplus_kb2007"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "KB2007"
device = "kebabt"
product = "kebabt"
name = "kebabt"
marketname = "OnePlus 8T+ T-Mobile 版"
fingerprint = "OnePlus/kebabt/kebabt:15/AP3A.241005.015.A1/kebabt.241005.001:user/release-keys"

[templates."oneplus_le2100"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "LE2100"
device = "lemonades"
product = "lemonades"
name = "lemonades"
marketname = "OnePlus 9R"
fingerprint = "OnePlus/lemonades/lemonades:15/AP3A.241005.015.A1/lemonades.241005.001:user/release-keys"

[templates."oneplus_le2110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "LE2110"
device = "lemonade"
product = "lemonade"
name = "lemonade"
marketname = "OnePlus 9"
fingerprint = "OnePlus/lemonade/lemonade:15/AP3A.241005.015.A1/lemonade.241005.001:user/release-keys"

[templates."oneplus_le2117"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "LE2117"
device = "lemonadet"
product = "lemonadet"
name = "lemonadet"
marketname = "OnePlus 9 T-Mobile 版"
fingerprint = "OnePlus/lemonadet/lemonadet:15/AP3A.241005.015.A1/lemonadet.241005.001:user/release-keys"

[templates."oneplus_le2119"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "LE2119"
device = "lemonadev"
product = "lemonadev"
name = "lemonadev"
marketname = "OnePlus 9 Verizon 版"
fingerprint = "OnePlus/lemonadev/lemonadev:15/AP3A.241005.015.A1/lemonadev.241005.001:user/release-keys"

[templates."oneplus_le2120"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "LE2120"
device = "lemonadep"
product = "lemonadep"
name = "lemonadep"
marketname = "OnePlus 9 Pro"
fingerprint = "OnePlus/lemonadep/lemonadep:15/AP3A.241005.015.A1/lemonadep.241005.001:user/release-keys"

[templates."oneplus_le2127"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "LE2127"
device = "lemonadept"
product = "lemonadept"
name = "lemonadept"
marketname = "OnePlus 9 Pro T-Mobile 版"
fingerprint = "OnePlus/lemonadept/lemonadept:15/AP3A.241005.015.A1/lemonadept.241005.001:user/release-keys"

[templates."oneplus_mt2110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "MT2110"
device = "martini"
product = "martini"
name = "martini"
marketname = "OnePlus 9RT"
fingerprint = "OnePlus/martini/martini:15/AP3A.241005.015.A1/martini.241005.001:user/release-keys"

[templates."oneplus_ne2210"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "NE2210"
device = "negroni"
product = "negroni"
name = "negroni"
marketname = "OnePlus 10 Pro"
fingerprint = "OnePlus/negroni/negroni:15/AP3A.241005.015.A1/negroni.241005.001:user/release-keys"

[templates."oneplus_ne2217"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "NE2217"
device = "negroni"
product = "negroni"
name = "negroni"
marketname = "OnePlus 10 Pro T-Mobile 版"
fingerprint = "OnePlus/negroni/negroni:15/AP3A.241005.015.A1/negroni.241005.001:user/release-keys"

[templates."oneplus_pgkm10"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PGKM10"
device = "pickle"
product = "pickle"
name = "pickle"
marketname = "OnePlus Ace"
fingerprint = "OnePlus/pickle/pickle:15/AP3A.241005.015.A1/pickle.241005.001:user/release-keys"

[templates."oneplus_cph2423"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2423"
device = "pickle"
product = "pickle"
name = "pickle"
marketname = "OnePlus 10R"
fingerprint = "OnePlus/pickle/pickle:15/AP3A.241005.015.A1/pickle.241005.001:user/release-keys"

[templates."oneplus_cph2411"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2411"
device = "pickle"
product = "pickle"
name = "pickle"
marketname = "OnePlus 10R 长寿版"
fingerprint = "OnePlus/pickle/pickle:15/AP3A.241005.015.A1/pickle.241005.001:user/release-keys"

[templates."oneplus_pgz110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PGZ110"
device = "qqcandy"
product = "qqcandy"
name = "qqcandy"
marketname = "OnePlus Ace 竞速版"
fingerprint = "OnePlus/qqcandy/qqcandy:15/AP3A.241005.015.A1/qqcandy.241005.001:user/release-keys"

[templates."oneplus_pgp110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PGP110"
device = "ovaltine"
product = "ovaltine"
name = "ovaltine"
marketname = "OnePlus Ace Pro"
fingerprint = "OnePlus/ovaltine/ovaltine:15/AP3A.241005.015.A1/ovaltine.241005.001:user/release-keys"

[templates."oneplus_cph2413"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2413"
device = "ovaltine"
product = "ovaltine"
name = "ovaltine"
marketname = "OnePlus 10T"
fingerprint = "OnePlus/ovaltine/ovaltine:15/AP3A.241005.015.A1/ovaltine.241005.001:user/release-keys"

[templates."oneplus_cph2419"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2419"
device = "ovaltine"
product = "ovaltine"
name = "ovaltine"
marketname = "OnePlus 10T T-Mobile 版"
fingerprint = "OnePlus/ovaltine/ovaltine:15/AP3A.241005.015.A1/ovaltine.241005.001:user/release-keys"

[templates."oneplus_phb110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PHB110"
device = "salami"
product = "salami"
name = "salami"
marketname = "OnePlus 11"
fingerprint = "OnePlus/salami/salami:15/AP3A.241005.015.A1/salami.241005.001:user/release-keys"

[templates."oneplus_phk110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PHK110"
device = "udon"
product = "udon"
name = "udon"
marketname = "OnePlus Ace 2"
fingerprint = "OnePlus/udon/udon:15/AP3A.241005.015.A1/udon.241005.001:user/release-keys"

[templates."oneplus_cph2487"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2487"
device = "udon"
product = "udon"
name = "udon"
marketname = "OnePlus 11R"
fingerprint = "OnePlus/udon/udon:15/AP3A.241005.015.A1/udon.241005.001:user/release-keys"

[templates."oneplus_php110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PHP110"
device = "vitamin"
product = "vitamin"
name = "vitamin"
marketname = "OnePlus Ace 2V"
fingerprint = "OnePlus/vitamin/vitamin:15/AP3A.241005.015.A1/vitamin.241005.001:user/release-keys"

[templates."oneplus_cph2491"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2491"
device = "vitamin"
product = "vitamin"
name = "vitamin"
marketname = "OnePlus Nord 3"
fingerprint = "OnePlus/vitamin/vitamin:15/AP3A.241005.015.A1/vitamin.241005.001:user/release-keys"

[templates."oneplus_pja110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PJA110"
device = "xigua"
product = "xigua"
name = "xigua"
marketname = "OnePlus Ace 2 Pro"
fingerprint = "OnePlus/xigua/xigua:15/AP3A.241005.015.A1/xigua.241005.001:user/release-keys"

[templates."oneplus_pjd110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PJD110"
device = "waffle"
product = "waffle"
name = "waffle"
marketname = "OnePlus 12"
fingerprint = "OnePlus/waffle/waffle:15/AP3A.241005.015.A1/waffle.241005.001:user/release-keys"

[templates."oneplus_pje110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PJE110"
device = "aston"
product = "aston"
name = "aston"
marketname = "OnePlus Ace 3"
fingerprint = "OnePlus/aston/aston:15/AP3A.241005.015.A1/aston.241005.001:user/release-keys"

[templates."oneplus_cph2585"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2585"
device = "aston"
product = "aston"
name = "aston"
marketname = "OnePlus 12R"
fingerprint = "OnePlus/aston/aston:15/AP3A.241005.015.A1/aston.241005.001:user/release-keys"

[templates."oneplus_pjf110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PJF110"
device = "audi"
product = "audi"
name = "audi"
marketname = "OnePlus Ace 3V"
fingerprint = "OnePlus/audi/audi:15/AP3A.241005.015.A1/audi.241005.001:user/release-keys"

[templates."oneplus_pjx110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PJX110"
device = "corvette"
product = "corvette"
name = "corvette"
marketname = "OnePlus Ace 3 Pro"
fingerprint = "OnePlus/corvette/corvette:15/AP3A.241005.015.A1/corvette.241005.001:user/release-keys"

[templates."oneplus_pjz110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PJZ110"
device = "dodge"
product = "dodge"
name = "dodge"
marketname = "OnePlus 13"
fingerprint = "OnePlus/dodge/dodge:15/AP3A.241005.015.A1/dodge.241005.001:user/release-keys"

[templates."oneplus_pkg110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PKG110"
device = "giulia"
product = "giulia"
name = "giulia"
marketname = "OnePlus Ace 5"
fingerprint = "OnePlus/giulia/giulia:15/AP3A.241005.015.A1/giulia.241005.001:user/release-keys"

[templates."oneplus_cph2645"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2645"
device = "giulia"
product = "giulia"
name = "giulia"
marketname = "OnePlus 13R"
fingerprint = "OnePlus/giulia/giulia:15/AP3A.241005.015.A1/giulia.241005.001:user/release-keys"

[templates."oneplus_pkr110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PKR110"
device = "hummer"
product = "hummer"
name = "hummer"
marketname = "OnePlus Ace 5 Pro"
fingerprint = "OnePlus/hummer/hummer:15/AP3A.241005.015.A1/hummer.241005.001:user/release-keys"

[templates."oneplus_pkx110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PKX110"
device = "pagani"
product = "pagani"
name = "pagani"
marketname = "OnePlus 13T"
fingerprint = "OnePlus/pagani/pagani:15/AP3A.241005.015.A1/pagani.241005.001:user/release-keys"

[templates."oneplus_cph2723"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2723"
device = "pagani"
product = "pagani"
name = "pagani"
marketname = "OnePlus 13s"
fingerprint = "OnePlus/pagani/pagani:15/AP3A.241005.015.A1/pagani.241005.001:user/release-keys"

[templates."oneplus_plc110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PLC110"
device = "emira"
product = "emira"
name = "emira"
marketname = "OnePlus Ace 5 至尊版"
fingerprint = "OnePlus/emira/emira:15/AP3A.241005.015.A1/emira.241005.001:user/release-keys"

[templates."oneplus_plf110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PLF110"
device = "subaru"
product = "subaru"
name = "subaru"
marketname = "OnePlus Ace 5 竞速版"
fingerprint = "OnePlus/subaru/subaru:15/AP3A.241005.015.A1/subaru.241005.001:user/release-keys"

[templates."oneplus_plk110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PLK110"
device = "infiniti"
product = "infiniti"
name = "infiniti"
marketname = "OnePlus 15"
fingerprint = "OnePlus/infiniti/infiniti:15/AP3A.241005.015.A1/infiniti.241005.001:user/release-keys"

[templates."oneplus_plq110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PLQ110"
device = "ktm"
product = "ktm"
name = "ktm"
marketname = "OnePlus Ace 6"
fingerprint = "OnePlus/ktm/ktm:15/AP3A.241005.015.A1/ktm.241005.001:user/release-keys"

[templates."oneplus_plr110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PLR110"
device = "macan"
product = "macan"
name = "macan"
marketname = "OnePlus Ace 6T"
fingerprint = "OnePlus/macan/macan:15/AP3A.241005.015.A1/macan.241005.001:user/release-keys"

[templates."oneplus_cph2767"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2767"
device = "macan"
product = "macan"
name = "macan"
marketname = "OnePlus 15R"
fingerprint = "OnePlus/macan/macan:15/AP3A.241005.015.A1/macan.241005.001:user/release-keys"

[templates."oneplus_plz110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PLZ110"
device = "fairlady"
product = "fairlady"
name = "fairlady"
marketname = "OnePlus 15T"
fingerprint = "OnePlus/fairlady/fairlady:15/AP3A.241005.015.A1/fairlady.241005.001:user/release-keys"

[templates."oneplus_pmb110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PMB110"
device = "roadster"
product = "roadster"
name = "roadster"
marketname = "OnePlus Ace 6 至尊版"
fingerprint = "OnePlus/roadster/roadster:15/AP3A.241005.015.A1/roadster.241005.001:user/release-keys"

[templates."oneplus_plu110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PLU110"
device = "volkswagen"
product = "volkswagen"
name = "volkswagen"
marketname = "OnePlus Turbo 6"
fingerprint = "OnePlus/volkswagen/volkswagen:15/AP3A.241005.015.A1/volkswagen.241005.001:user/release-keys"

[templates."oneplus_cph2793"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2793"
device = "volkswagen"
product = "volkswagen"
name = "volkswagen"
marketname = "OnePlus Nord 6"
fingerprint = "OnePlus/volkswagen/volkswagen:15/AP3A.241005.015.A1/volkswagen.241005.001:user/release-keys"

[templates."oneplus_ply110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PLY110"
device = "prado"
product = "prado"
name = "prado"
marketname = "OnePlus Turbo 6V"
fingerprint = "OnePlus/prado/prado:15/AP3A.241005.015.A1/prado.241005.001:user/release-keys"

[templates."oneplus_cph2805"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2805"
device = "prado"
product = "prado"
name = "prado"
marketname = "OnePlus Nord CE 6"
fingerprint = "OnePlus/prado/prado:15/AP3A.241005.015.A1/prado.241005.001:user/release-keys"

[templates."oneplus_pys110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PYS110"
device = "kof"
product = "kof"
name = "kof"
marketname = "OnePlus Turbo 6X"
fingerprint = "OnePlus/kof/kof:15/AP3A.241005.015.A1/kof.241005.001:user/release-keys"

[templates."oneplus_pyr110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PYR110"
device = "lol"
product = "lol"
name = "lol"
marketname = "OnePlus Turbo 6X Pro"
fingerprint = "OnePlus/lol/lol:15/AP3A.241005.015.A1/lol.241005.001:user/release-keys"

[templates."oneplus_pyb110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PYB110"
device = "pokemon"
product = "pokemon"
name = "pokemon"
marketname = "OnePlus 16"
fingerprint = "OnePlus/pokemon/pokemon:15/AP3A.241005.015.A1/pokemon.241005.001:user/release-keys"

[templates."oneplus_pyf110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PYF110"
device = "mario"
product = "mario"
name = "mario"
marketname = "OnePlus Ace 7"
fingerprint = "OnePlus/mario/mario:15/AP3A.241005.015.A1/mario.241005.001:user/release-keys"

[templates."oneplus_pms110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "PMS110"
device = "redalert"
product = "redalert"
name = "redalert"
marketname = "OnePlus Ace 7 Pro"
fingerprint = "OnePlus/redalert/redalert:15/AP3A.241005.015.A1/redalert.241005.001:user/release-keys"

[templates."oneplus_ac2001"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "AC2001"
device = "avicii"
product = "avicii"
name = "avicii"
marketname = "OnePlus Nord"
fingerprint = "OnePlus/avicii/avicii:15/AP3A.241005.015.A1/avicii.241005.001:user/release-keys"

[templates."oneplus_dn2101"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "DN2101"
device = "denniz"
product = "denniz"
name = "denniz"
marketname = "OnePlus Nord 2"
fingerprint = "OnePlus/denniz/denniz:15/AP3A.241005.015.A1/denniz.241005.001:user/release-keys"

[templates."oneplus_cph2399"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2399"
device = "karen"
product = "karen"
name = "karen"
marketname = "OnePlus Nord 2T"
fingerprint = "OnePlus/karen/karen:15/AP3A.241005.015.A1/karen.241005.001:user/release-keys"

[templates."oneplus_cph2661"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2661"
device = "avalon"
product = "avalon"
name = "avalon"
marketname = "OnePlus Nord 4"
fingerprint = "OnePlus/avalon/avalon:15/AP3A.241005.015.A1/avalon.241005.001:user/release-keys"

[templates."oneplus_cph2707"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2707"
device = "lexus"
product = "lexus"
name = "lexus"
marketname = "OnePlus Nord 5"
fingerprint = "OnePlus/lexus/lexus:15/AP3A.241005.015.A1/lexus.241005.001:user/release-keys"

[templates."oneplus_eb2101"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "EB2101"
device = "ebba"
product = "ebba"
name = "ebba"
marketname = "OnePlus Nord CE"
fingerprint = "OnePlus/ebba/ebba:15/AP3A.241005.015.A1/ebba.241005.001:user/release-keys"

[templates."oneplus_iv2201"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "IV2201"
device = "ivan"
product = "ivan"
name = "ivan"
marketname = "OnePlus Nord CE 2"
fingerprint = "OnePlus/ivan/ivan:15/AP3A.241005.015.A1/ivan.241005.001:user/release-keys"

[templates."oneplus_cph2381"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2381"
device = "oscar"
product = "oscar"
name = "oscar"
marketname = "OnePlus Nord CE 2 Lite"
fingerprint = "OnePlus/oscar/oscar:15/AP3A.241005.015.A1/oscar.241005.001:user/release-keys"

[templates."oneplus_cph2569"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2569"
device = "ziti"
product = "ziti"
name = "ziti"
marketname = "OnePlus Nord CE 3"
fingerprint = "OnePlus/ziti/ziti:15/AP3A.241005.015.A1/ziti.241005.001:user/release-keys"

[templates."oneplus_cph2465"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2465"
device = "larry"
product = "larry"
name = "larry"
marketname = "OnePlus Nord CE 3 Lite"
fingerprint = "OnePlus/larry/larry:15/AP3A.241005.015.A1/larry.241005.001:user/release-keys"

[templates."oneplus_cph2513"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2513"
device = "larry"
product = "larry"
name = "larry"
marketname = "OnePlus Nord N30"
fingerprint = "OnePlus/larry/larry:15/AP3A.241005.015.A1/larry.241005.001:user/release-keys"

[templates."oneplus_cph2515"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2515"
device = "larry"
product = "larry"
name = "larry"
marketname = "OnePlus Nord N30 T-Mobile 版"
fingerprint = "OnePlus/larry/larry:15/AP3A.241005.015.A1/larry.241005.001:user/release-keys"

[templates."oneplus_cph2613"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2613"
device = "benz"
product = "benz"
name = "benz"
marketname = "OnePlus Nord CE 4"
fingerprint = "OnePlus/benz/benz:15/AP3A.241005.015.A1/benz.241005.001:user/release-keys"

[templates."oneplus_cph2619"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2619"
device = "camry"
product = "camry"
name = "camry"
marketname = "OnePlus Nord CE 4 Lite"
fingerprint = "OnePlus/camry/camry:15/AP3A.241005.015.A1/camry.241005.001:user/release-keys"

[templates."oneplus_cph2717"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2717"
device = "honda"
product = "honda"
name = "honda"
marketname = "OnePlus Nord CE 5"
fingerprint = "OnePlus/honda/honda:15/AP3A.241005.015.A1/honda.241005.001:user/release-keys"

[templates."oneplus_cph2943"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2943"
device = "suzuki-o"
product = "suzuki-o"
name = "suzuki-o"
marketname = "OnePlus Nord CE 6 Lite"
fingerprint = "OnePlus/suzuki-o/suzuki-o:15/AP3A.241005.015.A1/suzuki-o.241005.001:user/release-keys"

[templates."oneplus_cph2955"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2955"
device = "mumbai-o"
product = "mumbai-o"
name = "mumbai-o"
marketname = "OnePlus N6"
fingerprint = "OnePlus/mumbai-o/mumbai-o:15/AP3A.241005.015.A1/mumbai-o.241005.001:user/release-keys"

[templates."oneplus_cph2971"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2971"
device = "mumbai-c5"
product = "mumbai-c5"
name = "mumbai-c5"
marketname = "OnePlus N6x"
fingerprint = "OnePlus/mumbai-c5/mumbai-c5:15/AP3A.241005.015.A1/mumbai-c5.241005.001:user/release-keys"

[templates."oneplus_cph2993"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2993"
device = "CPH2993"
product = "CPH2993"
marketname = "OnePlus N6 Lite"
fingerprint = "OnePlus/CPH2993/CPH2993:15/AP3A.241005.015.A1/CPH2993.241005.001:user/release-keys"

[templates."oneplus_be2025"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "BE2025"
device = "billie8"
product = "billie8"
name = "billie8"
marketname = "OnePlus Nord N10 Metro 版"
fingerprint = "OnePlus/billie8/billie8:15/AP3A.241005.015.A1/billie8.241005.001:user/release-keys"

[templates."oneplus_be2026"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "BE2026"
device = "billie8"
product = "billie8"
name = "billie8"
marketname = "OnePlus Nord N10"
fingerprint = "OnePlus/billie8/billie8:15/AP3A.241005.015.A1/billie8.241005.001:user/release-keys"

[templates."oneplus_be2028"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "BE2028"
device = "billie8t"
product = "billie8t"
name = "billie8t"
marketname = "OnePlus Nord N10 T-Mobile 版"
fingerprint = "OnePlus/billie8t/billie8t:15/AP3A.241005.015.A1/billie8t.241005.001:user/release-keys"

[templates."oneplus_be2011"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "BE2011"
device = "bengal"
product = "bengal"
name = "bengal"
marketname = "OnePlus Nord N100"
fingerprint = "OnePlus/bengal/bengal:15/AP3A.241005.015.A1/bengal.241005.001:user/release-keys"

[templates."oneplus_be2012"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "BE2012"
device = "bengal"
product = "bengal"
name = "bengal"
marketname = "OnePlus Nord N100 T-Mobile 版"
fingerprint = "OnePlus/bengal/bengal:15/AP3A.241005.015.A1/bengal.241005.001:user/release-keys"

[templates."oneplus_be2015"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "BE2015"
device = "bengal"
product = "bengal"
name = "bengal"
marketname = "OnePlus Nord N100 Metro 版"
fingerprint = "OnePlus/bengal/bengal:15/AP3A.241005.015.A1/bengal.241005.001:user/release-keys"

[templates."oneplus_gn2200"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "GN2200"
device = "gunnar"
product = "gunnar"
name = "gunnar"
marketname = "OnePlus Nord N20 北美运营商版"
fingerprint = "OnePlus/gunnar/gunnar:15/AP3A.241005.015.A1/gunnar.241005.001:user/release-keys"

[templates."oneplus_cph2459"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2459"
device = "gunnar"
product = "gunnar"
name = "gunnar"
marketname = "OnePlus Nord N20 北美无锁版"
fingerprint = "OnePlus/gunnar/gunnar:15/AP3A.241005.015.A1/gunnar.241005.001:user/release-keys"

[templates."oneplus_cph2469"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2469"
device = "zhaoyun-o"
product = "zhaoyun-o"
name = "zhaoyun-o"
marketname = "OnePlus Nord N20 SE"
fingerprint = "OnePlus/zhaoyun-o/zhaoyun-o:15/AP3A.241005.015.A1/zhaoyun-o.241005.001:user/release-keys"

[templates."oneplus_cph2605"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2605"
device = "fanli-o"
product = "fanli-o"
name = "fanli-o"
marketname = "OnePlus Nord N30 SE"
fingerprint = "OnePlus/fanli-o/fanli-o:15/AP3A.241005.015.A1/fanli-o.241005.001:user/release-keys"

[templates."oneplus_de2117"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "DE2117"
device = "dre9"
product = "dre9"
name = "dre9"
marketname = "OnePlus Nord N200"
fingerprint = "OnePlus/dre9/dre9:15/AP3A.241005.015.A1/dre9.241005.001:user/release-keys"

[templates."oneplus_de2118"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "DE2118"
device = "dre8t"
product = "dre8t"
name = "dre8t"
marketname = "OnePlus Nord N200 T-Mobile 版"
fingerprint = "OnePlus/dre8t/dre8t:15/AP3A.241005.015.A1/dre8t.241005.001:user/release-keys"

[templates."oneplus_cph2389"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2389"
device = "hilda"
product = "hilda"
name = "hilda"
marketname = "OnePlus Nord N300"
fingerprint = "OnePlus/hilda/hilda:15/AP3A.241005.015.A1/hilda.241005.001:user/release-keys"

[templates."oneplus_cph2551"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "CPH2551"
device = "hedwig"
product = "hedwig"
name = "hedwig"
marketname = "OnePlus Open"
fingerprint = "OnePlus/hedwig/hedwig:15/AP3A.241005.015.A1/hedwig.241005.001:user/release-keys"

[templates."oneplus_opd2203"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OPD2203"
device = "aries-o"
product = "aries-o"
name = "aries-o"
marketname = "OnePlus 平板"
fingerprint = "OnePlus/aries-o/aries-o:15/AP3A.241005.015.A1/aries-o.241005.001:user/release-keys"

[templates."oneplus_opd2304"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OPD2304"
device = "bluey-o"
product = "bluey-o"
name = "bluey-o"
marketname = "OnePlus 平板 Go"
fingerprint = "OnePlus/bluey-o/bluey-o:15/AP3A.241005.015.A1/bluey-o.241005.001:user/release-keys"

[templates."oneplus_opd2404"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OPD2404"
device = "rainbow"
product = "rainbow"
name = "rainbow"
marketname = "OnePlus 平板 Pro"
fingerprint = "OnePlus/rainbow/rainbow:15/AP3A.241005.015.A1/rainbow.241005.001:user/release-keys"

[templates."oneplus_opd2403"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OPD2403"
device = "rainbow"
product = "rainbow"
name = "rainbow"
marketname = "OnePlus 平板 2"
fingerprint = "OnePlus/rainbow/rainbow:15/AP3A.241005.015.A1/rainbow.241005.001:user/release-keys"

[templates."oneplus_opd2413"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OPD2413"
device = "erhai-o"
product = "erhai-o"
name = "erhai-o"
marketname = "OnePlus 平板 2 Pro"
fingerprint = "OnePlus/erhai-o/erhai-o:15/AP3A.241005.015.A1/erhai-o.241005.001:user/release-keys"

[templates."oneplus_opd2415"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OPD2415"
device = "erhai-o"
product = "erhai-o"
name = "erhai-o"
marketname = "OnePlus 平板 3"
fingerprint = "OnePlus/erhai-o/erhai-o:15/AP3A.241005.015.A1/erhai-o.241005.001:user/release-keys"

[templates."oneplus_opd2480"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OPD2480"
device = "fiji-o"
product = "fiji-o"
name = "fiji-o"
marketname = "OnePlus 平板 Lite"
fingerprint = "OnePlus/fiji-o/fiji-o:15/AP3A.241005.015.A1/fiji-o.241005.001:user/release-keys"

[templates."oneplus_opd2504"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OPD2504"
device = "greenland-o"
product = "greenland-o"
name = "greenland-o"
marketname = "OnePlus 平板 Go 2"
fingerprint = "OnePlus/greenland-o/greenland-o:15/AP3A.241005.015.A1/greenland-o.241005.001:user/release-keys"

[templates."oneplus_opd2505"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OPD2505"
device = "greenland-o"
product = "greenland-o"
name = "greenland-o"
marketname = "OnePlus 平板 Go 2 5G"
fingerprint = "OnePlus/greenland-o/greenland-o:15/AP3A.241005.015.A1/greenland-o.241005.001:user/release-keys"

[templates."oneplus_opd2513"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OPD2513"
device = "iceland-o"
product = "iceland-o"
name = "iceland-o"
marketname = "OnePlus 平板 3 Pro"
fingerprint = "OnePlus/iceland-o/iceland-o:15/AP3A.241005.015.A1/iceland-o.241005.001:user/release-keys"

[templates."oneplus_opd2514"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OPD2514"
device = "iceland-o"
product = "iceland-o"
name = "iceland-o"
marketname = "OnePlus 平板 4"
fingerprint = "OnePlus/iceland-o/iceland-o:15/AP3A.241005.015.A1/iceland-o.241005.001:user/release-keys"

[templates."oppo_pafm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PAFM00"
device = "PAFM00"
product = "PAFM00"
marketname = "OPPO Find X"
fingerprint = "OPPO/PAFM00/PAFM00:15/AP3A.241005.015.A1/PAFM00.241005.001:user/release-keys"

[templates."oppo_pahm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PAHM00"
device = "PAHM00"
product = "PAHM00"
marketname = "OPPO Find X 超级闪充版/兰博基尼版"
fingerprint = "OPPO/PAHM00/PAHM00:15/AP3A.241005.015.A1/PAHM00.241005.001:user/release-keys"

[templates."oppo_paft10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PAFT10"
device = "PAFT10"
product = "PAFT10"
marketname = "OPPO Find X 超级闪充版"
fingerprint = "OPPO/PAFT10/PAFT10:15/AP3A.241005.015.A1/PAFT10.241005.001:user/release-keys"

[templates."oppo_pdem10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PDEM10"
device = "PDEM10"
product = "PDEM10"
marketname = "OPPO Find X2"
fingerprint = "OPPO/PDEM10/PDEM10:15/AP3A.241005.015.A1/PDEM10.241005.001:user/release-keys"

[templates."oppo_pdem30"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PDEM30"
device = "PDEM30"
product = "PDEM30"
marketname = "OPPO Find X2 Pro"
fingerprint = "OPPO/PDEM30/PDEM30:15/AP3A.241005.015.A1/PDEM30.241005.001:user/release-keys"

[templates."oppo_pedm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PEDM00"
device = "horee"
product = "horee"
name = "horee"
marketname = "OPPO Find X3"
fingerprint = "OPPO/horee/horee:15/AP3A.241005.015.A1/horee.241005.001:user/release-keys"

[templates."oppo_peem00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PEEM00"
device = "fluorite"
product = "fluorite"
name = "fluorite"
marketname = "OPPO Find X3 Pro"
fingerprint = "OPPO/fluorite/fluorite:15/AP3A.241005.015.A1/fluorite.241005.001:user/release-keys"

[templates."oppo_pffm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PFFM10"
device = "luwu"
product = "luwu"
name = "luwu"
marketname = "OPPO Find X5"
fingerprint = "OPPO/luwu/luwu:15/AP3A.241005.015.A1/luwu.241005.001:user/release-keys"

[templates."oppo_pfem10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PFEM10"
device = "baize"
product = "baize"
name = "baize"
marketname = "OPPO Find X5 Pro"
fingerprint = "OPPO/baize/baize:15/AP3A.241005.015.A1/baize.241005.001:user/release-keys"

[templates."oppo_pffm20"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PFFM20"
device = "diting"
product = "diting"
name = "diting"
marketname = "OPPO Find X5 Pro 天玑版"
fingerprint = "OPPO/diting/diting:15/AP3A.241005.015.A1/diting.241005.001:user/release-keys"

[templates."oppo_pgfm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PGFM10"
device = "luna"
product = "luna"
name = "luna"
marketname = "OPPO Find X6"
fingerprint = "OPPO/luna/luna:15/AP3A.241005.015.A1/luna.241005.001:user/release-keys"

[templates."oppo_pgem10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PGEM10"
device = "wukong"
product = "wukong"
name = "wukong"
marketname = "OPPO Find X6 Pro"
fingerprint = "OPPO/wukong/wukong:15/AP3A.241005.015.A1/wukong.241005.001:user/release-keys"

[templates."oppo_phz110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PHZ110"
device = "nvwa-v"
product = "nvwa-v"
name = "nvwa-v"
marketname = "OPPO Find X7"
fingerprint = "OPPO/nvwa-v/nvwa-v:15/AP3A.241005.015.A1/nvwa-v.241005.001:user/release-keys"

[templates."oppo_phy110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PHY110"
device = "pangu"
product = "pangu"
name = "pangu"
marketname = "OPPO Find X7 Ultra"
fingerprint = "OPPO/pangu/pangu:15/AP3A.241005.015.A1/pangu.241005.001:user/release-keys"

[templates."oppo_phy120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PHY120"
device = "pangu"
product = "pangu"
name = "pangu"
marketname = "OPPO Find X7 Ultra 卫星通信版"
fingerprint = "OPPO/pangu/pangu:15/AP3A.241005.015.A1/pangu.241005.001:user/release-keys"

[templates."oppo_pkb110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKB110"
device = "yala"
product = "yala"
name = "yala"
marketname = "OPPO Find X8"
fingerprint = "OPPO/yala/yala:15/AP3A.241005.015.A1/yala.241005.001:user/release-keys"

[templates."oppo_pkc110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKC110"
device = "konka"
product = "konka"
name = "konka"
marketname = "OPPO Find X8 Pro"
fingerprint = "OPPO/konka/konka:15/AP3A.241005.015.A1/konka.241005.001:user/release-keys"

[templates."oppo_pkc130"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKC130"
device = "konka"
product = "konka"
name = "konka"
marketname = "OPPO Find X8 Pro 卫星通信版"
fingerprint = "OPPO/konka/konka:15/AP3A.241005.015.A1/konka.241005.001:user/release-keys"

[templates."oppo_pkt110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKT110"
device = "koktokay"
product = "koktokay"
name = "koktokay"
marketname = "OPPO Find X8s"
fingerprint = "OPPO/koktokay/koktokay:15/AP3A.241005.015.A1/koktokay.241005.001:user/release-keys"

[templates."oppo_plb110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLB110"
device = "slmh"
product = "slmh"
name = "slmh"
marketname = "OPPO Find X8s+"
fingerprint = "OPPO/slmh/slmh:15/AP3A.241005.015.A1/slmh.241005.001:user/release-keys"

[templates."oppo_pkj110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKJ110"
device = "zhufeng"
product = "zhufeng"
name = "zhufeng"
marketname = "OPPO Find X8 Ultra"
fingerprint = "OPPO/zhufeng/zhufeng:15/AP3A.241005.015.A1/zhufeng.241005.001:user/release-keys"

[templates."oppo_pku110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKU110"
device = "zhufeng"
product = "zhufeng"
name = "zhufeng"
marketname = "OPPO Find X8 Ultra 卫星通信版"
fingerprint = "OPPO/zhufeng/zhufeng:15/AP3A.241005.015.A1/zhufeng.241005.001:user/release-keys"

[templates."oppo_plj110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLJ110"
device = "zhujiang"
product = "zhujiang"
name = "zhujiang"
marketname = "OPPO Find X9"
fingerprint = "OPPO/zhujiang/zhujiang:15/AP3A.241005.015.A1/zhujiang.241005.001:user/release-keys"

[templates."oppo_plg110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLG110"
device = "changjiang"
product = "changjiang"
name = "changjiang"
marketname = "OPPO Find X9 Pro"
fingerprint = "OPPO/changjiang/changjiang:15/AP3A.241005.015.A1/changjiang.241005.001:user/release-keys"

[templates."oppo_plg120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLG120"
device = "changjiang"
product = "changjiang"
name = "changjiang"
marketname = "OPPO Find X9 Pro 卫星通信版"
fingerprint = "OPPO/changjiang/changjiang:15/AP3A.241005.015.A1/changjiang.241005.001:user/release-keys"

[templates."oppo_pme110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PME110"
device = "venus"
product = "venus"
name = "venus"
marketname = "OPPO Find X9s Pro"
fingerprint = "OPPO/venus/venus:15/AP3A.241005.015.A1/venus.241005.001:user/release-keys"

[templates."oppo_pma110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PMA110"
device = "lighthouse"
product = "lighthouse"
name = "lighthouse"
marketname = "OPPO Find X9 Ultra"
fingerprint = "OPPO/lighthouse/lighthouse:15/AP3A.241005.015.A1/lighthouse.241005.001:user/release-keys"

[templates."oppo_pma120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PMA120"
device = "lighthouse"
product = "lighthouse"
name = "lighthouse"
marketname = "OPPO Find X9 Ultra 卫星通信版"
fingerprint = "OPPO/lighthouse/lighthouse:15/AP3A.241005.015.A1/lighthouse.241005.001:user/release-keys"

[templates."oppo_pmw110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PMW110"
device = "uranus"
product = "uranus"
name = "uranus"
marketname = "OPPO Find X10"
fingerprint = "OPPO/uranus/uranus:15/AP3A.241005.015.A1/uranus.241005.001:user/release-keys"

[templates."oppo_pna110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PNA110"
device = "neptune"
product = "neptune"
name = "neptune"
marketname = "OPPO Find X10 E"
fingerprint = "OPPO/neptune/neptune:15/AP3A.241005.015.A1/neptune.241005.001:user/release-keys"

[templates."oppo_pmx110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PMX110"
device = "mars"
product = "mars"
name = "mars"
marketname = "OPPO Find X10 Pro Max"
fingerprint = "OPPO/mars/mars:15/AP3A.241005.015.A1/mars.241005.001:user/release-keys"

[templates."oppo_peum00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PEUM00"
device = "peacock"
product = "peacock"
name = "peacock"
marketname = "OPPO Find N"
fingerprint = "OPPO/peacock/peacock:15/AP3A.241005.015.A1/peacock.241005.001:user/release-keys"

[templates."oppo_pgu110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PGU110"
device = "whiteswan"
product = "whiteswan"
name = "whiteswan"
marketname = "OPPO Find N2"
fingerprint = "OPPO/whiteswan/whiteswan:15/AP3A.241005.015.A1/whiteswan.241005.001:user/release-keys"

[templates."oppo_pgt110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PGT110"
device = "dragonfly"
product = "dragonfly"
name = "dragonfly"
marketname = "OPPO Find N2 Flip"
fingerprint = "OPPO/dragonfly/dragonfly:15/AP3A.241005.015.A1/dragonfly.241005.001:user/release-keys"

[templates."oppo_phn110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PHN110"
device = "xueying"
product = "xueying"
name = "xueying"
marketname = "OPPO Find N3"
fingerprint = "OPPO/xueying/xueying:15/AP3A.241005.015.A1/xueying.241005.001:user/release-keys"

[templates."oppo_pht110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PHT110"
device = "flamingo"
product = "flamingo"
name = "flamingo"
marketname = "OPPO Find N3 Flip"
fingerprint = "OPPO/flamingo/flamingo:15/AP3A.241005.015.A1/flamingo.241005.001:user/release-keys"

[templates."oppo_pkh110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKH110"
device = "petrel"
product = "petrel"
name = "petrel"
marketname = "OPPO Find N5"
fingerprint = "OPPO/petrel/petrel:15/AP3A.241005.015.A1/petrel.241005.001:user/release-keys"

[templates."oppo_pkh120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKH120"
device = "petrel"
product = "petrel"
name = "petrel"
marketname = "OPPO Find N5 卫星通信版"
fingerprint = "OPPO/petrel/petrel:15/AP3A.241005.015.A1/petrel.241005.001:user/release-keys"

[templates."oppo_plp110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLP110"
device = "swangoose"
product = "swangoose"
name = "swangoose"
marketname = "OPPO Find N6"
fingerprint = "OPPO/swangoose/swangoose:15/AP3A.241005.015.A1/swangoose.241005.001:user/release-keys"

[templates."oppo_plp120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLP120"
device = "swangoose"
product = "swangoose"
name = "swangoose"
marketname = "OPPO Find N6 卫星通信版"
fingerprint = "OPPO/swangoose/swangoose:15/AP3A.241005.015.A1/swangoose.241005.001:user/release-keys"

[templates."oppo_pcam00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCAM00"
device = "PCAM00"
product = "PCAM00"
marketname = "OPPO Reno"
fingerprint = "OPPO/PCAM00/PCAM00:15/AP3A.241005.015.A1/PCAM00.241005.001:user/release-keys"

[templates."oppo_pccm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCCM00"
device = "PCCM00"
product = "PCCM00"
marketname = "OPPO Reno 10 倍变焦版"
fingerprint = "OPPO/PCCM00/PCCM00:15/AP3A.241005.015.A1/PCCM00.241005.001:user/release-keys"

[templates."oppo_pcdm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCDM10"
device = "PCDM10"
product = "PCDM10"
marketname = "OPPO Reno Z"
fingerprint = "OPPO/PCDM10/PCDM10:15/AP3A.241005.015.A1/PCDM10.241005.001:user/release-keys"

[templates."oppo_pckm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCKM00"
device = "PCKM00"
product = "PCKM00"
marketname = "OPPO Reno2"
fingerprint = "OPPO/PCKM00/PCKM00:15/AP3A.241005.015.A1/PCKM00.241005.001:user/release-keys"

[templates."oppo_pckm80"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCKM80"
device = "PCKM80"
product = "PCKM80"
marketname = "OPPO Reno2 Z"
fingerprint = "OPPO/PCKM80/PCKM80:15/AP3A.241005.015.A1/PCKM80.241005.001:user/release-keys"

[templates."oppo_pdcm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PDCM00"
device = "PDCM00"
product = "PDCM00"
marketname = "OPPO Reno3"
fingerprint = "OPPO/PDCM00/PDCM00:15/AP3A.241005.015.A1/PDCM00.241005.001:user/release-keys"

[templates."oppo_pcrm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCRM00"
device = "PCRM00"
product = "PCRM00"
marketname = "OPPO Reno3 Pro"
fingerprint = "OPPO/PCRM00/PCRM00:15/AP3A.241005.015.A1/PCRM00.241005.001:user/release-keys"

[templates."oppo_pclm50"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCLM50"
device = "PCLM50"
product = "PCLM50"
marketname = "OPPO Reno3 元气版"
fingerprint = "OPPO/PCLM50/PCLM50:15/AP3A.241005.015.A1/PCLM50.241005.001:user/release-keys"

[templates."oppo_pdpm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PDPM00"
device = "PDPM00"
product = "PDPM00"
marketname = "OPPO Reno4"
fingerprint = "OPPO/PDPM00/PDPM00:15/AP3A.241005.015.A1/PDPM00.241005.001:user/release-keys"

[templates."oppo_pdnm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PDNM00"
device = "PDNM00"
product = "PDNM00"
marketname = "OPPO Reno4 Pro"
fingerprint = "OPPO/PDNM00/PDNM00:15/AP3A.241005.015.A1/PDNM00.241005.001:user/release-keys"

[templates."oppo_peam00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PEAM00"
device = "PEAM00"
product = "PEAM00"
marketname = "OPPO Reno4 SE"
fingerprint = "OPPO/PEAM00/PEAM00:15/AP3A.241005.015.A1/PEAM00.241005.001:user/release-keys"

[templates."oppo_pegm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PEGM00"
device = "kunlun"
product = "kunlun"
name = "kunlun"
marketname = "OPPO Reno5"
fingerprint = "OPPO/kunlun/kunlun:15/AP3A.241005.015.A1/kunlun.241005.001:user/release-keys"

[templates."oppo_pegm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PEGM10"
device = "wudang"
product = "wudang"
name = "wudang"
marketname = "OPPO Reno5 K"
fingerprint = "OPPO/wudang/wudang:15/AP3A.241005.015.A1/wudang.241005.001:user/release-keys"

[templates."oppo_pdsm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PDSM00"
device = "chaka"
product = "chaka"
name = "chaka"
marketname = "OPPO Reno5 Pro"
fingerprint = "OPPO/chaka/chaka:15/AP3A.241005.015.A1/chaka.241005.001:user/release-keys"

[templates."oppo_pdrm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PDRM00"
device = "hima"
product = "hima"
name = "hima"
marketname = "OPPO Reno5 Pro+"
fingerprint = "OPPO/hima/hima:15/AP3A.241005.015.A1/hima.241005.001:user/release-keys"

[templates."oppo_peqm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PEQM00"
device = "garen"
product = "garen"
name = "garen"
marketname = "OPPO Reno6"
fingerprint = "OPPO/garen/garen:15/AP3A.241005.015.A1/garen.241005.001:user/release-keys"

[templates."oppo_pepm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PEPM00"
device = "yasuo"
product = "yasuo"
name = "yasuo"
marketname = "OPPO Reno6 Pro"
fingerprint = "OPPO/yasuo/yasuo:15/AP3A.241005.015.A1/yasuo.241005.001:user/release-keys"

[templates."oppo_penm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PENM00"
device = "jin"
product = "jin"
name = "jin"
marketname = "OPPO Reno6 Pro+"
fingerprint = "OPPO/jin/jin:15/AP3A.241005.015.A1/jin.241005.001:user/release-keys"

[templates."oppo_pfjm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PFJM10"
device = "libai"
product = "libai"
name = "libai"
marketname = "OPPO Reno7"
fingerprint = "OPPO/libai/libai:15/AP3A.241005.015.A1/libai.241005.001:user/release-keys"

[templates."oppo_pfdm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PFDM00"
device = "mozi"
product = "mozi"
name = "mozi"
marketname = "OPPO Reno7 Pro"
fingerprint = "OPPO/mozi/mozi:15/AP3A.241005.015.A1/mozi.241005.001:user/release-keys"

[templates."oppo_pfcm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PFCM00"
device = "dufu"
product = "dufu"
name = "dufu"
marketname = "OPPO Reno7 SE"
fingerprint = "OPPO/dufu/dufu:15/AP3A.241005.015.A1/dufu.241005.001:user/release-keys"

[templates."oppo_pgbm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PGBM10"
device = "ali"
product = "ali"
name = "ali"
marketname = "OPPO Reno8"
fingerprint = "OPPO/ali/ali:15/AP3A.241005.015.A1/ali.241005.001:user/release-keys"

[templates."oppo_pgam10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PGAM10"
device = "wuyi"
product = "wuyi"
name = "wuyi"
marketname = "OPPO Reno8 Pro"
fingerprint = "OPPO/wuyi/wuyi:15/AP3A.241005.015.A1/wuyi.241005.001:user/release-keys"

[templates."oppo_pfzm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PFZM10"
device = "taibai"
product = "taibai"
name = "taibai"
marketname = "OPPO Reno8 Pro+"
fingerprint = "OPPO/taibai/taibai:15/AP3A.241005.015.A1/taibai.241005.001:user/release-keys"

[templates."oppo_phm110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PHM110"
device = "lantian"
product = "lantian"
name = "lantian"
marketname = "OPPO Reno9"
fingerprint = "OPPO/lantian/lantian:15/AP3A.241005.015.A1/lantian.241005.001:user/release-keys"

[templates."oppo_pgx110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PGX110"
device = "linhai"
product = "linhai"
name = "linhai"
marketname = "OPPO Reno9 Pro"
fingerprint = "OPPO/linhai/linhai:15/AP3A.241005.015.A1/linhai.241005.001:user/release-keys"

[templates."oppo_pgw110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PGW110"
device = "lvzhou"
product = "lvzhou"
name = "lvzhou"
marketname = "OPPO Reno9 Pro+"
fingerprint = "OPPO/lvzhou/lvzhou:15/AP3A.241005.015.A1/lvzhou.241005.001:user/release-keys"

[templates."oppo_phw110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PHW110"
device = "taylor"
product = "taylor"
name = "taylor"
marketname = "OPPO Reno10"
fingerprint = "OPPO/taylor/taylor:15/AP3A.241005.015.A1/taylor.241005.001:user/release-keys"

[templates."oppo_phv110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PHV110"
device = "viven"
product = "viven"
name = "viven"
marketname = "OPPO Reno10 Pro"
fingerprint = "OPPO/viven/viven:15/AP3A.241005.015.A1/viven.241005.001:user/release-keys"

[templates."oppo_phu110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PHU110"
device = "monroe"
product = "monroe"
name = "monroe"
marketname = "OPPO Reno10 Pro+"
fingerprint = "OPPO/monroe/monroe:15/AP3A.241005.015.A1/monroe.241005.001:user/release-keys"

[templates."oppo_pjh110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PJH110"
device = "huahai"
product = "huahai"
name = "huahai"
marketname = "OPPO Reno11"
fingerprint = "OPPO/huahai/huahai:15/AP3A.241005.015.A1/huahai.241005.001:user/release-keys"

[templates."oppo_pjj110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PJJ110"
device = "daoxiang"
product = "daoxiang"
name = "daoxiang"
marketname = "OPPO Reno11 Pro"
fingerprint = "OPPO/daoxiang/daoxiang:15/AP3A.241005.015.A1/daoxiang.241005.001:user/release-keys"

[templates."oppo_pjv110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PJV110"
device = "omega"
product = "omega"
name = "omega"
marketname = "OPPO Reno12"
fingerprint = "OPPO/omega/omega:15/AP3A.241005.015.A1/omega.241005.001:user/release-keys"

[templates."oppo_pjw110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PJW110"
device = "omega"
product = "omega"
name = "omega"
marketname = "OPPO Reno12 Pro"
fingerprint = "OPPO/omega/omega:15/AP3A.241005.015.A1/omega.241005.001:user/release-keys"

[templates."oppo_pkm110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKM110"
device = "milkyway"
product = "milkyway"
name = "milkyway"
marketname = "OPPO Reno13"
fingerprint = "OPPO/milkyway/milkyway:15/AP3A.241005.015.A1/milkyway.241005.001:user/release-keys"

[templates."oppo_pkk110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKK110"
device = "milkyway"
product = "milkyway"
name = "milkyway"
marketname = "OPPO Reno13 Pro"
fingerprint = "OPPO/milkyway/milkyway:15/AP3A.241005.015.A1/milkyway.241005.001:user/release-keys"

[templates."oppo_pla110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLA110"
device = "zhuque"
product = "zhuque"
name = "zhuque"
marketname = "OPPO Reno14"
fingerprint = "OPPO/zhuque/zhuque:15/AP3A.241005.015.A1/zhuque.241005.001:user/release-keys"

[templates."oppo_pkz110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKZ110"
device = "zhuque"
product = "zhuque"
name = "zhuque"
marketname = "OPPO Reno14 Pro"
fingerprint = "OPPO/zhuque/zhuque:15/AP3A.241005.015.A1/zhuque.241005.001:user/release-keys"

[templates."oppo_plw110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLW110"
device = "whoopass-c2"
product = "whoopass-c2"
name = "whoopass-c2"
marketname = "OPPO Reno15"
fingerprint = "OPPO/whoopass-c2/whoopass-c2:15/AP3A.241005.015.A1/whoopass-c2.241005.001:user/release-keys"

[templates."oppo_plv110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLV110"
device = "whoopass-c1"
product = "whoopass-c1"
name = "whoopass-c1"
marketname = "OPPO Reno15 Pro"
fingerprint = "OPPO/whoopass-c1/whoopass-c1:15/AP3A.241005.015.A1/whoopass-c1.241005.001:user/release-keys"

[templates."oppo_pmd110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PMD110"
device = "whoopass-c3"
product = "whoopass-c3"
name = "whoopass-c3"
marketname = "OPPO Reno15c"
fingerprint = "OPPO/whoopass-c3/whoopass-c3:15/AP3A.241005.015.A1/whoopass-c3.241005.001:user/release-keys"

[templates."oppo_pmm110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PMM110"
device = "lychee-c2"
product = "lychee-c2"
name = "lychee-c2"
marketname = "OPPO Reno16"
fingerprint = "OPPO/lychee-c2/lychee-c2:15/AP3A.241005.015.A1/lychee-c2.241005.001:user/release-keys"

[templates."oppo_pmk110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PMK110"
device = "lychee-c1"
product = "lychee-c1"
name = "lychee-c1"
marketname = "OPPO Reno16 Pro"
fingerprint = "OPPO/lychee-c1/lychee-c1:15/AP3A.241005.015.A1/lychee-c1.241005.001:user/release-keys"

[templates."oppo_pyk110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PYK110"
device = "PYK110"
product = "PYK110"
marketname = "OPPO Reno17"
fingerprint = "OPPO/PYK110/PYK110:15/AP3A.241005.015.A1/PYK110.241005.001:user/release-keys"

[templates."oppo_pnd110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PND110"
device = "PND110"
product = "PND110"
marketname = "OPPO Reno17 Pro"
fingerprint = "OPPO/PND110/PND110:15/AP3A.241005.015.A1/PND110.241005.001:user/release-keys"

[templates."oppo_pclm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCLM10"
device = "PCLM10"
product = "PCLM10"
marketname = "OPPO Reno Ace"
fingerprint = "OPPO/PCLM10/PCLM10:15/AP3A.241005.015.A1/PCLM10.241005.001:user/release-keys"

[templates."oppo_pdhm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PDHM00"
device = "PDHM00"
product = "PDHM00"
marketname = "OPPO Ace2"
fingerprint = "OPPO/PDHM00/PDHM00:15/AP3A.241005.015.A1/PDHM00.241005.001:user/release-keys"

[templates."oppo_pacm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PACM00"
device = "PACM00"
product = "PACM00"
marketname = "OPPO R15"
fingerprint = "OPPO/PACM00/PACM00:15/AP3A.241005.015.A1/PACM00.241005.001:user/release-keys"

[templates."oppo_paam00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PAAM00"
device = "PAAM00"
product = "PAAM00"
marketname = "OPPO R15 梦镜版"
fingerprint = "OPPO/PAAM00/PAAM00:15/AP3A.241005.015.A1/PAAM00.241005.001:user/release-keys"

[templates."oppo_pbcm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PBCM10"
device = "PBCM10"
product = "PBCM10"
marketname = "OPPO R15x"
fingerprint = "OPPO/PBCM10/PBCM10:15/AP3A.241005.015.A1/PBCM10.241005.001:user/release-keys"

[templates."oppo_pbem00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PBEM00"
device = "PBEM00"
product = "PBEM00"
marketname = "OPPO R17"
fingerprint = "OPPO/PBEM00/PBEM00:15/AP3A.241005.015.A1/PBEM00.241005.001:user/release-keys"

[templates."oppo_pbdm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PBDM00"
device = "PBDM00"
product = "PBDM00"
marketname = "OPPO R17 Pro"
fingerprint = "OPPO/PBDM00/PBDM00:15/AP3A.241005.015.A1/PBDM00.241005.001:user/release-keys"

[templates."oppo_padm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PADM00"
device = "PADM00"
product = "PADM00"
marketname = "OPPO A3"
fingerprint = "OPPO/PADM00/PADM00:15/AP3A.241005.015.A1/PADM00.241005.001:user/release-keys"

[templates."oppo_pbam00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PBAM00"
device = "PBAM00"
product = "PBAM00"
marketname = "OPPO A5"
fingerprint = "OPPO/PBAM00/PBAM00:15/AP3A.241005.015.A1/PBAM00.241005.001:user/release-keys"

[templates."oppo_pbfm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PBFM00"
device = "PBFM00"
product = "PBFM00"
marketname = "OPPO A7"
fingerprint = "OPPO/PBFM00/PBFM00:15/AP3A.241005.015.A1/PBFM00.241005.001:user/release-keys"

[templates."oppo_pbbm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PBBM00"
device = "PBBM00"
product = "PBBM00"
marketname = "OPPO A7x"
fingerprint = "OPPO/PBBM00/PBBM00:15/AP3A.241005.015.A1/PBBM00.241005.001:user/release-keys"

[templates."oppo_pcdm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCDM00"
device = "PCDM00"
product = "PCDM00"
marketname = "OPPO A7n"
fingerprint = "OPPO/PCDM00/PCDM00:15/AP3A.241005.015.A1/PCDM00.241005.001:user/release-keys"

[templates."oppo_pdbm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PDBM00"
device = "PDBM00"
product = "PDBM00"
marketname = "OPPO A8"
fingerprint = "OPPO/PDBM00/PDBM00:15/AP3A.241005.015.A1/PDBM00.241005.001:user/release-keys"

[templates."oppo_pcam10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCAM10"
device = "PCAM10"
product = "PCAM10"
marketname = "OPPO A9"
fingerprint = "OPPO/PCAM10/PCAM10:15/AP3A.241005.015.A1/PCAM10.241005.001:user/release-keys"

[templates."oppo_pcem00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCEM00"
device = "PCEM00"
product = "PCEM00"
marketname = "OPPO A9x"
fingerprint = "OPPO/PCEM00/PCEM00:15/AP3A.241005.015.A1/PCEM00.241005.001:user/release-keys"

[templates."oppo_pchm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCHM10"
device = "PCHM10"
product = "PCHM10"
marketname = "OPPO A11"
fingerprint = "OPPO/PCHM10/PCHM10:15/AP3A.241005.015.A1/PCHM10.241005.001:user/release-keys"

[templates."oppo_pchm30"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCHM30"
device = "PCHM30"
product = "PCHM30"
marketname = "OPPO A11x"
fingerprint = "OPPO/PCHM30/PCHM30:15/AP3A.241005.015.A1/PCHM30.241005.001:user/release-keys"

[templates."oppo_pchm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCHM00"
device = "PCHM00"
product = "PCHM00"
marketname = "OPPO A11n"
fingerprint = "OPPO/PCHM00/PCHM00:15/AP3A.241005.015.A1/PCHM00.241005.001:user/release-keys"

[templates."oppo_pdvm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PDVM00"
device = "PDVM00"
product = "PDVM00"
marketname = "OPPO A11s"
fingerprint = "OPPO/PDVM00/PDVM00:15/AP3A.241005.015.A1/PDVM00.241005.001:user/release-keys"

[templates."oppo_pefm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PEFM00"
device = "PEFM00"
product = "PEFM00"
marketname = "OPPO A35"
fingerprint = "OPPO/PEFM00/PEFM00:15/AP3A.241005.015.A1/PEFM00.241005.001:user/release-keys"

[templates."oppo_pesm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PESM10"
device = "PESM10"
product = "PESM10"
marketname = "OPPO A36"
fingerprint = "OPPO/PESM10/PESM10:15/AP3A.241005.015.A1/PESM10.241005.001:user/release-keys"

[templates."oppo_pdam10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PDAM10"
device = "PDAM10"
product = "PDAM10"
marketname = "OPPO A52"
fingerprint = "OPPO/PDAM10/PDAM10:15/AP3A.241005.015.A1/PDAM10.241005.001:user/release-keys"

[templates."oppo_pecm20"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PECM20"
device = "PECM20"
product = "PECM20"
marketname = "OPPO A53"
fingerprint = "OPPO/PECM20/PECM20:15/AP3A.241005.015.A1/PECM20.241005.001:user/release-keys"

[templates."oppo_pemm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PEMM00"
device = "PEMM00"
product = "PEMM00"
marketname = "OPPO A55"
fingerprint = "OPPO/PEMM00/PEMM00:15/AP3A.241005.015.A1/PEMM00.241005.001:user/release-keys"

[templates."oppo_pfvm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PFVM10"
device = "PFVM10"
product = "PFVM10"
marketname = "OPPO A56"
fingerprint = "OPPO/PFVM10/PFVM10:15/AP3A.241005.015.A1/PFVM10.241005.001:user/release-keys"

[templates."oppo_pftm20"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PFTM20"
device = "PFTM20"
product = "PFTM20"
marketname = "OPPO A56s"
fingerprint = "OPPO/PFTM20/PFTM20:15/AP3A.241005.015.A1/PFTM20.241005.001:user/release-keys"

[templates."oppo_phj110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PHJ110"
device = "lijing"
product = "lijing"
name = "lijing"
marketname = "OPPO A58"
fingerprint = "OPPO/lijing/lijing:15/AP3A.241005.015.A1/lijing.241005.001:user/release-keys"

[templates."oppo_pdym20"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PDYM20"
device = "PDYM20"
product = "PDYM20"
marketname = "OPPO A72"
fingerprint = "OPPO/PDYM20/PDYM20:15/AP3A.241005.015.A1/PDYM20.241005.001:user/release-keys"

[templates."oppo_pdym10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PDYM10"
device = "PDYM10"
product = "PDYM10"
marketname = "OPPO A72n"
fingerprint = "OPPO/PDYM10/PDYM10:15/AP3A.241005.015.A1/PDYM10.241005.001:user/release-keys"

[templates."oppo_pcpm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCPM00"
device = "PCPM00"
product = "PCPM00"
marketname = "OPPO A91"
fingerprint = "OPPO/PCPM00/PCPM00:15/AP3A.241005.015.A1/PCPM00.241005.001:user/release-keys"

[templates."oppo_pdkm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PDKM00"
device = "PDKM00"
product = "PDKM00"
marketname = "OPPO A92s"
fingerprint = "OPPO/PDKM00/PDKM00:15/AP3A.241005.015.A1/PDKM00.241005.001:user/release-keys"

[templates."oppo_pehm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PEHM00"
device = "PEHM00"
product = "PEHM00"
marketname = "OPPO A93"
fingerprint = "OPPO/PEHM00/PEHM00:15/AP3A.241005.015.A1/PEHM00.241005.001:user/release-keys"

[templates."oppo_pfgm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PFGM00"
device = "odin-a"
product = "odin-a"
name = "odin-a"
marketname = "OPPO A93s"
fingerprint = "OPPO/odin-a/odin-a:15/AP3A.241005.015.A1/odin-a.241005.001:user/release-keys"

[templates."oppo_pelm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PELM00"
device = "PELM00"
product = "PELM00"
marketname = "OPPO A95"
fingerprint = "OPPO/PELM00/PELM00:15/AP3A.241005.015.A1/PELM00.241005.001:user/release-keys"

[templates."oppo_pfum10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PFUM10"
device = "mulan"
product = "mulan"
name = "mulan"
marketname = "OPPO A96"
fingerprint = "OPPO/mulan/mulan:15/AP3A.241005.015.A1/mulan.241005.001:user/release-keys"

[templates."oppo_pftm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PFTM10"
device = "alice"
product = "alice"
name = "alice"
marketname = "OPPO A97"
fingerprint = "OPPO/alice/alice:15/AP3A.241005.015.A1/alice.241005.001:user/release-keys"

[templates."oppo_phs110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PHS110"
device = "colombo"
product = "colombo"
name = "colombo"
marketname = "OPPO A1 5G"
fingerprint = "OPPO/colombo/colombo:15/AP3A.241005.015.A1/colombo.241005.001:user/release-keys"

[templates."oppo_phq110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PHQ110"
device = "hepburn"
product = "hepburn"
name = "hepburn"
marketname = "OPPO A1 Pro"
fingerprint = "OPPO/hepburn/hepburn:15/AP3A.241005.015.A1/hepburn.241005.001:user/release-keys"

[templates."oppo_pjb110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PJB110"
device = "fanli"
product = "fanli"
name = "fanli"
marketname = "OPPO A1s"
fingerprint = "OPPO/fanli/fanli:15/AP3A.241005.015.A1/fanli.241005.001:user/release-keys"

[templates."oppo_pju110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PJU110"
device = "lijing-a"
product = "lijing-a"
name = "lijing-a"
marketname = "OPPO A1i"
fingerprint = "OPPO/lijing-a/lijing-a:15/AP3A.241005.015.A1/lijing-a.241005.001:user/release-keys"

[templates."oppo_pjs110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PJS110"
device = "lijing-a"
product = "lijing-a"
name = "lijing-a"
marketname = "OPPO A2x"
fingerprint = "OPPO/lijing-a/lijing-a:15/AP3A.241005.015.A1/lijing-a.241005.001:user/release-keys"

[templates."oppo_pjg110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PJG110"
device = "givenchy"
product = "givenchy"
name = "givenchy"
marketname = "OPPO A2 Pro"
fingerprint = "OPPO/givenchy/givenchy:15/AP3A.241005.015.A1/givenchy.241005.001:user/release-keys"

[templates."oppo_pka110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKA110"
device = "avatar-m"
product = "avatar-m"
name = "avatar-m"
marketname = "OPPO A3 5G"
fingerprint = "OPPO/avatar-m/avatar-m:15/AP3A.241005.015.A1/avatar-m.241005.001:user/release-keys"

[templates."oppo_pkd110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKD110"
device = "avatar-l5"
product = "avatar-l5"
name = "avatar-l5"
marketname = "OPPO A3 活力版"
fingerprint = "OPPO/avatar-l5/avatar-l5:15/AP3A.241005.015.A1/avatar-l5.241005.001:user/release-keys"

[templates."oppo_pkd120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKD120"
device = "PKD120"
product = "PKD120"
marketname = "OPPO A3m"
fingerprint = "OPPO/PKD120/PKD120:15/AP3A.241005.015.A1/PKD120.241005.001:user/release-keys"

[templates."oppo_pkd130"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKD130"
device = "avatar-l5"
product = "avatar-l5"
name = "avatar-l5"
marketname = "OPPO A3x"
fingerprint = "OPPO/avatar-l5/avatar-l5:15/AP3A.241005.015.A1/avatar-l5.241005.001:user/release-keys"

[templates."oppo_pkl110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKL110"
device = "avatar-b5"
product = "avatar-b5"
name = "avatar-b5"
marketname = "OPPO A3i"
fingerprint = "OPPO/avatar-b5/avatar-b5:15/AP3A.241005.015.A1/avatar-b5.241005.001:user/release-keys"

[templates."oppo_pjy110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PJY110"
device = "avatar-h"
product = "avatar-h"
name = "avatar-h"
marketname = "OPPO A3 Pro"
fingerprint = "OPPO/avatar-h/avatar-h:15/AP3A.241005.015.A1/avatar-h.241005.001:user/release-keys"

[templates."oppo_pkq110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKQ110"
device = "alpha-m"
product = "alpha-m"
name = "alpha-m"
marketname = "OPPO A5 5G"
fingerprint = "OPPO/alpha-m/alpha-m:15/AP3A.241005.015.A1/alpha-m.241005.001:user/release-keys"

[templates."oppo_pkv110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKV110"
device = "alpha-l5"
product = "alpha-l5"
name = "alpha-l5"
marketname = "OPPO A5 活力版"
fingerprint = "OPPO/alpha-l5/alpha-l5:15/AP3A.241005.015.A1/alpha-l5.241005.001:user/release-keys"

[templates."oppo_pkw110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKW110"
device = "alpha-b5"
product = "alpha-b5"
name = "alpha-b5"
marketname = "OPPO A5x"
fingerprint = "OPPO/alpha-b5/alpha-b5:15/AP3A.241005.015.A1/alpha-b5.241005.001:user/release-keys"

[templates."oppo_pkp110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKP110"
device = "alpha"
product = "alpha"
name = "alpha"
marketname = "OPPO A5 Pro"
fingerprint = "OPPO/alpha/alpha:15/AP3A.241005.015.A1/alpha.241005.001:user/release-keys"

[templates."oppo_pls120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLS120"
device = "baikal-l5"
product = "baikal-l5"
name = "baikal-l5"
marketname = "OPPO A6"
fingerprint = "OPPO/baikal-l5/baikal-l5:15/AP3A.241005.015.A1/baikal-l5.241005.001:user/release-keys"

[templates."oppo_pll110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLL110"
device = "baikal-h"
product = "baikal-h"
name = "baikal-h"
marketname = "OPPO A6 GT"
fingerprint = "OPPO/baikal-h/baikal-h:15/AP3A.241005.015.A1/baikal-h.241005.001:user/release-keys"

[templates."oppo_pln110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLN110"
device = "baikal-m"
product = "baikal-m"
name = "baikal-m"
marketname = "OPPO A6 Pro"
fingerprint = "OPPO/baikal-m/baikal-m:15/AP3A.241005.015.A1/baikal-m.241005.001:user/release-keys"

[templates."oppo_pkw120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKW120"
device = "alpha-b5"
product = "alpha-b5"
name = "alpha-b5"
marketname = "OPPO A6i"
fingerprint = "OPPO/alpha-b5/alpha-b5:15/AP3A.241005.015.A1/alpha-b5.241005.001:user/release-keys"

[templates."oppo_plt120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLT120"
device = "baikal-b5"
product = "baikal-b5"
name = "baikal-b5"
marketname = "OPPO A6s"
fingerprint = "OPPO/baikal-b5/baikal-b5:15/AP3A.241005.015.A1/baikal-b5.241005.001:user/release-keys"

[templates."oppo_pmt110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PMT110"
device = "cruiser-l5"
product = "cruiser-l5"
name = "cruiser-l5"
marketname = "OPPO A6s Pro"
fingerprint = "OPPO/cruiser-l5/cruiser-l5:15/AP3A.241005.015.A1/cruiser-l5.241005.001:user/release-keys"

[templates."oppo_plt130"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLT130"
device = "baikal-b5"
product = "baikal-b5"
name = "baikal-b5"
marketname = "OPPO A6v"
fingerprint = "OPPO/baikal-b5/baikal-b5:15/AP3A.241005.015.A1/baikal-b5.241005.001:user/release-keys"

[templates."oppo_plt140"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLT140"
device = "baikal-b5"
product = "baikal-b5"
name = "baikal-b5"
marketname = "OPPO A6x"
fingerprint = "OPPO/baikal-b5/baikal-b5:15/AP3A.241005.015.A1/baikal-b5.241005.001:user/release-keys"

[templates."oppo_pmc110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PMC110"
device = "baikal-b4"
product = "baikal-b4"
name = "baikal-b4"
marketname = "OPPO A6c"
fingerprint = "OPPO/baikal-b4/baikal-b4:15/AP3A.241005.015.A1/baikal-b4.241005.001:user/release-keys"

[templates."oppo_plt150"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLT150"
device = "baikal-b5"
product = "baikal-b5"
name = "baikal-b5"
marketname = "OPPO A7i"
fingerprint = "OPPO/baikal-b5/baikal-b5:15/AP3A.241005.015.A1/baikal-b5.241005.001:user/release-keys"

[templates."oppo_pye110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PYE110"
device = "doraemon-b5"
product = "doraemon-b5"
name = "doraemon-b5"
marketname = "OPPO A7 Pro"
fingerprint = "OPPO/doraemon-b5/doraemon-b5:15/AP3A.241005.015.A1/doraemon-b5.241005.001:user/release-keys"

[templates."oppo_pyc110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PYC110"
device = "doraemon-m"
product = "doraemon-m"
name = "doraemon-m"
marketname = "OPPO A7 Pro Max"
fingerprint = "OPPO/doraemon-m/doraemon-m:15/AP3A.241005.015.A1/doraemon-m.241005.001:user/release-keys"

[templates."oppo_pbcm30"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PBCM30"
device = "PBCM30"
product = "PBCM30"
marketname = "OPPO K1"
fingerprint = "OPPO/PBCM30/PBCM30:15/AP3A.241005.015.A1/PBCM30.241005.001:user/release-keys"

[templates."oppo_pcgm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCGM00"
device = "PCGM00"
product = "PCGM00"
marketname = "OPPO K3"
fingerprint = "OPPO/PCGM00/PCGM00:15/AP3A.241005.015.A1/PCGM00.241005.001:user/release-keys"

[templates."oppo_pcnm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PCNM00"
device = "PCNM00"
product = "PCNM00"
marketname = "OPPO K5"
fingerprint = "OPPO/PCNM00/PCNM00:15/AP3A.241005.015.A1/PCNM00.241005.001:user/release-keys"

[templates."oppo_perm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PERM00"
device = "PERM00"
product = "PERM00"
marketname = "OPPO K7x"
fingerprint = "OPPO/PERM00/PERM00:15/AP3A.241005.015.A1/PERM00.241005.001:user/release-keys"

[templates."oppo_pexm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PEXM00"
device = "ciri"
product = "ciri"
name = "ciri"
marketname = "OPPO K9"
fingerprint = "OPPO/ciri/ciri:15/AP3A.241005.015.A1/ciri.241005.001:user/release-keys"

[templates."oppo_perm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PERM10"
device = "walle"
product = "walle"
name = "walle"
marketname = "OPPO K9s"
fingerprint = "OPPO/walle/walle:15/AP3A.241005.015.A1/walle.241005.001:user/release-keys"

[templates."oppo_peym00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PEYM00"
device = "tiga"
product = "tiga"
name = "tiga"
marketname = "OPPO K9 Pro"
fingerprint = "OPPO/tiga/tiga:15/AP3A.241005.015.A1/tiga.241005.001:user/release-keys"

[templates."oppo_pgcm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PGCM10"
device = "apollo-o"
product = "apollo-o"
name = "apollo-o"
marketname = "OPPO K9x"
fingerprint = "OPPO/apollo-o/apollo-o:15/AP3A.241005.015.A1/apollo-o.241005.001:user/release-keys"

[templates."oppo_pgjm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PGJM10"
device = "qqcandy"
product = "qqcandy"
name = "qqcandy"
marketname = "OPPO K10"
fingerprint = "OPPO/qqcandy/qqcandy:15/AP3A.241005.015.A1/qqcandy.241005.001:user/release-keys"

[templates."oppo_pgim10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PGIM10"
device = "eva"
product = "eva"
name = "eva"
marketname = "OPPO K10 Pro"
fingerprint = "OPPO/eva/eva:15/AP3A.241005.015.A1/eva.241005.001:user/release-keys"

[templates."oppo_pggm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PGGM10"
device = "oscar-y"
product = "oscar-y"
name = "oscar-y"
marketname = "OPPO K10x"
fingerprint = "OPPO/oscar-y/oscar-y:15/AP3A.241005.015.A1/oscar-y.241005.001:user/release-keys"

[templates."oppo_pjc110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PJC110"
device = "ziti"
product = "ziti"
name = "ziti"
marketname = "OPPO K11"
fingerprint = "OPPO/ziti/ziti:15/AP3A.241005.015.A1/ziti.241005.001:user/release-keys"

[templates."oppo_phf110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PHF110"
device = "larry"
product = "larry"
name = "larry"
marketname = "OPPO K11x"
fingerprint = "OPPO/larry/larry:15/AP3A.241005.015.A1/larry.241005.001:user/release-keys"

[templates."oppo_pjr110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PJR110"
device = "benz"
product = "benz"
name = "benz"
marketname = "OPPO K12"
fingerprint = "OPPO/benz/benz:15/AP3A.241005.015.A1/benz.241005.001:user/release-keys"

[templates."oppo_pks110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PKS110"
device = "jeep"
product = "jeep"
name = "jeep"
marketname = "OPPO K12 Plus"
fingerprint = "OPPO/jeep/jeep:15/AP3A.241005.015.A1/jeep.241005.001:user/release-keys"

[templates."oppo_pjt110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PJT110"
device = "camry"
product = "camry"
name = "camry"
marketname = "OPPO K12x"
fingerprint = "OPPO/camry/camry:15/AP3A.241005.015.A1/camry.241005.001:user/release-keys"

[templates."oppo_pld110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLD110"
device = "knight-l"
product = "knight-l"
name = "knight-l"
marketname = "OPPO K12s"
fingerprint = "OPPO/knight-l/knight-l:15/AP3A.241005.015.A1/knight-l.241005.001:user/release-keys"

[templates."oppo_plm110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLM110"
device = "knight"
product = "knight"
name = "knight"
marketname = "OPPO K13 Turbo"
fingerprint = "OPPO/knight/knight:15/AP3A.241005.015.A1/knight.241005.001:user/release-keys"

[templates."oppo_ple110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PLE110"
device = "knight-h"
product = "knight-h"
name = "knight-h"
marketname = "OPPO K13 Turbo Pro"
fingerprint = "OPPO/knight-h/knight-h:15/AP3A.241005.015.A1/knight-h.241005.001:user/release-keys"

[templates."oppo_pyd110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PYD110"
device = "jinx-m"
product = "jinx-m"
name = "jinx-m"
marketname = "OPPO K15"
fingerprint = "OPPO/jinx-m/jinx-m:15/AP3A.241005.015.A1/jinx-m.241005.001:user/release-keys"

[templates."oppo_pmh110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PMH110"
device = "lux-m"
product = "lux-m"
name = "lux-m"
marketname = "OPPO K15 Pro"
fingerprint = "OPPO/lux-m/lux-m:15/AP3A.241005.015.A1/lux-m.241005.001:user/release-keys"

[templates."oppo_pmg110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PMG110"
device = "lux-h"
product = "lux-h"
name = "lux-h"
marketname = "OPPO K15 Pro+"
fingerprint = "OPPO/lux-h/lux-h:15/AP3A.241005.015.A1/lux-h.241005.001:user/release-keys"

[templates."oppo_pye130"]
manufacturer = "OPPO"
brand = "OPPO"
model = "PYE130"
device = "doraemon-b5"
product = "doraemon-b5"
name = "doraemon-b5"
marketname = "OPPO K15s"
fingerprint = "OPPO/doraemon-b5/doraemon-b5:15/AP3A.241005.015.A1/doraemon-b5.241005.001:user/release-keys"

[templates."oppo_opd2101"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPD2101"
device = "oslo"
product = "oslo"
name = "oslo"
marketname = "OPPO Pad"
fingerprint = "OPPO/oslo/oslo:15/AP3A.241005.015.A1/oslo.241005.001:user/release-keys"

[templates."oppo_opd2102"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPD2102"
device = "reeves"
product = "reeves"
name = "reeves"
marketname = "OPPO Pad Air"
fingerprint = "OPPO/reeves/reeves:15/AP3A.241005.015.A1/reeves.241005.001:user/release-keys"

[templates."oppo_opd2201"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPD2201"
device = "aries"
product = "aries"
name = "aries"
marketname = "OPPO Pad 2"
fingerprint = "OPPO/aries/aries:15/AP3A.241005.015.A1/aries.241005.001:user/release-keys"

[templates."oppo_opd2301"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPD2301"
device = "bluey"
product = "bluey"
name = "bluey"
marketname = "OPPO Pad Air2"
fingerprint = "OPPO/bluey/bluey:15/AP3A.241005.015.A1/bluey.241005.001:user/release-keys"

[templates."oppo_opd2405"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPD2405"
device = "dunhuang"
product = "dunhuang"
name = "dunhuang"
marketname = "OPPO Pad 3"
fingerprint = "OPPO/dunhuang/dunhuang:15/AP3A.241005.015.A1/dunhuang.241005.001:user/release-keys"

[templates."oppo_opd2401"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPD2401"
device = "caihong"
product = "caihong"
name = "caihong"
marketname = "OPPO Pad 3 Pro"
fingerprint = "OPPO/caihong/caihong:15/AP3A.241005.015.A1/caihong.241005.001:user/release-keys"

[templates."oppo_opd2409"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPD2409"
device = "erhai"
product = "erhai"
name = "erhai"
marketname = "OPPO Pad 4 Pro"
fingerprint = "OPPO/erhai/erhai:15/AP3A.241005.015.A1/erhai.241005.001:user/release-keys"

[templates."oppo_opd2417"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPD2417"
device = "fiji"
product = "fiji"
name = "fiji"
marketname = "OPPO Pad SE"
fingerprint = "OPPO/fiji/fiji:15/AP3A.241005.015.A1/fiji.241005.001:user/release-keys"

[templates."oppo_opd2506"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPD2506"
device = "himalayan"
product = "himalayan"
name = "himalayan"
marketname = "OPPO Pad 5"
fingerprint = "OPPO/himalayan/himalayan:15/AP3A.241005.015.A1/himalayan.241005.001:user/release-keys"

[templates."oppo_opd2501"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPD2501"
device = "greenland"
product = "greenland"
name = "greenland"
marketname = "OPPO Pad Air5"
fingerprint = "OPPO/greenland/greenland:15/AP3A.241005.015.A1/greenland.241005.001:user/release-keys"

[templates."oppo_opd2511"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPD2511"
device = "iceland"
product = "iceland"
name = "iceland"
marketname = "OPPO Pad 5 Pro"
fingerprint = "OPPO/iceland/iceland:15/AP3A.241005.015.A1/iceland.241005.001:user/release-keys"

[templates."oppo_opd2515"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPD2515"
device = "ivy"
product = "ivy"
name = "ivy"
marketname = "OPPO Pad Mini"
fingerprint = "OPPO/ivy/ivy:15/AP3A.241005.015.A1/ivy.241005.001:user/release-keys"

[templates."oppo_opd2601"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPD2601"
device = "jinggangshan"
product = "jinggangshan"
name = "jinggangshan"
marketname = "OPPO Pad 6"
fingerprint = "OPPO/jinggangshan/jinggangshan:15/AP3A.241005.015.A1/jinggangshan.241005.001:user/release-keys"

[templates."oppo_opd2613"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPD2613"
device = "OPD2613"
product = "OPD2613"
marketname = "OPPO Pad Air6"
fingerprint = "OPPO/OPD2613/OPD2613:15/AP3A.241005.015.A1/OPD2613.241005.001:user/release-keys"

[templates."realme_rmx1901"]
manufacturer = "realme"
brand = "realme"
model = "RMX1901"
device = "RMX1901"
product = "RMX1901"
marketname = "realme X"
fingerprint = "realme/RMX1901/RMX1901:15/AP3A.241005.015.A1/RMX1901.241005.001:user/release-keys"

[templates."realme_rmx1851"]
manufacturer = "realme"
brand = "realme"
model = "RMX1851"
device = "RMX1851"
product = "RMX1851"
marketname = "realme X 青春版"
fingerprint = "realme/RMX1851/RMX1851:15/AP3A.241005.015.A1/RMX1851.241005.001:user/release-keys"

[templates."realme_rmx1991"]
manufacturer = "realme"
brand = "realme"
model = "RMX1991"
device = "RMX1991"
product = "RMX1991"
marketname = "realme X2"
fingerprint = "realme/RMX1991/RMX1991:15/AP3A.241005.015.A1/RMX1991.241005.001:user/release-keys"

[templates."realme_rmx1931"]
manufacturer = "realme"
brand = "realme"
model = "RMX1931"
device = "samurai"
product = "samurai"
name = "samurai"
marketname = "realme X2 Pro"
fingerprint = "realme/samurai/samurai:15/AP3A.241005.015.A1/samurai.241005.001:user/release-keys"

[templates."realme_rmx2051"]
manufacturer = "realme"
brand = "realme"
model = "RMX2051"
device = "RMX2051"
product = "RMX2051"
marketname = "realme X50 5G"
fingerprint = "realme/RMX2051/RMX2051:15/AP3A.241005.015.A1/RMX2051.241005.001:user/release-keys"

[templates."realme_rmx2071"]
manufacturer = "realme"
brand = "realme"
model = "RMX2071"
device = "bladerunner"
product = "bladerunner"
name = "bladerunner"
marketname = "realme X50 Pro 5G"
fingerprint = "realme/bladerunner/bladerunner:15/AP3A.241005.015.A1/bladerunner.241005.001:user/release-keys"

[templates."realme_rmx2072"]
manufacturer = "realme"
brand = "realme"
model = "RMX2072"
device = "bladerunner_48m"
product = "bladerunner_48m"
name = "bladerunner_48m"
marketname = "realme X50 Pro 玩家版"
fingerprint = "realme/bladerunner_48m/bladerunner_48m:15/AP3A.241005.015.A1/bladerunner_48m.241005.001:user/release-keys"

[templates."realme_rmx2141"]
manufacturer = "realme"
brand = "realme"
model = "RMX2141"
device = "RMX2141"
product = "RMX2141"
marketname = "realme X50m 5G"
fingerprint = "realme/RMX2141/RMX2141:15/AP3A.241005.015.A1/RMX2141.241005.001:user/release-keys"

[templates."realme_rmx2052"]
manufacturer = "realme"
brand = "realme"
model = "RMX2052"
device = "RMX2052"
product = "RMX2052"
marketname = "realme X50t 5G"
fingerprint = "realme/RMX2052/RMX2052:15/AP3A.241005.015.A1/RMX2052.241005.001:user/release-keys"

[templates."realme_rmx2176"]
manufacturer = "realme"
brand = "realme"
model = "RMX2176"
device = "RMX2176"
product = "RMX2176"
marketname = "realme X7 5G"
fingerprint = "realme/RMX2176/RMX2176:15/AP3A.241005.015.A1/RMX2176.241005.001:user/release-keys"

[templates."realme_rmx2121"]
manufacturer = "realme"
brand = "realme"
model = "RMX2121"
device = "RMX2121"
product = "RMX2121"
marketname = "realme X7 Pro 5G"
fingerprint = "realme/RMX2121/RMX2121:15/AP3A.241005.015.A1/RMX2121.241005.001:user/release-keys"

[templates."realme_rmx3115"]
manufacturer = "realme"
brand = "realme"
model = "RMX3115"
device = "RMX3115"
product = "RMX3115"
marketname = "realme X7 Pro 至尊版 5G"
fingerprint = "realme/RMX3115/RMX3115:15/AP3A.241005.015.A1/RMX3115.241005.001:user/release-keys"

[templates."realme_rmx2202"]
manufacturer = "realme"
brand = "realme"
model = "RMX2202"
device = "cupid"
product = "cupid"
name = "cupid"
marketname = "realme GT 5G"
fingerprint = "realme/cupid/cupid:15/AP3A.241005.015.A1/cupid.241005.001:user/release-keys"

[templates."realme_rmx3361"]
manufacturer = "realme"
brand = "realme"
model = "RMX3361"
device = "lunaa"
product = "lunaa"
name = "lunaa"
marketname = "realme GT 大师版"
fingerprint = "realme/lunaa/lunaa:15/AP3A.241005.015.A1/lunaa.241005.001:user/release-keys"

[templates."realme_rmx3366"]
manufacturer = "realme"
brand = "realme"
model = "RMX3366"
device = "rivena"
product = "rivena"
name = "rivena"
marketname = "realme GT 大师探索版"
fingerprint = "realme/rivena/rivena:15/AP3A.241005.015.A1/rivena.241005.001:user/release-keys"

[templates."realme_rmx3310"]
manufacturer = "realme"
brand = "realme"
model = "RMX3310"
device = "porsche"
product = "porsche"
name = "porsche"
marketname = "realme GT2"
fingerprint = "realme/porsche/porsche:15/AP3A.241005.015.A1/porsche.241005.001:user/release-keys"

[templates."realme_rmx3300"]
manufacturer = "realme"
brand = "realme"
model = "RMX3300"
device = "ferrari"
product = "ferrari"
name = "ferrari"
marketname = "realme GT2 Pro"
fingerprint = "realme/ferrari/ferrari:15/AP3A.241005.015.A1/ferrari.241005.001:user/release-keys"

[templates."realme_rmx3551"]
manufacturer = "realme"
brand = "realme"
model = "RMX3551"
device = "jennie"
product = "jennie"
name = "jennie"
marketname = "realme GT2 大师探索版"
fingerprint = "realme/jennie/jennie:15/AP3A.241005.015.A1/jennie.241005.001:user/release-keys"

[templates."realme_rmx3820"]
manufacturer = "realme"
brand = "realme"
model = "RMX3820"
device = "jennie"
product = "jennie"
name = "jennie"
marketname = "realme GT5"
fingerprint = "realme/jennie/jennie:15/AP3A.241005.015.A1/jennie.241005.001:user/release-keys"

[templates."realme_rmx3823"]
manufacturer = "realme"
brand = "realme"
model = "RMX3823"
device = "zonda-b"
product = "zonda-b"
name = "zonda-b"
marketname = "realme GT5 240W"
fingerprint = "realme/zonda-b/zonda-b:15/AP3A.241005.015.A1/zonda-b.241005.001:user/release-keys"

[templates."realme_rmx3888"]
manufacturer = "realme"
brand = "realme"
model = "RMX3888"
device = "enzo"
product = "enzo"
name = "enzo"
marketname = "realme GT5 Pro"
fingerprint = "realme/enzo/enzo:15/AP3A.241005.015.A1/enzo.241005.001:user/release-keys"

[templates."realme_rmx3800"]
manufacturer = "realme"
brand = "realme"
model = "RMX3800"
device = "divo"
product = "divo"
name = "divo"
marketname = "realme GT6"
fingerprint = "realme/divo/divo:15/AP3A.241005.015.A1/divo.241005.001:user/release-keys"

[templates."realme_rmx6688"]
manufacturer = "realme"
brand = "realme"
model = "RMX6688"
device = "targa"
product = "targa"
name = "targa"
marketname = "realme GT7"
fingerprint = "realme/targa/targa:15/AP3A.241005.015.A1/targa.241005.001:user/release-keys"

[templates."realme_rmx5010"]
manufacturer = "realme"
brand = "realme"
model = "RMX5010"
device = "pista"
product = "pista"
name = "pista"
marketname = "realme GT7 Pro"
fingerprint = "realme/pista/pista:15/AP3A.241005.015.A1/pista.241005.001:user/release-keys"

[templates."realme_rmx5090"]
manufacturer = "realme"
brand = "realme"
model = "RMX5090"
device = "piloti"
product = "piloti"
name = "piloti"
marketname = "realme GT7 Pro 竞速版"
fingerprint = "realme/piloti/piloti:15/AP3A.241005.015.A1/piloti.241005.001:user/release-keys"

[templates."realme_rmx6699"]
manufacturer = "realme"
brand = "realme"
model = "RMX6699"
device = "amg"
product = "amg"
name = "amg"
marketname = "realme GT8"
fingerprint = "realme/amg/amg:15/AP3A.241005.015.A1/amg.241005.001:user/release-keys"

[templates."realme_rmx5200"]
manufacturer = "realme"
brand = "realme"
model = "RMX5200"
device = "lafa"
product = "lafa"
name = "lafa"
marketname = "realme GT8 Pro"
fingerprint = "realme/lafa/lafa:15/AP3A.241005.015.A1/lafa.241005.001:user/release-keys"

[templates."realme_rmx3031"]
manufacturer = "realme"
brand = "realme"
model = "RMX3031"
device = "RMX3031"
product = "RMX3031"
marketname = "realme GT Neo 5G"
fingerprint = "realme/RMX3031/RMX3031:15/AP3A.241005.015.A1/RMX3031.241005.001:user/release-keys"

[templates."realme_rmx3350"]
manufacturer = "realme"
brand = "realme"
model = "RMX3350"
device = "RMX3350"
product = "RMX3350"
marketname = "realme GT Neo 闪速版"
fingerprint = "realme/RMX3350/RMX3350:15/AP3A.241005.015.A1/RMX3350.241005.001:user/release-keys"

[templates."realme_rmx3370"]
manufacturer = "realme"
brand = "realme"
model = "RMX3370"
device = "bitra"
product = "bitra"
name = "bitra"
marketname = "realme GT Neo2"
fingerprint = "realme/bitra/bitra:15/AP3A.241005.015.A1/bitra.241005.001:user/release-keys"

[templates."realme_rmx3357"]
manufacturer = "realme"
brand = "realme"
model = "RMX3357"
device = "RMX3357"
product = "RMX3357"
marketname = "realme GT Neo2T"
fingerprint = "realme/RMX3357/RMX3357:15/AP3A.241005.015.A1/RMX3357.241005.001:user/release-keys"

[templates."realme_rmx3560"]
manufacturer = "realme"
brand = "realme"
model = "RMX3560"
device = "lisa-a"
product = "lisa-a"
name = "lisa-a"
marketname = "realme GT Neo3"
fingerprint = "realme/lisa-a/lisa-a:15/AP3A.241005.015.A1/lisa-a.241005.001:user/release-keys"

[templates."realme_rmx3562"]
manufacturer = "realme"
brand = "realme"
model = "RMX3562"
device = "lisa-b"
product = "lisa-b"
name = "lisa-b"
marketname = "realme GT Neo3 150W"
fingerprint = "realme/lisa-b/lisa-b:15/AP3A.241005.015.A1/lisa-b.241005.001:user/release-keys"

[templates."realme_rmx3706"]
manufacturer = "realme"
brand = "realme"
model = "RMX3706"
device = "senna-b"
product = "senna-b"
name = "senna-b"
marketname = "realme GT Neo5"
fingerprint = "realme/senna-b/senna-b:15/AP3A.241005.015.A1/senna-b.241005.001:user/release-keys"

[templates."realme_rmx3708"]
manufacturer = "realme"
brand = "realme"
model = "RMX3708"
device = "senna-c"
product = "senna-c"
name = "senna-c"
marketname = "realme GT Neo5 240W"
fingerprint = "realme/senna-c/senna-c:15/AP3A.241005.015.A1/senna-c.241005.001:user/release-keys"

[templates."realme_rmx3700"]
manufacturer = "realme"
brand = "realme"
model = "RMX3700"
device = "senna-a"
product = "senna-a"
name = "senna-a"
marketname = "realme GT Neo5 SE"
fingerprint = "realme/senna-a/senna-a:15/AP3A.241005.015.A1/senna-a.241005.001:user/release-keys"

[templates."realme_rmx3852"]
manufacturer = "realme"
brand = "realme"
model = "RMX3852"
device = "bale-b"
product = "bale-b"
name = "bale-b"
marketname = "realme GT Neo6"
fingerprint = "realme/bale-b/bale-b:15/AP3A.241005.015.A1/bale-b.241005.001:user/release-keys"

[templates."realme_rmx3850"]
manufacturer = "realme"
brand = "realme"
model = "RMX3850"
device = "bale-a"
product = "bale-a"
name = "bale-a"
marketname = "realme GT Neo6 SE"
fingerprint = "realme/bale-a/bale-a:15/AP3A.241005.015.A1/bale-a.241005.001:user/release-keys"

[templates."realme_rmx5060"]
manufacturer = "realme"
brand = "realme"
model = "RMX5060"
device = "cayman-a"
product = "cayman-a"
name = "cayman-a"
marketname = "realme Neo7"
fingerprint = "realme/cayman-a/cayman-a:15/AP3A.241005.015.A1/cayman-a.241005.001:user/release-keys"

[templates."realme_rmx5062"]
manufacturer = "realme"
brand = "realme"
model = "RMX5062"
device = "cayman-c"
product = "cayman-c"
name = "cayman-c"
marketname = "realme Neo7 Turbo"
fingerprint = "realme/cayman-c/cayman-c:15/AP3A.241005.015.A1/cayman-c.241005.001:user/release-keys"

[templates."realme_rmx5080"]
manufacturer = "realme"
brand = "realme"
model = "RMX5080"
device = "brz-a"
product = "brz-a"
name = "brz-a"
marketname = "realme Neo7 SE"
fingerprint = "realme/brz-a/brz-a:15/AP3A.241005.015.A1/brz-a.241005.001:user/release-keys"

[templates."realme_rmx5071"]
manufacturer = "realme"
brand = "realme"
model = "RMX5071"
device = "dongfeng"
product = "dongfeng"
name = "dongfeng"
marketname = "realme Neo7x"
fingerprint = "realme/dongfeng/dongfeng:15/AP3A.241005.015.A1/dongfeng.241005.001:user/release-keys"

[templates."realme_rmx8899"]
manufacturer = "realme"
brand = "realme"
model = "RMX8899"
device = "u9"
product = "u9"
name = "u9"
marketname = "realme Neo8"
fingerprint = "realme/u9/u9:15/AP3A.241005.015.A1/u9.241005.001:user/release-keys"

[templates."realme_rmx1971"]
manufacturer = "realme"
brand = "realme"
model = "RMX1971"
device = "RMX1971"
product = "RMX1971"
marketname = "realme Q"
fingerprint = "realme/RMX1971/RMX1971:15/AP3A.241005.015.A1/RMX1971.241005.001:user/release-keys"

[templates."realme_rmx2117"]
manufacturer = "realme"
brand = "realme"
model = "RMX2117"
device = "RMX2117"
product = "RMX2117"
marketname = "realme Q2 5G"
fingerprint = "realme/RMX2117/RMX2117:15/AP3A.241005.015.A1/RMX2117.241005.001:user/release-keys"

[templates."realme_rmx2173"]
manufacturer = "realme"
brand = "realme"
model = "RMX2173"
device = "RMX2173"
product = "RMX2173"
marketname = "realme Q2 Pro 5G"
fingerprint = "realme/RMX2173/RMX2173:15/AP3A.241005.015.A1/RMX2173.241005.001:user/release-keys"

[templates."realme_rmx2200"]
manufacturer = "realme"
brand = "realme"
model = "RMX2200"
device = "RMX2200"
product = "RMX2200"
marketname = "realme Q2i 5G"
fingerprint = "realme/RMX2200/RMX2200:15/AP3A.241005.015.A1/RMX2200.241005.001:user/release-keys"

[templates."realme_rmx3161"]
manufacturer = "realme"
brand = "realme"
model = "RMX3161"
device = "zeus"
product = "zeus"
name = "zeus"
marketname = "realme Q3 5G"
fingerprint = "realme/zeus/zeus:15/AP3A.241005.015.A1/zeus.241005.001:user/release-keys"

[templates."realme_rmx2205"]
manufacturer = "realme"
brand = "realme"
model = "RMX2205"
device = "RMX2205"
product = "RMX2205"
marketname = "realme Q3 Pro 5G"
fingerprint = "realme/RMX2205/RMX2205:15/AP3A.241005.015.A1/RMX2205.241005.001:user/release-keys"

[templates."realme_rmx3142"]
manufacturer = "realme"
brand = "realme"
model = "RMX3142"
device = "luna"
product = "luna"
name = "luna"
marketname = "realme Q3 Pro 狂欢版"
fingerprint = "realme/luna/luna:15/AP3A.241005.015.A1/luna.241005.001:user/release-keys"

[templates."realme_rmx3042"]
manufacturer = "realme"
brand = "realme"
model = "RMX3042"
device = "RMX3042"
product = "RMX3042"
marketname = "realme Q3i 5G"
fingerprint = "realme/RMX3042/RMX3042:15/AP3A.241005.015.A1/RMX3042.241005.001:user/release-keys"

[templates."realme_rmx3461"]
manufacturer = "realme"
brand = "realme"
model = "RMX3461"
device = "ice"
product = "ice"
name = "ice"
marketname = "realme Q3s"
fingerprint = "realme/ice/ice:15/AP3A.241005.015.A1/ice.241005.001:user/release-keys"

[templates."realme_rmx3462"]
manufacturer = "realme"
brand = "realme"
model = "RMX3462"
device = "ice"
product = "ice"
name = "ice"
marketname = "realme Q3t"
fingerprint = "realme/ice/ice:15/AP3A.241005.015.A1/ice.241005.001:user/release-keys"

[templates."realme_rmx3478"]
manufacturer = "realme"
brand = "realme"
model = "RMX3478"
device = "oscar"
product = "oscar"
name = "oscar"
marketname = "realme Q5"
fingerprint = "realme/oscar/oscar:15/AP3A.241005.015.A1/oscar.241005.001:user/release-keys"

[templates."realme_rmx3372"]
manufacturer = "realme"
brand = "realme"
model = "RMX3372"
device = "spartan"
product = "spartan"
name = "spartan"
marketname = "realme Q5 Pro"
fingerprint = "realme/spartan/spartan:15/AP3A.241005.015.A1/spartan.241005.001:user/release-keys"

[templates."realme_rmx3574"]
manufacturer = "realme"
brand = "realme"
model = "RMX3574"
device = "alice"
product = "alice"
name = "alice"
marketname = "realme Q5i"
fingerprint = "realme/alice/alice:15/AP3A.241005.015.A1/alice.241005.001:user/release-keys"

[templates."realme_rmx3616"]
manufacturer = "realme"
brand = "realme"
model = "RMX3616"
device = "blade"
product = "blade"
name = "blade"
marketname = "realme Q5x"
fingerprint = "realme/blade/blade:15/AP3A.241005.015.A1/blade.241005.001:user/release-keys"

[templates."realme_rmx3615"]
manufacturer = "realme"
brand = "realme"
model = "RMX3615"
device = "blade"
product = "blade"
name = "blade"
marketname = "realme 10"
fingerprint = "realme/blade/blade:15/AP3A.241005.015.A1/blade.241005.001:user/release-keys"

[templates."realme_rmx3617"]
manufacturer = "realme"
brand = "realme"
model = "RMX3617"
device = "blade"
product = "blade"
name = "blade"
marketname = "realme 10s"
fingerprint = "realme/blade/blade:15/AP3A.241005.015.A1/blade.241005.001:user/release-keys"

[templates."realme_rmx3663"]
manufacturer = "realme"
brand = "realme"
model = "RMX3663"
device = "luigi"
product = "luigi"
name = "luigi"
marketname = "realme 10 Pro"
fingerprint = "realme/luigi/luigi:15/AP3A.241005.015.A1/luigi.241005.001:user/release-keys"

[templates."realme_rmx3687"]
manufacturer = "realme"
brand = "realme"
model = "RMX3687"
device = "roma"
product = "roma"
name = "roma"
marketname = "realme 10 Pro+"
fingerprint = "realme/roma/roma:15/AP3A.241005.015.A1/roma.241005.001:user/release-keys"

[templates."realme_rmx3751"]
manufacturer = "realme"
brand = "realme"
model = "RMX3751"
device = "hawaii"
product = "hawaii"
name = "hawaii"
marketname = "realme 11"
fingerprint = "realme/hawaii/hawaii:15/AP3A.241005.015.A1/hawaii.241005.001:user/release-keys"

[templates."realme_rmx3770"]
manufacturer = "realme"
brand = "realme"
model = "RMX3770"
device = "chengdu-b"
product = "chengdu-b"
name = "chengdu-b"
marketname = "realme 11 Pro"
fingerprint = "realme/chengdu-b/chengdu-b:15/AP3A.241005.015.A1/chengdu-b.241005.001:user/release-keys"

[templates."realme_rmx3740"]
manufacturer = "realme"
brand = "realme"
model = "RMX3740"
device = "chengdu"
product = "chengdu"
name = "chengdu"
marketname = "realme 11 Pro+"
fingerprint = "realme/chengdu/chengdu:15/AP3A.241005.015.A1/chengdu.241005.001:user/release-keys"

[templates."realme_rmx3992"]
manufacturer = "realme"
brand = "realme"
model = "RMX3992"
device = "RMX3992"
product = "RMX3992"
marketname = "realme 12"
fingerprint = "realme/RMX3992/RMX3992:15/AP3A.241005.015.A1/RMX3992.241005.001:user/release-keys"

[templates."realme_rmx3993"]
manufacturer = "realme"
brand = "realme"
model = "RMX3993"
device = "RMX3993"
product = "RMX3993"
marketname = "realme 12x"
fingerprint = "realme/RMX3993/RMX3993:15/AP3A.241005.015.A1/RMX3993.241005.001:user/release-keys"

[templates."realme_rmx3843"]
manufacturer = "realme"
brand = "realme"
model = "RMX3843"
device = "coffee-a"
product = "coffee-a"
name = "coffee-a"
marketname = "realme 12 Pro"
fingerprint = "realme/coffee-a/coffee-a:15/AP3A.241005.015.A1/coffee-a.241005.001:user/release-keys"

[templates."realme_rmx3841"]
manufacturer = "realme"
brand = "realme"
model = "RMX3841"
device = "coffee"
product = "coffee"
name = "coffee"
marketname = "realme 12 Pro+"
fingerprint = "realme/coffee/coffee:15/AP3A.241005.015.A1/coffee.241005.001:user/release-keys"

[templates."realme_rmx3952"]
manufacturer = "realme"
brand = "realme"
model = "RMX3952"
device = "barley-x"
product = "barley-x"
name = "barley-x"
marketname = "realme 13"
fingerprint = "realme/barley-x/barley-x:15/AP3A.241005.015.A1/barley-x.241005.001:user/release-keys"

[templates."realme_rmx5002"]
manufacturer = "realme"
brand = "realme"
model = "RMX5002"
device = "casio"
product = "casio"
name = "casio"
marketname = "realme 13 Pro"
fingerprint = "realme/casio/casio:15/AP3A.241005.015.A1/casio.241005.001:user/release-keys"

[templates."realme_rmx3989"]
manufacturer = "realme"
brand = "realme"
model = "RMX3989"
device = "amber-t"
product = "amber-t"
name = "amber-t"
marketname = "realme 13 Pro 至尊版"
fingerprint = "realme/amber-t/amber-t:15/AP3A.241005.015.A1/amber-t.241005.001:user/release-keys"

[templates."realme_rmx3920"]
manufacturer = "realme"
brand = "realme"
model = "RMX3920"
device = "amber"
product = "amber"
name = "amber"
marketname = "realme 13 Pro+"
fingerprint = "realme/amber/amber:15/AP3A.241005.015.A1/amber.241005.001:user/release-keys"

[templates."realme_rmx5075"]
manufacturer = "realme"
brand = "realme"
model = "RMX5075"
device = "dongfeng"
product = "dongfeng"
name = "dongfeng"
marketname = "realme 14"
fingerprint = "realme/dongfeng/dongfeng:15/AP3A.241005.015.A1/dongfeng.241005.001:user/release-keys"

[templates."realme_rmx5055"]
manufacturer = "realme"
brand = "realme"
model = "RMX5055"
device = "casio-x"
product = "casio-x"
name = "casio-x"
marketname = "realme 14 Pro"
fingerprint = "realme/casio-x/casio-x:15/AP3A.241005.015.A1/casio-x.241005.001:user/release-keys"

[templates."realme_rmx5050"]
manufacturer = "realme"
brand = "realme"
model = "RMX5050"
device = "piaget"
product = "piaget"
name = "piaget"
marketname = "realme 14 Pro+"
fingerprint = "realme/piaget/piaget:15/AP3A.241005.015.A1/piaget.241005.001:user/release-keys"

[templates."realme_rmx5105"]
manufacturer = "realme"
brand = "realme"
model = "RMX5105"
device = "casio-y"
product = "casio-y"
name = "casio-y"
marketname = "realme 15"
fingerprint = "realme/casio-y/casio-y:15/AP3A.241005.015.A1/casio-y.241005.001:user/release-keys"

[templates."realme_rmx5100"]
manufacturer = "realme"
brand = "realme"
model = "RMX5100"
device = "neutron"
product = "neutron"
name = "neutron"
marketname = "realme 15 Pro"
fingerprint = "realme/neutron/neutron:15/AP3A.241005.015.A1/neutron.241005.001:user/release-keys"

[templates."realme_rmx5112"]
manufacturer = "realme"
brand = "realme"
model = "RMX5112"
device = "chopard-a"
product = "chopard-a"
name = "chopard-a"
marketname = "realme 15T"
fingerprint = "realme/chopard-a/chopard-a:15/AP3A.241005.015.A1/chopard-a.241005.001:user/release-keys"

[templates."realme_rmx2201"]
manufacturer = "realme"
brand = "realme"
model = "RMX2201"
device = "RMX2201"
product = "RMX2201"
marketname = "realme V3 5G"
fingerprint = "realme/RMX2201/RMX2201:15/AP3A.241005.015.A1/RMX2201.241005.001:user/release-keys"

[templates."realme_rmx2111"]
manufacturer = "realme"
brand = "realme"
model = "RMX2111"
device = "RMX2111"
product = "RMX2111"
marketname = "realme V5 5G"
fingerprint = "realme/RMX2111/RMX2111:15/AP3A.241005.015.A1/RMX2111.241005.001:user/release-keys"

[templates."realme_rmx3121"]
manufacturer = "realme"
brand = "realme"
model = "RMX3121"
device = "RMX3121"
product = "RMX3121"
marketname = "realme V11 5G"
fingerprint = "realme/RMX3121/RMX3121:15/AP3A.241005.015.A1/RMX3121.241005.001:user/release-keys"

[templates."realme_rmx3125"]
manufacturer = "realme"
brand = "realme"
model = "RMX3125"
device = "RMX3125"
product = "RMX3125"
marketname = "realme V11s 5G"
fingerprint = "realme/RMX3125/RMX3125:15/AP3A.241005.015.A1/RMX3125.241005.001:user/release-keys"

[templates."realme_rmx3041"]
manufacturer = "realme"
brand = "realme"
model = "RMX3041"
device = "RMX3041"
product = "RMX3041"
marketname = "realme V13 5G"
fingerprint = "realme/RMX3041/RMX3041:15/AP3A.241005.015.A1/RMX3041.241005.001:user/release-keys"

[templates."realme_rmx3092"]
manufacturer = "realme"
brand = "realme"
model = "RMX3092"
device = "RMX3092"
product = "RMX3092"
marketname = "realme V15 5G"
fingerprint = "realme/RMX3092/RMX3092:15/AP3A.241005.015.A1/RMX3092.241005.001:user/release-keys"

[templates."realme_rmx3610"]
manufacturer = "realme"
brand = "realme"
model = "RMX3610"
device = "blade"
product = "blade"
name = "blade"
marketname = "realme V20"
fingerprint = "realme/blade/blade:15/AP3A.241005.015.A1/blade.241005.001:user/release-keys"

[templates."realme_rmx3571"]
manufacturer = "realme"
brand = "realme"
model = "RMX3571"
device = "alice"
product = "alice"
name = "alice"
marketname = "realme V23"
fingerprint = "realme/alice/alice:15/AP3A.241005.015.A1/alice.241005.001:user/release-keys"

[templates."realme_rmx3576"]
manufacturer = "realme"
brand = "realme"
model = "RMX3576"
device = "alice"
product = "alice"
name = "alice"
marketname = "realme V23i"
fingerprint = "realme/alice/alice:15/AP3A.241005.015.A1/alice.241005.001:user/release-keys"

[templates."realme_rmx3475"]
manufacturer = "realme"
brand = "realme"
model = "RMX3475"
device = "oscar"
product = "oscar"
name = "oscar"
marketname = "realme V25"
fingerprint = "realme/oscar/oscar:15/AP3A.241005.015.A1/oscar.241005.001:user/release-keys"

[templates."realme_rmx3619"]
manufacturer = "realme"
brand = "realme"
model = "RMX3619"
device = "blade"
product = "blade"
name = "blade"
marketname = "realme V30"
fingerprint = "realme/blade/blade:15/AP3A.241005.015.A1/blade.241005.001:user/release-keys"

[templates."realme_rmx3618"]
manufacturer = "realme"
brand = "realme"
model = "RMX3618"
device = "blade"
product = "blade"
name = "blade"
marketname = "realme V30t"
fingerprint = "realme/blade/blade:15/AP3A.241005.015.A1/blade.241005.001:user/release-keys"

[templates."realme_rmx3783"]
manufacturer = "realme"
brand = "realme"
model = "RMX3783"
device = "chongqing"
product = "chongqing"
name = "chongqing"
marketname = "realme V50"
fingerprint = "realme/chongqing/chongqing:15/AP3A.241005.015.A1/chongqing.241005.001:user/release-keys"

[templates."realme_rmx3781"]
manufacturer = "realme"
brand = "realme"
model = "RMX3781"
device = "chongqing"
product = "chongqing"
name = "chongqing"
marketname = "realme V50s"
fingerprint = "realme/chongqing/chongqing:15/AP3A.241005.015.A1/chongqing.241005.001:user/release-keys"

[templates."realme_rmx3995"]
manufacturer = "realme"
brand = "realme"
model = "RMX3995"
device = "barley-d"
product = "barley-d"
name = "barley-d"
marketname = "realme V60"
fingerprint = "realme/barley-d/barley-d:15/AP3A.241005.015.A1/barley-d.241005.001:user/release-keys"

[templates."realme_rmx3996"]
manufacturer = "realme"
brand = "realme"
model = "RMX3996"
device = "barley-d"
product = "barley-d"
name = "barley-d"
marketname = "realme V60s"
fingerprint = "realme/barley-d/barley-d:15/AP3A.241005.015.A1/barley-d.241005.001:user/release-keys"

[templates."realme_rmx3953"]
manufacturer = "realme"
brand = "realme"
model = "RMX3953"
device = "rado"
product = "rado"
name = "rado"
marketname = "realme V60 Pro"
fingerprint = "realme/rado/rado:15/AP3A.241005.015.A1/rado.241005.001:user/release-keys"

[templates."realme_rmx3946"]
manufacturer = "realme"
brand = "realme"
model = "RMX3946"
device = "rado"
product = "rado"
name = "rado"
marketname = "realme V70"
fingerprint = "realme/rado/rado:15/AP3A.241005.015.A1/rado.241005.001:user/release-keys"

[templates."realme_rmx3948"]
manufacturer = "realme"
brand = "realme"
model = "RMX3948"
device = "rado"
product = "rado"
name = "rado"
marketname = "realme V70s"
fingerprint = "realme/rado/rado:15/AP3A.241005.015.A1/rado.241005.001:user/release-keys"

[templates."realme_rmp2108"]
manufacturer = "realme"
brand = "realme"
model = "RMP2108"
device = "tyr"
product = "tyr"
name = "tyr"
marketname = "realme 平板 X"
fingerprint = "realme/tyr/tyr:15/AP3A.241005.015.A1/tyr.241005.001:user/release-keys"

[templates."samsung_gt_i9000"]
manufacturer = "samsung"
brand = "samsung"
model = "GT-I9000"
device = "GT-I9000"
product = "GT-I9000"
marketname = "Samsung Galaxy S"
fingerprint = "samsung/GT-I9000/GT-I9000:15/AP3A.241005.015.A1/GT-I9000.241005.001:user/release-keys"

[templates."samsung_gt_i9100"]
manufacturer = "samsung"
brand = "samsung"
model = "GT-I9100"
device = "GT-I9100"
product = "GT-I9100"
marketname = "Samsung Galaxy S2"
fingerprint = "samsung/GT-I9100/GT-I9100:15/AP3A.241005.015.A1/GT-I9100.241005.001:user/release-keys"

[templates."samsung_sch_i919"]
manufacturer = "samsung"
brand = "samsung"
model = "SCH-I919"
device = "SCH-I919"
product = "SCH-I919"
marketname = "Samsung Galaxy S Duos"
fingerprint = "samsung/SCH-I919/SCH-I919:15/AP3A.241005.015.A1/SCH-I919.241005.001:user/release-keys"

[templates."samsung_gt_i9300"]
manufacturer = "samsung"
brand = "samsung"
model = "GT-I9300"
device = "m0"
product = "m0"
name = "m0"
marketname = "Samsung Galaxy S3"
fingerprint = "samsung/m0/m0:15/AP3A.241005.015.A1/m0.241005.001:user/release-keys"

[templates."samsung_sch_i939d"]
manufacturer = "samsung"
brand = "samsung"
model = "SCH-I939D"
device = "m0ctcduos"
product = "m0ctcduos"
name = "m0ctcduos"
marketname = "Samsung Galaxy S3 电信双卡"
fingerprint = "samsung/m0ctcduos/m0ctcduos:15/AP3A.241005.015.A1/m0ctcduos.241005.001:user/release-keys"

[templates."samsung_gt_i9300i"]
manufacturer = "samsung"
brand = "samsung"
model = "GT-I9300I"
device = "s3ve3g"
product = "s3ve3g"
name = "s3ve3g"
marketname = "Samsung Galaxy S3 Neo+"
fingerprint = "samsung/s3ve3g/s3ve3g:15/AP3A.241005.015.A1/s3ve3g.241005.001:user/release-keys"

[templates."samsung_gt_i8190n"]
manufacturer = "samsung"
brand = "samsung"
model = "GT-I8190N"
device = "golden"
product = "golden"
name = "golden"
marketname = "Samsung Galaxy S3 Mini"
fingerprint = "samsung/golden/golden:15/AP3A.241005.015.A1/golden.241005.001:user/release-keys"

[templates."samsung_gt_i9500"]
manufacturer = "samsung"
brand = "samsung"
model = "GT-I9500"
device = "ja3g"
product = "ja3g"
name = "ja3g"
marketname = "Samsung Galaxy S4"
fingerprint = "samsung/ja3g/ja3g:15/AP3A.241005.015.A1/ja3g.241005.001:user/release-keys"

[templates."samsung_sm_c101"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-C101"
device = "mproject3g"
product = "mproject3g"
name = "mproject3g"
marketname = "Samsung Galaxy S4 zoom"
fingerprint = "samsung/mproject3g/mproject3g:15/AP3A.241005.015.A1/mproject3g.241005.001:user/release-keys"

[templates."samsung_sm_g9009d"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9009D"
device = "k3g"
product = "k3g"
name = "k3g"
marketname = "Samsung Galaxy S5"
fingerprint = "samsung/k3g/k3g:15/AP3A.241005.015.A1/k3g.241005.001:user/release-keys"

[templates."samsung_sm_g9006v"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9006V"
device = "klte"
product = "klte"
name = "klte"
marketname = "Samsung Galaxy S5 联通 4G 单卡版"
fingerprint = "samsung/klte/klte:15/AP3A.241005.015.A1/klte.241005.001:user/release-keys"

[templates."samsung_sm_g9008v"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9008V"
device = "klte"
product = "klte"
name = "klte"
marketname = "Samsung Galaxy S5 移动 4G 单卡版"
fingerprint = "samsung/klte/klte:15/AP3A.241005.015.A1/klte.241005.001:user/release-keys"

[templates."samsung_sm_g9200"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9200"
device = "zerofltechn"
product = "zerofltechn"
name = "zerofltechn"
marketname = "Samsung Galaxy S6"
fingerprint = "samsung/zerofltechn/zerofltechn:15/AP3A.241005.015.A1/zerofltechn.241005.001:user/release-keys"

[templates."samsung_sm_g9250"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9250"
device = "zeroltechn"
product = "zeroltechn"
name = "zeroltechn"
marketname = "Samsung Galaxy S6 edge"
fingerprint = "samsung/zeroltechn/zeroltechn:15/AP3A.241005.015.A1/zeroltechn.241005.001:user/release-keys"

[templates."samsung_sm_g9280"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9280"
device = "zenltechn"
product = "zenltechn"
name = "zenltechn"
marketname = "Samsung Galaxy S6 edge+"
fingerprint = "samsung/zenltechn/zenltechn:15/AP3A.241005.015.A1/zenltechn.241005.001:user/release-keys"

[templates."samsung_sm_g9300"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9300"
device = "heroqltechn"
product = "heroqltechn"
name = "heroqltechn"
marketname = "Samsung Galaxy S7"
fingerprint = "samsung/heroqltechn/heroqltechn:15/AP3A.241005.015.A1/heroqltechn.241005.001:user/release-keys"

[templates."samsung_sm_g9350"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9350"
device = "hero2qltechn"
product = "hero2qltechn"
name = "hero2qltechn"
marketname = "Samsung Galaxy S7 edge"
fingerprint = "samsung/hero2qltechn/hero2qltechn:15/AP3A.241005.015.A1/hero2qltechn.241005.001:user/release-keys"

[templates."samsung_sm_g9500"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9500"
device = "dreamqltechn"
product = "dreamqltechn"
name = "dreamqltechn"
marketname = "Samsung Galaxy S8"
fingerprint = "samsung/dreamqltechn/dreamqltechn:15/AP3A.241005.015.A1/dreamqltechn.241005.001:user/release-keys"

[templates."samsung_sm_g9508"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9508"
device = "dreamqltecmcc"
product = "dreamqltecmcc"
name = "dreamqltecmcc"
marketname = "Samsung Galaxy S8 4G+"
fingerprint = "samsung/dreamqltecmcc/dreamqltecmcc:15/AP3A.241005.015.A1/dreamqltecmcc.241005.001:user/release-keys"

[templates."samsung_sm_g9550"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9550"
device = "dream2qltechn"
product = "dream2qltechn"
name = "dream2qltechn"
marketname = "Samsung Galaxy S8+"
fingerprint = "samsung/dream2qltechn/dream2qltechn:15/AP3A.241005.015.A1/dream2qltechn.241005.001:user/release-keys"

[templates."samsung_sm_g9600_ds"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9600/DS"
device = "starqltechn"
product = "starqltechn"
name = "starqltechn"
marketname = "Samsung Galaxy S9"
fingerprint = "samsung/starqltechn/starqltechn:15/AP3A.241005.015.A1/starqltechn.241005.001:user/release-keys"

[templates."samsung_sm_g9608_ds"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9608/DS"
device = "starqltecmcc"
product = "starqltecmcc"
name = "starqltecmcc"
marketname = "Samsung Galaxy S9 4G+"
fingerprint = "samsung/starqltecmcc/starqltecmcc:15/AP3A.241005.015.A1/starqltecmcc.241005.001:user/release-keys"

[templates."samsung_sm_g9650_ds"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9650/DS"
device = "star2qltechn"
product = "star2qltechn"
name = "star2qltechn"
marketname = "Samsung Galaxy S9+"
fingerprint = "samsung/star2qltechn/star2qltechn:15/AP3A.241005.015.A1/star2qltechn.241005.001:user/release-keys"

[templates."samsung_sm_g8750"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G8750"
device = "dreamliteqltechn"
product = "dreamliteqltechn"
name = "dreamliteqltechn"
marketname = "Samsung Galaxy S 轻奢版"
fingerprint = "samsung/dreamliteqltechn/dreamliteqltechn:15/AP3A.241005.015.A1/dreamliteqltechn.241005.001:user/release-keys"

[templates."samsung_sm_g9700"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9700"
device = "beyond0q"
product = "beyond0q"
name = "beyond0q"
marketname = "Samsung Galaxy S10e"
fingerprint = "samsung/beyond0q/beyond0q:15/AP3A.241005.015.A1/beyond0q.241005.001:user/release-keys"

[templates."samsung_sm_g9708"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9708"
device = "beyond0q"
product = "beyond0q"
name = "beyond0q"
marketname = "Samsung Galaxy S10e 4G+"
fingerprint = "samsung/beyond0q/beyond0q:15/AP3A.241005.015.A1/beyond0q.241005.001:user/release-keys"

[templates."samsung_sm_g9730"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9730"
device = "beyond1q"
product = "beyond1q"
name = "beyond1q"
marketname = "Samsung Galaxy S10"
fingerprint = "samsung/beyond1q/beyond1q:15/AP3A.241005.015.A1/beyond1q.241005.001:user/release-keys"

[templates."samsung_sm_g9738"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9738"
device = "beyond1q"
product = "beyond1q"
name = "beyond1q"
marketname = "Samsung Galaxy S10 4G+"
fingerprint = "samsung/beyond1q/beyond1q:15/AP3A.241005.015.A1/beyond1q.241005.001:user/release-keys"

[templates."samsung_sm_g9750"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9750"
device = "beyond2q"
product = "beyond2q"
name = "beyond2q"
marketname = "Samsung Galaxy S10+"
fingerprint = "samsung/beyond2q/beyond2q:15/AP3A.241005.015.A1/beyond2q.241005.001:user/release-keys"

[templates."samsung_sm_g9758"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9758"
device = "beyond2q"
product = "beyond2q"
name = "beyond2q"
marketname = "Samsung Galaxy S10+ 4G+"
fingerprint = "samsung/beyond2q/beyond2q:15/AP3A.241005.015.A1/beyond2q.241005.001:user/release-keys"

[templates."samsung_sm_g9810"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9810"
device = "x1q"
product = "x1q"
name = "x1q"
marketname = "Samsung Galaxy S20 5G"
fingerprint = "samsung/x1q/x1q:15/AP3A.241005.015.A1/x1q.241005.001:user/release-keys"

[templates."samsung_sm_g9860"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9860"
device = "y2q"
product = "y2q"
name = "y2q"
marketname = "Samsung Galaxy S20+ 5G"
fingerprint = "samsung/y2q/y2q:15/AP3A.241005.015.A1/y2q.241005.001:user/release-keys"

[templates."samsung_sm_g9880"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9880"
device = "z3q"
product = "z3q"
name = "z3q"
marketname = "Samsung Galaxy S20 Ultra 5G"
fingerprint = "samsung/z3q/z3q:15/AP3A.241005.015.A1/z3q.241005.001:user/release-keys"

[templates."samsung_sm_g7810"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G7810"
device = "r8q"
product = "r8q"
name = "r8q"
marketname = "Samsung Galaxy S20 FE 5G"
fingerprint = "samsung/r8q/r8q:15/AP3A.241005.015.A1/r8q.241005.001:user/release-keys"

[templates."samsung_sm_g9910"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9910"
device = "o1q"
product = "o1q"
name = "o1q"
marketname = "Samsung Galaxy S21 5G"
fingerprint = "samsung/o1q/o1q:15/AP3A.241005.015.A1/o1q.241005.001:user/release-keys"

[templates."samsung_sm_g9960"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9960"
device = "t2q"
product = "t2q"
name = "t2q"
marketname = "Samsung Galaxy S21+ 5G"
fingerprint = "samsung/t2q/t2q:15/AP3A.241005.015.A1/t2q.241005.001:user/release-keys"

[templates."samsung_sm_g9980"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9980"
device = "p3q"
product = "p3q"
name = "p3q"
marketname = "Samsung Galaxy S21 Ultra 5G"
fingerprint = "samsung/p3q/p3q:15/AP3A.241005.015.A1/p3q.241005.001:user/release-keys"

[templates."samsung_sm_g9900"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G9900"
device = "r9q"
product = "r9q"
name = "r9q"
marketname = "Samsung Galaxy S21 FE 5G"
fingerprint = "samsung/r9q/r9q:15/AP3A.241005.015.A1/r9q.241005.001:user/release-keys"

[templates."samsung_sm_s9010"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9010"
device = "r0q"
product = "r0q"
name = "r0q"
marketname = "Samsung Galaxy S22"
fingerprint = "samsung/r0q/r0q:15/AP3A.241005.015.A1/r0q.241005.001:user/release-keys"

[templates."samsung_sm_s9060"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9060"
device = "g0q"
product = "g0q"
name = "g0q"
marketname = "Samsung Galaxy S22+"
fingerprint = "samsung/g0q/g0q:15/AP3A.241005.015.A1/g0q.241005.001:user/release-keys"

[templates."samsung_sm_s9080"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9080"
device = "b0q"
product = "b0q"
name = "b0q"
marketname = "Samsung Galaxy S22 Ultra"
fingerprint = "samsung/b0q/b0q:15/AP3A.241005.015.A1/b0q.241005.001:user/release-keys"

[templates."samsung_sm_s9110"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9110"
device = "dm1q"
product = "dm1q"
name = "dm1q"
marketname = "Samsung Galaxy S23"
fingerprint = "samsung/dm1q/dm1q:15/AP3A.241005.015.A1/dm1q.241005.001:user/release-keys"

[templates."samsung_sm_s9160"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9160"
device = "dm2q"
product = "dm2q"
name = "dm2q"
marketname = "Samsung Galaxy S23+"
fingerprint = "samsung/dm2q/dm2q:15/AP3A.241005.015.A1/dm2q.241005.001:user/release-keys"

[templates."samsung_sm_s9180"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9180"
device = "dm3q"
product = "dm3q"
name = "dm3q"
marketname = "Samsung Galaxy S23 Ultra"
fingerprint = "samsung/dm3q/dm3q:15/AP3A.241005.015.A1/dm3q.241005.001:user/release-keys"

[templates."samsung_sm_s7110"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S7110"
device = "r11q"
product = "r11q"
name = "r11q"
marketname = "Samsung Galaxy S23 FE"
fingerprint = "samsung/r11q/r11q:15/AP3A.241005.015.A1/r11q.241005.001:user/release-keys"

[templates."samsung_sm_s9210"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9210"
device = "e1q"
product = "e1q"
name = "e1q"
marketname = "Samsung Galaxy S24"
fingerprint = "samsung/e1q/e1q:15/AP3A.241005.015.A1/e1q.241005.001:user/release-keys"

[templates."samsung_sm_s9260"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9260"
device = "e2q"
product = "e2q"
name = "e2q"
marketname = "Samsung Galaxy S24+"
fingerprint = "samsung/e2q/e2q:15/AP3A.241005.015.A1/e2q.241005.001:user/release-keys"

[templates."samsung_sm_s9280"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9280"
device = "e3q"
product = "e3q"
name = "e3q"
marketname = "Samsung Galaxy S24 Ultra"
fingerprint = "samsung/e3q/e3q:15/AP3A.241005.015.A1/e3q.241005.001:user/release-keys"

[templates."samsung_sm_s9310"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9310"
device = "pa1q"
product = "pa1q"
name = "pa1q"
marketname = "Samsung Galaxy S25"
fingerprint = "samsung/pa1q/pa1q:15/AP3A.241005.015.A1/pa1q.241005.001:user/release-keys"

[templates."samsung_sm_s9360"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9360"
device = "pa2q"
product = "pa2q"
name = "pa2q"
marketname = "Samsung Galaxy S25+"
fingerprint = "samsung/pa2q/pa2q:15/AP3A.241005.015.A1/pa2q.241005.001:user/release-keys"

[templates."samsung_sm_s9370"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9370"
device = "psq"
product = "psq"
name = "psq"
marketname = "Samsung Galaxy S25 Edge"
fingerprint = "samsung/psq/psq:15/AP3A.241005.015.A1/psq.241005.001:user/release-keys"

[templates."samsung_sm_s9380"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9380"
device = "pa3q"
product = "pa3q"
name = "pa3q"
marketname = "Samsung Galaxy S25 Ultra"
fingerprint = "samsung/pa3q/pa3q:15/AP3A.241005.015.A1/pa3q.241005.001:user/release-keys"

[templates."samsung_sm_s9420"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9420"
device = "m1q"
product = "m1q"
name = "m1q"
marketname = "Samsung Galaxy S26"
fingerprint = "samsung/m1q/m1q:15/AP3A.241005.015.A1/m1q.241005.001:user/release-keys"

[templates."samsung_sm_s9470"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9470"
device = "m2q"
product = "m2q"
name = "m2q"
marketname = "Samsung Galaxy S26+"
fingerprint = "samsung/m2q/m2q:15/AP3A.241005.015.A1/m2q.241005.001:user/release-keys"

[templates."samsung_sm_s9480"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-S9480"
device = "m3q"
product = "m3q"
name = "m3q"
marketname = "Samsung Galaxy S26 Ultra"
fingerprint = "samsung/m3q/m3q:15/AP3A.241005.015.A1/m3q.241005.001:user/release-keys"

[templates."samsung_gt_i9220"]
manufacturer = "samsung"
brand = "samsung"
model = "GT-I9220"
device = "GT-I9220"
product = "GT-I9220"
marketname = "Samsung Galaxy Note"
fingerprint = "samsung/GT-I9220/GT-I9220:15/AP3A.241005.015.A1/GT-I9220.241005.001:user/release-keys"

[templates."samsung_gt_n7100"]
manufacturer = "samsung"
brand = "samsung"
model = "GT-N7100"
device = "t03gchn"
product = "t03gchn"
name = "t03gchn"
marketname = "Samsung Galaxy Note2"
fingerprint = "samsung/t03gchn/t03gchn:15/AP3A.241005.015.A1/t03gchn.241005.001:user/release-keys"

[templates."samsung_sm_n9002"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-N9002"
device = "hlte"
product = "hlte"
name = "hlte"
marketname = "Samsung Galaxy Note3"
fingerprint = "samsung/hlte/hlte:15/AP3A.241005.015.A1/hlte.241005.001:user/release-keys"

[templates."samsung_sm_n9008s"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-N9008S"
device = "hlte"
product = "hlte"
name = "hlte"
marketname = "Samsung Galaxy Note3 4G"
fingerprint = "samsung/hlte/hlte:15/AP3A.241005.015.A1/hlte.241005.001:user/release-keys"

[templates."samsung_sm_n7506v"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-N7506V"
device = "hllte"
product = "hllte"
name = "hllte"
marketname = "Samsung Galaxy Note3 Lite"
fingerprint = "samsung/hllte/hllte:15/AP3A.241005.015.A1/hllte.241005.001:user/release-keys"

[templates."samsung_sm_n9100"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-N9100"
device = "trltechn"
product = "trltechn"
name = "trltechn"
marketname = "Samsung Galaxy Note4"
fingerprint = "samsung/trltechn/trltechn:15/AP3A.241005.015.A1/trltechn.241005.001:user/release-keys"

[templates."samsung_sm_n9150"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-N9150"
device = "tbltechn"
product = "tbltechn"
name = "tbltechn"
marketname = "Samsung Galaxy Note Edge"
fingerprint = "samsung/tbltechn/tbltechn:15/AP3A.241005.015.A1/tbltechn.241005.001:user/release-keys"

[templates."samsung_sm_n9200"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-N9200"
device = "nobleltechn"
product = "nobleltechn"
name = "nobleltechn"
marketname = "Samsung Galaxy Note5"
fingerprint = "samsung/nobleltechn/nobleltechn:15/AP3A.241005.015.A1/nobleltechn.241005.001:user/release-keys"

[templates."samsung_sm_n9300"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-N9300"
device = "graceqltechn"
product = "graceqltechn"
name = "graceqltechn"
marketname = "Samsung Galaxy Note7"
fingerprint = "samsung/graceqltechn/graceqltechn:15/AP3A.241005.015.A1/graceqltechn.241005.001:user/release-keys"

[templates."samsung_sm_n9500"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-N9500"
device = "greatqltechn"
product = "greatqltechn"
name = "greatqltechn"
marketname = "Samsung Galaxy Note8"
fingerprint = "samsung/greatqltechn/greatqltechn:15/AP3A.241005.015.A1/greatqltechn.241005.001:user/release-keys"

[templates."samsung_sm_n9508"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-N9508"
device = "greatqltecmcc"
product = "greatqltecmcc"
name = "greatqltecmcc"
marketname = "Samsung Galaxy Note8 4G+"
fingerprint = "samsung/greatqltecmcc/greatqltecmcc:15/AP3A.241005.015.A1/greatqltecmcc.241005.001:user/release-keys"

[templates."samsung_sm_n9600"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-N9600"
device = "crownqltechn"
product = "crownqltechn"
name = "crownqltechn"
marketname = "Samsung Galaxy Note9"
fingerprint = "samsung/crownqltechn/crownqltechn:15/AP3A.241005.015.A1/crownqltechn.241005.001:user/release-keys"

[templates."samsung_sm_n9608"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-N9608"
device = "crownqltecmcc"
product = "crownqltecmcc"
name = "crownqltecmcc"
marketname = "Samsung Galaxy Note9 4G+"
fingerprint = "samsung/crownqltecmcc/crownqltecmcc:15/AP3A.241005.015.A1/crownqltecmcc.241005.001:user/release-keys"

[templates."samsung_sm_n9700"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-N9700"
device = "d1q"
product = "d1q"
name = "d1q"
marketname = "Samsung Galaxy Note10"
fingerprint = "samsung/d1q/d1q:15/AP3A.241005.015.A1/d1q.241005.001:user/release-keys"

[templates."samsung_sm_n9760"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-N9760"
device = "d2xq"
product = "d2xq"
name = "d2xq"
marketname = "Samsung Galaxy Note10+ 5G"
fingerprint = "samsung/d2xq/d2xq:15/AP3A.241005.015.A1/d2xq.241005.001:user/release-keys"

[templates."samsung_sm_n9810"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-N9810"
device = "c1q"
product = "c1q"
name = "c1q"
marketname = "Samsung Galaxy Note20 5G"
fingerprint = "samsung/c1q/c1q:15/AP3A.241005.015.A1/c1q.241005.001:user/release-keys"

[templates."samsung_sm_n9860"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-N9860"
device = "c2q"
product = "c2q"
name = "c2q"
marketname = "Samsung Galaxy Note20 Ultra 5G"
fingerprint = "samsung/c2q/c2q:15/AP3A.241005.015.A1/c2q.241005.001:user/release-keys"

[templates."samsung_sm_f9000"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F9000"
device = "winner"
product = "winner"
name = "winner"
marketname = "Samsung Galaxy Fold"
fingerprint = "samsung/winner/winner:15/AP3A.241005.015.A1/winner.241005.001:user/release-keys"

[templates."samsung_sm_f9160"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F9160"
device = "f2q"
product = "f2q"
name = "f2q"
marketname = "Samsung Galaxy Z Fold2 5G"
fingerprint = "samsung/f2q/f2q:15/AP3A.241005.015.A1/f2q.241005.001:user/release-keys"

[templates."samsung_sm_f9260"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F9260"
device = "q2q"
product = "q2q"
name = "q2q"
marketname = "Samsung Galaxy Z Fold3 5G"
fingerprint = "samsung/q2q/q2q:15/AP3A.241005.015.A1/q2q.241005.001:user/release-keys"

[templates."samsung_sm_f9360"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F9360"
device = "q4q"
product = "q4q"
name = "q4q"
marketname = "Samsung Galaxy Z Fold4"
fingerprint = "samsung/q4q/q4q:15/AP3A.241005.015.A1/q4q.241005.001:user/release-keys"

[templates."samsung_sm_f9460"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F9460"
device = "q5q"
product = "q5q"
name = "q5q"
marketname = "Samsung Galaxy Z Fold5"
fingerprint = "samsung/q5q/q5q:15/AP3A.241005.015.A1/q5q.241005.001:user/release-keys"

[templates."samsung_sm_f9560"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F9560"
device = "q6q"
product = "q6q"
name = "q6q"
marketname = "Samsung Galaxy Z Fold6"
fingerprint = "samsung/q6q/q6q:15/AP3A.241005.015.A1/q6q.241005.001:user/release-keys"

[templates."samsung_sm_f9660"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F9660"
device = "q7q"
product = "q7q"
name = "q7q"
marketname = "Samsung Galaxy Z Fold7"
fingerprint = "samsung/q7q/q7q:15/AP3A.241005.015.A1/q7q.241005.001:user/release-keys"

[templates."samsung_sm_f9680"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F9680"
device = "q7mq"
product = "q7mq"
name = "q7mq"
marketname = "Samsung Galaxy Z TriFold"
fingerprint = "samsung/q7mq/q7mq:15/AP3A.241005.015.A1/q7mq.241005.001:user/release-keys"

[templates."samsung_sm_f9710"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F9710"
device = "h8q"
product = "h8q"
name = "h8q"
marketname = "Samsung Galaxy Z Fold8"
fingerprint = "samsung/h8q/h8q:15/AP3A.241005.015.A1/h8q.241005.001:user/release-keys"

[templates."samsung_sm_f9760"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F9760"
device = "q8q"
product = "q8q"
name = "q8q"
marketname = "Samsung Galaxy Z Fold8 Ultra"
fingerprint = "samsung/q8q/q8q:15/AP3A.241005.015.A1/q8q.241005.001:user/release-keys"

[templates."samsung_sm_f7000"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F7000"
device = "bloomq"
product = "bloomq"
name = "bloomq"
marketname = "Samsung Galaxy Z Flip"
fingerprint = "samsung/bloomq/bloomq:15/AP3A.241005.015.A1/bloomq.241005.001:user/release-keys"

[templates."samsung_sm_f7070"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F7070"
device = "bloomxq"
product = "bloomxq"
name = "bloomxq"
marketname = "Samsung Galaxy Z Flip 5G"
fingerprint = "samsung/bloomxq/bloomxq:15/AP3A.241005.015.A1/bloomxq.241005.001:user/release-keys"

[templates."samsung_sm_f7110"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F7110"
device = "b2q"
product = "b2q"
name = "b2q"
marketname = "Samsung Galaxy Z Flip3 5G"
fingerprint = "samsung/b2q/b2q:15/AP3A.241005.015.A1/b2q.241005.001:user/release-keys"

[templates."samsung_sm_f7210"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F7210"
device = "b4q"
product = "b4q"
name = "b4q"
marketname = "Samsung Galaxy Z Flip4"
fingerprint = "samsung/b4q/b4q:15/AP3A.241005.015.A1/b4q.241005.001:user/release-keys"

[templates."samsung_sm_f7310"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F7310"
device = "b5q"
product = "b5q"
name = "b5q"
marketname = "Samsung Galaxy Z Flip5"
fingerprint = "samsung/b5q/b5q:15/AP3A.241005.015.A1/b5q.241005.001:user/release-keys"

[templates."samsung_sm_f7410"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F7410"
device = "b6q"
product = "b6q"
name = "b6q"
marketname = "Samsung Galaxy Z Flip6"
fingerprint = "samsung/b6q/b6q:15/AP3A.241005.015.A1/b6q.241005.001:user/release-keys"

[templates."samsung_sm_f7660"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F7660"
device = "b7s"
product = "b7s"
name = "b7s"
marketname = "Samsung Galaxy Z Flip7"
fingerprint = "samsung/b7s/b7s:15/AP3A.241005.015.A1/b7s.241005.001:user/release-keys"

[templates."samsung_sm_f7610"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F7610"
device = "b7r"
product = "b7r"
name = "b7r"
marketname = "Samsung Galaxy Z Flip7 FE"
fingerprint = "samsung/b7r/b7r:15/AP3A.241005.015.A1/b7r.241005.001:user/release-keys"

[templates."samsung_sm_f7760"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-F7760"
device = "b8q"
product = "b8q"
name = "b8q"
marketname = "Samsung Galaxy Z Flip8"
fingerprint = "samsung/b8q/b8q:15/AP3A.241005.015.A1/b8q.241005.001:user/release-keys"

[templates."samsung_sm_a3000"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A3000"
device = "a3ltechn"
product = "a3ltechn"
name = "a3ltechn"
marketname = "Samsung Galaxy A3"
fingerprint = "samsung/a3ltechn/a3ltechn:15/AP3A.241005.015.A1/a3ltechn.241005.001:user/release-keys"

[templates."samsung_sm_a5000"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A5000"
device = "a5ltechn"
product = "a5ltechn"
name = "a5ltechn"
marketname = "Samsung Galaxy A5"
fingerprint = "samsung/a5ltechn/a5ltechn:15/AP3A.241005.015.A1/a5ltechn.241005.001:user/release-keys"

[templates."samsung_sm_a7000"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A7000"
device = "a7ltechn"
product = "a7ltechn"
name = "a7ltechn"
marketname = "Samsung Galaxy A7"
fingerprint = "samsung/a7ltechn/a7ltechn:15/AP3A.241005.015.A1/a7ltechn.241005.001:user/release-keys"

[templates."samsung_sm_a8000"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A8000"
device = "a8ltechn"
product = "a8ltechn"
name = "a8ltechn"
marketname = "Samsung Galaxy A8"
fingerprint = "samsung/a8ltechn/a8ltechn:15/AP3A.241005.015.A1/a8ltechn.241005.001:user/release-keys"

[templates."samsung_sm_a5108"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A5108"
device = "a5xeltecmcc"
product = "a5xeltecmcc"
name = "a5xeltecmcc"
marketname = "Samsung Galaxy A5 移动定制疾速版"
fingerprint = "samsung/a5xeltecmcc/a5xeltecmcc:15/AP3A.241005.015.A1/a5xeltecmcc.241005.001:user/release-keys"

[templates."samsung_sm_a7108"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A7108"
device = "a7xeltecmcc"
product = "a7xeltecmcc"
name = "a7xeltecmcc"
marketname = "Samsung Galaxy A7 移动定制疾速版"
fingerprint = "samsung/a7xeltecmcc/a7xeltecmcc:15/AP3A.241005.015.A1/a7xeltecmcc.241005.001:user/release-keys"

[templates."samsung_sm_a9000"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A9000"
device = "a9xltechn"
product = "a9xltechn"
name = "a9xltechn"
marketname = "Samsung Galaxy A9"
fingerprint = "samsung/a9xltechn/a9xltechn:15/AP3A.241005.015.A1/a9xltechn.241005.001:user/release-keys"

[templates."samsung_sm_g8850"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G8850"
device = "astarqltechn"
product = "astarqltechn"
name = "astarqltechn"
marketname = "Samsung Galaxy A9 Star"
fingerprint = "samsung/astarqltechn/astarqltechn:15/AP3A.241005.015.A1/astarqltechn.241005.001:user/release-keys"

[templates."samsung_sm_g8858"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G8858"
device = "astarqltecmcc"
product = "astarqltecmcc"
name = "astarqltecmcc"
marketname = "Samsung Galaxy A9 Star 4G+"
fingerprint = "samsung/astarqltecmcc/astarqltecmcc:15/AP3A.241005.015.A1/astarqltecmcc.241005.001:user/release-keys"

[templates."samsung_sm_a6050"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A6050"
device = "a6pltechn"
product = "a6pltechn"
name = "a6pltechn"
marketname = "Samsung Galaxy A9 Star Lite"
fingerprint = "samsung/a6pltechn/a6pltechn:15/AP3A.241005.015.A1/a6pltechn.241005.001:user/release-keys"

[templates."samsung_sm_a6058"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A6058"
device = "a6pltecmcc"
product = "a6pltecmcc"
name = "a6pltecmcc"
marketname = "Samsung Galaxy A9 Star Lite 4G+"
fingerprint = "samsung/a6pltecmcc/a6pltecmcc:15/AP3A.241005.015.A1/a6pltecmcc.241005.001:user/release-keys"

[templates."samsung_sm_g6200"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G6200"
device = "phoenix"
product = "phoenix"
name = "phoenix"
marketname = "Samsung Galaxy A6s"
fingerprint = "samsung/phoenix/phoenix:15/AP3A.241005.015.A1/phoenix.241005.001:user/release-keys"

[templates."samsung_sm_g8870"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G8870"
device = "a8sqltechn"
product = "a8sqltechn"
name = "a8sqltechn"
marketname = "Samsung Galaxy A8s"
fingerprint = "samsung/a8sqltechn/a8sqltechn:15/AP3A.241005.015.A1/a8sqltechn.241005.001:user/release-keys"

[templates."samsung_sm_a9200"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A9200"
device = "a9y18qltechn"
product = "a9y18qltechn"
name = "a9y18qltechn"
marketname = "Samsung Galaxy A9s"
fingerprint = "samsung/a9y18qltechn/a9y18qltechn:15/AP3A.241005.015.A1/a9y18qltechn.241005.001:user/release-keys"

[templates."samsung_sm_a2070"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A2070"
device = "a20s"
product = "a20s"
name = "a20s"
marketname = "Samsung Galaxy A20s"
fingerprint = "samsung/a20s/a20s:15/AP3A.241005.015.A1/a20s.241005.001:user/release-keys"

[templates."samsung_sm_a3050"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A3050"
device = "a30c"
product = "a30c"
name = "a30c"
marketname = "Samsung Galaxy A40s"
fingerprint = "samsung/a30c/a30c:15/AP3A.241005.015.A1/a30c.241005.001:user/release-keys"

[templates."samsung_sm_a3058"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A3058"
device = "a30c"
product = "a30c"
name = "a30c"
marketname = "Samsung Galaxy A40s 4G+"
fingerprint = "samsung/a30c/a30c:15/AP3A.241005.015.A1/a30c.241005.001:user/release-keys"

[templates."samsung_sm_a5070"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A5070"
device = "a50s"
product = "a50s"
name = "a50s"
marketname = "Samsung Galaxy A50s"
fingerprint = "samsung/a50s/a50s:15/AP3A.241005.015.A1/a50s.241005.001:user/release-keys"

[templates."samsung_sm_a6060"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A6060"
device = "a60q"
product = "a60q"
name = "a60q"
marketname = "Samsung Galaxy A60"
fingerprint = "samsung/a60q/a60q:15/AP3A.241005.015.A1/a60q.241005.001:user/release-keys"

[templates."samsung_sm_a7050"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A7050"
device = "a70q"
product = "a70q"
name = "a70q"
marketname = "Samsung Galaxy A70"
fingerprint = "samsung/a70q/a70q:15/AP3A.241005.015.A1/a70q.241005.001:user/release-keys"

[templates."samsung_sm_a7070"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A7070"
device = "a70s"
product = "a70s"
name = "a70s"
marketname = "Samsung Galaxy A70s"
fingerprint = "samsung/a70s/a70s:15/AP3A.241005.015.A1/a70s.241005.001:user/release-keys"

[templates."samsung_sm_a8050"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A8050"
device = "r1q"
product = "r1q"
name = "r1q"
marketname = "Samsung Galaxy A80"
fingerprint = "samsung/r1q/r1q:15/AP3A.241005.015.A1/r1q.241005.001:user/release-keys"

[templates."samsung_sm_a9080"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A9080"
device = "r3q"
product = "r3q"
name = "r3q"
marketname = "Samsung Galaxy A90 5G"
fingerprint = "samsung/r3q/r3q:15/AP3A.241005.015.A1/r3q.241005.001:user/release-keys"

[templates."samsung_sm_a5160"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A5160"
device = "a51x"
product = "a51x"
name = "a51x"
marketname = "Samsung Galaxy A51 5G"
fingerprint = "samsung/a51x/a51x:15/AP3A.241005.015.A1/a51x.241005.001:user/release-keys"

[templates."samsung_sm_a7160"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A7160"
device = "a71x"
product = "a71x"
name = "a71x"
marketname = "Samsung Galaxy A71 5G"
fingerprint = "samsung/a71x/a71x:15/AP3A.241005.015.A1/a71x.241005.001:user/release-keys"

[templates."samsung_sm_a5260"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A5260"
device = "a52xq"
product = "a52xq"
name = "a52xq"
marketname = "Samsung Galaxy A52 5G"
fingerprint = "samsung/a52xq/a52xq:15/AP3A.241005.015.A1/a52xq.241005.001:user/release-keys"

[templates."samsung_sm_a5360"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A5360"
device = "a53x"
product = "a53x"
name = "a53x"
marketname = "Samsung Galaxy A53 5G"
fingerprint = "samsung/a53x/a53x:15/AP3A.241005.015.A1/a53x.241005.001:user/release-keys"

[templates."samsung_sm_a5460"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A5460"
device = "a54x"
product = "a54x"
name = "a54x"
marketname = "Samsung Galaxy A54 5G"
fingerprint = "samsung/a54x/a54x:15/AP3A.241005.015.A1/a54x.241005.001:user/release-keys"

[templates."samsung_sm_a5560"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A5560"
device = "a55x"
product = "a55x"
name = "a55x"
marketname = "Samsung Galaxy A55 5G"
fingerprint = "samsung/a55x/a55x:15/AP3A.241005.015.A1/a55x.241005.001:user/release-keys"

[templates."samsung_sm_a5660"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A5660"
device = "a56x"
product = "a56x"
name = "a56x"
marketname = "Samsung Galaxy A56 5G"
fingerprint = "samsung/a56x/a56x:15/AP3A.241005.015.A1/a56x.241005.001:user/release-keys"

[templates."samsung_sm_a5760"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-A5760"
device = "a57x"
product = "a57x"
name = "a57x"
marketname = "Samsung Galaxy A57 5G"
fingerprint = "samsung/a57x/a57x:15/AP3A.241005.015.A1/a57x.241005.001:user/release-keys"

[templates."samsung_sm_e5260"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-E5260"
device = "f52x"
product = "f52x"
name = "f52x"
marketname = "Samsung Galaxy F52 5G"
fingerprint = "samsung/f52x/f52x:15/AP3A.241005.015.A1/f52x.241005.001:user/release-keys"

[templates."samsung_sm_m3070"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-M3070"
device = "m30s"
product = "m30s"
name = "m30s"
marketname = "Samsung Galaxy M30s"
fingerprint = "samsung/m30s/m30s:15/AP3A.241005.015.A1/m30s.241005.001:user/release-keys"

[templates."samsung_sm_c5000"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-C5000"
device = "c5ltechn"
product = "c5ltechn"
name = "c5ltechn"
marketname = "Samsung Galaxy C5"
fingerprint = "samsung/c5ltechn/c5ltechn:15/AP3A.241005.015.A1/c5ltechn.241005.001:user/release-keys"

[templates."samsung_sm_c5010"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-C5010"
device = "c5proltechn"
product = "c5proltechn"
name = "c5proltechn"
marketname = "Samsung Galaxy C5 Pro"
fingerprint = "samsung/c5proltechn/c5proltechn:15/AP3A.241005.015.A1/c5proltechn.241005.001:user/release-keys"

[templates."samsung_sm_c5018"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-C5018"
device = "c5proltechn"
product = "c5proltechn"
name = "c5proltechn"
marketname = "Samsung Galaxy C5 Pro 4G+"
fingerprint = "samsung/c5proltechn/c5proltechn:15/AP3A.241005.015.A1/c5proltechn.241005.001:user/release-keys"

[templates."samsung_sm_c7000"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-C7000"
device = "c7ltechn"
product = "c7ltechn"
name = "c7ltechn"
marketname = "Samsung Galaxy C7"
fingerprint = "samsung/c7ltechn/c7ltechn:15/AP3A.241005.015.A1/c7ltechn.241005.001:user/release-keys"

[templates."samsung_sm_c7010"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-C7010"
device = "c7proltechn"
product = "c7proltechn"
name = "c7proltechn"
marketname = "Samsung Galaxy C7 Pro"
fingerprint = "samsung/c7proltechn/c7proltechn:15/AP3A.241005.015.A1/c7proltechn.241005.001:user/release-keys"

[templates."samsung_sm_c7018"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-C7018"
device = "c7proltechn"
product = "c7proltechn"
name = "c7proltechn"
marketname = "Samsung Galaxy C7 Pro 4G+"
fingerprint = "samsung/c7proltechn/c7proltechn:15/AP3A.241005.015.A1/c7proltechn.241005.001:user/release-keys"

[templates."samsung_sm_c7100"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-C7100"
device = "jadeltechn"
product = "jadeltechn"
name = "jadeltechn"
marketname = "Samsung Galaxy C8"
fingerprint = "samsung/jadeltechn/jadeltechn:15/AP3A.241005.015.A1/jadeltechn.241005.001:user/release-keys"

[templates."samsung_sm_c7108"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-C7108"
device = "jadeltecmcc"
product = "jadeltecmcc"
name = "jadeltecmcc"
marketname = "Samsung Galaxy C8 4G+"
fingerprint = "samsung/jadeltecmcc/jadeltecmcc:15/AP3A.241005.015.A1/jadeltecmcc.241005.001:user/release-keys"

[templates."samsung_sm_c9000"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-C9000"
device = "c9ltechn"
product = "c9ltechn"
name = "c9ltechn"
marketname = "Samsung Galaxy C9 Pro"
fingerprint = "samsung/c9ltechn/c9ltechn:15/AP3A.241005.015.A1/c9ltechn.241005.001:user/release-keys"

[templates."samsung_sm_c9008"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-C9008"
device = "c9ltechn"
product = "c9ltechn"
name = "c9ltechn"
marketname = "Samsung Galaxy C9 Pro 4G+"
fingerprint = "samsung/c9ltechn/c9ltechn:15/AP3A.241005.015.A1/c9ltechn.241005.001:user/release-keys"

[templates."samsung_sm_c5560"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-C5560"
device = "m55xq"
product = "m55xq"
name = "m55xq"
marketname = "Samsung Galaxy C55 5G"
fingerprint = "samsung/m55xq/m55xq:15/AP3A.241005.015.A1/m55xq.241005.001:user/release-keys"

[templates."samsung_sm_j3109"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-J3109"
device = "j3ltectc"
product = "j3ltectc"
name = "j3ltectc"
marketname = "Samsung Galaxy J3"
fingerprint = "samsung/j3ltectc/j3ltectc:15/AP3A.241005.015.A1/j3ltectc.241005.001:user/release-keys"

[templates."samsung_sm_j5008"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-J5008"
device = "j5ltechn"
product = "j5ltechn"
name = "j5ltechn"
marketname = "Samsung Galaxy J5"
fingerprint = "samsung/j5ltechn/j5ltechn:15/AP3A.241005.015.A1/j5ltechn.241005.001:user/release-keys"

[templates."samsung_sm_j7008"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-J7008"
device = "j7ltechn"
product = "j7ltechn"
name = "j7ltechn"
marketname = "Samsung Galaxy J7"
fingerprint = "samsung/j7ltechn/j7ltechn:15/AP3A.241005.015.A1/j7ltechn.241005.001:user/release-keys"

[templates."samsung_sm_j3110"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-J3110"
device = "j3xproltechn"
product = "j3xproltechn"
name = "j3xproltechn"
marketname = "Samsung Galaxy J3 Pro"
fingerprint = "samsung/j3xproltechn/j3xproltechn:15/AP3A.241005.015.A1/j3xproltechn.241005.001:user/release-keys"

[templates."samsung_sm_j3119s"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-J3119S"
device = "j3xpro6mltechn"
product = "j3xpro6mltechn"
name = "j3xpro6mltechn"
marketname = "Samsung Galaxy J3 Pro 增强版"
fingerprint = "samsung/j3xpro6mltechn/j3xpro6mltechn:15/AP3A.241005.015.A1/j3xpro6mltechn.241005.001:user/release-keys"

[templates."samsung_sm_j3308"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-J3308"
device = "j3y17qltecmcc"
product = "j3y17qltecmcc"
name = "j3y17qltecmcc"
marketname = "Samsung Galaxy J3 4G+"
fingerprint = "samsung/j3y17qltecmcc/j3y17qltecmcc:15/AP3A.241005.015.A1/j3y17qltecmcc.241005.001:user/release-keys"

[templates."samsung_sm_g5500"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G5500"
device = "o5ltechn"
product = "o5ltechn"
name = "o5ltechn"
marketname = "Samsung Galaxy On5"
fingerprint = "samsung/o5ltechn/o5ltechn:15/AP3A.241005.015.A1/o5ltechn.241005.001:user/release-keys"

[templates."samsung_sm_g6000"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G6000"
device = "o7ltechn"
product = "o7ltechn"
name = "o7ltechn"
marketname = "Samsung Galaxy On7"
fingerprint = "samsung/o7ltechn/o7ltechn:15/AP3A.241005.015.A1/o7ltechn.241005.001:user/release-keys"

[templates."samsung_sm_g5510"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G5510"
device = "on5xlltechn"
product = "on5xlltechn"
name = "on5xlltechn"
marketname = "Samsung Galaxy On5 青春版"
fingerprint = "samsung/on5xlltechn/on5xlltechn:15/AP3A.241005.015.A1/on5xlltechn.241005.001:user/release-keys"

[templates."samsung_sm_g5520"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G5520"
device = "on5xfltechn"
product = "on5xfltechn"
name = "on5xfltechn"
marketname = "Samsung Galaxy On5 时尚版"
fingerprint = "samsung/on5xfltechn/on5xfltechn:15/AP3A.241005.015.A1/on5xfltechn.241005.001:user/release-keys"

[templates."samsung_sch_w699"]
manufacturer = "samsung"
brand = "samsung"
model = "SCH-W699"
device = "SCH-W699"
product = "SCH-W699"
marketname = "Samsung W699"
fingerprint = "samsung/SCH-W699/SCH-W699:15/AP3A.241005.015.A1/SCH-W699.241005.001:user/release-keys"

[templates."samsung_sch_w799"]
manufacturer = "samsung"
brand = "samsung"
model = "SCH-W799"
device = "SCH-W799"
product = "SCH-W799"
marketname = "Samsung W799"
fingerprint = "samsung/SCH-W799/SCH-W799:15/AP3A.241005.015.A1/SCH-W799.241005.001:user/release-keys"

[templates."samsung_sch_w899"]
manufacturer = "samsung"
brand = "samsung"
model = "SCH-W899"
device = "SCH-W899"
product = "SCH-W899"
marketname = "Samsung W899"
fingerprint = "samsung/SCH-W899/SCH-W899:15/AP3A.241005.015.A1/SCH-W899.241005.001:user/release-keys"

[templates."samsung_sch_w999"]
manufacturer = "samsung"
brand = "samsung"
model = "SCH-W999"
device = "SCH-W999"
product = "SCH-W999"
marketname = "Samsung W999"
fingerprint = "samsung/SCH-W999/SCH-W999:15/AP3A.241005.015.A1/SCH-W999.241005.001:user/release-keys"

[templates."samsung_sch_w2013"]
manufacturer = "samsung"
brand = "samsung"
model = "SCH-W2013"
device = "m0grandectc"
product = "m0grandectc"
name = "m0grandectc"
marketname = "Samsung W2013"
fingerprint = "samsung/m0grandectc/m0grandectc:15/AP3A.241005.015.A1/m0grandectc.241005.001:user/release-keys"

[templates."samsung_sm_w2014"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W2014"
device = "montblanc3gctc"
product = "montblanc3gctc"
name = "montblanc3gctc"
marketname = "Samsung W2014"
fingerprint = "samsung/montblanc3gctc/montblanc3gctc:15/AP3A.241005.015.A1/montblanc3gctc.241005.001:user/release-keys"

[templates."samsung_sm_w2015"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W2015"
device = "pateklte"
product = "pateklte"
name = "pateklte"
marketname = "Samsung W2015"
fingerprint = "samsung/pateklte/pateklte:15/AP3A.241005.015.A1/pateklte.241005.001:user/release-keys"

[templates."samsung_sm_w2016"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W2016"
device = "royceltectc"
product = "royceltectc"
name = "royceltectc"
marketname = "Samsung W2016"
fingerprint = "samsung/royceltectc/royceltectc:15/AP3A.241005.015.A1/royceltectc.241005.001:user/release-keys"

[templates."samsung_sm_w2017"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W2017"
device = "veyronltectc"
product = "veyronltectc"
name = "veyronltectc"
marketname = "Samsung W2017"
fingerprint = "samsung/veyronltectc/veyronltectc:15/AP3A.241005.015.A1/veyronltectc.241005.001:user/release-keys"

[templates."samsung_sm_w2018"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W2018"
device = "kellyltechn"
product = "kellyltechn"
name = "kellyltechn"
marketname = "Samsung W2018"
fingerprint = "samsung/kellyltechn/kellyltechn:15/AP3A.241005.015.A1/kellyltechn.241005.001:user/release-keys"

[templates."samsung_sm_w2019"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W2019"
device = "lykanlte"
product = "lykanlte"
name = "lykanlte"
marketname = "Samsung W2019"
fingerprint = "samsung/lykanlte/lykanlte:15/AP3A.241005.015.A1/lykanlte.241005.001:user/release-keys"

[templates."samsung_sm_w2020"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W2020"
device = "zodiac"
product = "zodiac"
name = "zodiac"
marketname = "Samsung W20 5G"
fingerprint = "samsung/zodiac/zodiac:15/AP3A.241005.015.A1/zodiac.241005.001:user/release-keys"

[templates."samsung_sm_w2021"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W2021"
device = "victory"
product = "victory"
name = "victory"
marketname = "Samsung W21 5G"
fingerprint = "samsung/victory/victory:15/AP3A.241005.015.A1/victory.241005.001:user/release-keys"

[templates."samsung_sm_w2022"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W2022"
device = "v2q"
product = "v2q"
name = "v2q"
marketname = "Samsung W22 5G"
fingerprint = "samsung/v2q/v2q:15/AP3A.241005.015.A1/v2q.241005.001:user/release-keys"

[templates."samsung_sm_w9023"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W9023"
device = "v4q"
product = "v4q"
name = "v4q"
marketname = "Samsung W23"
fingerprint = "samsung/v4q/v4q:15/AP3A.241005.015.A1/v4q.241005.001:user/release-keys"

[templates."samsung_sm_w7023"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W7023"
device = "e4q"
product = "e4q"
name = "e4q"
marketname = "Samsung W23 Flip"
fingerprint = "samsung/e4q/e4q:15/AP3A.241005.015.A1/e4q.241005.001:user/release-keys"

[templates."samsung_sm_w9024"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W9024"
device = "v5q"
product = "v5q"
name = "v5q"
marketname = "Samsung W24"
fingerprint = "samsung/v5q/v5q:15/AP3A.241005.015.A1/v5q.241005.001:user/release-keys"

[templates."samsung_sm_w7024"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W7024"
device = "e5q"
product = "e5q"
name = "e5q"
marketname = "Samsung W24 Flip"
fingerprint = "samsung/e5q/e5q:15/AP3A.241005.015.A1/e5q.241005.001:user/release-keys"

[templates."samsung_sm_w9025"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W9025"
device = "q6aq"
product = "q6aq"
name = "q6aq"
marketname = "Samsung W25"
fingerprint = "samsung/q6aq/q6aq:15/AP3A.241005.015.A1/q6aq.241005.001:user/release-keys"

[templates."samsung_sm_w7025"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W7025"
device = "b6q"
product = "b6q"
name = "b6q"
marketname = "Samsung W25 Flip"
fingerprint = "samsung/b6q/b6q:15/AP3A.241005.015.A1/b6q.241005.001:user/release-keys"

[templates."samsung_sm_w9026"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W9026"
device = "q7q"
product = "q7q"
name = "q7q"
marketname = "Samsung W26"
fingerprint = "samsung/q7q/q7q:15/AP3A.241005.015.A1/q7q.241005.001:user/release-keys"

[templates."samsung_sm_w9027"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W9027"
device = "q8q"
product = "q8q"
name = "q8q"
marketname = "Samsung W27"
fingerprint = "samsung/q8q/q8q:15/AP3A.241005.015.A1/q8q.241005.001:user/release-keys"

[templates."samsung_sm_g1600"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G1600"
device = "eliteltechn"
product = "eliteltechn"
name = "eliteltechn"
marketname = "Samsung Galaxy Folder"
fingerprint = "samsung/eliteltechn/eliteltechn:15/AP3A.241005.015.A1/eliteltechn.241005.001:user/release-keys"

[templates."samsung_sm_g1650"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G1650"
device = "elitexltechn"
product = "elitexltechn"
name = "elitexltechn"
marketname = "Samsung Galaxy Folder 2"
fingerprint = "samsung/elitexltechn/elitexltechn:15/AP3A.241005.015.A1/elitexltechn.241005.001:user/release-keys"

[templates."samsung_sm_g8508s"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-G8508S"
device = "sltechn"
product = "sltechn"
name = "sltechn"
marketname = "Samsung Galaxy Alpha"
fingerprint = "samsung/sltechn/sltechn:15/AP3A.241005.015.A1/sltechn.241005.001:user/release-keys"

[templates."samsung_sm_e7000"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-E7000"
device = "e7ltechn"
product = "e7ltechn"
name = "e7ltechn"
marketname = "Samsung Galaxy E7"
fingerprint = "samsung/e7ltechn/e7ltechn:15/AP3A.241005.015.A1/e7ltechn.241005.001:user/release-keys"

[templates."samsung_sm_t700"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T700"
device = "klimtwifi"
product = "klimtwifi"
name = "klimtwifi"
marketname = "Samsung Galaxy Tab S 8.4 WLAN"
fingerprint = "samsung/klimtwifi/klimtwifi:15/AP3A.241005.015.A1/klimtwifi.241005.001:user/release-keys"

[templates."samsung_sm_t705c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T705C"
device = "klimtlte"
product = "klimtlte"
name = "klimtlte"
marketname = "Samsung Galaxy Tab S 8.4"
fingerprint = "samsung/klimtlte/klimtlte:15/AP3A.241005.015.A1/klimtlte.241005.001:user/release-keys"

[templates."samsung_sm_t800"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T800"
device = "chagallwifi"
product = "chagallwifi"
name = "chagallwifi"
marketname = "Samsung Galaxy Tab S 10.5 WLAN"
fingerprint = "samsung/chagallwifi/chagallwifi:15/AP3A.241005.015.A1/chagallwifi.241005.001:user/release-keys"

[templates."samsung_sm_t805c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T805C"
device = "chagalllte"
product = "chagalllte"
name = "chagalllte"
marketname = "Samsung Galaxy Tab S 10.5"
fingerprint = "samsung/chagalllte/chagalllte:15/AP3A.241005.015.A1/chagalllte.241005.001:user/release-keys"

[templates."samsung_sm_t710"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T710"
device = "gts28wifichn"
product = "gts28wifichn"
name = "gts28wifichn"
marketname = "Samsung Galaxy Tab S2 8.0 WLAN"
fingerprint = "samsung/gts28wifichn/gts28wifichn:15/AP3A.241005.015.A1/gts28wifichn.241005.001:user/release-keys"

[templates."samsung_sm_t715c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T715C"
device = "gts28ltechn"
product = "gts28ltechn"
name = "gts28ltechn"
marketname = "Samsung Galaxy Tab S2 8.0"
fingerprint = "samsung/gts28ltechn/gts28ltechn:15/AP3A.241005.015.A1/gts28ltechn.241005.001:user/release-keys"

[templates."samsung_sm_t810"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T810"
device = "gts210wifichn"
product = "gts210wifichn"
name = "gts210wifichn"
marketname = "Samsung Galaxy Tab S2 9.7 WLAN"
fingerprint = "samsung/gts210wifichn/gts210wifichn:15/AP3A.241005.015.A1/gts210wifichn.241005.001:user/release-keys"

[templates."samsung_sm_t815c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T815C"
device = "gts210ltechn"
product = "gts210ltechn"
name = "gts210ltechn"
marketname = "Samsung Galaxy Tab S2 9.7"
fingerprint = "samsung/gts210ltechn/gts210ltechn:15/AP3A.241005.015.A1/gts210ltechn.241005.001:user/release-keys"

[templates."samsung_sm_t820"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T820"
device = "gts3lwifichn"
product = "gts3lwifichn"
name = "gts3lwifichn"
marketname = "Samsung Galaxy Tab S3 WLAN"
fingerprint = "samsung/gts3lwifichn/gts3lwifichn:15/AP3A.241005.015.A1/gts3lwifichn.241005.001:user/release-keys"

[templates."samsung_sm_t825c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T825C"
device = "gts3lltechn"
product = "gts3lltechn"
name = "gts3lltechn"
marketname = "Samsung Galaxy Tab S3"
fingerprint = "samsung/gts3lltechn/gts3lltechn:15/AP3A.241005.015.A1/gts3lltechn.241005.001:user/release-keys"

[templates."samsung_sm_t830"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T830"
device = "gts4lwifichn"
product = "gts4lwifichn"
name = "gts4lwifichn"
marketname = "Samsung Galaxy Tab S4 WLAN"
fingerprint = "samsung/gts4lwifichn/gts4lwifichn:15/AP3A.241005.015.A1/gts4lwifichn.241005.001:user/release-keys"

[templates."samsung_sm_t835c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T835C"
device = "gts4lltechn"
product = "gts4lltechn"
name = "gts4lltechn"
marketname = "Samsung Galaxy Tab S4"
fingerprint = "samsung/gts4lltechn/gts4lltechn:15/AP3A.241005.015.A1/gts4lltechn.241005.001:user/release-keys"

[templates."samsung_sm_t720"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T720"
device = "gts4lvwifichn"
product = "gts4lvwifichn"
name = "gts4lvwifichn"
marketname = "Samsung Galaxy Tab S5e WLAN"
fingerprint = "samsung/gts4lvwifichn/gts4lvwifichn:15/AP3A.241005.015.A1/gts4lvwifichn.241005.001:user/release-keys"

[templates."samsung_sm_t725c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T725C"
device = "gts4lv"
product = "gts4lv"
name = "gts4lv"
marketname = "Samsung Galaxy Tab S5e"
fingerprint = "samsung/gts4lv/gts4lv:15/AP3A.241005.015.A1/gts4lv.241005.001:user/release-keys"

[templates."samsung_sm_t860"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T860"
device = "gts6lwifi"
product = "gts6lwifi"
name = "gts6lwifi"
marketname = "Samsung Galaxy Tab S6 WLAN"
fingerprint = "samsung/gts6lwifi/gts6lwifi:15/AP3A.241005.015.A1/gts6lwifi.241005.001:user/release-keys"

[templates."samsung_sm_p610"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-P610"
device = "gta4xlwifi"
product = "gta4xlwifi"
name = "gta4xlwifi"
marketname = "Samsung Galaxy Tab S6 Lite WLAN"
fingerprint = "samsung/gta4xlwifi/gta4xlwifi:15/AP3A.241005.015.A1/gta4xlwifi.241005.001:user/release-keys"

[templates."samsung_sm_p615c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-P615C"
device = "gta4xl"
product = "gta4xl"
name = "gta4xl"
marketname = "Samsung Galaxy Tab S6 Lite"
fingerprint = "samsung/gta4xl/gta4xl:15/AP3A.241005.015.A1/gta4xl.241005.001:user/release-keys"

[templates."samsung_sm_t870"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T870"
device = "gts7lwifi"
product = "gts7lwifi"
name = "gts7lwifi"
marketname = "Samsung Galaxy Tab S7 WLAN"
fingerprint = "samsung/gts7lwifi/gts7lwifi:15/AP3A.241005.015.A1/gts7lwifi.241005.001:user/release-keys"

[templates."samsung_sm_t970"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T970"
device = "gts7xlwifi"
product = "gts7xlwifi"
name = "gts7xlwifi"
marketname = "Samsung Galaxy Tab S7+ WLAN"
fingerprint = "samsung/gts7xlwifi/gts7xlwifi:15/AP3A.241005.015.A1/gts7xlwifi.241005.001:user/release-keys"

[templates."samsung_sm_t730"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T730"
device = "gts7xllitewifi"
product = "gts7xllitewifi"
name = "gts7xllitewifi"
marketname = "Samsung Galaxy Tab S7 FE WLAN"
fingerprint = "samsung/gts7xllitewifi/gts7xllitewifi:15/AP3A.241005.015.A1/gts7xllitewifi.241005.001:user/release-keys"

[templates."samsung_sm_t735c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T735C"
device = "gts7xllite"
product = "gts7xllite"
name = "gts7xllite"
marketname = "Samsung Galaxy Tab S7 FE"
fingerprint = "samsung/gts7xllite/gts7xllite:15/AP3A.241005.015.A1/gts7xllite.241005.001:user/release-keys"

[templates."samsung_sm_x700"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X700"
device = "gts8wifi"
product = "gts8wifi"
name = "gts8wifi"
marketname = "Samsung Galaxy Tab S8 WLAN"
fingerprint = "samsung/gts8wifi/gts8wifi:15/AP3A.241005.015.A1/gts8wifi.241005.001:user/release-keys"

[templates."samsung_sm_x706c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X706C"
device = "gts8"
product = "gts8"
name = "gts8"
marketname = "Samsung Galaxy Tab S8 5G"
fingerprint = "samsung/gts8/gts8:15/AP3A.241005.015.A1/gts8.241005.001:user/release-keys"

[templates."samsung_sm_x800"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X800"
device = "gts8pwifi"
product = "gts8pwifi"
name = "gts8pwifi"
marketname = "Samsung Galaxy Tab S8+ WLAN"
fingerprint = "samsung/gts8pwifi/gts8pwifi:15/AP3A.241005.015.A1/gts8pwifi.241005.001:user/release-keys"

[templates."samsung_sm_x806c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X806C"
device = "gts8p"
product = "gts8p"
name = "gts8p"
marketname = "Samsung Galaxy Tab S8+ 5G"
fingerprint = "samsung/gts8p/gts8p:15/AP3A.241005.015.A1/gts8p.241005.001:user/release-keys"

[templates."samsung_sm_x900"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X900"
device = "gts8uwifi"
product = "gts8uwifi"
name = "gts8uwifi"
marketname = "Samsung Galaxy Tab S8 Ultra WLAN"
fingerprint = "samsung/gts8uwifi/gts8uwifi:15/AP3A.241005.015.A1/gts8uwifi.241005.001:user/release-keys"

[templates."samsung_sm_x906c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X906C"
device = "gts8u"
product = "gts8u"
name = "gts8u"
marketname = "Samsung Galaxy Tab S8 Ultra 5G"
fingerprint = "samsung/gts8u/gts8u:15/AP3A.241005.015.A1/gts8u.241005.001:user/release-keys"

[templates."samsung_sm_x710"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X710"
device = "gts9wifi"
product = "gts9wifi"
name = "gts9wifi"
marketname = "Samsung Galaxy Tab S9 WLAN"
fingerprint = "samsung/gts9wifi/gts9wifi:15/AP3A.241005.015.A1/gts9wifi.241005.001:user/release-keys"

[templates."samsung_sm_x810"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X810"
device = "gts9pwifi"
product = "gts9pwifi"
name = "gts9pwifi"
marketname = "Samsung Galaxy Tab S9+ WLAN"
fingerprint = "samsung/gts9pwifi/gts9pwifi:15/AP3A.241005.015.A1/gts9pwifi.241005.001:user/release-keys"

[templates."samsung_sm_x910"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X910"
device = "gts9uwifi"
product = "gts9uwifi"
name = "gts9uwifi"
marketname = "Samsung Galaxy Tab S9 Ultra WLAN"
fingerprint = "samsung/gts9uwifi/gts9uwifi:15/AP3A.241005.015.A1/gts9uwifi.241005.001:user/release-keys"

[templates."samsung_sm_x916c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X916C"
device = "gts9u"
product = "gts9u"
name = "gts9u"
marketname = "Samsung Galaxy Tab S9 Ultra 5G"
fingerprint = "samsung/gts9u/gts9u:15/AP3A.241005.015.A1/gts9u.241005.001:user/release-keys"

[templates."samsung_sm_x510"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X510"
device = "gts9fewifi"
product = "gts9fewifi"
name = "gts9fewifi"
marketname = "Samsung Galaxy Tab S9 FE WLAN"
fingerprint = "samsung/gts9fewifi/gts9fewifi:15/AP3A.241005.015.A1/gts9fewifi.241005.001:user/release-keys"

[templates."samsung_sm_x516c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X516C"
device = "gts9fe"
product = "gts9fe"
name = "gts9fe"
marketname = "Samsung Galaxy Tab S9 FE 5G"
fingerprint = "samsung/gts9fe/gts9fe:15/AP3A.241005.015.A1/gts9fe.241005.001:user/release-keys"

[templates."samsung_sm_x610"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X610"
device = "gts9fepwifi"
product = "gts9fepwifi"
name = "gts9fepwifi"
marketname = "Samsung Galaxy Tab S9 FE+ WLAN"
fingerprint = "samsung/gts9fepwifi/gts9fepwifi:15/AP3A.241005.015.A1/gts9fepwifi.241005.001:user/release-keys"

[templates."samsung_sm_x616c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X616C"
device = "gts9fep"
product = "gts9fep"
name = "gts9fep"
marketname = "Samsung Galaxy Tab S9 FE+ 5G"
fingerprint = "samsung/gts9fep/gts9fep:15/AP3A.241005.015.A1/gts9fep.241005.001:user/release-keys"

[templates."samsung_sm_x820"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X820"
device = "gts10pwifi"
product = "gts10pwifi"
name = "gts10pwifi"
marketname = "Samsung Galaxy Tab S10+ WLAN"
fingerprint = "samsung/gts10pwifi/gts10pwifi:15/AP3A.241005.015.A1/gts10pwifi.241005.001:user/release-keys"

[templates."samsung_sm_x920"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X920"
device = "gts10uwifi"
product = "gts10uwifi"
name = "gts10uwifi"
marketname = "Samsung Galaxy Tab S10 Ultra WLAN"
fingerprint = "samsung/gts10uwifi/gts10uwifi:15/AP3A.241005.015.A1/gts10uwifi.241005.001:user/release-keys"

[templates."samsung_sm_x926c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X926C"
device = "gts10u"
product = "gts10u"
name = "gts10u"
marketname = "Samsung Galaxy Tab S10 Ultra 5G"
fingerprint = "samsung/gts10u/gts10u:15/AP3A.241005.015.A1/gts10u.241005.001:user/release-keys"

[templates."samsung_sm_x520"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X520"
device = "gts10fewifi"
product = "gts10fewifi"
name = "gts10fewifi"
marketname = "Samsung Galaxy Tab S10 FE WLAN"
fingerprint = "samsung/gts10fewifi/gts10fewifi:15/AP3A.241005.015.A1/gts10fewifi.241005.001:user/release-keys"

[templates."samsung_sm_x526c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X526C"
device = "gts10fe"
product = "gts10fe"
name = "gts10fe"
marketname = "Samsung Galaxy Tab S10 FE 5G"
fingerprint = "samsung/gts10fe/gts10fe:15/AP3A.241005.015.A1/gts10fe.241005.001:user/release-keys"

[templates."samsung_sm_x620"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X620"
device = "gts10fepwifi"
product = "gts10fepwifi"
name = "gts10fepwifi"
marketname = "Samsung Galaxy Tab S10 FE+ WLAN"
fingerprint = "samsung/gts10fepwifi/gts10fepwifi:15/AP3A.241005.015.A1/gts10fepwifi.241005.001:user/release-keys"

[templates."samsung_sm_x626c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X626C"
device = "gts10fep"
product = "gts10fep"
name = "gts10fep"
marketname = "Samsung Galaxy Tab S10 FE+ 5G"
fingerprint = "samsung/gts10fep/gts10fep:15/AP3A.241005.015.A1/gts10fep.241005.001:user/release-keys"

[templates."samsung_sm_x400"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X400"
device = "gts10litewifi"
product = "gts10litewifi"
name = "gts10litewifi"
marketname = "Samsung Galaxy Tab S10 Lite WLAN"
fingerprint = "samsung/gts10litewifi/gts10litewifi:15/AP3A.241005.015.A1/gts10litewifi.241005.001:user/release-keys"

[templates."samsung_sm_x730"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X730"
device = "gts11wifi"
product = "gts11wifi"
name = "gts11wifi"
marketname = "Samsung Galaxy Tab S11 WLAN"
fingerprint = "samsung/gts11wifi/gts11wifi:15/AP3A.241005.015.A1/gts11wifi.241005.001:user/release-keys"

[templates."samsung_sm_x736c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X736C"
device = "gts11"
product = "gts11"
name = "gts11"
marketname = "Samsung Galaxy Tab S11 5G"
fingerprint = "samsung/gts11/gts11:15/AP3A.241005.015.A1/gts11.241005.001:user/release-keys"

[templates."samsung_sm_x930"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X930"
device = "gts11uwifi"
product = "gts11uwifi"
name = "gts11uwifi"
marketname = "Samsung Galaxy Tab S11 Ultra WLAN"
fingerprint = "samsung/gts11uwifi/gts11uwifi:15/AP3A.241005.015.A1/gts11uwifi.241005.001:user/release-keys"

[templates."samsung_sm_x936c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X936C"
device = "gts11u"
product = "gts11u"
name = "gts11u"
marketname = "Samsung Galaxy Tab S11 Ultra 5G"
fingerprint = "samsung/gts11u/gts11u:15/AP3A.241005.015.A1/gts11u.241005.001:user/release-keys"

[templates."samsung_sm_x840"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X840"
device = "gts12pwifi"
product = "gts12pwifi"
name = "gts12pwifi"
marketname = "Samsung Galaxy Tab S12+ WLAN"
fingerprint = "samsung/gts12pwifi/gts12pwifi:15/AP3A.241005.015.A1/gts12pwifi.241005.001:user/release-keys"

[templates."samsung_sm_x940"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X940"
device = "gts12uwifi"
product = "gts12uwifi"
name = "gts12uwifi"
marketname = "Samsung Galaxy Tab S12 Ultra WLAN"
fingerprint = "samsung/gts12uwifi/gts12uwifi:15/AP3A.241005.015.A1/gts12uwifi.241005.001:user/release-keys"

[templates."samsung_sm_t350"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T350"
device = "gt58wifichn"
product = "gt58wifichn"
name = "gt58wifichn"
marketname = "Samsung Galaxy Tab A 8.0 WLAN"
fingerprint = "samsung/gt58wifichn/gt58wifichn:15/AP3A.241005.015.A1/gt58wifichn.241005.001:user/release-keys"

[templates."samsung_sm_t355c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T355C"
device = "gt58ltechn"
product = "gt58ltechn"
name = "gt58ltechn"
marketname = "Samsung Galaxy Tab A 8.0"
fingerprint = "samsung/gt58ltechn/gt58ltechn:15/AP3A.241005.015.A1/gt58ltechn.241005.001:user/release-keys"

[templates."samsung_sm_t550"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T550"
device = "gt510wifichn"
product = "gt510wifichn"
name = "gt510wifichn"
marketname = "Samsung Galaxy Tab A 9.7 WLAN"
fingerprint = "samsung/gt510wifichn/gt510wifichn:15/AP3A.241005.015.A1/gt510wifichn.241005.001:user/release-keys"

[templates."samsung_sm_t555c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T555C"
device = "gt510ltechn"
product = "gt510ltechn"
name = "gt510ltechn"
marketname = "Samsung Galaxy Tab A 9.7"
fingerprint = "samsung/gt510ltechn/gt510ltechn:15/AP3A.241005.015.A1/gt510ltechn.241005.001:user/release-keys"

[templates."samsung_sm_t580"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T580"
device = "gtaxlwifichn"
product = "gtaxlwifichn"
name = "gtaxlwifichn"
marketname = "Samsung Galaxy Tab A 10.1 WLAN"
fingerprint = "samsung/gtaxlwifichn/gtaxlwifichn:15/AP3A.241005.015.A1/gtaxlwifichn.241005.001:user/release-keys"

[templates."samsung_sm_t585c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T585C"
device = "gtaxlltechn"
product = "gtaxlltechn"
name = "gtaxlltechn"
marketname = "Samsung Galaxy Tab A 10.1"
fingerprint = "samsung/gtaxlltechn/gtaxlltechn:15/AP3A.241005.015.A1/gtaxlltechn.241005.001:user/release-keys"

[templates."samsung_sm_p583"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-P583"
device = "gtanotexlwifichn"
product = "gtanotexlwifichn"
name = "gtanotexlwifichn"
marketname = "Samsung Galaxy Tab A with S Pen 10.1 WLAN"
fingerprint = "samsung/gtanotexlwifichn/gtanotexlwifichn:15/AP3A.241005.015.A1/gtanotexlwifichn.241005.001:user/release-keys"

[templates."samsung_sm_p588c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-P588C"
device = "S"
product = "S"
name = "S"
marketname = "Samsung Galaxy Tab A with S Pen 10.1"
fingerprint = "samsung/S/S:15/AP3A.241005.015.A1/S.241005.001:user/release-keys"

[templates."samsung_sm_t590"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T590"
device = "gta2xlwifichn"
product = "gta2xlwifichn"
name = "gta2xlwifichn"
marketname = "Samsung Galaxy Tab A 10.5 WLAN"
fingerprint = "samsung/gta2xlwifichn/gta2xlwifichn:15/AP3A.241005.015.A1/gta2xlwifichn.241005.001:user/release-keys"

[templates."samsung_sm_t595c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T595C"
device = "gta2xlltechn"
product = "gta2xlltechn"
name = "gta2xlltechn"
marketname = "Samsung Galaxy Tab A 10.5"
fingerprint = "samsung/gta2xlltechn/gta2xlltechn:15/AP3A.241005.015.A1/gta2xlltechn.241005.001:user/release-keys"

[templates."samsung_sm_t500"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T500"
device = "gta4lwifi"
product = "gta4lwifi"
name = "gta4lwifi"
marketname = "Samsung Galaxy Tab A7 10.4 WLAN"
fingerprint = "samsung/gta4lwifi/gta4lwifi:15/AP3A.241005.015.A1/gta4lwifi.241005.001:user/release-keys"

[templates."samsung_sm_t505c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T505C"
device = "gta4l"
product = "gta4l"
name = "gta4l"
marketname = "Samsung Galaxy Tab A7 10.4"
fingerprint = "samsung/gta4l/gta4l:15/AP3A.241005.015.A1/gta4l.241005.001:user/release-keys"

[templates."samsung_sm_t220"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T220"
device = "gta7litewifi"
product = "gta7litewifi"
name = "gta7litewifi"
marketname = "Samsung Galaxy Tab A7 Lite 8.7 WLAN"
fingerprint = "samsung/gta7litewifi/gta7litewifi:15/AP3A.241005.015.A1/gta7litewifi.241005.001:user/release-keys"

[templates."samsung_sm_t225c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T225C"
device = "gta7lite"
product = "gta7lite"
name = "gta7lite"
marketname = "Samsung Galaxy Tab A7 Lite 8.7"
fingerprint = "samsung/gta7lite/gta7lite:15/AP3A.241005.015.A1/gta7lite.241005.001:user/release-keys"

[templates."samsung_sm_x200"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X200"
device = "gta8wifi"
product = "gta8wifi"
name = "gta8wifi"
marketname = "Samsung Galaxy Tab A8 WLAN"
fingerprint = "samsung/gta8wifi/gta8wifi:15/AP3A.241005.015.A1/gta8wifi.241005.001:user/release-keys"

[templates."samsung_sm_x205c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X205C"
device = "gta8"
product = "gta8"
name = "gta8"
marketname = "Samsung Galaxy Tab A8"
fingerprint = "samsung/gta8/gta8:15/AP3A.241005.015.A1/gta8.241005.001:user/release-keys"

[templates."samsung_sm_x210"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X210"
device = "gta9pwifi"
product = "gta9pwifi"
name = "gta9pwifi"
marketname = "Samsung Galaxy Tab A9+ WLAN"
fingerprint = "samsung/gta9pwifi/gta9pwifi:15/AP3A.241005.015.A1/gta9pwifi.241005.001:user/release-keys"

[templates."samsung_sm_x216c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X216C"
device = "gta9p"
product = "gta9p"
name = "gta9p"
marketname = "Samsung Galaxy Tab A9+ 5G"
fingerprint = "samsung/gta9p/gta9p:15/AP3A.241005.015.A1/gta9p.241005.001:user/release-keys"

[templates."samsung_sm_x230"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X230"
device = "gta11pwifi"
product = "gta11pwifi"
name = "gta11pwifi"
marketname = "Samsung Galaxy Tab A11+ WLAN"
fingerprint = "samsung/gta11pwifi/gta11pwifi:15/AP3A.241005.015.A1/gta11pwifi.241005.001:user/release-keys"

[templates."samsung_sm_x236c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-X236C"
device = "gta11p"
product = "gta11p"
name = "gta11p"
marketname = "Samsung Galaxy Tab A11+ 5H"
fingerprint = "samsung/gta11p/gta11p:15/AP3A.241005.015.A1/gta11p.241005.001:user/release-keys"

[templates."samsung_sm_t230"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T230"
device = "degaswifi"
product = "degaswifi"
name = "degaswifi"
marketname = "Samsung Galaxy Tab4 7.0 WLAN"
fingerprint = "samsung/degaswifi/degaswifi:15/AP3A.241005.015.A1/degaswifi.241005.001:user/release-keys"

[templates."samsung_sm_t231"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T231"
device = "degas3g"
product = "degas3g"
name = "degas3g"
marketname = "Samsung Galaxy Tab4 7.0 3G"
fingerprint = "samsung/degas3g/degas3g:15/AP3A.241005.015.A1/degas3g.241005.001:user/release-keys"

[templates."samsung_sm_t239c"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T239C"
device = "degasveltechn"
product = "degasveltechn"
name = "degasveltechn"
marketname = "Samsung Galaxy Tab4 7.0 VE"
fingerprint = "samsung/degasveltechn/degasveltechn:15/AP3A.241005.015.A1/degasveltechn.241005.001:user/release-keys"

[templates."samsung_sm_t330"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T330"
device = "milletwifi"
product = "milletwifi"
name = "milletwifi"
marketname = "Samsung Galaxy Tab4 8.0 WLAN"
fingerprint = "samsung/milletwifi/milletwifi:15/AP3A.241005.015.A1/milletwifi.241005.001:user/release-keys"

[templates."samsung_sm_t331"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T331"
device = "millet3g"
product = "millet3g"
name = "millet3g"
marketname = "Samsung Galaxy Tab4 8.0 3G"
fingerprint = "samsung/millet3g/millet3g:15/AP3A.241005.015.A1/millet3g.241005.001:user/release-keys"

[templates."samsung_sm_t530"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T530"
device = "matissewifi"
product = "matissewifi"
name = "matissewifi"
marketname = "Samsung Galaxy Tab4 10.1 WLAN"
fingerprint = "samsung/matissewifi/matissewifi:15/AP3A.241005.015.A1/matissewifi.241005.001:user/release-keys"

[templates."samsung_sm_t531"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T531"
device = "matisse3g"
product = "matisse3g"
name = "matisse3g"
marketname = "Samsung Galaxy Tab4 10.1 3G"
fingerprint = "samsung/matisse3g/matisse3g:15/AP3A.241005.015.A1/matisse3g.241005.001:user/release-keys"

[templates."samsung_sm_t320"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T320"
device = "mondrianwifi"
product = "mondrianwifi"
name = "mondrianwifi"
marketname = "Samsung Galaxy Tab PRO 8.4 WLAN"
fingerprint = "samsung/mondrianwifi/mondrianwifi:15/AP3A.241005.015.A1/mondrianwifi.241005.001:user/release-keys"

[templates."samsung_sm_t321"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T321"
device = "mondrian3g"
product = "mondrian3g"
name = "mondrian3g"
marketname = "Samsung Galaxy Tab PRO 8.4 3G"
fingerprint = "samsung/mondrian3g/mondrian3g:15/AP3A.241005.015.A1/mondrian3g.241005.001:user/release-keys"

[templates."samsung_sm_t520"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-T520"
device = "picassowifi"
product = "picassowifi"
name = "picassowifi"
marketname = "Samsung Galaxy Tab PRO 10.1 WLAN"
fingerprint = "samsung/picassowifi/picassowifi:15/AP3A.241005.015.A1/picassowifi.241005.001:user/release-keys"

[templates."samsung_sm_w700"]
manufacturer = "samsung"
brand = "samsung"
model = "SM-W700"
device = "SM-W700"
product = "SM-W700"
marketname = "Samsung Galaxy TabPro S WLAN"
fingerprint = "samsung/SM-W700/SM-W700:15/AP3A.241005.015.A1/SM-W700.241005.001:user/release-keys"

[templates."vivo_v1821a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1821A"
device = "PD1821"
product = "PD1821"
name = "PD1821"
marketname = "vivo NEX 双屏版"
fingerprint = "vivo/PD1821/PD1821:15/AP3A.241005.015.A1/PD1821.241005.001:user/release-keys"

[templates."vivo_v1923a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1923A"
device = "PD1923"
product = "PD1923"
name = "PD1923"
marketname = "vivo NEX 3"
fingerprint = "vivo/PD1923/PD1923:15/AP3A.241005.015.A1/PD1923.241005.001:user/release-keys"

[templates."vivo_v1924a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1924A"
device = "PD1924"
product = "PD1924"
name = "PD1924"
marketname = "vivo NEX 3 5G"
fingerprint = "vivo/PD1924/PD1924:15/AP3A.241005.015.A1/PD1924.241005.001:user/release-keys"

[templates."vivo_v1950a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1950A"
device = "PD1950"
product = "PD1950"
name = "PD1950"
marketname = "vivo NEX 3S 5G"
fingerprint = "vivo/PD1950/PD1950:15/AP3A.241005.015.A1/PD1950.241005.001:user/release-keys"

[templates."vivo_v1814a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1814A"
device = "PD1814"
product = "PD1814"
name = "PD1814"
marketname = "vivo X21s"
fingerprint = "vivo/PD1814/PD1814:15/AP3A.241005.015.A1/PD1814.241005.001:user/release-keys"

[templates."vivo_v1809a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1809A"
device = "PD1809"
product = "PD1809"
name = "PD1809"
marketname = "vivo X23"
fingerprint = "vivo/PD1809/PD1809:15/AP3A.241005.015.A1/PD1809.241005.001:user/release-keys"

[templates."vivo_v1816a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1816A"
device = "PD1816"
product = "PD1816"
name = "PD1816"
marketname = "vivo X23 幻彩版"
fingerprint = "vivo/PD1816/PD1816:15/AP3A.241005.015.A1/PD1816.241005.001:user/release-keys"

[templates."vivo_v1829a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1829A"
device = "PD1829"
product = "PD1829"
name = "PD1829"
marketname = "vivo X27 8GB+256GB"
fingerprint = "vivo/PD1829/PD1829:15/AP3A.241005.015.A1/PD1829.241005.001:user/release-keys"

[templates."vivo_v1838a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1838A"
device = "PD1838"
product = "PD1838"
name = "PD1838"
marketname = "vivo X27 8GB+128GB"
fingerprint = "vivo/PD1838/PD1838:15/AP3A.241005.015.A1/PD1838.241005.001:user/release-keys"

[templates."vivo_v1836a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1836A"
device = "PD1836"
product = "PD1836"
name = "PD1836"
marketname = "vivo X27 Pro"
fingerprint = "vivo/PD1836/PD1836:15/AP3A.241005.015.A1/PD1836.241005.001:user/release-keys"

[templates."vivo_v1938ca"]
manufacturer = "vivo"
brand = "vivo"
model = "V1938CA"
device = "PD1938C"
product = "PD1938C"
name = "PD1938C"
marketname = "vivo X30 5G"
fingerprint = "vivo/PD1938C/PD1938C:15/AP3A.241005.015.A1/PD1938C.241005.001:user/release-keys"

[templates."vivo_v1938a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1938A"
device = "PD1938"
product = "PD1938"
name = "PD1938"
marketname = "vivo X30 Pro 5G"
fingerprint = "vivo/PD1938/PD1938:15/AP3A.241005.015.A1/PD1938.241005.001:user/release-keys"

[templates."vivo_v2001a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2001A"
device = "PD2001"
product = "PD2001"
name = "PD2001"
marketname = "vivo X50"
fingerprint = "vivo/PD2001/PD2001:15/AP3A.241005.015.A1/PD2001.241005.001:user/release-keys"

[templates."vivo_v2005a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2005A"
device = "PD2005"
product = "PD2005"
name = "PD2005"
marketname = "vivo X50 Pro"
fingerprint = "vivo/PD2005/PD2005:15/AP3A.241005.015.A1/PD2005.241005.001:user/release-keys"

[templates."vivo_v2011a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2011A"
device = "PD2011"
product = "PD2011"
name = "PD2011"
marketname = "vivo X50 Pro+"
fingerprint = "vivo/PD2011/PD2011:15/AP3A.241005.015.A1/PD2011.241005.001:user/release-keys"

[templates."vivo_v2046a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2046A"
device = "PD2046"
product = "PD2046"
name = "PD2046"
marketname = "vivo X60"
fingerprint = "vivo/PD2046/PD2046:15/AP3A.241005.015.A1/PD2046.241005.001:user/release-keys"

[templates."vivo_v2059a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2059A"
device = "PD2059"
product = "PD2059"
name = "PD2059"
marketname = "vivo X60 曲屏版"
fingerprint = "vivo/PD2059/PD2059:15/AP3A.241005.015.A1/PD2059.241005.001:user/release-keys"

[templates."vivo_v2085a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2085A"
device = "PD2085"
product = "PD2085"
name = "PD2085"
marketname = "vivo X60t"
fingerprint = "vivo/PD2085/PD2085:15/AP3A.241005.015.A1/PD2085.241005.001:user/release-keys"

[templates."vivo_v2047a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2047A"
device = "PD2047"
product = "PD2047"
name = "PD2047"
marketname = "vivo X60 Pro"
fingerprint = "vivo/PD2047/PD2047:15/AP3A.241005.015.A1/PD2047.241005.001:user/release-keys"

[templates."vivo_v2120a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2120A"
device = "PD2120"
product = "PD2120"
name = "PD2120"
marketname = "vivo X60t Pro"
fingerprint = "vivo/PD2120/PD2120:15/AP3A.241005.015.A1/PD2120.241005.001:user/release-keys"

[templates."vivo_v2056a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2056A"
device = "PD2056"
product = "PD2056"
name = "PD2056"
marketname = "vivo X60 Pro+"
fingerprint = "vivo/PD2056/PD2056:15/AP3A.241005.015.A1/PD2056.241005.001:user/release-keys"

[templates."vivo_v2133a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2133A"
device = "PD2133"
product = "PD2133"
name = "PD2133"
marketname = "vivo X70"
fingerprint = "vivo/PD2133/PD2133:15/AP3A.241005.015.A1/PD2133.241005.001:user/release-keys"

[templates."vivo_v2132a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2132A"
device = "PD2132"
product = "PD2132"
name = "PD2132"
marketname = "vivo X70t"
fingerprint = "vivo/PD2132/PD2132:15/AP3A.241005.015.A1/PD2132.241005.001:user/release-keys"

[templates."vivo_v2134a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2134A"
device = "PD2134"
product = "PD2134"
name = "PD2134"
marketname = "vivo X70 Pro"
fingerprint = "vivo/PD2134/PD2134:15/AP3A.241005.015.A1/PD2134.241005.001:user/release-keys"

[templates."vivo_v2145a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2145A"
device = "PD2145"
product = "PD2145"
name = "PD2145"
marketname = "vivo X70 Pro+"
fingerprint = "vivo/PD2145/PD2145:15/AP3A.241005.015.A1/PD2145.241005.001:user/release-keys"

[templates."vivo_v2178a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2178A"
device = "PD2178"
product = "PD2178"
name = "PD2178"
marketname = "vivo X Fold"
fingerprint = "vivo/PD2178/PD2178:15/AP3A.241005.015.A1/PD2178.241005.001:user/release-keys"

[templates."vivo_v2170a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2170A"
device = "PD2170"
product = "PD2170"
name = "PD2170"
marketname = "vivo X Note"
fingerprint = "vivo/PD2170/PD2170:15/AP3A.241005.015.A1/PD2170.241005.001:user/release-keys"

[templates."vivo_v2183a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2183A"
device = "PD2183"
product = "PD2183"
name = "PD2183"
marketname = "vivo X80"
fingerprint = "vivo/PD2183/PD2183:15/AP3A.241005.015.A1/PD2183.241005.001:user/release-keys"

[templates."vivo_v2185a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2185A"
device = "PD2185"
product = "PD2185"
name = "PD2185"
marketname = "vivo X80 Pro"
fingerprint = "vivo/PD2185/PD2185:15/AP3A.241005.015.A1/PD2185.241005.001:user/release-keys"

[templates."vivo_v2186a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2186A"
device = "PD2186"
product = "PD2186"
name = "PD2186"
marketname = "vivo X80 Pro 天玑 9000 版"
fingerprint = "vivo/PD2186/PD2186:15/AP3A.241005.015.A1/PD2186.241005.001:user/release-keys"

[templates."vivo_v2229a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2229A"
device = "PD2229"
product = "PD2229"
name = "PD2229"
marketname = "vivo X Fold+"
fingerprint = "vivo/PD2229/PD2229:15/AP3A.241005.015.A1/PD2229.241005.001:user/release-keys"

[templates."vivo_v2241a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2241A"
device = "PD2241"
product = "PD2241"
name = "PD2241"
marketname = "vivo X90"
fingerprint = "vivo/PD2241/PD2241:15/AP3A.241005.015.A1/PD2241.241005.001:user/release-keys"

[templates."vivo_v2241ha"]
manufacturer = "vivo"
brand = "vivo"
model = "V2241HA"
device = "PD2241"
product = "PD2241"
name = "PD2241"
marketname = "vivo X90s"
fingerprint = "vivo/PD2241/PD2241:15/AP3A.241005.015.A1/PD2241.241005.001:user/release-keys"

[templates."vivo_v2242a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2242A"
device = "PD2242"
product = "PD2242"
name = "PD2242"
marketname = "vivo X90 Pro"
fingerprint = "vivo/PD2242/PD2242:15/AP3A.241005.015.A1/PD2242.241005.001:user/release-keys"

[templates."vivo_v2227a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2227A"
device = "PD2227"
product = "PD2227"
name = "PD2227"
marketname = "vivo X90 Pro+"
fingerprint = "vivo/PD2227/PD2227:15/AP3A.241005.015.A1/PD2227.241005.001:user/release-keys"

[templates."vivo_v2266a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2266A"
device = "PD2266"
product = "PD2266"
name = "PD2266"
marketname = "vivo X Fold2"
fingerprint = "vivo/PD2266/PD2266:15/AP3A.241005.015.A1/PD2266.241005.001:user/release-keys"

[templates."vivo_v2256a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2256A"
device = "PD2256"
product = "PD2256"
name = "PD2256"
marketname = "vivo X Flip"
fingerprint = "vivo/PD2256/PD2256:15/AP3A.241005.015.A1/PD2256.241005.001:user/release-keys"

[templates."vivo_v2309a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2309A"
device = "PD2309"
product = "PD2309"
name = "PD2309"
marketname = "vivo X100"
fingerprint = "vivo/PD2309/PD2309:15/AP3A.241005.015.A1/PD2309.241005.001:user/release-keys"

[templates."vivo_v2324a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2324A"
device = "PD2324"
product = "PD2324"
name = "PD2324"
marketname = "vivo X100 Pro"
fingerprint = "vivo/PD2324/PD2324:15/AP3A.241005.015.A1/PD2324.241005.001:user/release-keys"

[templates."vivo_v2303a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2303A"
device = "PD2303"
product = "PD2303"
name = "PD2303"
marketname = "vivo X Fold3"
fingerprint = "vivo/PD2303/PD2303:15/AP3A.241005.015.A1/PD2303.241005.001:user/release-keys"

[templates."vivo_v2337a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2337A"
device = "PD2337"
product = "PD2337"
name = "PD2337"
marketname = "vivo X Fold3 Pro"
fingerprint = "vivo/PD2337/PD2337:15/AP3A.241005.015.A1/PD2337.241005.001:user/release-keys"

[templates."vivo_v2359a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2359A"
device = "PD2359"
product = "PD2359"
name = "PD2359"
marketname = "vivo X100s"
fingerprint = "vivo/PD2359/PD2359:15/AP3A.241005.015.A1/PD2359.241005.001:user/release-keys"

[templates."vivo_v2324ha"]
manufacturer = "vivo"
brand = "vivo"
model = "V2324HA"
device = "PD2324"
product = "PD2324"
name = "PD2324"
marketname = "vivo X100s Pro"
fingerprint = "vivo/PD2324/PD2324:15/AP3A.241005.015.A1/PD2324.241005.001:user/release-keys"

[templates."vivo_v2366ga"]
manufacturer = "vivo"
brand = "vivo"
model = "V2366GA"
device = "PD2366"
product = "PD2366"
name = "PD2366"
marketname = "vivo X100 Ultra"
fingerprint = "vivo/PD2366/PD2366:15/AP3A.241005.015.A1/PD2366.241005.001:user/release-keys"

[templates."vivo_v2366ha"]
manufacturer = "vivo"
brand = "vivo"
model = "V2366HA"
device = "PD2366"
product = "PD2366"
name = "PD2366"
marketname = "vivo X100 Ultra 卫星通信版"
fingerprint = "vivo/PD2366/PD2366:15/AP3A.241005.015.A1/PD2366.241005.001:user/release-keys"

[templates."vivo_v2415a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2415A"
device = "PD2415"
product = "PD2415"
name = "PD2415"
marketname = "vivo X200"
fingerprint = "vivo/PD2415/PD2415:15/AP3A.241005.015.A1/PD2415.241005.001:user/release-keys"

[templates."vivo_v2405a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2405A"
device = "PD2405"
product = "PD2405"
name = "PD2405"
marketname = "vivo X200 Pro"
fingerprint = "vivo/PD2405/PD2405:15/AP3A.241005.015.A1/PD2405.241005.001:user/release-keys"

[templates."vivo_v2405da"]
manufacturer = "vivo"
brand = "vivo"
model = "V2405DA"
device = "PD2405"
product = "PD2405"
name = "PD2405"
marketname = "vivo X200 Pro 卫星通信版"
fingerprint = "vivo/PD2405/PD2405:15/AP3A.241005.015.A1/PD2405.241005.001:user/release-keys"

[templates."vivo_v2419a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2419A"
device = "PD2419"
product = "PD2419"
name = "PD2419"
marketname = "vivo X200 Pro mini"
fingerprint = "vivo/PD2419/PD2419:15/AP3A.241005.015.A1/PD2419.241005.001:user/release-keys"

[templates."vivo_v2458a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2458A"
device = "PD2458"
product = "PD2458"
name = "PD2458"
marketname = "vivo X200s"
fingerprint = "vivo/PD2458/PD2458:15/AP3A.241005.015.A1/PD2458.241005.001:user/release-keys"

[templates."vivo_v2454a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2454A"
device = "PD2454"
product = "PD2454"
name = "PD2454"
marketname = "vivo X200 Ultra"
fingerprint = "vivo/PD2454/PD2454:15/AP3A.241005.015.A1/PD2454.241005.001:user/release-keys"

[templates."vivo_v2454da"]
manufacturer = "vivo"
brand = "vivo"
model = "V2454DA"
device = "PD2454"
product = "PD2454"
name = "PD2454"
marketname = "vivo X200 Ultra 卫星通信版"
fingerprint = "vivo/PD2454/PD2454:15/AP3A.241005.015.A1/PD2454.241005.001:user/release-keys"

[templates."vivo_v2436a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2436A"
device = "PD2436"
product = "PD2436"
name = "PD2436"
marketname = "vivo X Fold5"
fingerprint = "vivo/PD2436/PD2436:15/AP3A.241005.015.A1/PD2436.241005.001:user/release-keys"

[templates."vivo_v2509a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2509A"
device = "PD2509"
product = "PD2509"
name = "PD2509"
marketname = "vivo X300"
fingerprint = "vivo/PD2509/PD2509:15/AP3A.241005.015.A1/PD2509.241005.001:user/release-keys"

[templates."vivo_v2502a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2502A"
device = "PD2502"
product = "PD2502"
name = "PD2502"
marketname = "vivo X300 Pro"
fingerprint = "vivo/PD2502/PD2502:15/AP3A.241005.015.A1/PD2502.241005.001:user/release-keys"

[templates."vivo_v2502da"]
manufacturer = "vivo"
brand = "vivo"
model = "V2502DA"
device = "PD2502"
product = "PD2502"
name = "PD2502"
marketname = "vivo X300 Pro 卫星通信版"
fingerprint = "vivo/PD2502/PD2502:15/AP3A.241005.015.A1/PD2502.241005.001:user/release-keys"

[templates."vivo_v2548a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2548A"
device = "PD2548"
product = "PD2548"
name = "PD2548"
marketname = "vivo X300s"
fingerprint = "vivo/PD2548/PD2548:15/AP3A.241005.015.A1/PD2548.241005.001:user/release-keys"

[templates."vivo_v2547a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2547A"
device = "PD2547"
product = "PD2547"
name = "PD2547"
marketname = "vivo X300 Ultra"
fingerprint = "vivo/PD2547/PD2547:15/AP3A.241005.015.A1/PD2547.241005.001:user/release-keys"

[templates."vivo_v2547da"]
manufacturer = "vivo"
brand = "vivo"
model = "V2547DA"
device = "PD2547"
product = "PD2547"
name = "PD2547"
marketname = "vivo X300 Ultra 卫星通信版"
fingerprint = "vivo/PD2547/PD2547:15/AP3A.241005.015.A1/PD2547.241005.001:user/release-keys"

[templates."vivo_v2612a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2612A"
device = "PD2612"
product = "PD2612"
name = "PD2612"
marketname = "vivo X300 E"
fingerprint = "vivo/PD2612/PD2612:15/AP3A.241005.015.A1/PD2612.241005.001:user/release-keys"

[templates."vivo_v2545a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2545A"
device = "PD2545"
product = "PD2545"
name = "PD2545"
marketname = "vivo X Fold6"
fingerprint = "vivo/PD2545/PD2545:15/AP3A.241005.015.A1/PD2545.241005.001:user/release-keys"

[templates."vivo_v2609a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2609A"
device = "PD2609"
product = "PD2609"
name = "PD2609"
marketname = "vivo X500"
fingerprint = "vivo/PD2609/PD2609:15/AP3A.241005.015.A1/PD2609.241005.001:user/release-keys"

[templates."vivo_v2608a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2608A"
device = "PD2608"
product = "PD2608"
name = "PD2608"
marketname = "vivo X500 Pro"
fingerprint = "vivo/PD2608/PD2608:15/AP3A.241005.015.A1/PD2608.241005.001:user/release-keys"

[templates."vivo_v2608da"]
manufacturer = "vivo"
brand = "vivo"
model = "V2608DA"
device = "PD2608"
product = "PD2608"
name = "PD2608"
marketname = "vivo X500 Pro eSIM 版"
fingerprint = "vivo/PD2608/PD2608:15/AP3A.241005.015.A1/PD2608.241005.001:user/release-keys"

[templates."vivo_v2602a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2602A"
device = "PD2602"
product = "PD2602"
name = "PD2602"
marketname = "vivo X500 Pro Max"
fingerprint = "vivo/PD2602/PD2602:15/AP3A.241005.015.A1/PD2602.241005.001:user/release-keys"

[templates."vivo_v2602da"]
manufacturer = "vivo"
brand = "vivo"
model = "V2602DA"
device = "PD2602"
product = "PD2602"
name = "PD2602"
marketname = "vivo X500 Pro Max 卫星通信版"
fingerprint = "vivo/PD2602/PD2602:15/AP3A.241005.015.A1/PD2602.241005.001:user/release-keys"

[templates."vivo_v1831a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1831A"
device = "PD1831"
product = "PD1831"
name = "PD1831"
marketname = "vivo S1"
fingerprint = "vivo/PD1831/PD1831:15/AP3A.241005.015.A1/PD1831.241005.001:user/release-keys"

[templates."vivo_v1832a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1832A"
device = "PD1832"
product = "PD1832"
name = "PD1832"
marketname = "vivo S1 Pro"
fingerprint = "vivo/PD1832/PD1832:15/AP3A.241005.015.A1/PD1832.241005.001:user/release-keys"

[templates."vivo_v1932a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1932A"
device = "PD1932"
product = "PD1932"
name = "PD1932"
marketname = "vivo S5"
fingerprint = "vivo/PD1932/PD1932:15/AP3A.241005.015.A1/PD1932.241005.001:user/release-keys"

[templates."vivo_v1962a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1962A"
device = "PD1962"
product = "PD1962"
name = "PD1962"
marketname = "vivo S6"
fingerprint = "vivo/PD1962/PD1962:15/AP3A.241005.015.A1/PD1962.241005.001:user/release-keys"

[templates."vivo_v2020a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2020A"
device = "PD2020"
product = "PD2020"
name = "PD2020"
marketname = "vivo S7"
fingerprint = "vivo/PD2020/PD2020:15/AP3A.241005.015.A1/PD2020.241005.001:user/release-keys"

[templates."vivo_v2080a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2080A"
device = "PD2080"
product = "PD2080"
name = "PD2080"
marketname = "vivo S7t"
fingerprint = "vivo/PD2080/PD2080:15/AP3A.241005.015.A1/PD2080.241005.001:user/release-keys"

[templates."vivo_v2031a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2031A"
device = "PD2031"
product = "PD2031"
name = "PD2031"
marketname = "vivo S7e"
fingerprint = "vivo/PD2031/PD2031:15/AP3A.241005.015.A1/PD2031.241005.001:user/release-keys"

[templates."vivo_v2031ea"]
manufacturer = "vivo"
brand = "vivo"
model = "V2031EA"
device = "PD2031EA"
product = "PD2031EA"
name = "PD2031EA"
marketname = "vivo S7e 活力版"
fingerprint = "vivo/PD2031EA/PD2031EA:15/AP3A.241005.015.A1/PD2031EA.241005.001:user/release-keys"

[templates."vivo_v2072a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2072A"
device = "PD2072"
product = "PD2072"
name = "PD2072"
marketname = "vivo S9"
fingerprint = "vivo/PD2072/PD2072:15/AP3A.241005.015.A1/PD2072.241005.001:user/release-keys"

[templates."vivo_v2048a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2048A"
device = "PD2048"
product = "PD2048"
name = "PD2048"
marketname = "vivo S9e"
fingerprint = "vivo/PD2048/PD2048:15/AP3A.241005.015.A1/PD2048.241005.001:user/release-keys"

[templates."vivo_v2121a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2121A"
device = "PD2121"
product = "PD2121"
name = "PD2121"
marketname = "vivo S10"
fingerprint = "vivo/PD2121/PD2121:15/AP3A.241005.015.A1/PD2121.241005.001:user/release-keys"

[templates."vivo_v2130a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2130A"
device = "PD2130"
product = "PD2130"
name = "PD2130"
marketname = "vivo S10e"
fingerprint = "vivo/PD2130/PD2130:15/AP3A.241005.015.A1/PD2130.241005.001:user/release-keys"

[templates."vivo_v2162a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2162A"
device = "PD2162"
product = "PD2162"
name = "PD2162"
marketname = "vivo S12"
fingerprint = "vivo/PD2162/PD2162:15/AP3A.241005.015.A1/PD2162.241005.001:user/release-keys"

[templates."vivo_v2163a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2163A"
device = "PD2163"
product = "PD2163"
name = "PD2163"
marketname = "vivo S12 Pro"
fingerprint = "vivo/PD2163/PD2163:15/AP3A.241005.015.A1/PD2163.241005.001:user/release-keys"

[templates."vivo_v2203a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2203A"
device = "PD2203"
product = "PD2203"
name = "PD2203"
marketname = "vivo S15"
fingerprint = "vivo/PD2203/PD2203:15/AP3A.241005.015.A1/PD2203.241005.001:user/release-keys"

[templates."vivo_v2207a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2207A"
device = "PD2207"
product = "PD2207"
name = "PD2207"
marketname = "vivo S15 Pro"
fingerprint = "vivo/PD2207/PD2207:15/AP3A.241005.015.A1/PD2207.241005.001:user/release-keys"

[templates."vivo_v2190a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2190A"
device = "PD2190"
product = "PD2190"
name = "PD2190"
marketname = "vivo S15e"
fingerprint = "vivo/PD2190/PD2190:15/AP3A.241005.015.A1/PD2190.241005.001:user/release-keys"

[templates."vivo_v2244a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2244A"
device = "PD2244"
product = "PD2244"
name = "PD2244"
marketname = "vivo S16"
fingerprint = "vivo/PD2244/PD2244:15/AP3A.241005.015.A1/PD2244.241005.001:user/release-keys"

[templates."vivo_v2245a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2245A"
device = "PD2245"
product = "PD2245"
name = "PD2245"
marketname = "vivo S16 Pro"
fingerprint = "vivo/PD2245/PD2245:15/AP3A.241005.015.A1/PD2245.241005.001:user/release-keys"

[templates."vivo_v2239a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2239A"
device = "PD2239"
product = "PD2239"
name = "PD2239"
marketname = "vivo S16e"
fingerprint = "vivo/PD2239/PD2239:15/AP3A.241005.015.A1/PD2239.241005.001:user/release-keys"

[templates."vivo_v2283a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2283A"
device = "PD2283"
product = "PD2283"
name = "PD2283"
marketname = "vivo S17"
fingerprint = "vivo/PD2283/PD2283:15/AP3A.241005.015.A1/PD2283.241005.001:user/release-keys"

[templates."vivo_v2282a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2282A"
device = "PD2282"
product = "PD2282"
name = "PD2282"
marketname = "vivo S17t"
fingerprint = "vivo/PD2282/PD2282:15/AP3A.241005.015.A1/PD2282.241005.001:user/release-keys"

[templates."vivo_v2284a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2284A"
device = "PD2284"
product = "PD2284"
name = "PD2284"
marketname = "vivo S17 Pro"
fingerprint = "vivo/PD2284/PD2284:15/AP3A.241005.015.A1/PD2284.241005.001:user/release-keys"

[templates."vivo_v2285a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2285A"
device = "PD2285"
product = "PD2285"
name = "PD2285"
marketname = "vivo S17e"
fingerprint = "vivo/PD2285/PD2285:15/AP3A.241005.015.A1/PD2285.241005.001:user/release-keys"

[templates."vivo_v2323a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2323A"
device = "PD2323"
product = "PD2323"
name = "PD2323"
marketname = "vivo S18"
fingerprint = "vivo/PD2323/PD2323:15/AP3A.241005.015.A1/PD2323.241005.001:user/release-keys"

[templates."vivo_v2344a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2344A"
device = "PD2344"
product = "PD2344"
name = "PD2344"
marketname = "vivo S18 Pro"
fingerprint = "vivo/PD2344/PD2344:15/AP3A.241005.015.A1/PD2344.241005.001:user/release-keys"

[templates."vivo_v2334a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2334A"
device = "PD2334"
product = "PD2334"
name = "PD2334"
marketname = "vivo S18e"
fingerprint = "vivo/PD2334/PD2334:15/AP3A.241005.015.A1/PD2334.241005.001:user/release-keys"

[templates."vivo_v2364a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2364A"
device = "PD2364"
product = "PD2364"
name = "PD2364"
marketname = "vivo S19"
fingerprint = "vivo/PD2364/PD2364:15/AP3A.241005.015.A1/PD2364.241005.001:user/release-keys"

[templates."vivo_v2362a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2362A"
device = "PD2362"
product = "PD2362"
name = "PD2362"
marketname = "vivo S19 Pro"
fingerprint = "vivo/PD2362/PD2362:15/AP3A.241005.015.A1/PD2362.241005.001:user/release-keys"

[templates."vivo_v2429a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2429A"
device = "PD2429"
product = "PD2429"
name = "PD2429"
marketname = "vivo S20"
fingerprint = "vivo/PD2429/PD2429:15/AP3A.241005.015.A1/PD2429.241005.001:user/release-keys"

[templates."vivo_v2430a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2430A"
device = "PD2430"
product = "PD2430"
name = "PD2430"
marketname = "vivo S20 Pro"
fingerprint = "vivo/PD2430/PD2430:15/AP3A.241005.015.A1/PD2430.241005.001:user/release-keys"

[templates."vivo_v2464a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2464A"
device = "PD2464"
product = "PD2464"
name = "PD2464"
marketname = "vivo S30"
fingerprint = "vivo/PD2464/PD2464:15/AP3A.241005.015.A1/PD2464.241005.001:user/release-keys"

[templates."vivo_v2465a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2465A"
device = "PD2465"
product = "PD2465"
name = "PD2465"
marketname = "vivo S30 Pro mini"
fingerprint = "vivo/PD2465/PD2465:15/AP3A.241005.015.A1/PD2465.241005.001:user/release-keys"

[templates."vivo_v2528a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2528A"
device = "PD2528"
product = "PD2528"
name = "PD2528"
marketname = "vivo S50"
fingerprint = "vivo/PD2528/PD2528:15/AP3A.241005.015.A1/PD2528.241005.001:user/release-keys"

[templates."vivo_v2527a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2527A"
device = "PD2527"
product = "PD2527"
name = "PD2527"
marketname = "vivo S50 Pro mini"
fingerprint = "vivo/PD2527/PD2527:15/AP3A.241005.015.A1/PD2527.241005.001:user/release-keys"

[templates."vivo_v2571a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2571A"
device = "PD2571"
product = "PD2571"
name = "PD2571"
marketname = "vivo S60"
fingerprint = "vivo/PD2571/PD2571:15/AP3A.241005.015.A1/PD2571.241005.001:user/release-keys"

[templates."vivo_v2572a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2572A"
device = "PD2572"
product = "PD2572"
name = "PD2572"
marketname = "vivo S60 元气版"
fingerprint = "vivo/PD2572/PD2572:15/AP3A.241005.015.A1/PD2572.241005.001:user/release-keys"

[templates."vivo_v2620a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2620A"
device = "PD2620"
product = "PD2620"
name = "PD2620"
marketname = "vivo S60t"
fingerprint = "vivo/PD2620/PD2620:15/AP3A.241005.015.A1/PD2620.241005.001:user/release-keys"

[templates."vivo_v1901a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1901A"
device = "PD1901"
product = "PD1901"
name = "PD1901"
marketname = "vivo Y3"
fingerprint = "vivo/PD1901/PD1901:15/AP3A.241005.015.A1/PD1901.241005.001:user/release-keys"

[templates."vivo_v1934a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1934A"
device = "PD1934"
product = "PD1934"
name = "PD1934"
marketname = "vivo Y5s"
fingerprint = "vivo/PD1934/PD1934:15/AP3A.241005.015.A1/PD1934.241005.001:user/release-keys"

[templates."vivo_v1913a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1913A"
device = "PD1913"
product = "PD1913"
name = "PD1913"
marketname = "vivo Y7s"
fingerprint = "vivo/PD1913/PD1913:15/AP3A.241005.015.A1/PD1913.241005.001:user/release-keys"

[templates."vivo_v1945a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1945A"
device = "PD1945"
product = "PD1945"
name = "PD1945"
marketname = "vivo Y9s"
fingerprint = "vivo/PD1945/PD1945:15/AP3A.241005.015.A1/PD1945.241005.001:user/release-keys"

[templates."vivo_v2140a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2140A"
device = "PD2140"
product = "PD2140"
name = "PD2140"
marketname = "vivo Y10"
fingerprint = "vivo/PD2140/PD2140:15/AP3A.241005.015.A1/PD2140.241005.001:user/release-keys"

[templates."vivo_v2236a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2236A"
device = "PD2236"
product = "PD2236"
name = "PD2236"
marketname = "vivo Y11"
fingerprint = "vivo/PD2236/PD2236:15/AP3A.241005.015.A1/PD2236.241005.001:user/release-keys"

[templates."vivo_v2317a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2317A"
device = "PD2317"
product = "PD2317"
name = "PD2317"
marketname = "vivo Y12"
fingerprint = "vivo/PD2317/PD2317:15/AP3A.241005.015.A1/PD2317.241005.001:user/release-keys"

[templates."vivo_v2034a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2034A"
device = "PD2034"
product = "PD2034"
name = "PD2034"
marketname = "vivo Y30"
fingerprint = "vivo/PD2034/PD2034:15/AP3A.241005.015.A1/PD2034.241005.001:user/release-keys"

[templates."vivo_v2099a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2099A"
device = "PD2099"
product = "PD2099"
name = "PD2099"
marketname = "vivo Y30 2021"
fingerprint = "vivo/PD2099/PD2099:15/AP3A.241005.015.A1/PD2099.241005.001:user/release-keys"

[templates."vivo_v2066a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2066A"
device = "PD2066"
product = "PD2066"
name = "PD2066"
marketname = "vivo Y30 活力版"
fingerprint = "vivo/PD2066/PD2066:15/AP3A.241005.015.A1/PD2066.241005.001:user/release-keys"

[templates."vivo_v2066ba"]
manufacturer = "vivo"
brand = "vivo"
model = "V2066BA"
device = "PD2066B"
product = "PD2066B"
name = "PD2066B"
marketname = "vivo Y30g"
fingerprint = "vivo/PD2066B/PD2066B:15/AP3A.241005.015.A1/PD2066B.241005.001:user/release-keys"

[templates."vivo_v2054a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2054A"
device = "t1"
product = "t1"
name = "t1"
marketname = "vivo Y31s 5G"
fingerprint = "vivo/t1/t1:15/AP3A.241005.015.A1/t1.241005.001:user/release-keys"

[templates."vivo_v2068a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2068A"
device = "t1"
product = "t1"
name = "t1"
marketname = "vivo Y31s 标准版 5G"
fingerprint = "vivo/t1/t1:15/AP3A.241005.015.A1/t1.241005.001:user/release-keys"

[templates."vivo_v2158a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2158A"
device = "PD2158"
product = "PD2158"
name = "PD2158"
marketname = "vivo Y32"
fingerprint = "vivo/PD2158/PD2158:15/AP3A.241005.015.A1/PD2158.241005.001:user/release-keys"

[templates."vivo_v2166a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2166A"
device = "PD2166"
product = "PD2166"
name = "PD2166"
marketname = "vivo Y33s 5G"
fingerprint = "vivo/PD2166/PD2166:15/AP3A.241005.015.A1/PD2166.241005.001:user/release-keys"

[templates."vivo_v2230a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2230A"
device = "PD2230"
product = "PD2230"
name = "PD2230"
marketname = "vivo Y35 5G"
fingerprint = "vivo/PD2230/PD2230:15/AP3A.241005.015.A1/PD2230.241005.001:user/release-keys"

[templates."vivo_v2279a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2279A"
device = "PD2279"
product = "PD2279"
name = "PD2279"
marketname = "vivo Y35+ 5G"
fingerprint = "vivo/PD2279/PD2279:15/AP3A.241005.015.A1/PD2279.241005.001:user/release-keys"

[templates."vivo_v2318a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2318A"
device = "PD2318"
product = "PD2318"
name = "PD2318"
marketname = "vivo Y36 5G"
fingerprint = "vivo/PD2318/PD2318:15/AP3A.241005.015.A1/PD2318.241005.001:user/release-keys"

[templates."vivo_v2327a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2327A"
device = "PD2327"
product = "PD2327"
name = "PD2327"
marketname = "vivo Y36t"
fingerprint = "vivo/PD2327/PD2327:15/AP3A.241005.015.A1/PD2327.241005.001:user/release-keys"

[templates."vivo_v2357a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2357A"
device = "PD2357"
product = "PD2357"
name = "PD2357"
marketname = "vivo Y36c 5G"
fingerprint = "vivo/PD2357/PD2357:15/AP3A.241005.015.A1/PD2357.241005.001:user/release-keys"

[templates."vivo_v2357ea"]
manufacturer = "vivo"
brand = "vivo"
model = "V2357EA"
device = "PD2357"
product = "PD2357"
name = "PD2357"
marketname = "vivo Y37m 5G"
fingerprint = "vivo/PD2357/PD2357:15/AP3A.241005.015.A1/PD2357.241005.001:user/release-keys"

[templates."vivo_v2354a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2354A"
device = "PD2354"
product = "PD2354"
name = "PD2354"
marketname = "vivo Y37 Pro 5G"
fingerprint = "vivo/PD2354/PD2354:15/AP3A.241005.015.A1/PD2354.241005.001:user/release-keys"

[templates."vivo_v2442a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2442A"
device = "PD2442"
product = "PD2442"
name = "PD2442"
marketname = "vivo Y37c"
fingerprint = "vivo/PD2442/PD2442:15/AP3A.241005.015.A1/PD2442.241005.001:user/release-keys"

[templates."vivo_v1965a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1965A"
device = "PD1965"
product = "PD1965"
name = "PD1965"
marketname = "vivo Y50"
fingerprint = "vivo/PD1965/PD1965:15/AP3A.241005.015.A1/PD1965.241005.001:user/release-keys"

[templates."vivo_v2023ea"]
manufacturer = "vivo"
brand = "vivo"
model = "V2023EA"
device = "PD2023"
product = "PD2023"
name = "PD2023"
marketname = "vivo Y50t"
fingerprint = "vivo/PD2023/PD2023:15/AP3A.241005.015.A1/PD2023.241005.001:user/release-keys"

[templates."vivo_v2443a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2443A"
device = "PD2443"
product = "PD2443"
name = "PD2443"
marketname = "vivo Y37t 5G"
fingerprint = "vivo/PD2443/PD2443:15/AP3A.241005.015.A1/PD2443.241005.001:user/release-keys"

[templates."vivo_v2443ba"]
manufacturer = "vivo"
brand = "vivo"
model = "V2443BA"
device = "PD2443"
product = "PD2443"
name = "PD2443"
marketname = "vivo Y50m 5G"
fingerprint = "vivo/PD2443/PD2443:15/AP3A.241005.015.A1/PD2443.241005.001:user/release-keys"

[templates."vivo_v2002a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2002A"
device = "PD2019"
product = "PD2019"
name = "PD2019"
marketname = "vivo Y51s 5G"
fingerprint = "vivo/PD2019/PD2019:15/AP3A.241005.015.A1/PD2019.241005.001:user/release-keys"

[templates."vivo_v2057a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2057A"
device = "PD2057"
product = "PD2057"
name = "PD2057"
marketname = "vivo Y52s 5G"
fingerprint = "vivo/PD2057/PD2057:15/AP3A.241005.015.A1/PD2057.241005.001:user/release-keys"

[templates."vivo_v2111a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2111A"
device = "PD2111"
product = "PD2111"
name = "PD2111"
marketname = "vivo Y53s 5G"
fingerprint = "vivo/PD2111/PD2111:15/AP3A.241005.015.A1/PD2111.241005.001:user/release-keys"

[templates."vivo_v2045a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2045A"
device = "PD2045"
product = "PD2045"
name = "PD2045"
marketname = "vivo Y54s 5G"
fingerprint = "vivo/PD2045/PD2045:15/AP3A.241005.015.A1/PD2045.241005.001:user/release-keys"

[templates."vivo_v2164a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2164A"
device = "PD2164"
product = "PD2164"
name = "PD2164"
marketname = "vivo Y55s 5G"
fingerprint = "vivo/PD2164/PD2164:15/AP3A.241005.015.A1/PD2164.241005.001:user/release-keys"

[templates."vivo_v2541a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2541A"
device = "PD2541"
product = "PD2541"
name = "PD2541"
marketname = "vivo Y6c"
fingerprint = "vivo/PD2541/PD2541:15/AP3A.241005.015.A1/PD2541.241005.001:user/release-keys"

[templates."vivo_v2559a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2559A"
device = "PD2559"
product = "PD2559"
name = "PD2559"
marketname = "vivo Y60"
fingerprint = "vivo/PD2559/PD2559:15/AP3A.241005.015.A1/PD2559.241005.001:user/release-keys"

[templates."vivo_v2559ba"]
manufacturer = "vivo"
brand = "vivo"
model = "V2559BA"
device = "PD2559"
product = "PD2559"
name = "PD2559"
marketname = "vivo Y60m"
fingerprint = "vivo/PD2559/PD2559:15/AP3A.241005.015.A1/PD2559.241005.001:user/release-keys"

[templates."vivo_v2532ba"]
manufacturer = "vivo"
brand = "vivo"
model = "V2532BA"
device = "PD2532"
product = "PD2532"
name = "PD2532"
marketname = "vivo Y6m"
fingerprint = "vivo/PD2532/PD2532:15/AP3A.241005.015.A1/PD2532.241005.001:user/release-keys"

[templates."vivo_v2542a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2542A"
device = "PD2542"
product = "PD2542"
name = "PD2542"
marketname = "vivo Y60i"
fingerprint = "vivo/PD2542/PD2542:15/AP3A.241005.015.A1/PD2542.241005.001:user/release-keys"

[templates."vivo_v1731ca"]
manufacturer = "vivo"
brand = "vivo"
model = "V1731CA"
device = "PD1731C"
product = "PD1731C"
name = "PD1731C"
marketname = "vivo Y71s"
fingerprint = "vivo/PD1731C/PD1731C:15/AP3A.241005.015.A1/PD1731C.241005.001:user/release-keys"

[templates."vivo_v2102a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2102A"
device = "PD2102"
product = "PD2102"
name = "PD2102"
marketname = "vivo Y71t 5G"
fingerprint = "vivo/PD2102/PD2102:15/AP3A.241005.015.A1/PD2102.241005.001:user/release-keys"

[templates."vivo_v2164pa"]
manufacturer = "vivo"
brand = "vivo"
model = "V2164PA"
device = "PD2164U"
product = "PD2164U"
name = "PD2164U"
marketname = "vivo Y73t 5G"
fingerprint = "vivo/PD2164U/PD2164U:15/AP3A.241005.015.A1/PD2164U.241005.001:user/release-keys"

[templates."vivo_v2009a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2009A"
device = "PD2009"
product = "PD2009"
name = "PD2009"
marketname = "vivo Y74s 5G"
fingerprint = "vivo/PD2009/PD2009:15/AP3A.241005.015.A1/PD2009.241005.001:user/release-keys"

[templates."vivo_v2069ba"]
manufacturer = "vivo"
brand = "vivo"
model = "V2069BA"
device = "PD2069"
product = "PD2069"
name = "PD2069"
marketname = "vivo Y75s 5G"
fingerprint = "vivo/PD2069/PD2069:15/AP3A.241005.015.A1/PD2069.241005.001:user/release-keys"

[templates."vivo_v2156a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2156A"
device = "PD2156"
product = "PD2156"
name = "PD2156"
marketname = "vivo Y76s 5G"
fingerprint = "vivo/PD2156/PD2156:15/AP3A.241005.015.A1/PD2156.241005.001:user/release-keys"

[templates."vivo_v2219a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2219A"
device = "PD2219"
product = "PD2219"
name = "PD2219"
marketname = "vivo Y77 5G"
fingerprint = "vivo/PD2219/PD2219:15/AP3A.241005.015.A1/PD2219.241005.001:user/release-keys"

[templates."vivo_v2166ba"]
manufacturer = "vivo"
brand = "vivo"
model = "V2166BA"
device = "t1"
product = "t1"
name = "t1"
marketname = "vivo Y77e 5G"
fingerprint = "vivo/t1/t1:15/AP3A.241005.015.A1/t1.241005.001:user/release-keys"

[templates."vivo_v2278a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2278A"
device = "PD2278"
product = "PD2278"
name = "PD2278"
marketname = "vivo Y77t 5G"
fingerprint = "vivo/PD2278/PD2278:15/AP3A.241005.015.A1/PD2278.241005.001:user/release-keys"

[templates."vivo_v2271a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2271A"
device = "t1"
product = "t1"
name = "t1"
marketname = "vivo Y78+ 5G"
fingerprint = "vivo/t1/t1:15/AP3A.241005.015.A1/t1.241005.001:user/release-keys"

[templates."vivo_v2312ba"]
manufacturer = "vivo"
brand = "vivo"
model = "V2312BA"
device = "PD2312"
product = "PD2312"
name = "PD2312"
marketname = "vivo Y78t 5G"
fingerprint = "vivo/PD2312/PD2312:15/AP3A.241005.015.A1/PD2312.241005.001:user/release-keys"

[templates."vivo_v1732a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1732A"
device = "PD1732"
product = "PD1732"
name = "PD1732"
marketname = "vivo Y81"
fingerprint = "vivo/PD1732/PD1732:15/AP3A.241005.015.A1/PD1732.241005.001:user/release-keys"

[templates."vivo_v1730ea"]
manufacturer = "vivo"
brand = "vivo"
model = "V1730EA"
device = "PD1730E"
product = "PD1730E"
name = "PD1730E"
marketname = "vivo Y89"
fingerprint = "vivo/PD1730E/PD1730E:15/AP3A.241005.015.A1/PD1730E.241005.001:user/release-keys"

[templates."vivo_v1818ca"]
manufacturer = "vivo"
brand = "vivo"
model = "V1818CA"
device = "PD1818C"
product = "PD1818C"
name = "PD1818C"
marketname = "vivo Y91"
fingerprint = "vivo/PD1818C/PD1818C:15/AP3A.241005.015.A1/PD1818C.241005.001:user/release-keys"

[templates."vivo_v1818a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1818A"
device = "PD1818"
product = "PD1818"
name = "PD1818"
marketname = "vivo Y93"
fingerprint = "vivo/PD1818/PD1818:15/AP3A.241005.015.A1/PD1818.241005.001:user/release-keys"

[templates."vivo_v1813a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1813A"
device = "PD1813"
product = "PD1813"
name = "PD1813"
marketname = "vivo Y97"
fingerprint = "vivo/PD1813/PD1813:15/AP3A.241005.015.A1/PD1813.241005.001:user/release-keys"

[templates."vivo_v2313a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2313A"
device = "PD2313"
product = "PD2313"
name = "PD2313"
marketname = "vivo Y100 5G"
fingerprint = "vivo/PD2313/PD2313:15/AP3A.241005.015.A1/PD2313.241005.001:user/release-keys"

[templates."vivo_v2314da"]
manufacturer = "vivo"
brand = "vivo"
model = "V2314DA"
device = "PD2314"
product = "PD2314"
name = "PD2314"
marketname = "vivo Y100t 5G"
fingerprint = "vivo/PD2314/PD2314:15/AP3A.241005.015.A1/PD2314.241005.001:user/release-keys"

[templates."vivo_v2343a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2343A"
device = "PD2343"
product = "PD2343"
name = "PD2343"
marketname = "vivo Y200 5G"
fingerprint = "vivo/PD2343/PD2343:15/AP3A.241005.015.A1/PD2343.241005.001:user/release-keys"

[templates."vivo_v2361ga"]
manufacturer = "vivo"
brand = "vivo"
model = "V2361GA"
device = "PD2361"
product = "PD2361"
name = "PD2361"
marketname = "vivo Y200 GT 5G"
fingerprint = "vivo/PD2361/PD2361:15/AP3A.241005.015.A1/PD2361.241005.001:user/release-keys"

[templates."vivo_v2353da"]
manufacturer = "vivo"
brand = "vivo"
model = "V2353DA"
device = "PD2353"
product = "PD2353"
name = "PD2353"
marketname = "vivo Y200t 5G"
fingerprint = "vivo/PD2353/PD2353:15/AP3A.241005.015.A1/PD2353.241005.001:user/release-keys"

[templates."vivo_v2435a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2435A"
device = "PD2435"
product = "PD2435"
name = "PD2435"
marketname = "vivo Y300 5G"
fingerprint = "vivo/PD2435/PD2435:15/AP3A.241005.015.A1/PD2435.241005.001:user/release-keys"

[templates."vivo_v2444a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2444A"
device = "PD2444"
product = "PD2444"
name = "PD2444"
marketname = "vivo Y300i 5G"
fingerprint = "vivo/PD2444/PD2444:15/AP3A.241005.015.A1/PD2444.241005.001:user/release-keys"

[templates."vivo_v2410a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2410A"
device = "PD2410"
product = "PD2410"
name = "PD2410"
marketname = "vivo Y300 Pro"
fingerprint = "vivo/PD2410/PD2410:15/AP3A.241005.015.A1/PD2410.241005.001:user/release-keys"

[templates."vivo_v2456a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2456A"
device = "PD2456"
product = "PD2456"
name = "PD2456"
marketname = "vivo Y300 Pro+"
fingerprint = "vivo/PD2456/PD2456:15/AP3A.241005.015.A1/PD2456.241005.001:user/release-keys"

[templates."vivo_v2445ea"]
manufacturer = "vivo"
brand = "vivo"
model = "V2445EA"
device = "PD2445D"
product = "PD2445D"
name = "PD2445D"
marketname = "vivo Y300t"
fingerprint = "vivo/PD2445D/PD2445D:15/AP3A.241005.015.A1/PD2445D.241005.001:user/release-keys"

[templates."vivo_v2452ga"]
manufacturer = "vivo"
brand = "vivo"
model = "V2452GA"
device = "PD2452"
product = "PD2452"
name = "PD2452"
marketname = "vivo Y300 GT"
fingerprint = "vivo/PD2452/PD2452:15/AP3A.241005.015.A1/PD2452.241005.001:user/release-keys"

[templates."vivo_v2506a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2506A"
device = "PD2506"
product = "PD2506"
name = "PD2506"
marketname = "vivo Y500"
fingerprint = "vivo/PD2506/PD2506:15/AP3A.241005.015.A1/PD2506.241005.001:user/release-keys"

[templates."vivo_v2516a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2516A"
device = "PD2516"
product = "PD2516"
name = "PD2516"
marketname = "vivo Y500 Pro"
fingerprint = "vivo/PD2516/PD2516:15/AP3A.241005.015.A1/PD2516.241005.001:user/release-keys"

[templates."vivo_v2531a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2531A"
device = "PD2531"
product = "PD2531"
name = "PD2531"
marketname = "vivo Y500i"
fingerprint = "vivo/PD2531/PD2531:15/AP3A.241005.015.A1/PD2531.241005.001:user/release-keys"

[templates."vivo_v2617a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2617A"
device = "PD2617"
product = "PD2617"
name = "PD2617"
marketname = "vivo Y500k"
fingerprint = "vivo/PD2617/PD2617:15/AP3A.241005.015.A1/PD2617.241005.001:user/release-keys"

[templates."vivo_v2607a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2607A"
device = "PD2607"
product = "PD2607"
name = "PD2607"
marketname = "vivo Y600"
fingerprint = "vivo/PD2607/PD2607:15/AP3A.241005.015.A1/PD2607.241005.001:user/release-keys"

[templates."vivo_v2561a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2561A"
device = "PD2561"
product = "PD2561"
name = "PD2561"
marketname = "vivo Y600 Pro"
fingerprint = "vivo/PD2561/PD2561:15/AP3A.241005.015.A1/PD2561.241005.001:user/release-keys"

[templates."vivo_v2553a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2553A"
device = "PD2553"
product = "PD2553"
name = "PD2553"
marketname = "vivo Y600 Turbo"
fingerprint = "vivo/PD2553/PD2553:15/AP3A.241005.015.A1/PD2553.241005.001:user/release-keys"

[templates."vivo_v2115a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2115A"
device = "PD2115"
product = "PD2115"
name = "PD2115"
marketname = "vivo T1"
fingerprint = "vivo/PD2115/PD2115:15/AP3A.241005.015.A1/PD2115.241005.001:user/release-keys"

[templates."vivo_v2199ga"]
manufacturer = "vivo"
brand = "vivo"
model = "V2199GA"
device = "PD2199"
product = "PD2199"
name = "PD2199"
marketname = "vivo T2"
fingerprint = "vivo/PD2199/PD2199:15/AP3A.241005.015.A1/PD2199.241005.001:user/release-keys"

[templates."vivo_v2188a"]
manufacturer = "vivo"
brand = "vivo"
model = "V2188A"
device = "PD2188"
product = "PD2188"
name = "PD2188"
marketname = "vivo T2x"
fingerprint = "vivo/PD2188/PD2188:15/AP3A.241005.015.A1/PD2188.241005.001:user/release-keys"

[templates."vivo_v1801a0"]
manufacturer = "vivo"
brand = "vivo"
model = "V1801A0"
device = "PD1730C"
product = "PD1730C"
name = "PD1730C"
marketname = "vivo Z1"
fingerprint = "vivo/PD1730C/PD1730C:15/AP3A.241005.015.A1/PD1730C.241005.001:user/release-keys"

[templates."vivo_v1730da"]
manufacturer = "vivo"
brand = "vivo"
model = "V1730DA"
device = "PD1730D"
product = "PD1730D"
name = "PD1730D"
marketname = "vivo Z1i"
fingerprint = "vivo/PD1730D/PD1730D:15/AP3A.241005.015.A1/PD1730D.241005.001:user/release-keys"

[templates."vivo_v1813ba"]
manufacturer = "vivo"
brand = "vivo"
model = "V1813BA"
device = "PD1813B"
product = "PD1813B"
name = "PD1813B"
marketname = "vivo Z3"
fingerprint = "vivo/PD1813B/PD1813B:15/AP3A.241005.015.A1/PD1813B.241005.001:user/release-keys"

[templates."vivo_v1730ga"]
manufacturer = "vivo"
brand = "vivo"
model = "V1730GA"
device = "PD1730G"
product = "PD1730G"
name = "PD1730G"
marketname = "vivo Z3x"
fingerprint = "vivo/PD1730G/PD1730G:15/AP3A.241005.015.A1/PD1730G.241005.001:user/release-keys"

[templates."vivo_v1921a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1921A"
device = "PD1921"
product = "PD1921"
name = "PD1921"
marketname = "vivo Z5"
fingerprint = "vivo/PD1921/PD1921:15/AP3A.241005.015.A1/PD1921.241005.001:user/release-keys"

[templates."vivo_v1911a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1911A"
device = "PD1911"
product = "PD1911"
name = "PD1911"
marketname = "vivo Z5x"
fingerprint = "vivo/PD1911/PD1911:15/AP3A.241005.015.A1/PD1911.241005.001:user/release-keys"

[templates."vivo_v1990a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1990A"
device = "PD1990"
product = "PD1990"
name = "PD1990"
marketname = "vivo Z5x 712 版"
fingerprint = "vivo/PD1990/PD1990:15/AP3A.241005.015.A1/PD1990.241005.001:user/release-keys"

[templates."vivo_v1941a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1941A"
device = "PD1941"
product = "PD1941"
name = "PD1941"
marketname = "vivo Z5i"
fingerprint = "vivo/PD1941/PD1941:15/AP3A.241005.015.A1/PD1941.241005.001:user/release-keys"

[templates."vivo_v1963a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1963A"
device = "PD1963"
product = "PD1963"
name = "PD1963"
marketname = "vivo Z6 5G"
fingerprint = "vivo/PD1963/PD1963:15/AP3A.241005.015.A1/PD1963.241005.001:user/release-keys"

[templates."vivo_v1928a"]
manufacturer = "vivo"
brand = "vivo"
model = "V1928A"
device = "PD1928"
product = "PD1928"
name = "PD1928"
marketname = "vivo U3x"
fingerprint = "vivo/PD1928/PD1928:15/AP3A.241005.015.A1/PD1928.241005.001:user/release-keys"

[templates."vivo_v1962ba"]
manufacturer = "vivo"
brand = "vivo"
model = "V1962BA"
device = "PD1962B"
product = "PD1962B"
name = "PD1962B"
marketname = "vivo G1"
fingerprint = "vivo/PD1962B/PD1962B:15/AP3A.241005.015.A1/PD1962B.241005.001:user/release-keys"

[templates."iqoo_v1824ba"]
manufacturer = "vivo"
brand = "iQOO"
model = "V1824BA"
device = "PD1824"
product = "PD1824"
name = "PD1824"
marketname = "vivo iQOO"
fingerprint = "vivo/PD1824/PD1824:15/AP3A.241005.015.A1/PD1824.241005.001:user/release-keys"

[templates."iqoo_v1922a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V1922A"
device = "PD1922"
product = "PD1922"
name = "PD1922"
marketname = "vivo iQOO Pro"
fingerprint = "vivo/PD1922/PD1922:15/AP3A.241005.015.A1/PD1922.241005.001:user/release-keys"

[templates."iqoo_v1916a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V1916A"
device = "PD1916"
product = "PD1916"
name = "PD1916"
marketname = "vivo iQOO Pro 5G"
fingerprint = "vivo/PD1916/PD1916:15/AP3A.241005.015.A1/PD1916.241005.001:user/release-keys"

[templates."iqoo_v1955a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V1955A"
device = "PD1955"
product = "PD1955"
name = "PD1955"
marketname = "vivo iQOO 3"
fingerprint = "vivo/PD1955/PD1955:15/AP3A.241005.015.A1/PD1955.241005.001:user/release-keys"

[templates."iqoo_v2024a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2024A"
device = "PD2024"
product = "PD2024"
name = "PD2024"
marketname = "vivo iQOO 5"
fingerprint = "vivo/PD2024/PD2024:15/AP3A.241005.015.A1/PD2024.241005.001:user/release-keys"

[templates."iqoo_v2025a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2025A"
device = "PD2025"
product = "PD2025"
name = "PD2025"
marketname = "vivo iQOO 5 Pro"
fingerprint = "vivo/PD2025/PD2025:15/AP3A.241005.015.A1/PD2025.241005.001:user/release-keys"

[templates."iqoo_v2049a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2049A"
device = "PD2049"
product = "PD2049"
name = "PD2049"
marketname = "vivo iQOO 7"
fingerprint = "vivo/PD2049/PD2049:15/AP3A.241005.015.A1/PD2049.241005.001:user/release-keys"

[templates."iqoo_v2136a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2136A"
device = "PD2136"
product = "PD2136"
name = "PD2136"
marketname = "vivo iQOO 8"
fingerprint = "vivo/PD2136/PD2136:15/AP3A.241005.015.A1/PD2136.241005.001:user/release-keys"

[templates."iqoo_v2141a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2141A"
device = "PD2141"
product = "PD2141"
name = "PD2141"
marketname = "vivo iQOO 8 Pro"
fingerprint = "vivo/PD2141/PD2141:15/AP3A.241005.015.A1/PD2141.241005.001:user/release-keys"

[templates."iqoo_v2171a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2171A"
device = "PD2171"
product = "PD2171"
name = "PD2171"
marketname = "vivo iQOO 9"
fingerprint = "vivo/PD2171/PD2171:15/AP3A.241005.015.A1/PD2171.241005.001:user/release-keys"

[templates."iqoo_v2172a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2172A"
device = "PD2172"
product = "PD2172"
name = "PD2172"
marketname = "vivo iQOO 9 Pro"
fingerprint = "vivo/PD2172/PD2172:15/AP3A.241005.015.A1/PD2172.241005.001:user/release-keys"

[templates."iqoo_v2217a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2217A"
device = "PD2217"
product = "PD2217"
name = "PD2217"
marketname = "vivo iQOO 10"
fingerprint = "vivo/PD2217/PD2217:15/AP3A.241005.015.A1/PD2217.241005.001:user/release-keys"

[templates."iqoo_v2218a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2218A"
device = "PD2218"
product = "PD2218"
name = "PD2218"
marketname = "vivo iQOO 10 Pro"
fingerprint = "vivo/PD2218/PD2218:15/AP3A.241005.015.A1/PD2218.241005.001:user/release-keys"

[templates."iqoo_v2243a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2243A"
device = "PD2243"
product = "PD2243"
name = "PD2243"
marketname = "vivo iQOO 11"
fingerprint = "vivo/PD2243/PD2243:15/AP3A.241005.015.A1/PD2243.241005.001:user/release-keys"

[templates."iqoo_v2254a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2254A"
device = "PD2254"
product = "PD2254"
name = "PD2254"
marketname = "vivo iQOO 11 Pro"
fingerprint = "vivo/PD2254/PD2254:15/AP3A.241005.015.A1/PD2254.241005.001:user/release-keys"

[templates."iqoo_v2304a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2304A"
device = "PD2304"
product = "PD2304"
name = "PD2304"
marketname = "vivo iQOO 11S"
fingerprint = "vivo/PD2304/PD2304:15/AP3A.241005.015.A1/PD2304.241005.001:user/release-keys"

[templates."iqoo_v2307a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2307A"
device = "PD2307"
product = "PD2307"
name = "PD2307"
marketname = "vivo iQOO 12"
fingerprint = "vivo/PD2307/PD2307:15/AP3A.241005.015.A1/PD2307.241005.001:user/release-keys"

[templates."iqoo_v2329a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2329A"
device = "PD2329"
product = "PD2329"
name = "PD2329"
marketname = "vivo iQOO 12 Pro"
fingerprint = "vivo/PD2329/PD2329:15/AP3A.241005.015.A1/PD2329.241005.001:user/release-keys"

[templates."iqoo_v2408a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2408A"
device = "PD2408"
product = "PD2408"
name = "PD2408"
marketname = "vivo iQOO 13"
fingerprint = "vivo/PD2408/PD2408:15/AP3A.241005.015.A1/PD2408.241005.001:user/release-keys"

[templates."iqoo_v2505a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2505A"
device = "PD2505"
product = "PD2505"
name = "PD2505"
marketname = "vivo iQOO 15"
fingerprint = "vivo/PD2505/PD2505:15/AP3A.241005.015.A1/PD2505.241005.001:user/release-keys"

[templates."iqoo_v2546a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2546A"
device = "PD2546"
product = "PD2546"
name = "PD2546"
marketname = "vivo iQOO 15 Ultra"
fingerprint = "vivo/PD2546/PD2546:15/AP3A.241005.015.A1/PD2546.241005.001:user/release-keys"

[templates."iqoo_v2564a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2564A"
device = "PD2564"
product = "PD2564"
name = "PD2564"
marketname = "vivo iQOO 15T"
fingerprint = "vivo/PD2564/PD2564:15/AP3A.241005.015.A1/PD2564.241005.001:user/release-keys"

[templates."iqoo_v2606a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2606A"
device = "PD2606"
product = "PD2606"
name = "PD2606"
marketname = "vivo iQOO 16"
fingerprint = "vivo/PD2606/PD2606:15/AP3A.241005.015.A1/PD2606.241005.001:user/release-keys"

[templates."iqoo_v1914a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V1914A"
device = "PD1914"
product = "PD1914"
name = "PD1914"
marketname = "vivo iQOO Neo"
fingerprint = "vivo/PD1914/PD1914:15/AP3A.241005.015.A1/PD1914.241005.001:user/release-keys"

[templates."iqoo_v1936a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V1936A"
device = "PD1936"
product = "PD1936"
name = "PD1936"
marketname = "vivo iQOO Neo 855 版"
fingerprint = "vivo/PD1936/PD1936:15/AP3A.241005.015.A1/PD1936.241005.001:user/release-keys"

[templates."iqoo_v1936al"]
manufacturer = "vivo"
brand = "iQOO"
model = "V1936AL"
device = "PD1936"
product = "PD1936"
name = "PD1936"
marketname = "vivo iQOO Neo 855 竞速版"
fingerprint = "vivo/PD1936/PD1936:15/AP3A.241005.015.A1/PD1936.241005.001:user/release-keys"

[templates."iqoo_v1981a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V1981A"
device = "PD1981"
product = "PD1981"
name = "PD1981"
marketname = "vivo iQOO Neo3"
fingerprint = "vivo/PD1981/PD1981:15/AP3A.241005.015.A1/PD1981.241005.001:user/release-keys"

[templates."iqoo_v2055a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2055A"
device = "PD2055"
product = "PD2055"
name = "PD2055"
marketname = "vivo iQOO Neo5"
fingerprint = "vivo/PD2055/PD2055:15/AP3A.241005.015.A1/PD2055.241005.001:user/release-keys"

[templates."iqoo_v2118a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2118A"
device = "PD2118"
product = "PD2118"
name = "PD2118"
marketname = "vivo iQOO Neo5 活力版"
fingerprint = "vivo/PD2118/PD2118:15/AP3A.241005.015.A1/PD2118.241005.001:user/release-keys"

[templates."iqoo_v2154a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2154A"
device = "PD2154"
product = "PD2154"
name = "PD2154"
marketname = "vivo iQOO Neo5S"
fingerprint = "vivo/PD2154/PD2154:15/AP3A.241005.015.A1/PD2154.241005.001:user/release-keys"

[templates."iqoo_v2157a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2157A"
device = "PD2157"
product = "PD2157"
name = "PD2157"
marketname = "vivo iQOO Neo5 SE"
fingerprint = "vivo/PD2157/PD2157:15/AP3A.241005.015.A1/PD2157.241005.001:user/release-keys"

[templates."iqoo_v2196a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2196A"
device = "PD2196"
product = "PD2196"
name = "PD2196"
marketname = "vivo iQOO Neo6"
fingerprint = "vivo/PD2196/PD2196:15/AP3A.241005.015.A1/PD2196.241005.001:user/release-keys"

[templates."iqoo_v2199a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2199A"
device = "PD2199"
product = "PD2199"
name = "PD2199"
marketname = "vivo iQOO Neo6 SE"
fingerprint = "vivo/PD2199/PD2199:15/AP3A.241005.015.A1/PD2199.241005.001:user/release-keys"

[templates."iqoo_v2231a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2231A"
device = "PD2231"
product = "PD2231"
name = "PD2231"
marketname = "vivo iQOO Neo7"
fingerprint = "vivo/PD2231/PD2231:15/AP3A.241005.015.A1/PD2231.241005.001:user/release-keys"

[templates."iqoo_v2232a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2232A"
device = "PD2232"
product = "PD2232"
name = "PD2232"
marketname = "vivo iQOO Neo7 竞速版"
fingerprint = "vivo/PD2232/PD2232:15/AP3A.241005.015.A1/PD2232.241005.001:user/release-keys"

[templates."iqoo_v2238a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2238A"
device = "PD2238"
product = "PD2238"
name = "PD2238"
marketname = "vivo iQOO Neo7 SE"
fingerprint = "vivo/PD2238/PD2238:15/AP3A.241005.015.A1/PD2238.241005.001:user/release-keys"

[templates."iqoo_v2301a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2301A"
device = "PD2301"
product = "PD2301"
name = "PD2301"
marketname = "vivo iQOO Neo8"
fingerprint = "vivo/PD2301/PD2301:15/AP3A.241005.015.A1/PD2301.241005.001:user/release-keys"

[templates."iqoo_v2302a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2302A"
device = "PD2302"
product = "PD2302"
name = "PD2302"
marketname = "vivo iQOO Neo8 Pro"
fingerprint = "vivo/PD2302/PD2302:15/AP3A.241005.015.A1/PD2302.241005.001:user/release-keys"

[templates."iqoo_v2338a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2338A"
device = "PD2338"
product = "PD2338"
name = "PD2338"
marketname = "vivo iQOO Neo9"
fingerprint = "vivo/PD2338/PD2338:15/AP3A.241005.015.A1/PD2338.241005.001:user/release-keys"

[templates."iqoo_v2339a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2339A"
device = "PD2339"
product = "PD2339"
name = "PD2339"
marketname = "vivo iQOO Neo9 Pro"
fingerprint = "vivo/PD2339/PD2339:15/AP3A.241005.015.A1/PD2339.241005.001:user/release-keys"

[templates."iqoo_v2339fa"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2339FA"
device = "PD2339"
product = "PD2339"
name = "PD2339"
marketname = "vivo iQOO Neo9S Pro"
fingerprint = "vivo/PD2339/PD2339:15/AP3A.241005.015.A1/PD2339.241005.001:user/release-keys"

[templates."iqoo_v2403a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2403A"
device = "PD2403"
product = "PD2403"
name = "PD2403"
marketname = "vivo iQOO Neo9S Pro+"
fingerprint = "vivo/PD2403/PD2403:15/AP3A.241005.015.A1/PD2403.241005.001:user/release-keys"

[templates."iqoo_v2425a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2425A"
device = "PD2425"
product = "PD2425"
name = "PD2425"
marketname = "vivo iQOO Neo10"
fingerprint = "vivo/PD2425/PD2425:15/AP3A.241005.015.A1/PD2425.241005.001:user/release-keys"

[templates."iqoo_v2426a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2426A"
device = "PD2426"
product = "PD2426"
name = "PD2426"
marketname = "vivo iQOO Neo10 Pro"
fingerprint = "vivo/PD2426/PD2426:15/AP3A.241005.015.A1/PD2426.241005.001:user/release-keys"

[templates."iqoo_v2463a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2463A"
device = "PD2463"
product = "PD2463"
name = "PD2463"
marketname = "vivo iQOO Neo10 Pro+"
fingerprint = "vivo/PD2463/PD2463:15/AP3A.241005.015.A1/PD2463.241005.001:user/release-keys"

[templates."iqoo_v2520a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2520A"
device = "PD2520"
product = "PD2520"
name = "PD2520"
marketname = "vivo iQOO Neo11"
fingerprint = "vivo/PD2520/PD2520:15/AP3A.241005.015.A1/PD2520.241005.001:user/release-keys"

[templates."iqoo_v2573a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2573A"
device = "PD2573"
product = "PD2573"
name = "PD2573"
marketname = "vivo iQOO Neo11 至尊版"
fingerprint = "vivo/PD2573/PD2573:15/AP3A.241005.015.A1/PD2573.241005.001:user/release-keys"

[templates."iqoo_v2618a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2618A"
device = "PD2618"
product = "PD2618"
name = "PD2618"
marketname = "vivo iQOO Neo12"
fingerprint = "vivo/PD2618/PD2618:15/AP3A.241005.015.A1/PD2618.241005.001:user/release-keys"

[templates."iqoo_v1986a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V1986A"
device = "PD1986"
product = "PD1986"
name = "PD1986"
marketname = "vivo iQOO Z1"
fingerprint = "vivo/PD1986/PD1986:15/AP3A.241005.015.A1/PD1986.241005.001:user/release-keys"

[templates."iqoo_v2012a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2012A"
device = "PD2012"
product = "PD2012"
name = "PD2012"
marketname = "vivo iQOO Z1x"
fingerprint = "vivo/PD2012/PD2012:15/AP3A.241005.015.A1/PD2012.241005.001:user/release-keys"

[templates."iqoo_v2073a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2073A"
device = "PD2073"
product = "PD2073"
name = "PD2073"
marketname = "vivo iQOO Z3"
fingerprint = "vivo/PD2073/PD2073:15/AP3A.241005.015.A1/PD2073.241005.001:user/release-keys"

[templates."iqoo_v2148a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2148A"
device = "PD2148"
product = "PD2148"
name = "PD2148"
marketname = "vivo iQOO Z5"
fingerprint = "vivo/PD2148/PD2148:15/AP3A.241005.015.A1/PD2148.241005.001:user/release-keys"

[templates."iqoo_v2131a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2131A"
device = "PD2131"
product = "PD2131"
name = "PD2131"
marketname = "vivo iQOO Z5x"
fingerprint = "vivo/PD2131/PD2131:15/AP3A.241005.015.A1/PD2131.241005.001:user/release-keys"

[templates."iqoo_v2220a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2220A"
device = "PD2220"
product = "PD2220"
name = "PD2220"
marketname = "vivo iQOO Z6"
fingerprint = "vivo/PD2220/PD2220:15/AP3A.241005.015.A1/PD2220.241005.001:user/release-keys"

[templates."iqoo_v2164ka"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2164KA"
device = "PD2164U"
product = "PD2164U"
name = "PD2164U"
marketname = "vivo iQOO Z6x"
fingerprint = "vivo/PD2164U/PD2164U:15/AP3A.241005.015.A1/PD2164U.241005.001:user/release-keys"

[templates."iqoo_v2270a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2270A"
device = "PD2270"
product = "PD2270"
name = "PD2270"
marketname = "vivo iQOO Z7"
fingerprint = "vivo/PD2270/PD2270:15/AP3A.241005.015.A1/PD2270.241005.001:user/release-keys"

[templates."iqoo_v2272a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2272A"
device = "PD2272"
product = "PD2272"
name = "PD2272"
marketname = "vivo iQOO Z7x"
fingerprint = "vivo/PD2272/PD2272:15/AP3A.241005.015.A1/PD2272.241005.001:user/release-keys"

[templates."iqoo_v2230ea"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2230EA"
device = "PD2230"
product = "PD2230"
name = "PD2230"
marketname = "vivo iQOO Z7i"
fingerprint = "vivo/PD2230/PD2230:15/AP3A.241005.015.A1/PD2230.241005.001:user/release-keys"

[templates."iqoo_v2314a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2314A"
device = "PD2314"
product = "PD2314"
name = "PD2314"
marketname = "vivo iQOO Z8"
fingerprint = "vivo/PD2314/PD2314:15/AP3A.241005.015.A1/PD2314.241005.001:user/release-keys"

[templates."iqoo_v2312a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2312A"
device = "PD2312"
product = "PD2312"
name = "PD2312"
marketname = "vivo iQOO Z8x"
fingerprint = "vivo/PD2312/PD2312:15/AP3A.241005.015.A1/PD2312.241005.001:user/release-keys"

[templates."iqoo_v2361a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2361A"
device = "PD2361"
product = "PD2361"
name = "PD2361"
marketname = "vivo iQOO Z9"
fingerprint = "vivo/PD2361/PD2361:15/AP3A.241005.015.A1/PD2361.241005.001:user/release-keys"

[templates."iqoo_v2352a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2352A"
device = "PD2352"
product = "PD2352"
name = "PD2352"
marketname = "vivo iQOO Z9 Turbo"
fingerprint = "vivo/PD2352/PD2352:15/AP3A.241005.015.A1/PD2352.241005.001:user/release-keys"

[templates."iqoo_v2352ga"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2352GA"
device = "PD2352G"
product = "PD2352G"
name = "PD2352G"
marketname = "vivo iQOO Z9 Turbo 长续航版"
fingerprint = "vivo/PD2352G/PD2352G:15/AP3A.241005.015.A1/PD2352G.241005.001:user/release-keys"

[templates."iqoo_v2417a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2417A"
device = "PD2417"
product = "PD2417"
name = "PD2417"
marketname = "vivo iQOO Z9 Turbo+"
fingerprint = "vivo/PD2417/PD2417:15/AP3A.241005.015.A1/PD2417.241005.001:user/release-keys"

[templates."iqoo_v2353a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2353A"
device = "PD2353"
product = "PD2353"
name = "PD2353"
marketname = "vivo iQOO Z9x"
fingerprint = "vivo/PD2353/PD2353:15/AP3A.241005.015.A1/PD2353.241005.001:user/release-keys"

[templates."iqoo_v2452a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2452A"
device = "PD2452"
product = "PD2452"
name = "PD2452"
marketname = "vivo iQOO Z10 Turbo"
fingerprint = "vivo/PD2452/PD2452:15/AP3A.241005.015.A1/PD2452.241005.001:user/release-keys"

[templates."iqoo_v2453a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2453A"
device = "PD2453"
product = "PD2453"
name = "PD2453"
marketname = "vivo iQOO Z10 Turbo Pro"
fingerprint = "vivo/PD2453/PD2453:15/AP3A.241005.015.A1/PD2453.241005.001:user/release-keys"

[templates."iqoo_v2507a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2507A"
device = "PD2507"
product = "PD2507"
name = "PD2507"
marketname = "vivo iQOO Z10 Turbo+"
fingerprint = "vivo/PD2507/PD2507:15/AP3A.241005.015.A1/PD2507.241005.001:user/release-keys"

[templates."iqoo_v2445a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2445A"
device = "PD2445"
product = "PD2445"
name = "PD2445"
marketname = "vivo iQOO Z10x"
fingerprint = "vivo/PD2445/PD2445:15/AP3A.241005.015.A1/PD2445.241005.001:user/release-keys"

[templates."iqoo_v2536a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2536A"
device = "PD2536"
product = "PD2536"
name = "PD2536"
marketname = "vivo iQOO Z11 Turbo"
fingerprint = "vivo/PD2536/PD2536:15/AP3A.241005.015.A1/PD2536.241005.001:user/release-keys"

[templates."iqoo_v2551a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2551A"
device = "PD2551"
product = "PD2551"
name = "PD2551"
marketname = "vivo iQOO Z11"
fingerprint = "vivo/PD2551/PD2551:15/AP3A.241005.015.A1/PD2551.241005.001:user/release-keys"

[templates."iqoo_v2532a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2532A"
device = "PD2532"
product = "PD2532"
name = "PD2532"
marketname = "vivo iQOO Z11x"
fingerprint = "vivo/PD2532/PD2532:15/AP3A.241005.015.A1/PD2532.241005.001:user/release-keys"

[templates."iqoo_v2559ua"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2559UA"
device = "PD2559"
product = "PD2559"
name = "PD2559"
marketname = "vivo iQOO Z11i"
fingerprint = "vivo/PD2559/PD2559:15/AP3A.241005.015.A1/PD2559.241005.001:user/release-keys"

[templates."iqoo_v2603a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2603A"
device = "PD2603"
product = "PD2603"
name = "PD2603"
marketname = "vivo iQOO Z11S"
fingerprint = "vivo/PD2603/PD2603:15/AP3A.241005.015.A1/PD2603.241005.001:user/release-keys"

[templates."iqoo_v2023a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2023A"
device = "PD2023"
product = "PD2023"
name = "PD2023"
marketname = "vivo iQOO U1"
fingerprint = "vivo/PD2023/PD2023:15/AP3A.241005.015.A1/PD2023.241005.001:user/release-keys"

[templates."iqoo_v2065a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2065A"
device = "PD2065"
product = "PD2065"
name = "PD2065"
marketname = "vivo iQOO U1x"
fingerprint = "vivo/PD2065/PD2065:15/AP3A.241005.015.A1/PD2065.241005.001:user/release-keys"

[templates."iqoo_v2061a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2061A"
device = "PD2061"
product = "PD2061"
name = "PD2061"
marketname = "vivo iQOO U3 5G"
fingerprint = "vivo/PD2061/PD2061:15/AP3A.241005.015.A1/PD2061.241005.001:user/release-keys"

[templates."iqoo_v2106a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2106A"
device = "PD2106"
product = "PD2106"
name = "PD2106"
marketname = "vivo iQOO U3x 5G"
fingerprint = "vivo/PD2106/PD2106:15/AP3A.241005.015.A1/PD2106.241005.001:user/release-keys"

[templates."iqoo_v2143a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2143A"
device = "PD2143"
product = "PD2143"
name = "PD2143"
marketname = "vivo iQOO U3x"
fingerprint = "vivo/PD2143/PD2143:15/AP3A.241005.015.A1/PD2143.241005.001:user/release-keys"

[templates."iqoo_v2165a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2165A"
device = "PD2165"
product = "PD2165"
name = "PD2165"
marketname = "vivo iQOO U5 5G"
fingerprint = "vivo/PD2165/PD2165:15/AP3A.241005.015.A1/PD2165.241005.001:user/release-keys"

[templates."iqoo_v2180ga"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2180GA"
device = "PD2180G"
product = "PD2180G"
name = "PD2180G"
marketname = "vivo iQOO U5x"
fingerprint = "vivo/PD2180G/PD2180G:15/AP3A.241005.015.A1/PD2180G.241005.001:user/release-keys"

[templates."iqoo_v2197a"]
manufacturer = "vivo"
brand = "iQOO"
model = "V2197A"
device = "PD2197"
product = "PD2197"
name = "PD2197"
marketname = "vivo iQOO U5e 5G"
fingerprint = "vivo/PD2197/PD2197:15/AP3A.241005.015.A1/PD2197.241005.001:user/release-keys"

[templates."vivo_pa2170"]
manufacturer = "vivo"
brand = "vivo"
model = "PA2170"
device = "DPD2106"
product = "DPD2106"
name = "DPD2106"
marketname = "vivo Pad"
fingerprint = "vivo/DPD2106/DPD2106:15/AP3A.241005.015.A1/DPD2106.241005.001:user/release-keys"

[templates."vivo_pa2373"]
manufacturer = "vivo"
brand = "vivo"
model = "PA2373"
device = "DPD2221"
product = "DPD2221"
name = "DPD2221"
marketname = "vivo Pad2"
fingerprint = "vivo/DPD2221/DPD2221:15/AP3A.241005.015.A1/DPD2221.241005.001:user/release-keys"

[templates."vivo_pa2353"]
manufacturer = "vivo"
brand = "vivo"
model = "PA2353"
device = "DPD2305"
product = "DPD2305"
name = "DPD2305"
marketname = "vivo Pad Air"
fingerprint = "vivo/DPD2305/DPD2305:15/AP3A.241005.015.A1/DPD2305.241005.001:user/release-keys"

[templates."vivo_pa2455"]
manufacturer = "vivo"
brand = "vivo"
model = "PA2455"
device = "DPD2345"
product = "DPD2345"
name = "DPD2345"
marketname = "vivo Pad3"
fingerprint = "vivo/DPD2345/DPD2345:15/AP3A.241005.015.A1/DPD2345.241005.001:user/release-keys"

[templates."vivo_pa2473"]
manufacturer = "vivo"
brand = "vivo"
model = "PA2473"
device = "DPD2329"
product = "DPD2329"
name = "DPD2329"
marketname = "vivo Pad3 Pro"
fingerprint = "vivo/DPD2329/DPD2329:15/AP3A.241005.015.A1/DPD2329.241005.001:user/release-keys"

[templates."vivo_pa2553"]
manufacturer = "vivo"
brand = "vivo"
model = "PA2553"
device = "DPD2437"
product = "DPD2437"
name = "DPD2437"
marketname = "vivo Pad5"
fingerprint = "vivo/DPD2437/DPD2437:15/AP3A.241005.015.A1/DPD2437.241005.001:user/release-keys"

[templates."vivo_pa2573"]
manufacturer = "vivo"
brand = "vivo"
model = "PA2573"
device = "DPD2429"
product = "DPD2429"
name = "DPD2429"
marketname = "vivo Pad5 Pro"
fingerprint = "vivo/DPD2429/DPD2429:15/AP3A.241005.015.A1/DPD2429.241005.001:user/release-keys"

[templates."vivo_pa2535"]
manufacturer = "vivo"
brand = "vivo"
model = "PA2535"
device = "DPD2345"
product = "DPD2345"
name = "DPD2345"
marketname = "vivo Pad5e"
fingerprint = "vivo/DPD2345/DPD2345:15/AP3A.241005.015.A1/DPD2345.241005.001:user/release-keys"

[templates."vivo_pa2511"]
manufacturer = "vivo"
brand = "vivo"
model = "PA2511"
device = "DPD2424"
product = "DPD2424"
name = "DPD2424"
marketname = "vivo Pad SE"
fingerprint = "vivo/DPD2424/DPD2424:15/AP3A.241005.015.A1/DPD2424.241005.001:user/release-keys"

[templates."vivo_pa2671"]
manufacturer = "vivo"
brand = "vivo"
model = "PA2671"
device = "DPD2540"
product = "DPD2540"
name = "DPD2540"
marketname = "vivo Pad6 Pro"
fingerprint = "vivo/DPD2540/DPD2540:15/AP3A.241005.015.A1/DPD2540.241005.001:user/release-keys"

[templates."iqoo_ipa2375"]
manufacturer = "vivo"
brand = "iQOO"
model = "IPA2375"
device = "DPD2307"
product = "DPD2307"
name = "DPD2307"
marketname = "vivo iQOO Pad"
fingerprint = "vivo/DPD2307/DPD2307:15/AP3A.241005.015.A1/DPD2307.241005.001:user/release-keys"

[templates."iqoo_ipa2451"]
manufacturer = "vivo"
brand = "iQOO"
model = "IPA2451"
device = "DPD2305"
product = "DPD2305"
name = "DPD2305"
marketname = "vivo iQOO Pad Air"
fingerprint = "vivo/DPD2305/DPD2305:15/AP3A.241005.015.A1/DPD2305.241005.001:user/release-keys"

[templates."iqoo_ipa2453"]
manufacturer = "vivo"
brand = "iQOO"
model = "IPA2453"
device = "DPD2345"
product = "DPD2345"
name = "DPD2345"
marketname = "vivo iQOO Pad2"
fingerprint = "vivo/DPD2345/DPD2345:15/AP3A.241005.015.A1/DPD2345.241005.001:user/release-keys"

[templates."iqoo_ipa2475"]
manufacturer = "vivo"
brand = "iQOO"
model = "IPA2475"
device = "DPD2329"
product = "DPD2329"
name = "DPD2329"
marketname = "vivo iQOO Pad2 Pro"
fingerprint = "vivo/DPD2329/DPD2329:15/AP3A.241005.015.A1/DPD2329.241005.001:user/release-keys"

[templates."iqoo_ipa2556"]
manufacturer = "vivo"
brand = "iQOO"
model = "IPA2556"
device = "DPD2437"
product = "DPD2437"
name = "DPD2437"
marketname = "vivo iQOO Pad5"
fingerprint = "vivo/DPD2437/DPD2437:15/AP3A.241005.015.A1/DPD2437.241005.001:user/release-keys"

[templates."iqoo_ipa2575"]
manufacturer = "vivo"
brand = "iQOO"
model = "IPA2575"
device = "DPD2438"
product = "DPD2438"
name = "DPD2438"
marketname = "vivo iQOO Pad5 Pro"
fingerprint = "vivo/DPD2438/DPD2438:15/AP3A.241005.015.A1/DPD2438.241005.001:user/release-keys"

[templates."iqoo_ipa2537"]
manufacturer = "vivo"
brand = "iQOO"
model = "IPA2537"
device = "DPD2345"
product = "DPD2345"
name = "DPD2345"
marketname = "vivo iQOO Pad5e"
fingerprint = "vivo/DPD2345/DPD2345:15/AP3A.241005.015.A1/DPD2345.241005.001:user/release-keys"

[templates."iqoo_ipa2673"]
manufacturer = "vivo"
brand = "iQOO"
model = "IPA2673"
device = "DPD2540"
product = "DPD2540"
name = "DPD2540"
marketname = "vivo iQOO Pad6 Pro"
fingerprint = "vivo/DPD2540/DPD2540:15/AP3A.241005.015.A1/DPD2540.241005.001:user/release-keys"

[templates."iqoo_ipa2691"]
manufacturer = "vivo"
brand = "iQOO"
model = "IPA2691"
device = "DPD2605"
product = "DPD2605"
name = "DPD2605"
marketname = "vivo iQOO Pad Ultra"
fingerprint = "vivo/DPD2605/DPD2605:15/AP3A.241005.015.A1/DPD2605.241005.001:user/release-keys"

[templates."iqoo_ipa2693"]
manufacturer = "vivo"
brand = "iQOO"
model = "IPA2693"
device = "DPD2653"
product = "DPD2653"
name = "DPD2653"
marketname = "vivo iQOO Pad Pro 8.8"
fingerprint = "vivo/DPD2653/DPD2653:15/AP3A.241005.015.A1/DPD2653.241005.001:user/release-keys"

[templates."google_g_2pw4100"]
manufacturer = "Google"
brand = "google"
model = "Pixel"
device = "sailfish"
product = "sailfish"
name = "sailfish"
marketname = "Pixel"
fingerprint = "Google/sailfish/sailfish:15/AP3A.241005.015.A1/sailfish.241005.001:user/release-keys"

[templates."google_g_2pw2100"]
manufacturer = "Google"
brand = "google"
model = "Pixel XL"
device = "marlin"
product = "marlin"
name = "marlin"
marketname = "Pixel XL"
fingerprint = "Google/marlin/marlin:15/AP3A.241005.015.A1/marlin.241005.001:user/release-keys"

[templates."google_g011a"]
manufacturer = "Google"
brand = "google"
model = "Pixel 2"
device = "walleye"
product = "walleye"
name = "walleye"
marketname = "Pixel 2"
fingerprint = "Google/walleye/walleye:15/AP3A.241005.015.A1/walleye.241005.001:user/release-keys"

[templates."google_g011c"]
manufacturer = "Google"
brand = "google"
model = "Pixel 2 XL"
device = "taimen"
product = "taimen"
name = "taimen"
marketname = "Pixel 2 XL"
fingerprint = "Google/taimen/taimen:15/AP3A.241005.015.A1/taimen.241005.001:user/release-keys"

[templates."google_g013a"]
manufacturer = "Google"
brand = "google"
model = "Pixel 3"
device = "blueline"
product = "blueline"
name = "blueline"
marketname = "Pixel 3"
fingerprint = "Google/blueline/blueline:15/AP3A.241005.015.A1/blueline.241005.001:user/release-keys"

[templates."google_g013c"]
manufacturer = "Google"
brand = "google"
model = "Pixel 3 XL"
device = "crosshatch"
product = "crosshatch"
name = "crosshatch"
marketname = "Pixel 3 XL"
fingerprint = "Google/crosshatch/crosshatch:15/AP3A.241005.015.A1/crosshatch.241005.001:user/release-keys"

[templates."google_g020e"]
manufacturer = "Google"
brand = "google"
model = "Pixel 3a"
device = "sargo"
product = "sargo"
name = "sargo"
marketname = "Pixel 3a"
fingerprint = "Google/sargo/sargo:15/AP3A.241005.015.A1/sargo.241005.001:user/release-keys"

[templates."google_g020a"]
manufacturer = "Google"
brand = "google"
model = "Pixel 3a XL"
device = "bonito"
product = "bonito"
name = "bonito"
marketname = "Pixel 3a XL"
fingerprint = "Google/bonito/bonito:15/AP3A.241005.015.A1/bonito.241005.001:user/release-keys"

[templates."google_g020i"]
manufacturer = "Google"
brand = "google"
model = "Pixel 4"
device = "flame"
product = "flame"
name = "flame"
marketname = "Pixel 4"
fingerprint = "Google/flame/flame:15/AP3A.241005.015.A1/flame.241005.001:user/release-keys"

[templates."google_g020j"]
manufacturer = "Google"
brand = "google"
model = "Pixel 4 XL"
device = "coral"
product = "coral"
name = "coral"
marketname = "Pixel 4 XL"
fingerprint = "Google/coral/coral:15/AP3A.241005.015.A1/coral.241005.001:user/release-keys"

[templates."google_g025j"]
manufacturer = "Google"
brand = "google"
model = "Pixel 4a"
device = "sunfish"
product = "sunfish"
name = "sunfish"
marketname = "Pixel 4a"
fingerprint = "Google/sunfish/sunfish:15/AP3A.241005.015.A1/sunfish.241005.001:user/release-keys"

[templates."google_g025e"]
manufacturer = "Google"
brand = "google"
model = "Pixel 4a 5G"
device = "bramble"
product = "bramble"
name = "bramble"
marketname = "Pixel 4a 5G"
fingerprint = "Google/bramble/bramble:15/AP3A.241005.015.A1/bramble.241005.001:user/release-keys"

[templates."google_gd1yq"]
manufacturer = "Google"
brand = "google"
model = "Pixel 5"
device = "redfin"
product = "redfin"
name = "redfin"
marketname = "Pixel 5"
fingerprint = "Google/redfin/redfin:15/AP3A.241005.015.A1/redfin.241005.001:user/release-keys"

[templates."google_g1f8f"]
manufacturer = "Google"
brand = "google"
model = "Pixel 5a 5G"
device = "barbet"
product = "barbet"
name = "barbet"
marketname = "Pixel 5a 5G"
fingerprint = "Google/barbet/barbet:15/AP3A.241005.015.A1/barbet.241005.001:user/release-keys"

[templates."google_g9s9b"]
manufacturer = "Google"
brand = "google"
model = "Pixel 6"
device = "oriole"
product = "oriole"
name = "oriole"
marketname = "Pixel 6"
fingerprint = "Google/oriole/oriole:15/AP3A.241005.015.A1/oriole.241005.001:user/release-keys"

[templates."google_g8vou"]
manufacturer = "Google"
brand = "google"
model = "Pixel 6 Pro"
device = "raven"
product = "raven"
name = "raven"
marketname = "Pixel 6 Pro"
fingerprint = "Google/raven/raven:15/AP3A.241005.015.A1/raven.241005.001:user/release-keys"

[templates."google_gb62z"]
manufacturer = "Google"
brand = "google"
model = "Pixel 6a"
device = "bluejay"
product = "bluejay"
name = "bluejay"
marketname = "Pixel 6a"
fingerprint = "Google/bluejay/bluejay:15/AP3A.241005.015.A1/bluejay.241005.001:user/release-keys"

[templates."google_gqml3"]
manufacturer = "Google"
brand = "google"
model = "Pixel 7"
device = "panther"
product = "panther"
name = "panther"
marketname = "Pixel 7"
fingerprint = "Google/panther/panther:15/AP3A.241005.015.A1/panther.241005.001:user/release-keys"

[templates."google_ge2ae"]
manufacturer = "Google"
brand = "google"
model = "Pixel 7 Pro"
device = "cheetah"
product = "cheetah"
name = "cheetah"
marketname = "Pixel 7 Pro"
fingerprint = "Google/cheetah/cheetah:15/AP3A.241005.015.A1/cheetah.241005.001:user/release-keys"

[templates."google_g0dzq"]
manufacturer = "Google"
brand = "google"
model = "Pixel 7a"
device = "lynx"
product = "lynx"
name = "lynx"
marketname = "Pixel 7a"
fingerprint = "Google/lynx/lynx:15/AP3A.241005.015.A1/lynx.241005.001:user/release-keys"

[templates."google_gkws6"]
manufacturer = "Google"
brand = "google"
model = "Pixel 8"
device = "shiba"
product = "shiba"
name = "shiba"
marketname = "Pixel 8"
fingerprint = "Google/shiba/shiba:15/AP3A.241005.015.A1/shiba.241005.001:user/release-keys"

[templates."google_g1mnw"]
manufacturer = "Google"
brand = "google"
model = "Pixel 8 Pro"
device = "husky"
product = "husky"
name = "husky"
marketname = "Pixel 8 Pro"
fingerprint = "Google/husky/husky:15/AP3A.241005.015.A1/husky.241005.001:user/release-keys"

[templates."google_g8hnn"]
manufacturer = "Google"
brand = "google"
model = "Pixel 8a"
device = "akita"
product = "akita"
name = "akita"
marketname = "Pixel 8a"
fingerprint = "Google/akita/akita:15/AP3A.241005.015.A1/akita.241005.001:user/release-keys"

[templates."google_g9fpl"]
manufacturer = "Google"
brand = "google"
model = "Pixel Fold"
device = "felix"
product = "felix"
name = "felix"
marketname = "Pixel Fold"
fingerprint = "Google/felix/felix:15/AP3A.241005.015.A1/felix.241005.001:user/release-keys"

[templates."google_g2ybb"]
manufacturer = "Google"
brand = "google"
model = "Pixel 9"
device = "tokay"
product = "tokay"
name = "tokay"
marketname = "Pixel 9"
fingerprint = "Google/tokay/tokay:15/AP3A.241005.015.A1/tokay.241005.001:user/release-keys"

[templates."google_gr83y"]
manufacturer = "Google"
brand = "google"
model = "Pixel 9 Pro"
device = "caiman"
product = "caiman"
name = "caiman"
marketname = "Pixel 9 Pro"
fingerprint = "Google/caiman/caiman:15/AP3A.241005.015.A1/caiman.241005.001:user/release-keys"

[templates."google_ggx8b"]
manufacturer = "Google"
brand = "google"
model = "Pixel 9 Pro XL"
device = "komodo"
product = "komodo"
name = "komodo"
marketname = "Pixel 9 Pro XL"
fingerprint = "Google/komodo/komodo:15/AP3A.241005.015.A1/komodo.241005.001:user/release-keys"

[templates."google_ggh2x"]
manufacturer = "Google"
brand = "google"
model = "Pixel 9 Pro Fold"
device = "comet"
product = "comet"
name = "comet"
marketname = "Pixel 9 Pro Fold"
fingerprint = "Google/comet/comet:15/AP3A.241005.015.A1/comet.241005.001:user/release-keys"

[templates."google_gxq96"]
manufacturer = "Google"
brand = "google"
model = "Pixel 9a"
device = "tegu"
product = "tegu"
name = "tegu"
marketname = "Pixel 9a"
fingerprint = "Google/tegu/tegu:15/AP3A.241005.015.A1/tegu.241005.001:user/release-keys"

[templates."google_glbw0"]
manufacturer = "Google"
brand = "google"
model = "Pixel 10"
device = "frankel"
product = "frankel"
name = "frankel"
marketname = "Pixel 10"
fingerprint = "Google/frankel/frankel:15/AP3A.241005.015.A1/frankel.241005.001:user/release-keys"

[templates."google_g4qur"]
manufacturer = "Google"
brand = "google"
model = "Pixel 10 Pro"
device = "blazer"
product = "blazer"
name = "blazer"
marketname = "Pixel 10 Pro"
fingerprint = "Google/blazer/blazer:15/AP3A.241005.015.A1/blazer.241005.001:user/release-keys"

[templates."google_gul82"]
manufacturer = "Google"
brand = "google"
model = "Pixel 10 Pro XL"
device = "mustang"
product = "mustang"
name = "mustang"
marketname = "Pixel 10 Pro XL"
fingerprint = "Google/mustang/mustang:15/AP3A.241005.015.A1/mustang.241005.001:user/release-keys"

[templates."google_gu0np"]
manufacturer = "Google"
brand = "google"
model = "Pixel 10 Pro Fold"
device = "rango"
product = "rango"
name = "rango"
marketname = "Pixel 10 Pro Fold"
fingerprint = "Google/rango/rango:15/AP3A.241005.015.A1/rango.241005.001:user/release-keys"

[templates."google_ge1gq"]
manufacturer = "Google"
brand = "google"
model = "Pixel 10a"
device = "stallion"
product = "stallion"
name = "stallion"
marketname = "Pixel 10a"
fingerprint = "Google/stallion/stallion:15/AP3A.241005.015.A1/stallion.241005.001:user/release-keys"

[templates."google_gpqq7"]
manufacturer = "Google"
brand = "google"
model = "Pixel 11"
device = "cubs"
product = "cubs"
name = "cubs"
marketname = "Pixel 11"
fingerprint = "Google/cubs/cubs:15/AP3A.241005.015.A1/cubs.241005.001:user/release-keys"

[templates."google_g7swn"]
manufacturer = "Google"
brand = "google"
model = "Pixel 11 Pro"
device = "grizzly"
product = "grizzly"
name = "grizzly"
marketname = "Pixel 11 Pro"
fingerprint = "Google/grizzly/grizzly:15/AP3A.241005.015.A1/grizzly.241005.001:user/release-keys"

[templates."google_gbc0h"]
manufacturer = "Google"
brand = "google"
model = "Pixel 11 Pro XL"
device = "kodiak"
product = "kodiak"
name = "kodiak"
marketname = "Pixel 11 Pro XL"
fingerprint = "Google/kodiak/kodiak:15/AP3A.241005.015.A1/kodiak.241005.001:user/release-keys"

[templates."google_gzdq6"]
manufacturer = "Google"
brand = "google"
model = "Pixel 11 Pro Fold"
device = "yogi"
product = "yogi"
name = "yogi"
marketname = "Pixel 11 Pro Fold"
fingerprint = "Google/yogi/yogi:15/AP3A.241005.015.A1/yogi.241005.001:user/release-keys"

[templates."google_c1502w"]
manufacturer = "Google"
brand = "google"
model = "Pixel C"
device = "dragon"
product = "dragon"
name = "dragon"
marketname = "Pixel C"
fingerprint = "Google/dragon/dragon:15/AP3A.241005.015.A1/dragon.241005.001:user/release-keys"

[templates."google_gtu8p"]
manufacturer = "Google"
brand = "google"
model = "Pixel Tablet"
device = "tangorpro"
product = "tangorpro"
name = "tangorpro"
marketname = "Pixel Tablet"
fingerprint = "Google/tangorpro/tangorpro:15/AP3A.241005.015.A1/tangorpro.241005.001:user/release-keys"

[templates."apple_a1324"]
manufacturer = "Apple"
brand = "Apple"
model = "A1324"
device = "A1324"
product = "A1324"
marketname = "iPhone 3G"
fingerprint = "Apple/A1324/A1324:15/AP3A.241005.015.A1/A1324.241005.001:user/release-keys"

[templates."apple_a1303"]
manufacturer = "Apple"
brand = "Apple"
model = "A1303"
device = "A1303"
product = "A1303"
marketname = "iPhone 3GS"
fingerprint = "Apple/A1303/A1303:15/AP3A.241005.015.A1/A1303.241005.001:user/release-keys"

[templates."apple_a1332"]
manufacturer = "Apple"
brand = "Apple"
model = "A1332"
device = "A1332"
product = "A1332"
marketname = "iPhone 4"
fingerprint = "Apple/A1332/A1332:15/AP3A.241005.015.A1/A1332.241005.001:user/release-keys"

[templates."apple_a1431"]
manufacturer = "Apple"
brand = "Apple"
model = "A1431"
device = "A1431"
product = "A1431"
marketname = "iPhone 4S"
fingerprint = "Apple/A1431/A1431:15/AP3A.241005.015.A1/A1431.241005.001:user/release-keys"

[templates."apple_a1429"]
manufacturer = "Apple"
brand = "Apple"
model = "A1429"
device = "A1429"
product = "A1429"
marketname = "iPhone 5"
fingerprint = "Apple/A1429/A1429:15/AP3A.241005.015.A1/A1429.241005.001:user/release-keys"

[templates."apple_a1533"]
manufacturer = "Apple"
brand = "Apple"
model = "A1533"
device = "A1533"
product = "A1533"
marketname = "iPhone 5s"
fingerprint = "Apple/A1533/A1533:15/AP3A.241005.015.A1/A1533.241005.001:user/release-keys"

[templates."apple_a1532"]
manufacturer = "Apple"
brand = "Apple"
model = "A1532"
device = "A1532"
product = "A1532"
marketname = "iPhone 5c"
fingerprint = "Apple/A1532/A1532:15/AP3A.241005.015.A1/A1532.241005.001:user/release-keys"

[templates."apple_a1586"]
manufacturer = "Apple"
brand = "Apple"
model = "A1586"
device = "A1586"
product = "A1586"
marketname = "iPhone 6"
fingerprint = "Apple/A1586/A1586:15/AP3A.241005.015.A1/A1586.241005.001:user/release-keys"

[templates."apple_a1524"]
manufacturer = "Apple"
brand = "Apple"
model = "A1524"
device = "A1524"
product = "A1524"
marketname = "iPhone 6 Plus"
fingerprint = "Apple/A1524/A1524:15/AP3A.241005.015.A1/A1524.241005.001:user/release-keys"

[templates."apple_a1700"]
manufacturer = "Apple"
brand = "Apple"
model = "A1700"
device = "A1700"
product = "A1700"
marketname = "iPhone 6s"
fingerprint = "Apple/A1700/A1700:15/AP3A.241005.015.A1/A1700.241005.001:user/release-keys"

[templates."apple_a1699"]
manufacturer = "Apple"
brand = "Apple"
model = "A1699"
device = "A1699"
product = "A1699"
marketname = "iPhone 6s Plus"
fingerprint = "Apple/A1699/A1699:15/AP3A.241005.015.A1/A1699.241005.001:user/release-keys"

[templates."apple_a1723"]
manufacturer = "Apple"
brand = "Apple"
model = "A1723"
device = "A1723"
product = "A1723"
marketname = "iPhone SE"
fingerprint = "Apple/A1723/A1723:15/AP3A.241005.015.A1/A1723.241005.001:user/release-keys"

[templates."apple_a1660"]
manufacturer = "Apple"
brand = "Apple"
model = "A1660"
device = "A1660"
product = "A1660"
marketname = "iPhone 7"
fingerprint = "Apple/A1660/A1660:15/AP3A.241005.015.A1/A1660.241005.001:user/release-keys"

[templates."apple_a1661"]
manufacturer = "Apple"
brand = "Apple"
model = "A1661"
device = "A1661"
product = "A1661"
marketname = "iPhone 7 Plus"
fingerprint = "Apple/A1661/A1661:15/AP3A.241005.015.A1/A1661.241005.001:user/release-keys"

[templates."apple_a1863"]
manufacturer = "Apple"
brand = "Apple"
model = "A1863"
device = "A1863"
product = "A1863"
marketname = "iPhone 8"
fingerprint = "Apple/A1863/A1863:15/AP3A.241005.015.A1/A1863.241005.001:user/release-keys"

[templates."apple_a1864"]
manufacturer = "Apple"
brand = "Apple"
model = "A1864"
device = "A1864"
product = "A1864"
marketname = "iPhone 8 Plus"
fingerprint = "Apple/A1864/A1864:15/AP3A.241005.015.A1/A1864.241005.001:user/release-keys"

[templates."apple_a1865"]
manufacturer = "Apple"
brand = "Apple"
model = "A1865"
device = "A1865"
product = "A1865"
marketname = "iPhone X"
fingerprint = "Apple/A1865/A1865:15/AP3A.241005.015.A1/A1865.241005.001:user/release-keys"

[templates."apple_a2100"]
manufacturer = "Apple"
brand = "Apple"
model = "A2100"
device = "A2100"
product = "A2100"
marketname = "iPhone XS"
fingerprint = "Apple/A2100/A2100:15/AP3A.241005.015.A1/A2100.241005.001:user/release-keys"

[templates."apple_a2104"]
manufacturer = "Apple"
brand = "Apple"
model = "A2104"
device = "A2104"
product = "A2104"
marketname = "iPhone XS Max"
fingerprint = "Apple/A2104/A2104:15/AP3A.241005.015.A1/A2104.241005.001:user/release-keys"

[templates."apple_a2108"]
manufacturer = "Apple"
brand = "Apple"
model = "A2108"
device = "A2108"
product = "A2108"
marketname = "iPhone XR"
fingerprint = "Apple/A2108/A2108:15/AP3A.241005.015.A1/A2108.241005.001:user/release-keys"

[templates."apple_a2223"]
manufacturer = "Apple"
brand = "Apple"
model = "A2223"
device = "A2223"
product = "A2223"
marketname = "iPhone 11"
fingerprint = "Apple/A2223/A2223:15/AP3A.241005.015.A1/A2223.241005.001:user/release-keys"

[templates."apple_a2217"]
manufacturer = "Apple"
brand = "Apple"
model = "A2217"
device = "A2217"
product = "A2217"
marketname = "iPhone 11 Pro"
fingerprint = "Apple/A2217/A2217:15/AP3A.241005.015.A1/A2217.241005.001:user/release-keys"

[templates."apple_a2220"]
manufacturer = "Apple"
brand = "Apple"
model = "A2220"
device = "A2220"
product = "A2220"
marketname = "iPhone 11 Pro Max"
fingerprint = "Apple/A2220/A2220:15/AP3A.241005.015.A1/A2220.241005.001:user/release-keys"

[templates."apple_a2400"]
manufacturer = "Apple"
brand = "Apple"
model = "A2400"
device = "A2400"
product = "A2400"
marketname = "iPhone 12 mini"
fingerprint = "Apple/A2400/A2400:15/AP3A.241005.015.A1/A2400.241005.001:user/release-keys"

[templates."apple_a2404"]
manufacturer = "Apple"
brand = "Apple"
model = "A2404"
device = "A2404"
product = "A2404"
marketname = "iPhone 12"
fingerprint = "Apple/A2404/A2404:15/AP3A.241005.015.A1/A2404.241005.001:user/release-keys"

[templates."apple_a2408"]
manufacturer = "Apple"
brand = "Apple"
model = "A2408"
device = "A2408"
product = "A2408"
marketname = "iPhone 12 Pro"
fingerprint = "Apple/A2408/A2408:15/AP3A.241005.015.A1/A2408.241005.001:user/release-keys"

[templates."apple_a2412"]
manufacturer = "Apple"
brand = "Apple"
model = "A2412"
device = "A2412"
product = "A2412"
marketname = "iPhone 12 Pro Max"
fingerprint = "Apple/A2412/A2412:15/AP3A.241005.015.A1/A2412.241005.001:user/release-keys"

[templates."apple_a2629"]
manufacturer = "Apple"
brand = "Apple"
model = "A2629"
device = "A2629"
product = "A2629"
marketname = "iPhone 13 mini"
fingerprint = "Apple/A2629/A2629:15/AP3A.241005.015.A1/A2629.241005.001:user/release-keys"

[templates."apple_a2634"]
manufacturer = "Apple"
brand = "Apple"
model = "A2634"
device = "A2634"
product = "A2634"
marketname = "iPhone 13"
fingerprint = "Apple/A2634/A2634:15/AP3A.241005.015.A1/A2634.241005.001:user/release-keys"

[templates."apple_a2639"]
manufacturer = "Apple"
brand = "Apple"
model = "A2639"
device = "A2639"
product = "A2639"
marketname = "iPhone 13 Pro"
fingerprint = "Apple/A2639/A2639:15/AP3A.241005.015.A1/A2639.241005.001:user/release-keys"

[templates."apple_a2644"]
manufacturer = "Apple"
brand = "Apple"
model = "A2644"
device = "A2644"
product = "A2644"
marketname = "iPhone 13 Pro Max"
fingerprint = "Apple/A2644/A2644:15/AP3A.241005.015.A1/A2644.241005.001:user/release-keys"

[templates."apple_a2884"]
manufacturer = "Apple"
brand = "Apple"
model = "A2884"
device = "A2884"
product = "A2884"
marketname = "iPhone 14"
fingerprint = "Apple/A2884/A2884:15/AP3A.241005.015.A1/A2884.241005.001:user/release-keys"

[templates."apple_a2888"]
manufacturer = "Apple"
brand = "Apple"
model = "A2888"
device = "A2888"
product = "A2888"
marketname = "iPhone 14 Plus"
fingerprint = "Apple/A2888/A2888:15/AP3A.241005.015.A1/A2888.241005.001:user/release-keys"

[templates."apple_a2892"]
manufacturer = "Apple"
brand = "Apple"
model = "A2892"
device = "A2892"
product = "A2892"
marketname = "iPhone 14 Pro"
fingerprint = "Apple/A2892/A2892:15/AP3A.241005.015.A1/A2892.241005.001:user/release-keys"

[templates."apple_a2896"]
manufacturer = "Apple"
brand = "Apple"
model = "A2896"
device = "A2896"
product = "A2896"
marketname = "iPhone 14 Pro Max"
fingerprint = "Apple/A2896/A2896:15/AP3A.241005.015.A1/A2896.241005.001:user/release-keys"

[templates."apple_a3092"]
manufacturer = "Apple"
brand = "Apple"
model = "A3092"
device = "A3092"
product = "A3092"
marketname = "iPhone 15"
fingerprint = "Apple/A3092/A3092:15/AP3A.241005.015.A1/A3092.241005.001:user/release-keys"

[templates."apple_a3096"]
manufacturer = "Apple"
brand = "Apple"
model = "A3096"
device = "A3096"
product = "A3096"
marketname = "iPhone 15 Plus"
fingerprint = "Apple/A3096/A3096:15/AP3A.241005.015.A1/A3096.241005.001:user/release-keys"

[templates."apple_a3104"]
manufacturer = "Apple"
brand = "Apple"
model = "A3104"
device = "A3104"
product = "A3104"
marketname = "iPhone 15 Pro"
fingerprint = "Apple/A3104/A3104:15/AP3A.241005.015.A1/A3104.241005.001:user/release-keys"

[templates."apple_a3108"]
manufacturer = "Apple"
brand = "Apple"
model = "A3108"
device = "A3108"
product = "A3108"
marketname = "iPhone 15 Pro Max"
fingerprint = "Apple/A3108/A3108:15/AP3A.241005.015.A1/A3108.241005.001:user/release-keys"

[templates."apple_a3288"]
manufacturer = "Apple"
brand = "Apple"
model = "A3288"
device = "A3288"
product = "A3288"
marketname = "iPhone 16"
fingerprint = "Apple/A3288/A3288:15/AP3A.241005.015.A1/A3288.241005.001:user/release-keys"

[templates."apple_a3291"]
manufacturer = "Apple"
brand = "Apple"
model = "A3291"
device = "A3291"
product = "A3291"
marketname = "iPhone 16 Plus"
fingerprint = "Apple/A3291/A3291:15/AP3A.241005.015.A1/A3291.241005.001:user/release-keys"

[templates."apple_a3294"]
manufacturer = "Apple"
brand = "Apple"
model = "A3294"
device = "A3294"
product = "A3294"
marketname = "iPhone 16 Pro"
fingerprint = "Apple/A3294/A3294:15/AP3A.241005.015.A1/A3294.241005.001:user/release-keys"

[templates."apple_a3297"]
manufacturer = "Apple"
brand = "Apple"
model = "A3297"
device = "A3297"
product = "A3297"
marketname = "iPhone 16 Pro Max"
fingerprint = "Apple/A3297/A3297:15/AP3A.241005.015.A1/A3297.241005.001:user/release-keys"

[templates."apple_a3410"]
manufacturer = "Apple"
brand = "Apple"
model = "A3410"
device = "A3410"
product = "A3410"
marketname = "iPhone 16e"
fingerprint = "Apple/A3410/A3410:15/AP3A.241005.015.A1/A3410.241005.001:user/release-keys"

[templates."apple_a3521"]
manufacturer = "Apple"
brand = "Apple"
model = "A3521"
device = "A3521"
product = "A3521"
marketname = "iPhone 17"
fingerprint = "Apple/A3521/A3521:15/AP3A.241005.015.A1/A3521.241005.001:user/release-keys"

[templates."apple_a3518"]
manufacturer = "Apple"
brand = "Apple"
model = "A3518"
device = "A3518"
product = "A3518"
marketname = "iPhone Air"
fingerprint = "Apple/A3518/A3518:15/AP3A.241005.015.A1/A3518.241005.001:user/release-keys"

[templates."apple_a3524"]
manufacturer = "Apple"
brand = "Apple"
model = "A3524"
device = "A3524"
product = "A3524"
marketname = "iPhone 17 Pro"
fingerprint = "Apple/A3524/A3524:15/AP3A.241005.015.A1/A3524.241005.001:user/release-keys"

[templates."apple_a3527"]
manufacturer = "Apple"
brand = "Apple"
model = "A3527"
device = "A3527"
product = "A3527"
marketname = "iPhone 17 Pro Max"
fingerprint = "Apple/A3527/A3527:15/AP3A.241005.015.A1/A3527.241005.001:user/release-keys"

[templates."apple_a3635"]
manufacturer = "Apple"
brand = "Apple"
model = "A3635"
device = "A3635"
product = "A3635"
marketname = "iPhone 17e"
fingerprint = "Apple/A3635/A3635:15/AP3A.241005.015.A1/A3635.241005.001:user/release-keys"

[templates."apple_a3715"]
manufacturer = "Apple"
brand = "Apple"
model = "A3715"
device = "A3715"
product = "A3715"
marketname = "iPhone 18 Pro"
fingerprint = "Apple/A3715/A3715:15/AP3A.241005.015.A1/A3715.241005.001:user/release-keys"

[templates."apple_a3718"]
manufacturer = "Apple"
brand = "Apple"
model = "A3718"
device = "A3718"
product = "A3718"
marketname = "iPhone 18 Pro Max"
fingerprint = "Apple/A3718/A3718:15/AP3A.241005.015.A1/A3718.241005.001:user/release-keys"

[templates."apple_a3721"]
manufacturer = "Apple"
brand = "Apple"
model = "A3721"
device = "A3721"
product = "A3721"
marketname = "iPhone Duo"
fingerprint = "Apple/A3721/A3721:15/AP3A.241005.015.A1/A3721.241005.001:user/release-keys"

[templates."apple_a1219"]
manufacturer = "Apple"
brand = "Apple"
model = "A1219"
device = "A1219"
product = "A1219"
marketname = "iPad"
fingerprint = "Apple/A1219/A1219:15/AP3A.241005.015.A1/A1219.241005.001:user/release-keys"

[templates."apple_a1395"]
manufacturer = "Apple"
brand = "Apple"
model = "A1395"
device = "A1395"
product = "A1395"
marketname = "iPad 2"
fingerprint = "Apple/A1395/A1395:15/AP3A.241005.015.A1/A1395.241005.001:user/release-keys"

[templates."apple_a1474"]
manufacturer = "Apple"
brand = "Apple"
model = "A1474"
device = "A1474"
product = "A1474"
marketname = "iPad Air"
fingerprint = "Apple/A1474/A1474:15/AP3A.241005.015.A1/A1474.241005.001:user/release-keys"

[templates."apple_a1566"]
manufacturer = "Apple"
brand = "Apple"
model = "A1566"
device = "A1566"
product = "A1566"
marketname = "iPad Air 2"
fingerprint = "Apple/A1566/A1566:15/AP3A.241005.015.A1/A1566.241005.001:user/release-keys"

[templates."apple_a1584"]
manufacturer = "Apple"
brand = "Apple"
model = "A1584"
device = "A1584"
product = "A1584"
marketname = "iPad Pro"
fingerprint = "Apple/A1584/A1584:15/AP3A.241005.015.A1/A1584.241005.001:user/release-keys"

[templates."apple_a1432"]
manufacturer = "Apple"
brand = "Apple"
model = "A1432"
device = "A1432"
product = "A1432"
marketname = "iPad mini"
fingerprint = "Apple/A1432/A1432:15/AP3A.241005.015.A1/A1432.241005.001:user/release-keys"

[templates."apple_a1489"]
manufacturer = "Apple"
brand = "Apple"
model = "A1489"
device = "A1489"
product = "A1489"
marketname = "iPad mini 2"
fingerprint = "Apple/A1489/A1489:15/AP3A.241005.015.A1/A1489.241005.001:user/release-keys"

[templates."apple_a1599"]
manufacturer = "Apple"
brand = "Apple"
model = "A1599"
device = "A1599"
product = "A1599"
marketname = "iPad mini 3"
fingerprint = "Apple/A1599/A1599:15/AP3A.241005.015.A1/A1599.241005.001:user/release-keys"

[templates."apple_a1538"]
manufacturer = "Apple"
brand = "Apple"
model = "A1538"
device = "A1538"
product = "A1538"
marketname = "iPad mini 4"
fingerprint = "Apple/A1538/A1538:15/AP3A.241005.015.A1/A1538.241005.001:user/release-keys"

[templates."apple_a1603"]
manufacturer = "Apple"
brand = "Apple"
model = "A1603"
device = "A1603"
product = "A1603"
marketname = "Apple Pencil"
fingerprint = "Apple/A1603/A1603:15/AP3A.241005.015.A1/A1603.241005.001:user/release-keys"

[templates."apple_a2538"]
manufacturer = "Apple"
brand = "Apple"
model = "A2538"
device = "A2538"
product = "A2538"
marketname = "Apple Pencil Pro"
fingerprint = "Apple/A2538/A2538:15/AP3A.241005.015.A1/A2538.241005.001:user/release-keys"

[templates."apple_a2117"]
manufacturer = "Apple"
brand = "Apple"
model = "A2117"
device = "A2117"
product = "A2117"
marketname = "Apple Vision Pro"
fingerprint = "Apple/A2117/A2117:15/AP3A.241005.015.A1/A2117.241005.001:user/release-keys"

[templates."apple_a1213"]
manufacturer = "Apple"
brand = "Apple"
model = "A1213"
device = "A1213"
product = "A1213"
marketname = "iPod touch"
fingerprint = "Apple/A1213/A1213:15/AP3A.241005.015.A1/A1213.241005.001:user/release-keys"

[templates."apple_a2337"]
manufacturer = "Apple"
brand = "Apple"
model = "A2337"
device = "M1"
product = "M1"
name = "M1"
marketname = "Apple MacBook Air"
fingerprint = "Apple/M1/M1:15/AP3A.241005.015.A1/M1.241005.001:user/release-keys"

[templates."apple_a3404"]
manufacturer = "Apple"
brand = "Apple"
model = "A3404"
device = "A18"
product = "A18"
name = "A18"
marketname = "Apple MacBook Neo"
fingerprint = "Apple/A18/A18:15/AP3A.241005.015.A1/A18.241005.001:user/release-keys"

[templates."apple_a2338"]
manufacturer = "Apple"
brand = "Apple"
model = "A2338"
device = "M2"
product = "M2"
name = "M2"
marketname = "Apple MacBook Pro"
fingerprint = "Apple/M2/M2:15/AP3A.241005.015.A1/M2.241005.001:user/release-keys"

[templates."apple_a2438"]
manufacturer = "Apple"
brand = "Apple"
model = "A2438"
device = "M1"
product = "M1"
name = "M1"
marketname = "Apple iMac"
fingerprint = "Apple/M1/M1:15/AP3A.241005.015.A1/M1.241005.001:user/release-keys"

[templates."apple_a2348"]
manufacturer = "Apple"
brand = "Apple"
model = "A2348"
device = "M1"
product = "M1"
name = "M1"
marketname = "Apple Mac mini"
fingerprint = "Apple/M1/M1:15/AP3A.241005.015.A1/M1.241005.001:user/release-keys"

[templates."apple_a2615"]
manufacturer = "Apple"
brand = "Apple"
model = "A2615"
device = "M1"
product = "M1"
name = "M1"
marketname = "Apple Mac Studio"
fingerprint = "Apple/M1/M1:15/AP3A.241005.015.A1/M1.241005.001:user/release-keys"

[templates."apple_a2786"]
manufacturer = "Apple"
brand = "Apple"
model = "A2786"
device = "A2786"
product = "A2786"
marketname = "Apple Mac Pro"
fingerprint = "Apple/A2786/A2786:15/AP3A.241005.015.A1/A2786.241005.001:user/release-keys"

[templates."apple_a1999"]
manufacturer = "Apple"
brand = "Apple"
model = "A1999"
device = "A1999"
product = "A1999"
marketname = "Apple Pro Display XDR"
fingerprint = "Apple/A1999/A1999:15/AP3A.241005.015.A1/A1999.241005.001:user/release-keys"

[templates."apple_a2525"]
manufacturer = "Apple"
brand = "Apple"
model = "A2525"
device = "A2525"
product = "A2525"
marketname = "Apple Studio Display"
fingerprint = "Apple/A2525/A2525:15/AP3A.241005.015.A1/A2525.241005.001:user/release-keys"

[templates."apple_a3348"]
manufacturer = "Apple"
brand = "Apple"
model = "A3348"
device = "A3348"
product = "A3348"
marketname = "Apple Studio Display XDR"
fingerprint = "Apple/A3348/A3348:15/AP3A.241005.015.A1/A3348.241005.001:user/release-keys"

[templates."apple_a1523"]
manufacturer = "Apple"
brand = "Apple"
model = "A1523"
device = "A1523"
product = "A1523"
marketname = "Apple AirPods"
fingerprint = "Apple/A1523/A1523:15/AP3A.241005.015.A1/A1523.241005.001:user/release-keys"

[templates."apple_a3053"]
manufacturer = "Apple"
brand = "Apple"
model = "A3053"
device = "A3053"
product = "A3053"
marketname = "Apple AirPods 4"
fingerprint = "Apple/A3053/A3053:15/AP3A.241005.015.A1/A3053.241005.001:user/release-keys"

[templates."apple_a3531"]
manufacturer = "Apple"
brand = "Apple"
model = "A3531"
device = "A3531"
product = "A3531"
marketname = "Apple AirPods 5"
fingerprint = "Apple/A3531/A3531:15/AP3A.241005.015.A1/A3531.241005.001:user/release-keys"

[templates."apple_a2083"]
manufacturer = "Apple"
brand = "Apple"
model = "A2083"
device = "A2083"
product = "A2083"
marketname = "Apple AirPods Pro"
fingerprint = "Apple/A2083/A2083:15/AP3A.241005.015.A1/A2083.241005.001:user/release-keys"

[templates."apple_a2699"]
manufacturer = "Apple"
brand = "Apple"
model = "A2699"
device = "A2699"
product = "A2699"
marketname = "Apple AirPods Pro 2"
fingerprint = "Apple/A2699/A2699:15/AP3A.241005.015.A1/A2699.241005.001:user/release-keys"

[templates."apple_a3064"]
manufacturer = "Apple"
brand = "Apple"
model = "A3064"
device = "A3064"
product = "A3064"
marketname = "Apple AirPods Pro 3"
fingerprint = "Apple/A3064/A3064:15/AP3A.241005.015.A1/A3064.241005.001:user/release-keys"

[templates."apple_a2096"]
manufacturer = "Apple"
brand = "Apple"
model = "A2096"
device = "A2096"
product = "A2096"
marketname = "Apple AirPods Max"
fingerprint = "Apple/A2096/A2096:15/AP3A.241005.015.A1/A2096.241005.001:user/release-keys"

[templates."apple_a3454"]
manufacturer = "Apple"
brand = "Apple"
model = "A3454"
device = "A3454"
product = "A3454"
marketname = "Apple AirPods Max 2"
fingerprint = "Apple/A3454/A3454:15/AP3A.241005.015.A1/A3454.241005.001:user/release-keys"

[templates."apple_a2187"]
manufacturer = "Apple"
brand = "Apple"
model = "A2187"
device = "A2187"
product = "A2187"
marketname = "Apple AirTag"
fingerprint = "Apple/A2187/A2187:15/AP3A.241005.015.A1/A2187.241005.001:user/release-keys"

[templates."apple_a1639"]
manufacturer = "Apple"
brand = "Apple"
model = "A1639"
device = "A1639"
product = "A1639"
marketname = "Apple HomePod"
fingerprint = "Apple/A1639/A1639:15/AP3A.241005.015.A1/A1639.241005.001:user/release-keys"

[templates."apple_a2374"]
manufacturer = "Apple"
brand = "Apple"
model = "A2374"
device = "A2374"
product = "A2374"
marketname = "Apple HomePod mini"
fingerprint = "Apple/A2374/A2374:15/AP3A.241005.015.A1/A2374.241005.001:user/release-keys"

[templates."apple_a3374"]
manufacturer = "Apple"
brand = "Apple"
model = "A3374"
device = "A3374"
product = "A3374"
marketname = "Apple HomePod mini 2"
fingerprint = "Apple/A3374/A3374:15/AP3A.241005.015.A1/A3374.241005.001:user/release-keys"

[templates."nubia_nx501"]
manufacturer = "nubia"
brand = "nubia"
model = "NX501"
device = "NX501"
product = "NX501"
marketname = "nubia Z5"
fingerprint = "nubia/NX501/NX501:15/AP3A.241005.015.A1/NX501.241005.001:user/release-keys"

[templates."nubia_nx401"]
manufacturer = "nubia"
brand = "nubia"
model = "NX401"
device = "NX401"
product = "NX401"
marketname = "nubia Z5 mini"
fingerprint = "nubia/NX401/NX401:15/AP3A.241005.015.A1/NX401.241005.001:user/release-keys"

[templates."nubia_nx503a"]
manufacturer = "nubia"
brand = "nubia"
model = "NX503A"
device = "NX503A"
product = "NX503A"
marketname = "nubia Z5S"
fingerprint = "nubia/NX503A/NX503A:15/AP3A.241005.015.A1/NX503A.241005.001:user/release-keys"

[templates."nubia_nx403a"]
manufacturer = "nubia"
brand = "nubia"
model = "NX403A"
device = "NX403A"
product = "NX403A"
marketname = "nubia Z5S mini"
fingerprint = "nubia/NX403A/NX403A:15/AP3A.241005.015.A1/NX403A.241005.001:user/release-keys"

[templates."nubia_nx506j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX506J"
device = "NX506J"
product = "NX506J"
marketname = "nubia Z7"
fingerprint = "nubia/NX506J/NX506J:15/AP3A.241005.015.A1/NX506J.241005.001:user/release-keys"

[templates."nubia_nx507j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX507J"
device = "NX507J"
product = "NX507J"
marketname = "nubia Z7 mini"
fingerprint = "nubia/NX507J/NX507J:15/AP3A.241005.015.A1/NX507J.241005.001:user/release-keys"

[templates."nubia_nx505j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX505J"
device = "NX505J"
product = "NX505J"
marketname = "nubia Z7 Max"
fingerprint = "nubia/NX505J/NX505J:15/AP3A.241005.015.A1/NX505J.241005.001:user/release-keys"

[templates."nubia_nx508j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX508J"
device = "NX508J"
product = "NX508J"
marketname = "nubia Z9"
fingerprint = "nubia/NX508J/NX508J:15/AP3A.241005.015.A1/NX508J.241005.001:user/release-keys"

[templates."nubia_nx511j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX511J"
device = "NX511J"
product = "NX511J"
marketname = "nubia Z9 mini"
fingerprint = "nubia/NX511J/NX511J:15/AP3A.241005.015.A1/NX511J.241005.001:user/release-keys"

[templates."nubia_nx510j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX510J"
device = "NX510J"
product = "NX510J"
marketname = "nubia Z9 Max"
fingerprint = "nubia/NX510J/NX510J:15/AP3A.241005.015.A1/NX510J.241005.001:user/release-keys"

[templates."nubia_nx512j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX512J"
device = "NX512J"
product = "NX512J"
marketname = "nubia Z9 Max 极速版"
fingerprint = "nubia/NX512J/NX512J:15/AP3A.241005.015.A1/NX512J.241005.001:user/release-keys"

[templates."nubia_nx518j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX518J"
device = "NX518J"
product = "NX518J"
marketname = "nubia Z9 Max 精英版"
fingerprint = "nubia/NX518J/NX518J:15/AP3A.241005.015.A1/NX518J.241005.001:user/release-keys"

[templates."nubia_nx531j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX531J"
device = "NX531J"
product = "NX531J"
marketname = "nubia Z11"
fingerprint = "nubia/NX531J/NX531J:15/AP3A.241005.015.A1/NX531J.241005.001:user/release-keys"

[templates."nubia_nx529j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX529J"
device = "NX529J"
product = "NX529J"
marketname = "nubia Z11 mini"
fingerprint = "nubia/NX529J/NX529J:15/AP3A.241005.015.A1/NX529J.241005.001:user/release-keys"

[templates."nubia_nx523j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX523J"
device = "NX523J"
product = "NX523J"
marketname = "nubia Z11 Max"
fingerprint = "nubia/NX523J/NX523J:15/AP3A.241005.015.A1/NX523J.241005.001:user/release-keys"

[templates."nubia_nx535j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX535J"
device = "NX535J"
product = "NX535J"
marketname = "nubia Z11 Max 经典版"
fingerprint = "nubia/NX535J/NX535J:15/AP3A.241005.015.A1/NX535J.241005.001:user/release-keys"

[templates."nubia_nx549j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX549J"
device = "NX549J"
product = "NX549J"
marketname = "nubia Z11 miniS"
fingerprint = "nubia/NX549J/NX549J:15/AP3A.241005.015.A1/NX549J.241005.001:user/release-keys"

[templates."nubia_nx563j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX563J"
device = "NX563J"
product = "NX563J"
marketname = "nubia Z17"
fingerprint = "nubia/NX563J/NX563J:15/AP3A.241005.015.A1/NX563J.241005.001:user/release-keys"

[templates."nubia_nx591j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX591J"
device = "NX591J"
product = "NX591J"
marketname = "nubia Z17 畅享版"
fingerprint = "nubia/NX591J/NX591J:15/AP3A.241005.015.A1/NX591J.241005.001:user/release-keys"

[templates."nubia_nx569j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX569J"
device = "NX569J"
product = "NX569J"
marketname = "nubia Z17 mini"
fingerprint = "nubia/NX569J/NX569J:15/AP3A.241005.015.A1/NX569J.241005.001:user/release-keys"

[templates."nubia_nx595j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX595J"
device = "NX595J"
product = "NX595J"
marketname = "nubia Z17S"
fingerprint = "nubia/NX595J/NX595J:15/AP3A.241005.015.A1/NX595J.241005.001:user/release-keys"

[templates."nubia_nx589j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX589J"
device = "NX589J"
product = "NX589J"
marketname = "nubia Z17 miniS"
fingerprint = "nubia/NX589J/NX589J:15/AP3A.241005.015.A1/NX589J.241005.001:user/release-keys"

[templates."nubia_nx606j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX606J"
device = "NX606J"
product = "NX606J"
marketname = "nubia Z18"
fingerprint = "nubia/NX606J/NX606J:15/AP3A.241005.015.A1/NX606J.241005.001:user/release-keys"

[templates."nubia_nx611j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX611J"
device = "NX611J"
product = "NX611J"
marketname = "nubia Z18 mini"
fingerprint = "nubia/NX611J/NX611J:15/AP3A.241005.015.A1/NX611J.241005.001:user/release-keys"

[templates."nubia_nx627j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX627J"
device = "NX627J"
product = "NX627J"
marketname = "nubia Z20"
fingerprint = "nubia/NX627J/NX627J:15/AP3A.241005.015.A1/NX627J.241005.001:user/release-keys"

[templates."nubia_nx667j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX667J"
device = "NX667J"
product = "NX667J"
marketname = "nubia Z30 Pro"
fingerprint = "nubia/NX667J/NX667J:15/AP3A.241005.015.A1/NX667J.241005.001:user/release-keys"

[templates."nubia_nx701j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX701J"
device = "NX701J"
product = "NX701J"
marketname = "nubia Z40 Pro"
fingerprint = "nubia/NX701J/NX701J:15/AP3A.241005.015.A1/NX701J.241005.001:user/release-keys"

[templates."nubia_nx702j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX702J"
device = "NX702J"
product = "NX702J"
marketname = "nubia Z40S Pro"
fingerprint = "nubia/NX702J/NX702J:15/AP3A.241005.015.A1/NX702J.241005.001:user/release-keys"

[templates."nubia_nx711j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX711J"
device = "NX711J"
product = "NX711J"
marketname = "nubia Z50"
fingerprint = "nubia/NX711J/NX711J:15/AP3A.241005.015.A1/NX711J.241005.001:user/release-keys"

[templates."nubia_nx712j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX712J"
device = "NX712J"
product = "NX712J"
marketname = "nubia Z50 Ultra"
fingerprint = "nubia/NX712J/NX712J:15/AP3A.241005.015.A1/NX712J.241005.001:user/release-keys"

[templates."nubia_nx713j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX713J"
device = "NX713J"
product = "NX713J"
marketname = "nubia Z50S Pro"
fingerprint = "nubia/NX713J/NX713J:15/AP3A.241005.015.A1/NX713J.241005.001:user/release-keys"

[templates."nubia_nx715j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX715J"
device = "NX715J"
product = "NX715J"
marketname = "nubia Z50 SE"
fingerprint = "nubia/NX715J/NX715J:15/AP3A.241005.015.A1/NX715J.241005.001:user/release-keys"

[templates."nubia_nx721j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX721J"
device = "NX721J"
product = "NX721J"
marketname = "nubia Z60 Ultra"
fingerprint = "nubia/NX721J/NX721J:15/AP3A.241005.015.A1/NX721J.241005.001:user/release-keys"

[templates."nubia_nx725j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX725J"
device = "NX725J"
product = "NX725J"
marketname = "nubia Z60S Pro"
fingerprint = "nubia/NX725J/NX725J:15/AP3A.241005.015.A1/NX725J.241005.001:user/release-keys"

[templates."nubia_nx733j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX733J"
device = "NX733J"
product = "NX733J"
marketname = "nubia Z70 Ultra"
fingerprint = "nubia/NX733J/NX733J:15/AP3A.241005.015.A1/NX733J.241005.001:user/release-keys"

[templates."nubia_nx736j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX736J"
device = "NX736J"
product = "NX736J"
marketname = "nubia Z70 Ultra 星空典藏版"
fingerprint = "nubia/NX736J/NX736J:15/AP3A.241005.015.A1/NX736J.241005.001:user/release-keys"

[templates."nubia_nx737j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX737J"
device = "NX737J"
product = "NX737J"
marketname = "nubia Z70S Ultra 摄影师版"
fingerprint = "nubia/NX737J/NX737J:15/AP3A.241005.015.A1/NX737J.241005.001:user/release-keys"

[templates."nubia_nx741j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX741J"
device = "NX741J"
product = "NX741J"
marketname = "nubia Z80 Ultra"
fingerprint = "nubia/NX741J/NX741J:15/AP3A.241005.015.A1/NX741J.241005.001:user/release-keys"

[templates."nubia_nx601j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX601J"
device = "NX601J"
product = "NX601J"
marketname = "nubia X6"
fingerprint = "nubia/NX601J/NX601J:15/AP3A.241005.015.A1/NX601J.241005.001:user/release-keys"

[templates."nubia_nx616j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX616J"
device = "NX616J"
product = "NX616J"
marketname = "nubia X"
fingerprint = "nubia/NX616J/NX616J:15/AP3A.241005.015.A1/NX616J.241005.001:user/release-keys"

[templates."nubia_nx612j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX612J"
device = "NX612J"
product = "NX612J"
marketname = "nubia V18"
fingerprint = "nubia/NX612J/NX612J:15/AP3A.241005.015.A1/NX612J.241005.001:user/release-keys"

[templates."nubia_nx651j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX651J"
device = "NX651J"
product = "NX651J"
marketname = "nubia Play"
fingerprint = "nubia/NX651J/NX651J:15/AP3A.241005.015.A1/NX651J.241005.001:user/release-keys"

[templates."nubia_nx724j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX724J"
device = "NX724J"
product = "NX724J"
marketname = "nubia Flip 5G"
fingerprint = "nubia/NX724J/NX724J:15/AP3A.241005.015.A1/NX724J.241005.001:user/release-keys"

[templates."nubia_nx732j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX732J"
device = "NX732J"
product = "NX732J"
marketname = "nubia Flip 2"
fingerprint = "nubia/NX732J/NX732J:15/AP3A.241005.015.A1/NX732J.241005.001:user/release-keys"

[templates."nubia_a404zt"]
manufacturer = "nubia"
brand = "nubia"
model = "A404ZT"
device = "A404ZT"
product = "A404ZT"
marketname = "nubia Flip 2 SoftBank"
fingerprint = "nubia/A404ZT/A404ZT:15/AP3A.241005.015.A1/A404ZT.241005.001:user/release-keys"

[templates."nubia_z8900ca"]
manufacturer = "nubia"
brand = "nubia"
model = "Z8900CA"
device = "Z8900CA"
product = "Z8900CA"
marketname = "nubia Flip 2 eSIM"
fingerprint = "nubia/Z8900CA/Z8900CA:15/AP3A.241005.015.A1/Z8900CA.241005.001:user/release-keys"

[templates."nubia_nx302j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX302J"
device = "NX302J"
product = "NX302J"
marketname = "nubia 小牛"
fingerprint = "nubia/NX302J/NX302J:15/AP3A.241005.015.A1/NX302J.241005.001:user/release-keys"

[templates."nubia_nx513j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX513J"
device = "NX513J"
product = "NX513J"
marketname = "nubia My 布拉格"
fingerprint = "nubia/NX513J/NX513J:15/AP3A.241005.015.A1/NX513J.241005.001:user/release-keys"

[templates."nubia_nx551j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX551J"
device = "NX551J"
product = "NX551J"
marketname = "nubia M2"
fingerprint = "nubia/NX551J/NX551J:15/AP3A.241005.015.A1/NX551J.241005.001:user/release-keys"

[templates."nubia_nx573j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX573J"
device = "NX573J"
product = "NX573J"
marketname = "nubia M2 青春版"
fingerprint = "nubia/NX573J/NX573J:15/AP3A.241005.015.A1/NX573J.241005.001:user/release-keys"

[templates."nubia_nx907j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX907J"
device = "NX907J"
product = "NX907J"
marketname = "nubia M2 畅玩版"
fingerprint = "nubia/NX907J/NX907J:15/AP3A.241005.015.A1/NX907J.241005.001:user/release-keys"

[templates."nubia_p0110"]
manufacturer = "nubia"
brand = "nubia"
model = "P0110"
device = "P0110"
product = "P0110"
marketname = "nubia M153 豆包手机助手技术预览版"
fingerprint = "nubia/P0110/P0110:15/AP3A.241005.015.A1/P0110.241005.001:user/release-keys"

[templates."nubia_nx888j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX888J"
device = "NX888J"
product = "NX888J"
marketname = "nubia NaviX Ultra"
fingerprint = "nubia/NX888J/NX888J:15/AP3A.241005.015.A1/NX888J.241005.001:user/release-keys"

[templates."nubia_nx541j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX541J"
device = "NX541J"
product = "NX541J"
marketname = "nubia N1"
fingerprint = "nubia/NX541J/NX541J:15/AP3A.241005.015.A1/NX541J.241005.001:user/release-keys"

[templates."nubia_nx575j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX575J"
device = "NX575J"
product = "NX575J"
marketname = "nubia N2"
fingerprint = "nubia/NX575J/NX575J:15/AP3A.241005.015.A1/NX575J.241005.001:user/release-keys"

[templates."nubia_nx608j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX608J"
device = "NX608J"
product = "NX608J"
marketname = "nubia N3"
fingerprint = "nubia/NX608J/NX608J:15/AP3A.241005.015.A1/NX608J.241005.001:user/release-keys"

[templates."nubia_nx301j"]
manufacturer = "nubia"
brand = "nubia"
model = "NX301J"
device = "NX301J"
product = "NX301J"
marketname = "nubia N5"
fingerprint = "nubia/NX301J/NX301J:15/AP3A.241005.015.A1/NX301J.241005.001:user/release-keys"

[templates."nubia_lpd_20w"]
manufacturer = "nubia"
brand = "nubia"
model = "LPD-20W"
device = "LPD-20W"
product = "LPD-20W"
marketname = "nubia Pad 3D"
fingerprint = "nubia/LPD-20W/LPD-20W:15/AP3A.241005.015.A1/LPD-20W.241005.001:user/release-keys"

[templates."nubia_np02j"]
manufacturer = "nubia"
brand = "nubia"
model = "NP02J"
device = "NP02J"
product = "NP02J"
marketname = "nubia Pad 3D II"
fingerprint = "nubia/NP02J/NP02J:15/AP3A.241005.015.A1/NP02J.241005.001:user/release-keys"

[templates."nubia_nt01"]
manufacturer = "nubia"
brand = "nubia"
model = "NT01"
device = "NT01"
product = "NT01"
marketname = "nubia Pad Pro"
fingerprint = "nubia/NT01/NT01:15/AP3A.241005.015.A1/NT01.241005.001:user/release-keys"

[templates."redmagic_nx609j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX609J"
device = "REDMAGIC"
product = "NX609J"
name = "REDMAGIC"
marketname = "RedMagic"
fingerprint = "Nubia/REDMAGIC/REDMAGIC:15/AP3A.241005.015.A1/REDMAGIC.241005.001:user/release-keys"

[templates."redmagic_nx619j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX619J"
device = "REDMAGIC MARS"
product = "NX619J"
name = "REDMAGIC MARS"
marketname = "RedMagic Mars"
fingerprint = "Nubia/REDMAGIC MARS/REDMAGIC MARS:15/AP3A.241005.015.A1/REDMAGICMARS.241005.001:user/release-keys"

[templates."redmagic_nx629j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX629J"
device = "REDMAGIC 3"
product = "NX629J"
name = "REDMAGIC 3"
marketname = "RedMagic 3"
fingerprint = "Nubia/REDMAGIC 3/REDMAGIC 3:15/AP3A.241005.015.A1/REDMAGIC3.241005.001:user/release-keys"

[templates."redmagic_nx659j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX659J"
device = "REDMAGIC 5G"
product = "NX659J"
name = "REDMAGIC 5G"
marketname = "RedMagic 5G"
fingerprint = "Nubia/REDMAGIC 5G/REDMAGIC 5G:15/AP3A.241005.015.A1/REDMAGIC5G.241005.001:user/release-keys"

[templates."redmagic_nx669j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX669J"
device = "REDMAGIC 6"
product = "NX669J"
name = "REDMAGIC 6"
marketname = "RedMagic 6"
fingerprint = "Nubia/REDMAGIC 6/REDMAGIC 6:15/AP3A.241005.015.A1/REDMAGIC6.241005.001:user/release-keys"

[templates."redmagic_nx669j_p"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX669J-P"
device = "REDMAGIC 6 PRO"
product = "NX669J-P"
name = "REDMAGIC 6 PRO"
marketname = "RedMagic 6 Pro"
fingerprint = "Nubia/REDMAGIC 6 PRO/REDMAGIC 6 PRO:15/AP3A.241005.015.A1/REDMAGIC6PRO.241005.001:user/release-keys"

[templates."redmagic_nx666j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX666J"
device = "REDMAGIC 6R"
product = "NX666J"
name = "REDMAGIC 6R"
marketname = "RedMagic 6R"
fingerprint = "Nubia/REDMAGIC 6R/REDMAGIC 6R:15/AP3A.241005.015.A1/REDMAGIC6R.241005.001:user/release-keys"

[templates."redmagic_nx669j_s"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX669J-S"
device = "REDMAGIC 6S PRO"
product = "NX669J-S"
name = "REDMAGIC 6S PRO"
marketname = "RedMagic 6S Pro"
fingerprint = "Nubia/REDMAGIC 6S PRO/REDMAGIC 6S PRO:15/AP3A.241005.015.A1/REDMAGIC6SPRO.241005.001:user/release-keys"

[templates."redmagic_nx679j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX679J"
device = "REDMAGIC 7"
product = "NX679J"
name = "REDMAGIC 7"
marketname = "RedMagic 7"
fingerprint = "Nubia/REDMAGIC 7/REDMAGIC 7:15/AP3A.241005.015.A1/REDMAGIC7.241005.001:user/release-keys"

[templates."redmagic_nx709j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX709J"
device = "REDMAGIC 7 PRO"
product = "NX709J"
name = "REDMAGIC 7 PRO"
marketname = "RedMagic 7 Pro"
fingerprint = "Nubia/REDMAGIC 7 PRO/REDMAGIC 7 PRO:15/AP3A.241005.015.A1/REDMAGIC7PRO.241005.001:user/release-keys"

[templates."redmagic_nx679s"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX679S"
device = "REDMAGIC 7S"
product = "NX679S"
name = "REDMAGIC 7S"
marketname = "RedMagic 7S"
fingerprint = "Nubia/REDMAGIC 7S/REDMAGIC 7S:15/AP3A.241005.015.A1/REDMAGIC7S.241005.001:user/release-keys"

[templates."redmagic_nx709s"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX709S"
device = "REDMAGIC 7S PRO"
product = "NX709S"
name = "REDMAGIC 7S PRO"
marketname = "RedMagic 7S Pro"
fingerprint = "Nubia/REDMAGIC 7S PRO/REDMAGIC 7S PRO:15/AP3A.241005.015.A1/REDMAGIC7SPRO.241005.001:user/release-keys"

[templates."redmagic_nx729j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX729J"
device = "REDMAGIC 8 PRO+"
product = "NX729J"
name = "REDMAGIC 8 PRO+"
marketname = "RedMagic 8 Pro+"
fingerprint = "Nubia/REDMAGIC 8 PRO+/REDMAGIC 8 PRO+:15/AP3A.241005.015.A1/REDMAGIC8PRO+.241005.001:user/release-keys"

[templates."redmagic_nx729s"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX729S"
device = "REDMAGIC 8S PRO+"
product = "NX729S"
name = "REDMAGIC 8S PRO+"
marketname = "RedMagic 8S Pro+"
fingerprint = "Nubia/REDMAGIC 8S PRO+/REDMAGIC 8S PRO+:15/AP3A.241005.015.A1/REDMAGIC8SPRO+.241005.001:user/release-keys"

[templates."redmagic_nx769j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX769J"
device = "REDMAGIC 9 PRO+"
product = "NX769J"
name = "REDMAGIC 9 PRO+"
marketname = "RedMagic 9 Pro+"
fingerprint = "Nubia/REDMAGIC 9 PRO+/REDMAGIC 9 PRO+:15/AP3A.241005.015.A1/REDMAGIC9PRO+.241005.001:user/release-keys"

[templates."redmagic_nx789j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX789J"
device = "REDMAGIC 10 PRO+"
product = "NX789J"
name = "REDMAGIC 10 PRO+"
marketname = "RedMagic 10 Pro+"
fingerprint = "Nubia/REDMAGIC 10 PRO+/REDMAGIC 10 PRO+:15/AP3A.241005.015.A1/REDMAGIC10PRO+.241005.001:user/release-keys"

[templates."redmagic_nx779j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX779J"
device = "REDMAGIC 10 AIR"
product = "NX779J"
name = "REDMAGIC 10 AIR"
marketname = "RedMagic 10 Air"
fingerprint = "Nubia/REDMAGIC 10 AIR/REDMAGIC 10 AIR:15/AP3A.241005.015.A1/REDMAGIC10AIR.241005.001:user/release-keys"

[templates."redmagic_nx809j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX809J"
device = "REDMAGIC 11 PRO+"
product = "NX809J"
name = "REDMAGIC 11 PRO+"
marketname = "RedMagic 11 Pro+"
fingerprint = "REDMAGIC/NX809J-UN/NX809J:16/BP2A.250605.031.A3/20251017.000000:user/release-keys"

[templates."redmagic_nx799j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX799J"
device = "REDMAGIC 11 AIR"
product = "NX799J"
name = "REDMAGIC 11 AIR"
marketname = "RedMagic 11 Air"
fingerprint = "Nubia/REDMAGIC 11 AIR/REDMAGIC 11 AIR:15/AP3A.241005.015.A1/REDMAGIC11AIR.241005.001:user/release-keys"

[templates."redmagic_nx819j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NX819J"
device = "REDMAGIC 12 PRO+"
product = "NX819J"
name = "REDMAGIC 12 PRO+"
marketname = "RedMagic 12 Pro+"
fingerprint = "Nubia/REDMAGIC 12 PRO+/REDMAGIC 12 PRO+:15/AP3A.241005.015.A1/REDMAGIC12PRO+.241005.001:user/release-keys"

[templates."redmagic_np01j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NP01J"
device = "REDMAGIC PAD 5G"
product = "NP01J"
name = "REDMAGIC PAD 5G"
marketname = "RedMagic Pad 5G"
fingerprint = "Nubia/REDMAGIC PAD 5G/REDMAGIC PAD 5G:15/AP3A.241005.015.A1/REDMAGICPAD5G.241005.001:user/release-keys"

[templates."redmagic_np03j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NP03J"
device = "REDMAGIC PAD PRO"
product = "NP03J"
name = "REDMAGIC PAD PRO"
marketname = "RedMagic Pad Pro"
fingerprint = "Nubia/REDMAGIC PAD PRO/REDMAGIC PAD PRO:15/AP3A.241005.015.A1/REDMAGICPADPRO.241005.001:user/release-keys"

[templates."redmagic_np05j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NP05J"
device = "REDMAGIC PAD 3 PRO"
product = "NP05J"
name = "REDMAGIC PAD 3 PRO"
marketname = "RedMagic Pad 3 Pro"
fingerprint = "Nubia/REDMAGIC PAD 3 PRO/REDMAGIC PAD 3 PRO:15/AP3A.241005.015.A1/REDMAGICPAD3PRO.241005.001:user/release-keys"

[templates."redmagic_np06j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "NP06J"
device = "REDMAGIC PAD 5 PRO"
product = "NP06J"
name = "REDMAGIC PAD 5 PRO"
marketname = "RedMagic Pad 5 Pro"
fingerprint = "Nubia/REDMAGIC PAD 5 PRO/REDMAGIC PAD 5 PRO:15/AP3A.241005.015.A1/REDMAGICPAD5PRO.241005.001:user/release-keys"

[templates."zte_zte_a2017"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2017"
device = "ZTE A2017"
product = "ZTE A2017"
marketname = "ZTE 天机 7"
fingerprint = "ZTE/ZTE A2017/ZTE A2017:15/AP3A.241005.015.A1/ZTEA2017.241005.001:user/release-keys"

[templates."zte_zte_a2018"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2018"
device = "ZTE A2018"
product = "ZTE A2018"
marketname = "ZTE 天机 7S"
fingerprint = "ZTE/ZTE A2018/ZTE A2018:15/AP3A.241005.015.A1/ZTEA2018.241005.001:user/release-keys"

[templates."zte_zte_c2017"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE C2017"
device = "ZTE C2017"
product = "ZTE C2017"
marketname = "ZTE 天机 7 MAX"
fingerprint = "ZTE/ZTE C2017/ZTE C2017:15/AP3A.241005.015.A1/ZTEC2017.241005.001:user/release-keys"

[templates."zte_z999"]
manufacturer = "ZTE"
brand = "ZTE"
model = "Z999"
device = "Z999"
product = "Z999"
marketname = "ZTE 天机 Axon M"
fingerprint = "ZTE/Z999/Z999:15/AP3A.241005.015.A1/Z999.241005.001:user/release-keys"

[templates."zte_zte_a2019_pro"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2019 Pro"
device = "ZTE A2019 Pro"
product = "ZTE A2019 Pro"
marketname = "ZTE 天机 Axon 9 Pro"
fingerprint = "ZTE/ZTE A2019 Pro/ZTE A2019 Pro:15/AP3A.241005.015.A1/ZTEA2019Pro.241005.001:user/release-keys"

[templates."zte_zte_a2020_pro"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2020 Pro"
device = "ZTE A2020 Pro"
product = "ZTE A2020 Pro"
marketname = "ZTE 天机 Axon 10 Pro 4G"
fingerprint = "ZTE/ZTE A2020 Pro/ZTE A2020 Pro:15/AP3A.241005.015.A1/ZTEA2020Pro.241005.001:user/release-keys"

[templates."zte_zte_a2020n2_pro"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2020N2 Pro"
device = "ZTE A2020N2 Pro"
product = "ZTE A2020N2 Pro"
marketname = "ZTE 天机 Axon 10 Pro 5G"
fingerprint = "ZTE/ZTE A2020N2 Pro/ZTE A2020N2 Pro:15/AP3A.241005.015.A1/ZTEA2020N2Pro.241005.001:user/release-keys"

[templates."zte_zte_a2020_sp"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2020 SP"
device = "ZTE A2020 SP"
product = "ZTE A2020 SP"
marketname = "ZTE 天机 Axon 10s Pro 5G"
fingerprint = "ZTE/ZTE A2020 SP/ZTE A2020 SP:15/AP3A.241005.015.A1/ZTEA2020SP.241005.001:user/release-keys"

[templates."zte_zte_9000n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 9000N"
device = "ZTE 9000N"
product = "ZTE 9000N"
marketname = "ZTE 天机 Axon 11 SE 5G"
fingerprint = "ZTE/ZTE 9000N/ZTE 9000N:15/AP3A.241005.015.A1/ZTE9000N.241005.001:user/release-keys"

[templates."zte_zte_a2021"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2021"
device = "ZTE A2021"
product = "ZTE A2021"
marketname = "ZTE 天机 Axon 11 5G"
fingerprint = "ZTE/ZTE A2021/ZTE A2021:15/AP3A.241005.015.A1/ZTEA2021.241005.001:user/release-keys"

[templates."zte_zte_a2021h"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2021H"
device = "ZTE A2021H"
product = "ZTE A2021H"
marketname = "ZTE 天机 Axon 11 5G 行业版"
fingerprint = "ZTE/ZTE A2021H/ZTE A2021H:15/AP3A.241005.015.A1/ZTEA2021H.241005.001:user/release-keys"

[templates."zte_zte_a2121"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2121"
device = "ZTE A2121"
product = "ZTE A2121"
marketname = "ZTE 天机 Axon 20 5G"
fingerprint = "ZTE/ZTE A2121/ZTE A2121:15/AP3A.241005.015.A1/ZTEA2121.241005.001:user/release-keys"

[templates."zte_zte_a2322"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2322"
device = "ZTE A2322"
product = "ZTE A2322"
marketname = "ZTE Axon 30 5G"
fingerprint = "ZTE/ZTE A2322/ZTE A2322:15/AP3A.241005.015.A1/ZTEA2322.241005.001:user/release-keys"

[templates."zte_zte_a2022"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2022"
device = "ZTE A2022"
product = "ZTE A2022"
marketname = "ZTE Axon 30 Pro 5G"
fingerprint = "ZTE/ZTE A2022/ZTE A2022:15/AP3A.241005.015.A1/ZTEA2022.241005.001:user/release-keys"

[templates."zte_zte_a2022p"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2022P"
device = "ZTE A2022P"
product = "ZTE A2022P"
marketname = "ZTE Axon 30 Ultra 5G"
fingerprint = "ZTE/ZTE A2022P/ZTE A2022P:15/AP3A.241005.015.A1/ZTEA2022P.241005.001:user/release-keys"

[templates."zte_zte_a2122h"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2122H"
device = "ZTE A2122H"
product = "ZTE A2122H"
marketname = "ZTE 天机 A31 5G"
fingerprint = "ZTE/ZTE A2122H/ZTE A2122H:15/AP3A.241005.015.A1/ZTEA2122H.241005.001:user/release-keys"

[templates."zte_zte_a2022h"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2022H"
device = "ZTE A2022H"
product = "ZTE A2022H"
marketname = "ZTE 天机 A31 Pro 5G"
fingerprint = "ZTE/ZTE A2022H/ZTE A2022H:15/AP3A.241005.015.A1/ZTEA2022H.241005.001:user/release-keys"

[templates."zte_zte_a2023"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2023"
device = "ZTE A2023"
product = "ZTE A2023"
marketname = "ZTE Axon 40 Pro"
fingerprint = "ZTE/ZTE A2023/ZTE A2023:15/AP3A.241005.015.A1/ZTEA2023.241005.001:user/release-keys"

[templates."zte_zte_a2023p"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2023P"
device = "ZTE A2023P"
product = "ZTE A2023P"
marketname = "ZTE Axon 40 Ultra"
fingerprint = "ZTE/ZTE A2023P/ZTE A2023P:15/AP3A.241005.015.A1/ZTEA2023P.241005.001:user/release-keys"

[templates."zte_zte_a2024h"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2024H"
device = "ZTE A2024H"
product = "ZTE A2024H"
marketname = "ZTE Axon 50"
fingerprint = "ZTE/ZTE A2024H/ZTE A2024H:15/AP3A.241005.015.A1/ZTEA2024H.241005.001:user/release-keys"

[templates."zte_zte_a2025hl"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2025HL"
device = "ZTE A2025HL"
product = "ZTE A2025HL"
marketname = "ZTE Axon 60 Ultra"
fingerprint = "ZTE/ZTE A2025HL/ZTE A2025HL:15/AP3A.241005.015.A1/ZTEA2025HL.241005.001:user/release-keys"

[templates."zte_zte_a2025h"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2025H"
device = "ZTE A2025H"
product = "ZTE A2025H"
marketname = "ZTE Axon 60 Ultra 天通版"
fingerprint = "ZTE/ZTE A2025H/ZTE A2025H:15/AP3A.241005.015.A1/ZTEA2025H.241005.001:user/release-keys"

[templates."zte_zte_a2023bh"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2023BH"
device = "ZTE A2023BH"
product = "ZTE A2023BH"
marketname = "ZTE 天机 A41"
fingerprint = "ZTE/ZTE A2023BH/ZTE A2023BH:15/AP3A.241005.015.A1/ZTEA2023BH.241005.001:user/release-keys"

[templates."zte_zte_a2023h"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A2023H"
device = "ZTE A2023H"
product = "ZTE A2023H"
marketname = "ZTE 天机 A41 Ultra"
fingerprint = "ZTE/ZTE A2023H/ZTE A2023H:15/AP3A.241005.015.A1/ZTEA2023H.241005.001:user/release-keys"

[templates."zte_zte_9030n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 9030N"
device = "ZTE 9030N"
product = "ZTE 9030N"
marketname = "ZTE S30 5G"
fingerprint = "ZTE/ZTE 9030N/ZTE 9030N:15/AP3A.241005.015.A1/ZTE9030N.241005.001:user/release-keys"

[templates."zte_zte_8030n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 8030N"
device = "ZTE 8030N"
product = "ZTE 8030N"
marketname = "ZTE S30 SE 5G"
fingerprint = "ZTE/ZTE 8030N/ZTE 8030N:15/AP3A.241005.015.A1/ZTE8030N.241005.001:user/release-keys"

[templates."zte_zte_bv0730"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE BV0730"
device = "ZTE BV0730"
product = "ZTE BV0730"
marketname = "ZTE Blade A2 Plus"
fingerprint = "ZTE/ZTE BV0730/ZTE BV0730:15/AP3A.241005.015.A1/ZTEBV0730.241005.001:user/release-keys"

[templates."zte_zte_v0721"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE V0721"
device = "ZTE V0721"
product = "ZTE V0721"
marketname = "ZTE Blade A2S"
fingerprint = "ZTE/ZTE V0721/ZTE V0721:15/AP3A.241005.015.A1/ZTEV0721.241005.001:user/release-keys"

[templates."zte_zte_a0616"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A0616"
device = "ZTE A0616"
product = "ZTE A0616"
marketname = "ZTE Blade A3"
fingerprint = "ZTE/ZTE A0616/ZTE A0616:15/AP3A.241005.015.A1/ZTEA0616.241005.001:user/release-keys"

[templates."zte_zte_a0722"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A0722"
device = "ZTE A0722"
product = "ZTE A0722"
marketname = "ZTE Blade A4"
fingerprint = "ZTE/ZTE A0722/ZTE A0722:15/AP3A.241005.015.A1/ZTEA0722.241005.001:user/release-keys"

[templates."zte_zte_a7000"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A7000"
device = "ZTE A7000"
product = "ZTE A7000"
marketname = "ZTE Blade A7"
fingerprint = "ZTE/ZTE A7000/ZTE A7000:15/AP3A.241005.015.A1/ZTEA7000.241005.001:user/release-keys"

[templates."zte_zte_a7010"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A7010"
device = "ZTE A7010"
product = "ZTE A7010"
marketname = "ZTE Blade A7S"
fingerprint = "ZTE/ZTE A7010/ZTE A7010:15/AP3A.241005.015.A1/ZTEA7010.241005.001:user/release-keys"

[templates."zte_zte_bv0800"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE BV0800"
device = "ZTE BV0800"
product = "ZTE BV0800"
marketname = "ZTE Blade V8"
fingerprint = "ZTE/ZTE BV0800/ZTE BV0800:15/AP3A.241005.015.A1/ZTEBV0800.241005.001:user/release-keys"

[templates."zte_zte_bv0850"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE BV0850"
device = "ZTE BV0850"
product = "ZTE BV0850"
marketname = "ZTE Blade V8 mini"
fingerprint = "ZTE/ZTE BV0850/ZTE BV0850:15/AP3A.241005.015.A1/ZTEBV0850.241005.001:user/release-keys"

[templates."zte_zte_v0900"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE V0900"
device = "ZTE V0900"
product = "ZTE V0900"
marketname = "ZTE Blade V9"
fingerprint = "ZTE/ZTE V0900/ZTE V0900:15/AP3A.241005.015.A1/ZTEV0900.241005.001:user/release-keys"

[templates."zte_zte_v1000"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE V1000"
device = "ZTE V1000"
product = "ZTE V1000"
marketname = "ZTE Blade V10"
fingerprint = "ZTE/ZTE V1000/ZTE V1000:15/AP3A.241005.015.A1/ZTEV1000.241005.001:user/release-keys"

[templates."zte_zte_v1050"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE V1050"
device = "ZTE V1050"
product = "ZTE V1050"
marketname = "ZTE Blade 20 Smart"
fingerprint = "ZTE/ZTE V1050/ZTE V1050:15/AP3A.241005.015.A1/ZTEV1050.241005.001:user/release-keys"

[templates."zte_zte_8012n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 8012N"
device = "ZTE 8012N"
product = "ZTE 8012N"
marketname = "ZTE Blade 20 5G"
fingerprint = "ZTE/ZTE 8012N/ZTE 8012N:15/AP3A.241005.015.A1/ZTE8012N.241005.001:user/release-keys"

[templates."zte_zte_8010"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 8010"
device = "ZTE 8010"
product = "ZTE 8010"
marketname = "ZTE Blade V2020 Smart"
fingerprint = "ZTE/ZTE 8010/ZTE 8010:15/AP3A.241005.015.A1/ZTE8010.241005.001:user/release-keys"

[templates."zte_zte_8031"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 8031"
device = "ZTE 8031"
product = "ZTE 8031"
marketname = "ZTE ZTE V2022"
fingerprint = "ZTE/ZTE 8031/ZTE 8031:15/AP3A.241005.015.A1/ZTE8031.241005.001:user/release-keys"

[templates."zte_zte_bv0701"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE BV0701"
device = "ZTE BV0701"
product = "ZTE BV0701"
marketname = "ZTE 小鲜 4"
fingerprint = "ZTE/ZTE BV0701/ZTE BV0701:15/AP3A.241005.015.A1/ZTEBV0701.241005.001:user/release-keys"

[templates."zte_zte_v0840"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE V0840"
device = "ZTE V0840"
product = "ZTE V0840"
marketname = "ZTE 小鲜 5"
fingerprint = "ZTE/ZTE V0840/ZTE V0840:15/AP3A.241005.015.A1/ZTEV0840.241005.001:user/release-keys"

[templates."zte_zte_v0920"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE V0920"
device = "ZTE V0920"
product = "ZTE V0920"
marketname = "ZTE 小鲜 5S"
fingerprint = "ZTE/ZTE V0920/ZTE V0920:15/AP3A.241005.015.A1/ZTEV0920.241005.001:user/release-keys"

[templates."zte_zte_a0620"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE A0620"
device = "ZTE A0620"
product = "ZTE A0620"
marketname = "ZTE 远航 5 plus"
fingerprint = "ZTE/ZTE A0620/ZTE A0620:15/AP3A.241005.015.A1/ZTEA0620.241005.001:user/release-keys"

[templates."zte_zte_7530n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7530N"
device = "ZTE 7530N"
product = "ZTE 7530N"
marketname = "ZTE 远航 10"
fingerprint = "ZTE/ZTE 7530N/ZTE 7530N:15/AP3A.241005.015.A1/ZTE7530N.241005.001:user/release-keys"

[templates."zte_zte_9040n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 9040N"
device = "ZTE 9040N"
product = "ZTE 9040N"
marketname = "ZTE 远航 20 Pro"
fingerprint = "ZTE/ZTE 9040N/ZTE 9040N:15/AP3A.241005.015.A1/ZTE9040N.241005.001:user/release-keys"

[templates."zte_zte_7532n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7532N"
device = "ZTE 7532N"
product = "ZTE 7532N"
marketname = "ZTE 远航 30"
fingerprint = "ZTE/ZTE 7532N/ZTE 7532N:15/AP3A.241005.015.A1/ZTE7532N.241005.001:user/release-keys"

[templates."zte_zte_7531n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7531N"
device = "ZTE 7531N"
product = "ZTE 7531N"
marketname = "ZTE 远航 30S"
fingerprint = "ZTE/ZTE 7531N/ZTE 7531N:15/AP3A.241005.015.A1/ZTE7531N.241005.001:user/release-keys"

[templates."zte_zte_7534n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7534N"
device = "ZTE 7534N"
product = "ZTE 7534N"
marketname = "ZTE 远航 30 畅行版"
fingerprint = "ZTE/ZTE 7534N/ZTE 7534N:15/AP3A.241005.015.A1/ZTE7534N.241005.001:user/release-keys"

[templates."zte_zte_8040n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 8040N"
device = "ZTE 8040N"
product = "ZTE 8040N"
marketname = "ZTE 远航 30 Pro"
fingerprint = "ZTE/ZTE 8040N/ZTE 8040N:15/AP3A.241005.015.A1/ZTE8040N.241005.001:user/release-keys"

[templates."zte_zte_9041n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 9041N"
device = "ZTE 9041N"
product = "ZTE 9041N"
marketname = "ZTE 远航 30 Pro+"
fingerprint = "ZTE/ZTE 9041N/ZTE 9041N:15/AP3A.241005.015.A1/ZTE9041N.241005.001:user/release-keys"

[templates."zte_zte_1010l"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 1010L"
device = "ZTE 1010L"
product = "ZTE 1010L"
marketname = "ZTE 畅行 30"
fingerprint = "ZTE/ZTE 1010L/ZTE 1010L:15/AP3A.241005.015.A1/ZTE1010L.241005.001:user/release-keys"

[templates."zte_zte_7542n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7542N"
device = "ZTE 7542N"
product = "ZTE 7542N"
marketname = "ZTE 远航 40"
fingerprint = "ZTE/ZTE 7542N/ZTE 7542N:15/AP3A.241005.015.A1/ZTE7542N.241005.001:user/release-keys"

[templates."zte_zte_9042n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 9042N"
device = "ZTE 9042N"
product = "ZTE 9042N"
marketname = "ZTE 远航 40 Pro+"
fingerprint = "ZTE/ZTE 9042N/ZTE 9042N:15/AP3A.241005.015.A1/ZTE9042N.241005.001:user/release-keys"

[templates."zte_zte_7541n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7541N"
device = "ZTE 7541N"
product = "ZTE 7541N"
marketname = "ZTE 远航 41"
fingerprint = "ZTE/ZTE 7541N/ZTE 7541N:15/AP3A.241005.015.A1/ZTE7541N.241005.001:user/release-keys"

[templates."zte_zte_7546n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7546N"
device = "ZTE 7546N"
product = "ZTE 7546N"
marketname = "ZTE 远航 41S"
fingerprint = "ZTE/ZTE 7546N/ZTE 7546N:15/AP3A.241005.015.A1/ZTE7546N.241005.001:user/release-keys"

[templates."zte_zte_1021l"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 1021L"
device = "ZTE 1021L"
product = "ZTE 1021L"
marketname = "ZTE 畅行 40 SE"
fingerprint = "ZTE/ZTE 1021L/ZTE 1021L:15/AP3A.241005.015.A1/ZTE1021L.241005.001:user/release-keys"

[templates."zte_zte_7543n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7543N"
device = "ZTE 7543N"
product = "ZTE 7543N"
marketname = "ZTE 小鲜 50"
fingerprint = "ZTE/ZTE 7543N/ZTE 7543N:15/AP3A.241005.015.A1/ZTE7543N.241005.001:user/release-keys"

[templates."zte_zte_7551n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7551N"
device = "ZTE 7551N"
product = "ZTE 7551N"
marketname = "ZTE 小鲜 60"
fingerprint = "ZTE/ZTE 7551N/ZTE 7551N:15/AP3A.241005.015.A1/ZTE7551N.241005.001:user/release-keys"

[templates."zte_zte_7552n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7552N"
device = "ZTE 7552N"
product = "ZTE 7552N"
marketname = "ZTE 畅行 60"
fingerprint = "ZTE/ZTE 7552N/ZTE 7552N:15/AP3A.241005.015.A1/ZTE7552N.241005.001:user/release-keys"

[templates."zte_zte_7553n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7553N"
device = "ZTE 7553N"
product = "ZTE 7553N"
marketname = "ZTE 畅行 60 Plus"
fingerprint = "ZTE/ZTE 7553N/ZTE 7553N:15/AP3A.241005.015.A1/ZTE7553N.241005.001:user/release-keys"

[templates."zte_zte_7661n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7661N"
device = "ZTE 7661N"
product = "ZTE 7661N"
marketname = "ZTE 畅行 60 Ultra"
fingerprint = "ZTE/ZTE 7661N/ZTE 7661N:15/AP3A.241005.015.A1/ZTE7661N.241005.001:user/release-keys"

[templates."zte_zte_7561n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7561N"
device = "ZTE 7561N"
product = "ZTE 7561N"
marketname = "ZTE 远航 60 Plus"
fingerprint = "ZTE/ZTE 7561N/ZTE 7561N:15/AP3A.241005.015.A1/ZTE7561N.241005.001:user/release-keys"

[templates."zte_zte_7533n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7533N"
device = "ZTE 7533N"
product = "ZTE 7533N"
marketname = "ZTE 远航 3D"
fingerprint = "ZTE/ZTE 7533N/ZTE 7533N:15/AP3A.241005.015.A1/ZTE7533N.241005.001:user/release-keys"

[templates."zte_zte_7671n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7671N"
device = "ZTE 7671N"
product = "ZTE 7671N"
marketname = "ZTE 畅行 70 Plus"
fingerprint = "ZTE/ZTE 7671N/ZTE 7671N:15/AP3A.241005.015.A1/ZTE7671N.241005.001:user/release-keys"

[templates."zte_zte_7672n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 7672N"
device = "ZTE 7672N"
product = "ZTE 7672N"
marketname = "ZTE 小鲜 70 Plus"
fingerprint = "ZTE/ZTE 7672N/ZTE 7672N:15/AP3A.241005.015.A1/ZTE7672N.241005.001:user/release-keys"

[templates."zte_zte_9043n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 9043N"
device = "ZTE 9043N"
product = "ZTE 9043N"
marketname = "ZTE V70 Pro"
fingerprint = "ZTE/ZTE 9043N/ZTE 9043N:15/AP3A.241005.015.A1/ZTE9043N.241005.001:user/release-keys"

[templates."zte_zte_pa01"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE PA01"
device = "ZTE PA01"
product = "ZTE PA01"
marketname = "ZTE Axon Pad"
fingerprint = "ZTE/ZTE PA01/ZTE PA01:15/AP3A.241005.015.A1/ZTEPA01.241005.001:user/release-keys"

[templates."zte_w200ds"]
manufacturer = "ZTE"
brand = "ZTE"
model = "W200DS"
device = "W200DS"
product = "W200DS"
marketname = "ZTE 云电脑 逍遥系列"
fingerprint = "ZTE/W200DS/W200DS:15/AP3A.241005.015.A1/W200DS.241005.001:user/release-keys"

[templates."zte_w200ds_pro"]
manufacturer = "ZTE"
brand = "ZTE"
model = "W200DS Pro"
device = "W200DS Pro"
product = "W200DS Pro"
marketname = "ZTE 云电脑 逍遥系列 Pro"
fingerprint = "ZTE/W200DS Pro/W200DS Pro:15/AP3A.241005.015.A1/W200DSPro.241005.001:user/release-keys"

[templates."zte_w210ds"]
manufacturer = "ZTE"
brand = "ZTE"
model = "W210DS"
device = "W210DS"
product = "W210DS"
marketname = "ZTE 云电脑 逍遥 20"
fingerprint = "ZTE/W210DS/W210DS:15/AP3A.241005.015.A1/W210DS.241005.001:user/release-keys"

[templates."sony_e2104"]
manufacturer = "Sony"
brand = "Sony"
model = "E2104"
device = "Jasmine"
product = "Jasmine"
name = "Jasmine"
marketname = "Xperia E4"
fingerprint = "Sony/Jasmine/Jasmine:15/AP3A.241005.015.A1/Jasmine.241005.001:user/release-keys"

[templates."sony_e2115"]
manufacturer = "Sony"
brand = "Sony"
model = "E2115"
device = "Jasmine"
product = "Jasmine"
name = "Jasmine"
marketname = "Xperia E4 dual"
fingerprint = "Sony/Jasmine/Jasmine:15/AP3A.241005.015.A1/Jasmine.241005.001:user/release-keys"

[templates."sony_e2114"]
manufacturer = "Sony"
brand = "Sony"
model = "E2114"
device = "Jasmine"
product = "Jasmine"
name = "Jasmine"
marketname = "Xperia E4 dual Brazil"
fingerprint = "Sony/Jasmine/Jasmine:15/AP3A.241005.015.A1/Jasmine.241005.001:user/release-keys"

[templates."sony_e2303"]
manufacturer = "Sony"
brand = "Sony"
model = "E2303"
device = "Tulip"
product = "Tulip"
name = "Tulip"
marketname = "Xperia M4 Aqua"
fingerprint = "Sony/Tulip/Tulip:15/AP3A.241005.015.A1/Tulip.241005.001:user/release-keys"

[templates."sony_e2312"]
manufacturer = "Sony"
brand = "Sony"
model = "E2312"
device = "Tulip"
product = "Tulip"
name = "Tulip"
marketname = "Xperia M4 Aqua dual"
fingerprint = "Sony/Tulip/Tulip:15/AP3A.241005.015.A1/Tulip.241005.001:user/release-keys"

[templates."sony_e5603"]
manufacturer = "Sony"
brand = "Sony"
model = "E5603"
device = "Holly"
product = "Holly"
name = "Holly"
marketname = "Xperia M5"
fingerprint = "Sony/Holly/Holly:15/AP3A.241005.015.A1/Holly.241005.001:user/release-keys"

[templates."sony_e5633"]
manufacturer = "Sony"
brand = "Sony"
model = "E5633"
device = "Holly"
product = "Holly"
name = "Holly"
marketname = "Xperia M5 dual"
fingerprint = "Sony/Holly/Holly:15/AP3A.241005.015.A1/Holly.241005.001:user/release-keys"

[templates."sony_e5643"]
manufacturer = "Sony"
brand = "Sony"
model = "E5643"
device = "Holly"
product = "Holly"
name = "Holly"
marketname = "Xperia M5 dual Brazil"
fingerprint = "Sony/Holly/Holly:15/AP3A.241005.015.A1/Holly.241005.001:user/release-keys"

[templates."sony_e5303"]
manufacturer = "Sony"
brand = "Sony"
model = "E5303"
device = "Cosmos"
product = "Cosmos"
name = "Cosmos"
marketname = "Xperia C4"
fingerprint = "Sony/Cosmos/Cosmos:15/AP3A.241005.015.A1/Cosmos.241005.001:user/release-keys"

[templates."sony_e5333"]
manufacturer = "Sony"
brand = "Sony"
model = "E5333"
device = "Cosmos"
product = "Cosmos"
name = "Cosmos"
marketname = "Xperia C4 dual"
fingerprint = "Sony/Cosmos/Cosmos:15/AP3A.241005.015.A1/Cosmos.241005.001:user/release-keys"

[templates."sony_e5343"]
manufacturer = "Sony"
brand = "Sony"
model = "E5343"
device = "Cosmos"
product = "Cosmos"
name = "Cosmos"
marketname = "Xperia C4 dual Brazil"
fingerprint = "Sony/Cosmos/Cosmos:15/AP3A.241005.015.A1/Cosmos.241005.001:user/release-keys"

[templates."sony_e5606"]
manufacturer = "Sony"
brand = "Sony"
model = "E5606"
device = "Lavender"
product = "Lavender"
name = "Lavender"
marketname = "Xperia C5 Ultra"
fingerprint = "Sony/Lavender/Lavender:15/AP3A.241005.015.A1/Lavender.241005.001:user/release-keys"

[templates."sony_e5533"]
manufacturer = "Sony"
brand = "Sony"
model = "E5533"
device = "Lavender"
product = "Lavender"
name = "Lavender"
marketname = "Xperia C5 Ultra dual"
fingerprint = "Sony/Lavender/Lavender:15/AP3A.241005.015.A1/Lavender.241005.001:user/release-keys"

[templates."sony_e6553"]
manufacturer = "Sony"
brand = "Sony"
model = "E6553"
device = "Ivy"
product = "Ivy"
name = "Ivy"
marketname = "Xperia Z3+"
fingerprint = "Sony/Ivy/Ivy:15/AP3A.241005.015.A1/Ivy.241005.001:user/release-keys"

[templates."sony_e6533"]
manufacturer = "Sony"
brand = "Sony"
model = "E6533"
device = "Ivy"
product = "Ivy"
name = "Ivy"
marketname = "Xperia Z3+ dual"
fingerprint = "Sony/Ivy/Ivy:15/AP3A.241005.015.A1/Ivy.241005.001:user/release-keys"

[templates."sony_402so"]
manufacturer = "Sony"
brand = "Sony"
model = "402SO"
device = "Ivy"
product = "Ivy"
name = "Ivy"
marketname = "Xperia Z4 Japan"
fingerprint = "Sony/Ivy/Ivy:15/AP3A.241005.015.A1/Ivy.241005.001:user/release-keys"

[templates."sony_e6603"]
manufacturer = "Sony"
brand = "Sony"
model = "E6603"
device = "Sumire"
product = "Sumire"
name = "Sumire"
marketname = "Xperia Z5"
fingerprint = "Sony/Sumire/Sumire:15/AP3A.241005.015.A1/Sumire.241005.001:user/release-keys"

[templates."sony_e6633"]
manufacturer = "Sony"
brand = "Sony"
model = "E6633"
device = "Sumire"
product = "Sumire"
name = "Sumire"
marketname = "Xperia Z5 dual"
fingerprint = "Sony/Sumire/Sumire:15/AP3A.241005.015.A1/Sumire.241005.001:user/release-keys"

[templates."sony_501so"]
manufacturer = "Sony"
brand = "Sony"
model = "501SO"
device = "Sumire"
product = "Sumire"
name = "Sumire"
marketname = "Xperia Z5 Japan"
fingerprint = "Sony/Sumire/Sumire:15/AP3A.241005.015.A1/Sumire.241005.001:user/release-keys"

[templates."sony_e5803"]
manufacturer = "Sony"
brand = "Sony"
model = "E5803"
device = "Suzuran"
product = "Suzuran"
name = "Suzuran"
marketname = "Xperia Z5 Compact"
fingerprint = "Sony/Suzuran/Suzuran:15/AP3A.241005.015.A1/Suzuran.241005.001:user/release-keys"

[templates."sony_so_02h"]
manufacturer = "Sony"
brand = "Sony"
model = "SO-02H"
device = "Suzuran"
product = "Suzuran"
name = "Suzuran"
marketname = "Xperia Z5 Compact Japan"
fingerprint = "Sony/Suzuran/Suzuran:15/AP3A.241005.015.A1/Suzuran.241005.001:user/release-keys"

[templates."sony_e6853"]
manufacturer = "Sony"
brand = "Sony"
model = "E6853"
device = "Satsuki"
product = "Satsuki"
name = "Satsuki"
marketname = "Xperia Z5 Premium"
fingerprint = "Sony/Satsuki/Satsuki:15/AP3A.241005.015.A1/Satsuki.241005.001:user/release-keys"

[templates."sony_e6833"]
manufacturer = "Sony"
brand = "Sony"
model = "E6833"
device = "Satsuki"
product = "Satsuki"
name = "Satsuki"
marketname = "Xperia Z5 Premium dual"
fingerprint = "Sony/Satsuki/Satsuki:15/AP3A.241005.015.A1/Satsuki.241005.001:user/release-keys"

[templates."sony_so_03h"]
manufacturer = "Sony"
brand = "Sony"
model = "SO-03H"
device = "Satsuki"
product = "Satsuki"
name = "Satsuki"
marketname = "Xperia Z5 Premium Japan"
fingerprint = "Sony/Satsuki/Satsuki:15/AP3A.241005.015.A1/Satsuki.241005.001:user/release-keys"

[templates."sony_f3311"]
manufacturer = "Sony"
brand = "Sony"
model = "F3311"
device = "Bassoon"
product = "Bassoon"
name = "Bassoon"
marketname = "Xperia E5"
fingerprint = "Sony/Bassoon/Bassoon:15/AP3A.241005.015.A1/Bassoon.241005.001:user/release-keys"

[templates."sony_f3111"]
manufacturer = "Sony"
brand = "Sony"
model = "F3111"
device = "Tuba"
product = "Tuba"
name = "Tuba"
marketname = "Xperia XA"
fingerprint = "Sony/Tuba/Tuba:15/AP3A.241005.015.A1/Tuba.241005.001:user/release-keys"

[templates."sony_f3211"]
manufacturer = "Sony"
brand = "Sony"
model = "F3211"
device = "Tuba"
product = "Tuba"
name = "Tuba"
marketname = "Xperia XA Ultra"
fingerprint = "Sony/Tuba/Tuba:15/AP3A.241005.015.A1/Tuba.241005.001:user/release-keys"

[templates."sony_f5121"]
manufacturer = "Sony"
brand = "Sony"
model = "F5121"
device = "Suzu"
product = "Suzu"
name = "Suzu"
marketname = "Xperia X"
fingerprint = "Sony/Suzu/Suzu:15/AP3A.241005.015.A1/Suzu.241005.001:user/release-keys"

[templates."sony_f5321"]
manufacturer = "Sony"
brand = "Sony"
model = "F5321"
device = "Kugo"
product = "Kugo"
name = "Kugo"
marketname = "Xperia X Compact"
fingerprint = "Sony/Kugo/Kugo:15/AP3A.241005.015.A1/Kugo.241005.001:user/release-keys"

[templates."sony_so_02j"]
manufacturer = "Sony"
brand = "Sony"
model = "SO-02J"
device = "Kugo"
product = "Kugo"
name = "Kugo"
marketname = "Xperia X Compact Japan"
fingerprint = "Sony/Kugo/Kugo:15/AP3A.241005.015.A1/Kugo.241005.001:user/release-keys"

[templates."sony_f8131"]
manufacturer = "Sony"
brand = "Sony"
model = "F8131"
device = "Dora"
product = "Dora"
name = "Dora"
marketname = "Xperia X Performance"
fingerprint = "Sony/Dora/Dora:15/AP3A.241005.015.A1/Dora.241005.001:user/release-keys"

[templates."sony_502so"]
manufacturer = "Sony"
brand = "Sony"
model = "502SO"
device = "Dora"
product = "Dora"
name = "Dora"
marketname = "Xperia X Performance Japan"
fingerprint = "Sony/Dora/Dora:15/AP3A.241005.015.A1/Dora.241005.001:user/release-keys"

[templates."sony_f8331"]
manufacturer = "Sony"
brand = "Sony"
model = "F8331"
device = "Kagura"
product = "Kagura"
name = "Kagura"
marketname = "Xperia XZ"
fingerprint = "Sony/Kagura/Kagura:15/AP3A.241005.015.A1/Kagura.241005.001:user/release-keys"

[templates."sony_601so"]
manufacturer = "Sony"
brand = "Sony"
model = "601SO"
device = "Kagura"
product = "Kagura"
name = "Kagura"
marketname = "Xperia XZ Japan"
fingerprint = "Sony/Kagura/Kagura:15/AP3A.241005.015.A1/Kagura.241005.001:user/release-keys"

[templates."sony_g3311"]
manufacturer = "Sony"
brand = "Sony"
model = "G3311"
device = "Pine"
product = "Pine"
name = "Pine"
marketname = "Xperia L1"
fingerprint = "Sony/Pine/Pine:15/AP3A.241005.015.A1/Pine.241005.001:user/release-keys"

[templates."sony_g3121"]
manufacturer = "Sony"
brand = "Sony"
model = "G3121"
device = "Hinoki"
product = "Hinoki"
name = "Hinoki"
marketname = "Xperia XA1"
fingerprint = "Sony/Hinoki/Hinoki:15/AP3A.241005.015.A1/Hinoki.241005.001:user/release-keys"

[templates."sony_g3221"]
manufacturer = "Sony"
brand = "Sony"
model = "G3221"
device = "Redwood"
product = "Redwood"
name = "Redwood"
marketname = "Xperia XA1 Ultra"
fingerprint = "Sony/Redwood/Redwood:15/AP3A.241005.015.A1/Redwood.241005.001:user/release-keys"

[templates."sony_g3421"]
manufacturer = "Sony"
brand = "Sony"
model = "G3421"
device = "Teak"
product = "Teak"
name = "Teak"
marketname = "Xperia XA1 Plus"
fingerprint = "Sony/Teak/Teak:15/AP3A.241005.015.A1/Teak.241005.001:user/release-keys"

[templates."sony_g8231"]
manufacturer = "Sony"
brand = "Sony"
model = "G8231"
device = "Keyaki"
product = "Keyaki"
name = "Keyaki"
marketname = "Xperia XZs"
fingerprint = "Sony/Keyaki/Keyaki:15/AP3A.241005.015.A1/Keyaki.241005.001:user/release-keys"

[templates."sony_602so"]
manufacturer = "Sony"
brand = "Sony"
model = "602SO"
device = "Keyaki"
product = "Keyaki"
name = "Keyaki"
marketname = "Xperia XZs Japan"
fingerprint = "Sony/Keyaki/Keyaki:15/AP3A.241005.015.A1/Keyaki.241005.001:user/release-keys"

[templates."sony_g8141"]
manufacturer = "Sony"
brand = "Sony"
model = "G8141"
device = "Maple"
product = "Maple"
name = "Maple"
marketname = "Xperia XZ Premium"
fingerprint = "Sony/Maple/Maple:15/AP3A.241005.015.A1/Maple.241005.001:user/release-keys"

[templates."sony_g8188"]
manufacturer = "Sony"
brand = "Sony"
model = "G8188"
device = "Maple"
product = "Maple"
name = "Maple"
marketname = "Xperia XZ Premium Japan"
fingerprint = "Sony/Maple/Maple:15/AP3A.241005.015.A1/Maple.241005.001:user/release-keys"

[templates."sony_g8341"]
manufacturer = "Sony"
brand = "Sony"
model = "G8341"
device = "Poplar"
product = "Poplar"
name = "Poplar"
marketname = "Xperia XZ1"
fingerprint = "Sony/Poplar/Poplar:15/AP3A.241005.015.A1/Poplar.241005.001:user/release-keys"

[templates."sony_g8343"]
manufacturer = "Sony"
brand = "Sony"
model = "G8343"
device = "Poplar"
product = "Poplar"
name = "Poplar"
marketname = "Xperia XZ1 Canada"
fingerprint = "Sony/Poplar/Poplar:15/AP3A.241005.015.A1/Poplar.241005.001:user/release-keys"

[templates."sony_701so"]
manufacturer = "Sony"
brand = "Sony"
model = "701SO"
device = "Poplar"
product = "Poplar"
name = "Poplar"
marketname = "Xperia XZ1 Japan"
fingerprint = "Sony/Poplar/Poplar:15/AP3A.241005.015.A1/Poplar.241005.001:user/release-keys"

[templates."sony_g8441"]
manufacturer = "Sony"
brand = "Sony"
model = "G8441"
device = "Lilac"
product = "Lilac"
name = "Lilac"
marketname = "Xperia XZ1 Compact"
fingerprint = "Sony/Lilac/Lilac:15/AP3A.241005.015.A1/Lilac.241005.001:user/release-keys"

[templates."sony_so_02k"]
manufacturer = "Sony"
brand = "Sony"
model = "SO-02K"
device = "Lilac"
product = "Lilac"
name = "Lilac"
marketname = "Xperia XZ1 Compact Japan"
fingerprint = "Sony/Lilac/Lilac:15/AP3A.241005.015.A1/Lilac.241005.001:user/release-keys"

[templates."sony_h3311"]
manufacturer = "Sony"
brand = "Sony"
model = "H3311"
device = "Ranger"
product = "Ranger"
name = "Ranger"
marketname = "Xperia L2"
fingerprint = "Sony/Ranger/Ranger:15/AP3A.241005.015.A1/Ranger.241005.001:user/release-keys"

[templates."sony_h3113"]
manufacturer = "Sony"
brand = "Sony"
model = "H3113"
device = "Pioneer"
product = "Pioneer"
name = "Pioneer"
marketname = "Xperia XA2"
fingerprint = "Sony/Pioneer/Pioneer:15/AP3A.241005.015.A1/Pioneer.241005.001:user/release-keys"

[templates."sony_h3213"]
manufacturer = "Sony"
brand = "Sony"
model = "H3213"
device = "Discovery"
product = "Discovery"
name = "Discovery"
marketname = "Xperia XA2 Ultra"
fingerprint = "Sony/Discovery/Discovery:15/AP3A.241005.015.A1/Discovery.241005.001:user/release-keys"

[templates."sony_h3413"]
manufacturer = "Sony"
brand = "Sony"
model = "H3413"
device = "Voyager"
product = "Voyager"
name = "Voyager"
marketname = "Xperia XA2 Plus"
fingerprint = "Sony/Voyager/Voyager:15/AP3A.241005.015.A1/Voyager.241005.001:user/release-keys"

[templates."sony_h8216"]
manufacturer = "Sony"
brand = "Sony"
model = "H8216"
device = "Akari"
product = "Akari"
name = "Akari"
marketname = "Xperia XZ2"
fingerprint = "Sony/Akari/Akari:15/AP3A.241005.015.A1/Akari.241005.001:user/release-keys"

[templates."sony_h8276"]
manufacturer = "Sony"
brand = "Sony"
model = "H8276"
device = "Akari"
product = "Akari"
name = "Akari"
marketname = "Xperia XZ2 Canada"
fingerprint = "Sony/Akari/Akari:15/AP3A.241005.015.A1/Akari.241005.001:user/release-keys"

[templates."sony_702so"]
manufacturer = "Sony"
brand = "Sony"
model = "702SO"
device = "Akari"
product = "Akari"
name = "Akari"
marketname = "Xperia XZ2 Japan"
fingerprint = "Sony/Akari/Akari:15/AP3A.241005.015.A1/Akari.241005.001:user/release-keys"

[templates."sony_h8314"]
manufacturer = "Sony"
brand = "Sony"
model = "H8314"
device = "Apollo"
product = "Apollo"
name = "Apollo"
marketname = "Xperia XZ2 Compact"
fingerprint = "Sony/Apollo/Apollo:15/AP3A.241005.015.A1/Apollo.241005.001:user/release-keys"

[templates."sony_so_05k"]
manufacturer = "Sony"
brand = "Sony"
model = "SO-05K"
device = "Apollo"
product = "Apollo"
name = "Apollo"
marketname = "Xperia XZ2 Compact Japan"
fingerprint = "Sony/Apollo/Apollo:15/AP3A.241005.015.A1/Apollo.241005.001:user/release-keys"

[templates."sony_h8116"]
manufacturer = "Sony"
brand = "Sony"
model = "H8116"
device = "Aurora"
product = "Aurora"
name = "Aurora"
marketname = "Xperia XZ2 Premium"
fingerprint = "Sony/Aurora/Aurora:15/AP3A.241005.015.A1/Aurora.241005.001:user/release-keys"

[templates."sony_so_04k"]
manufacturer = "Sony"
brand = "Sony"
model = "SO-04K"
device = "Aurora"
product = "Aurora"
name = "Aurora"
marketname = "Xperia XZ2 Premium Japan"
fingerprint = "Sony/Aurora/Aurora:15/AP3A.241005.015.A1/Aurora.241005.001:user/release-keys"

[templates."sony_h8416"]
manufacturer = "Sony"
brand = "Sony"
model = "H8416"
device = "Akatsuki"
product = "Akatsuki"
name = "Akatsuki"
marketname = "Xperia XZ3"
fingerprint = "Sony/Akatsuki/Akatsuki:15/AP3A.241005.015.A1/Akatsuki.241005.001:user/release-keys"

[templates."sony_801so"]
manufacturer = "Sony"
brand = "Sony"
model = "801SO"
device = "Akatsuki"
product = "Akatsuki"
name = "Akatsuki"
marketname = "Xperia XZ3 Japan"
fingerprint = "Sony/Akatsuki/Akatsuki:15/AP3A.241005.015.A1/Akatsuki.241005.001:user/release-keys"

[templates."sony_i3312"]
manufacturer = "Sony"
brand = "Sony"
model = "I3312"
device = "Dragon"
product = "Dragon"
name = "Dragon"
marketname = "Xperia L3"
fingerprint = "Sony/Dragon/Dragon:15/AP3A.241005.015.A1/Dragon.241005.001:user/release-keys"

[templates."sony_j8110"]
manufacturer = "Sony"
brand = "Sony"
model = "J8110"
device = "Griffin"
product = "Griffin"
name = "Griffin"
marketname = "Xperia 1"
fingerprint = "Sony/Griffin/Griffin:15/AP3A.241005.015.A1/Griffin.241005.001:user/release-keys"

[templates."sony_j8170"]
manufacturer = "Sony"
brand = "Sony"
model = "J8170"
device = "Griffin"
product = "Griffin"
name = "Griffin"
marketname = "Xperia 1 US"
fingerprint = "Sony/Griffin/Griffin:15/AP3A.241005.015.A1/Griffin.241005.001:user/release-keys"

[templates."sony_j9180"]
manufacturer = "Sony"
brand = "Sony"
model = "J9180"
device = "Griffin"
product = "Griffin"
name = "Griffin"
marketname = "Xperia 1 Professional Editon China"
fingerprint = "Sony/Griffin/Griffin:15/AP3A.241005.015.A1/Griffin.241005.001:user/release-keys"

[templates."sony_j9150"]
manufacturer = "Sony"
brand = "Sony"
model = "J9150"
device = "Griffin"
product = "Griffin"
name = "Griffin"
marketname = "Xperia 1 Japan"
fingerprint = "Sony/Griffin/Griffin:15/AP3A.241005.015.A1/Griffin.241005.001:user/release-keys"

[templates."sony_j8210"]
manufacturer = "Sony"
brand = "Sony"
model = "J8210"
device = "Bahamut"
product = "Bahamut"
name = "Bahamut"
marketname = "Xperia 5"
fingerprint = "Sony/Bahamut/Bahamut:15/AP3A.241005.015.A1/Bahamut.241005.001:user/release-keys"

[templates."sony_j8270"]
manufacturer = "Sony"
brand = "Sony"
model = "J8270"
device = "Bahamut"
product = "Bahamut"
name = "Bahamut"
marketname = "Xperia 5 US"
fingerprint = "Sony/Bahamut/Bahamut:15/AP3A.241005.015.A1/Bahamut.241005.001:user/release-keys"

[templates."sony_j9260"]
manufacturer = "Sony"
brand = "Sony"
model = "J9260"
device = "Bahamut"
product = "Bahamut"
name = "Bahamut"
marketname = "Xperia 5 Japan"
fingerprint = "Sony/Bahamut/Bahamut:15/AP3A.241005.015.A1/Bahamut.241005.001:user/release-keys"

[templates."sony_j3273"]
manufacturer = "Sony"
brand = "Sony"
model = "J3273"
device = "Himiko"
product = "Himiko"
name = "Himiko"
marketname = "Xperia 8 Lite Japan"
fingerprint = "Sony/Himiko/Himiko:15/AP3A.241005.015.A1/Himiko.241005.001:user/release-keys"

[templates."sony_902so"]
manufacturer = "Sony"
brand = "Sony"
model = "902SO"
device = "Himiko"
product = "Himiko"
name = "Himiko"
marketname = "Xperia 8 Japan"
fingerprint = "Sony/Himiko/Himiko:15/AP3A.241005.015.A1/Himiko.241005.001:user/release-keys"

[templates."sony_i3113"]
manufacturer = "Sony"
brand = "Sony"
model = "I3113"
device = "Kirin"
product = "Kirin"
name = "Kirin"
marketname = "Xperia 10"
fingerprint = "Sony/Kirin/Kirin:15/AP3A.241005.015.A1/Kirin.241005.001:user/release-keys"

[templates."sony_i3213"]
manufacturer = "Sony"
brand = "Sony"
model = "I3213"
device = "Mermaid"
product = "Mermaid"
name = "Mermaid"
marketname = "Xperia 10 Plus"
fingerprint = "Sony/Mermaid/Mermaid:15/AP3A.241005.015.A1/Mermaid.241005.001:user/release-keys"

[templates."sony_j3173"]
manufacturer = "Sony"
brand = "Sony"
model = "J3173"
device = "Houou"
product = "Houou"
name = "Houou"
marketname = "Xperia Ace Japan"
fingerprint = "Sony/Houou/Houou:15/AP3A.241005.015.A1/Houou.241005.001:user/release-keys"

[templates."sony_xq_aq52"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-AQ52"
device = "PDX-204"
product = "PDX-204"
name = "PDX-204"
marketname = "Xperia PRO Global"
fingerprint = "Sony/PDX-204/PDX-204:15/AP3A.241005.015.A1/PDX-204.241005.001:user/release-keys"

[templates."sony_xq_aq62"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-AQ62"
device = "PDX-204"
product = "PDX-204"
name = "PDX-204"
marketname = "Xperia PRO US"
fingerprint = "Sony/PDX-204/PDX-204:15/AP3A.241005.015.A1/PDX-204.241005.001:user/release-keys"

[templates."sony_xq_at42"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-AT42"
device = "PDX-203"
product = "PDX-203"
name = "PDX-203"
marketname = "Xperia 1 II Japan"
fingerprint = "Sony/PDX-203/PDX-203:15/AP3A.241005.015.A1/PDX-203.241005.001:user/release-keys"

[templates."sony_xq_at51"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-AT51"
device = "PDX-203"
product = "PDX-203"
name = "PDX-203"
marketname = "Xperia 1 II Global"
fingerprint = "Sony/PDX-203/PDX-203:15/AP3A.241005.015.A1/PDX-203.241005.001:user/release-keys"

[templates."sony_xq_at72"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-AT72"
device = "PDX-203"
product = "PDX-203"
name = "PDX-203"
marketname = "Xperia 1 II China"
fingerprint = "Sony/PDX-203/PDX-203:15/AP3A.241005.015.A1/PDX-203.241005.001:user/release-keys"

[templates."sony_xq_as42"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-AS42"
device = "PDX-206"
product = "PDX-206"
name = "PDX-206"
marketname = "Xperia 5 II Japan"
fingerprint = "Sony/PDX-206/PDX-206:15/AP3A.241005.015.A1/PDX-206.241005.001:user/release-keys"

[templates."sony_xq_as52"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-AS52"
device = "PDX-206"
product = "PDX-206"
name = "PDX-206"
marketname = "Xperia 5 II Global"
fingerprint = "Sony/PDX-206/PDX-206:15/AP3A.241005.015.A1/PDX-206.241005.001:user/release-keys"

[templates."sony_xq_as62"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-AS62"
device = "PDX-206"
product = "PDX-206"
name = "PDX-206"
marketname = "Xperia 5 II US"
fingerprint = "Sony/PDX-206/PDX-206:15/AP3A.241005.015.A1/PDX-206.241005.001:user/release-keys"

[templates."sony_xq_as72"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-AS72"
device = "PDX-206"
product = "PDX-206"
name = "PDX-206"
marketname = "Xperia 5 II China"
fingerprint = "Sony/PDX-206/PDX-206:15/AP3A.241005.015.A1/PDX-206.241005.001:user/release-keys"

[templates."sony_xq_au42"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-AU42"
device = "PDX-201"
product = "PDX-201"
name = "PDX-201"
marketname = "Xperia 10 II Japan"
fingerprint = "Sony/PDX-201/PDX-201:15/AP3A.241005.015.A1/PDX-201.241005.001:user/release-keys"

[templates."sony_xq_au51"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-AU51"
device = "PDX-201"
product = "PDX-201"
name = "PDX-201"
marketname = "Xperia 10 II Global"
fingerprint = "Sony/PDX-201/PDX-201:15/AP3A.241005.015.A1/PDX-201.241005.001:user/release-keys"

[templates."sony_xq_ad51"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-AD51"
device = "PDX-202"
product = "PDX-202"
name = "PDX-202"
marketname = "Xperia L4"
fingerprint = "Sony/PDX-202/PDX-202:15/AP3A.241005.015.A1/PDX-202.241005.001:user/release-keys"

[templates."sony_xq_bc42"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-BC42"
device = "PDX-215"
product = "PDX-215"
name = "PDX-215"
marketname = "Xperia 1 III Japan"
fingerprint = "Sony/PDX-215/PDX-215:15/AP3A.241005.015.A1/PDX-215.241005.001:user/release-keys"

[templates."sony_xq_bc52"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-BC52"
device = "PDX-215"
product = "PDX-215"
name = "PDX-215"
marketname = "Xperia 1 III Global"
fingerprint = "Sony/PDX-215/PDX-215:15/AP3A.241005.015.A1/PDX-215.241005.001:user/release-keys"

[templates."sony_xq_bc62"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-BC62"
device = "PDX-215"
product = "PDX-215"
name = "PDX-215"
marketname = "Xperia 1 III US"
fingerprint = "Sony/PDX-215/PDX-215:15/AP3A.241005.015.A1/PDX-215.241005.001:user/release-keys"

[templates."sony_xq_bc72"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-BC72"
device = "PDX-215"
product = "PDX-215"
name = "PDX-215"
marketname = "Xperia 1 III Asia Pacific"
fingerprint = "Sony/PDX-215/PDX-215:15/AP3A.241005.015.A1/PDX-215.241005.001:user/release-keys"

[templates."sony_xq_bq42"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-BQ42"
device = "PDX-214"
product = "PDX-214"
name = "PDX-214"
marketname = "Xperia 5 III Japan"
fingerprint = "Sony/PDX-214/PDX-214:15/AP3A.241005.015.A1/PDX-214.241005.001:user/release-keys"

[templates."sony_xq_bq52"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-BQ52"
device = "PDX-214"
product = "PDX-214"
name = "PDX-214"
marketname = "Xperia 5 III Global"
fingerprint = "Sony/PDX-214/PDX-214:15/AP3A.241005.015.A1/PDX-214.241005.001:user/release-keys"

[templates."sony_xq_bq62"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-BQ62"
device = "PDX-214"
product = "PDX-214"
name = "PDX-214"
marketname = "Xperia 5 III US"
fingerprint = "Sony/PDX-214/PDX-214:15/AP3A.241005.015.A1/PDX-214.241005.001:user/release-keys"

[templates."sony_xq_bq72"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-BQ72"
device = "PDX-214"
product = "PDX-214"
name = "PDX-214"
marketname = "Xperia 5 III Asia Pacific"
fingerprint = "Sony/PDX-214/PDX-214:15/AP3A.241005.015.A1/PDX-214.241005.001:user/release-keys"

[templates."sony_xq_bt44"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-BT44"
device = "PDX-213"
product = "PDX-213"
name = "PDX-213"
marketname = "Xperia 10 III Japan"
fingerprint = "Sony/PDX-213/PDX-213:15/AP3A.241005.015.A1/PDX-213.241005.001:user/release-keys"

[templates."sony_xq_bt52"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-BT52"
device = "PDX-213"
product = "PDX-213"
name = "PDX-213"
marketname = "Xperia 10 III Global"
fingerprint = "Sony/PDX-213/PDX-213:15/AP3A.241005.015.A1/PDX-213.241005.001:user/release-keys"

[templates."sony_xq_be42"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-BE42"
device = "PDX-217"
product = "PDX-217"
name = "PDX-217"
marketname = "Xperia PRO-I Japan"
fingerprint = "Sony/PDX-217/PDX-217:15/AP3A.241005.015.A1/PDX-217.241005.001:user/release-keys"

[templates."sony_xq_be52"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-BE52"
device = "PDX-217"
product = "PDX-217"
name = "PDX-217"
marketname = "Xperia PRO-I Global"
fingerprint = "Sony/PDX-217/PDX-217:15/AP3A.241005.015.A1/PDX-217.241005.001:user/release-keys"

[templates."sony_xq_be62"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-BE62"
device = "PDX-217"
product = "PDX-217"
name = "PDX-217"
marketname = "Xperia PRO-I US"
fingerprint = "Sony/PDX-217/PDX-217:15/AP3A.241005.015.A1/PDX-217.241005.001:user/release-keys"

[templates."sony_xq_be72"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-BE72"
device = "PDX-217"
product = "PDX-217"
name = "PDX-217"
marketname = "Xperia PRO-I Asia Pacific"
fingerprint = "Sony/PDX-217/PDX-217:15/AP3A.241005.015.A1/PDX-217.241005.001:user/release-keys"

[templates."sony_so_41b"]
manufacturer = "Sony"
brand = "Sony"
model = "SO-41B"
device = "PDX-212"
product = "PDX-212"
name = "PDX-212"
marketname = "Xperia Ace II Japan"
fingerprint = "Sony/PDX-212/PDX-212:15/AP3A.241005.015.A1/PDX-212.241005.001:user/release-keys"

[templates."sony_xq_ct44"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-CT44"
device = "PDX-223"
product = "PDX-223"
name = "PDX-223"
marketname = "Xperia 1 IV Japan"
fingerprint = "Sony/PDX-223/PDX-223:15/AP3A.241005.015.A1/PDX-223.241005.001:user/release-keys"

[templates."sony_xq_ct54"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-CT54"
device = "PDX-223"
product = "PDX-223"
name = "PDX-223"
marketname = "Xperia 1 IV Global"
fingerprint = "Sony/PDX-223/PDX-223:15/AP3A.241005.015.A1/PDX-223.241005.001:user/release-keys"

[templates."sony_xq_ct62"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-CT62"
device = "PDX-223"
product = "PDX-223"
name = "PDX-223"
marketname = "Xperia 1 IV US"
fingerprint = "Sony/PDX-223/PDX-223:15/AP3A.241005.015.A1/PDX-223.241005.001:user/release-keys"

[templates."sony_xq_ct72"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-CT72"
device = "PDX-223"
product = "PDX-223"
name = "PDX-223"
marketname = "Xperia 1 IV Asia Pacific"
fingerprint = "Sony/PDX-223/PDX-223:15/AP3A.241005.015.A1/PDX-223.241005.001:user/release-keys"

[templates."sony_xq_cq44"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-CQ44"
device = "PDX-224"
product = "PDX-224"
name = "PDX-224"
marketname = "Xperia 5 IV Japan"
fingerprint = "Sony/PDX-224/PDX-224:15/AP3A.241005.015.A1/PDX-224.241005.001:user/release-keys"

[templates."sony_xq_cq54"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-CQ54"
device = "PDX-224"
product = "PDX-224"
name = "PDX-224"
marketname = "Xperia 5 IV Global"
fingerprint = "Sony/PDX-224/PDX-224:15/AP3A.241005.015.A1/PDX-224.241005.001:user/release-keys"

[templates."sony_xq_cq62"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-CQ62"
device = "PDX-224"
product = "PDX-224"
name = "PDX-224"
marketname = "Xperia 5 IV US"
fingerprint = "Sony/PDX-224/PDX-224:15/AP3A.241005.015.A1/PDX-224.241005.001:user/release-keys"

[templates."sony_xq_cq72"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-CQ72"
device = "PDX-224"
product = "PDX-224"
name = "PDX-224"
marketname = "Xperia 5 IV Asia Pacific"
fingerprint = "Sony/PDX-224/PDX-224:15/AP3A.241005.015.A1/PDX-224.241005.001:user/release-keys"

[templates."sony_xq_cc44"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-CC44"
device = "PDX-225"
product = "PDX-225"
name = "PDX-225"
marketname = "Xperia 10 IV Japan"
fingerprint = "Sony/PDX-225/PDX-225:15/AP3A.241005.015.A1/PDX-225.241005.001:user/release-keys"

[templates."sony_xq_cc54"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-CC54"
device = "PDX-225"
product = "PDX-225"
name = "PDX-225"
marketname = "Xperia 10 IV Global"
fingerprint = "Sony/PDX-225/PDX-225:15/AP3A.241005.015.A1/PDX-225.241005.001:user/release-keys"

[templates."sony_xq_cc72"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-CC72"
device = "PDX-225"
product = "PDX-225"
name = "PDX-225"
marketname = "Xperia 10 IV Asia Pacific"
fingerprint = "Sony/PDX-225/PDX-225:15/AP3A.241005.015.A1/PDX-225.241005.001:user/release-keys"

[templates."sony_a203so"]
manufacturer = "Sony"
brand = "Sony"
model = "A203SO"
device = "PDX-226"
product = "PDX-226"
name = "PDX-226"
marketname = "Xperia Ace III Japan"
fingerprint = "Sony/PDX-226/PDX-226:15/AP3A.241005.015.A1/PDX-226.241005.001:user/release-keys"

[templates."sony_xq_dq44"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-DQ44"
device = "PDX-234"
product = "PDX-234"
name = "PDX-234"
marketname = "Xperia 1 V Japan"
fingerprint = "Sony/PDX-234/PDX-234:15/AP3A.241005.015.A1/PDX-234.241005.001:user/release-keys"

[templates."sony_xq_dq54"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-DQ54"
device = "PDX-234"
product = "PDX-234"
name = "PDX-234"
marketname = "Xperia 1 V Global"
fingerprint = "Sony/PDX-234/PDX-234:15/AP3A.241005.015.A1/PDX-234.241005.001:user/release-keys"

[templates."sony_xq_dq62"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-DQ62"
device = "PDX-234"
product = "PDX-234"
name = "PDX-234"
marketname = "Xperia 1 V US"
fingerprint = "Sony/PDX-234/PDX-234:15/AP3A.241005.015.A1/PDX-234.241005.001:user/release-keys"

[templates."sony_xq_dq72"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-DQ72"
device = "PDX-234"
product = "PDX-234"
name = "PDX-234"
marketname = "Xperia 1 V Asia Pacific"
fingerprint = "Sony/PDX-234/PDX-234:15/AP3A.241005.015.A1/PDX-234.241005.001:user/release-keys"

[templates."sony_xq_de44"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-DE44"
device = "PDX-237"
product = "PDX-237"
name = "PDX-237"
marketname = "Xperia 5 V Japan"
fingerprint = "Sony/PDX-237/PDX-237:15/AP3A.241005.015.A1/PDX-237.241005.001:user/release-keys"

[templates."sony_xq_de54"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-DE54"
device = "PDX-237"
product = "PDX-237"
name = "PDX-237"
marketname = "Xperia 5 V Global"
fingerprint = "Sony/PDX-237/PDX-237:15/AP3A.241005.015.A1/PDX-237.241005.001:user/release-keys"

[templates."sony_xq_de72"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-DE72"
device = "PDX-237"
product = "PDX-237"
name = "PDX-237"
marketname = "Xperia 5 V Asia Pacific"
fingerprint = "Sony/PDX-237/PDX-237:15/AP3A.241005.015.A1/PDX-237.241005.001:user/release-keys"

[templates."sony_xq_dc44"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-DC44"
device = "PDX-235"
product = "PDX-235"
name = "PDX-235"
marketname = "Xperia 10 V Japan"
fingerprint = "Sony/PDX-235/PDX-235:15/AP3A.241005.015.A1/PDX-235.241005.001:user/release-keys"

[templates."sony_xq_dc54"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-DC54"
device = "PDX-235"
product = "PDX-235"
name = "PDX-235"
marketname = "Xperia 10 V Global"
fingerprint = "Sony/PDX-235/PDX-235:15/AP3A.241005.015.A1/PDX-235.241005.001:user/release-keys"

[templates."sony_xq_dc72"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-DC72"
device = "PDX-235"
product = "PDX-235"
name = "PDX-235"
marketname = "Xperia 10 V Asia Pacific"
fingerprint = "Sony/PDX-235/PDX-235:15/AP3A.241005.015.A1/PDX-235.241005.001:user/release-keys"

[templates."sony_xq_ec44"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-EC44"
device = "PDX-245"
product = "PDX-245"
name = "PDX-245"
marketname = "Xperia 1 VI Japan"
fingerprint = "Sony/PDX-245/PDX-245:15/AP3A.241005.015.A1/PDX-245.241005.001:user/release-keys"

[templates."sony_xq_ec54"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-EC54"
device = "PDX-245"
product = "PDX-245"
name = "PDX-245"
marketname = "Xperia 1 VI Global"
fingerprint = "Sony/PDX-245/PDX-245:15/AP3A.241005.015.A1/PDX-245.241005.001:user/release-keys"

[templates."sony_xq_ec72"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-EC72"
device = "PDX-245"
product = "PDX-245"
name = "PDX-245"
marketname = "Xperia 1 VI Asia Pacific"
fingerprint = "Sony/PDX-245/PDX-245:15/AP3A.241005.015.A1/PDX-245.241005.001:user/release-keys"

[templates."sony_xq_es44"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-ES44"
device = "PDX-246"
product = "PDX-246"
name = "PDX-246"
marketname = "Xperia 10 VI Japan"
fingerprint = "Sony/PDX-246/PDX-246:15/AP3A.241005.015.A1/PDX-246.241005.001:user/release-keys"

[templates."sony_xq_es54"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-ES54"
device = "PDX-246"
product = "PDX-246"
name = "PDX-246"
marketname = "Xperia 10 VI Global"
fingerprint = "Sony/PDX-246/PDX-246:15/AP3A.241005.015.A1/PDX-246.241005.001:user/release-keys"

[templates."sony_xq_es72"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-ES72"
device = "PDX-246"
product = "PDX-246"
name = "PDX-246"
marketname = "Xperia 10 VI Asia Pacific"
fingerprint = "Sony/PDX-246/PDX-246:15/AP3A.241005.015.A1/PDX-246.241005.001:user/release-keys"

[templates."sony_xq_fs44"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-FS44"
device = "PDX-256"
product = "PDX-256"
name = "PDX-256"
marketname = "Xperia 1 VII Japan"
fingerprint = "Sony/PDX-256/PDX-256:15/AP3A.241005.015.A1/PDX-256.241005.001:user/release-keys"

[templates."sony_xq_fs54"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-FS54"
device = "PDX-256"
product = "PDX-256"
name = "PDX-256"
marketname = "Xperia 1 VII Global"
fingerprint = "Sony/PDX-256/PDX-256:15/AP3A.241005.015.A1/PDX-256.241005.001:user/release-keys"

[templates."sony_xq_fs72"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-FS72"
device = "PDX-256"
product = "PDX-256"
name = "PDX-256"
marketname = "Xperia 1 VII Asia Pacific"
fingerprint = "Sony/PDX-256/PDX-256:15/AP3A.241005.015.A1/PDX-256.241005.001:user/release-keys"

[templates."sony_xq_fe44"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-FE44"
device = "PDX-257"
product = "PDX-257"
name = "PDX-257"
marketname = "Xperia 10 VII Japan"
fingerprint = "Sony/PDX-257/PDX-257:15/AP3A.241005.015.A1/PDX-257.241005.001:user/release-keys"

[templates."sony_xq_fe54"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-FE54"
device = "PDX-257"
product = "PDX-257"
name = "PDX-257"
marketname = "Xperia 10 VII Global"
fingerprint = "Sony/PDX-257/PDX-257:15/AP3A.241005.015.A1/PDX-257.241005.001:user/release-keys"

[templates."sony_xq_fe72"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-FE72"
device = "PDX-257"
product = "PDX-257"
name = "PDX-257"
marketname = "Xperia 10 VII Asia Pacific"
fingerprint = "Sony/PDX-257/PDX-257:15/AP3A.241005.015.A1/PDX-257.241005.001:user/release-keys"

[templates."sony_xq_ge44"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-GE44"
device = "PDX-267"
product = "PDX-267"
name = "PDX-267"
marketname = "Xperia 1 VIII Japan"
fingerprint = "Sony/PDX-267/PDX-267:15/AP3A.241005.015.A1/PDX-267.241005.001:user/release-keys"

[templates."sony_xq_ge54"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-GE54"
device = "PDX-267"
product = "PDX-267"
name = "PDX-267"
marketname = "Xperia 1 VIII Global"
fingerprint = "Sony/PDX-267/PDX-267:15/AP3A.241005.015.A1/PDX-267.241005.001:user/release-keys"

[templates."sony_xq_ge74"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-GE74"
device = "PDX-267"
product = "PDX-267"
name = "PDX-267"
marketname = "Xperia 1 VIII Asia Pacific"
fingerprint = "Sony/PDX-267/PDX-267:15/AP3A.241005.015.A1/PDX-267.241005.001:user/release-keys"

[templates."sony_xq_gh44"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-GH44"
device = "PDX-268"
product = "PDX-268"
name = "PDX-268"
marketname = "Xperia 10 VIII Japan"
fingerprint = "Sony/PDX-268/PDX-268:15/AP3A.241005.015.A1/PDX-268.241005.001:user/release-keys"

[templates."sony_xq_gh54"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-GH54"
device = "PDX-268"
product = "PDX-268"
name = "PDX-268"
marketname = "Xperia 10 VIII Global"
fingerprint = "Sony/PDX-268/PDX-268:15/AP3A.241005.015.A1/PDX-268.241005.001:user/release-keys"

[templates."sony_xq_gh74"]
manufacturer = "Sony"
brand = "Sony"
model = "XQ-GH74"
device = "PDX-268"
product = "PDX-268"
name = "PDX-268"
marketname = "Xperia 10 VIII Asia Pacific"
fingerprint = "Sony/PDX-268/PDX-268:15/AP3A.241005.015.A1/PDX-268.241005.001:user/release-keys"

[templates."sony_sgp712"]
manufacturer = "Sony"
brand = "Sony"
model = "SGP712"
device = "Karin"
product = "Karin"
name = "Karin"
marketname = "Xperia Z4 Tablet"
fingerprint = "Sony/Karin/Karin:15/AP3A.241005.015.A1/Karin.241005.001:user/release-keys"

[templates."sony_so_05g"]
manufacturer = "Sony"
brand = "Sony"
model = "SO-05G"
device = "Karin"
product = "Karin"
name = "Karin"
marketname = "Xperia Z4 Tablet LTE Japan"
fingerprint = "Sony/Karin/Karin:15/AP3A.241005.015.A1/Karin.241005.001:user/release-keys"

[templates."nothing_a063"]
manufacturer = "Nothing"
brand = "Nothing"
model = "A063"
device = "Spacewar"
product = "Spacewar"
name = "Spacewar"
marketname = "Nothing Phone"
fingerprint = "Nothing/Spacewar/Spacewar:15/AP3A.241005.015.A1/Spacewar.241005.001:user/release-keys"

[templates."nothing_a065"]
manufacturer = "Nothing"
brand = "Nothing"
model = "A065"
device = "Pong"
product = "Pong"
name = "Pong"
marketname = "Nothing Phone Global"
fingerprint = "Nothing/Pong/Pong:15/AP3A.241005.015.A1/Pong.241005.001:user/release-keys"

[templates."nothing_ain065"]
manufacturer = "Nothing"
brand = "Nothing"
model = "AIN065"
device = "Pong"
product = "Pong"
name = "Pong"
marketname = "Nothing Phone India"
fingerprint = "Nothing/Pong/Pong:15/AP3A.241005.015.A1/Pong.241005.001:user/release-keys"

[templates."nothing_a142p"]
manufacturer = "Nothing"
brand = "Nothing"
model = "A142P"
device = "PacmanPro"
product = "PacmanPro"
name = "PacmanPro"
marketname = "Nothing Phone Plus"
fingerprint = "Nothing/PacmanPro/PacmanPro:15/AP3A.241005.015.A1/PacmanPro.241005.001:user/release-keys"

[templates."nothing_a059p"]
manufacturer = "Nothing"
brand = "Nothing"
model = "A059P"
device = "Asteroids"
product = "Asteroids"
name = "Asteroids"
marketname = "Nothing Phone Pro"
fingerprint = "Nothing/Asteroids/Asteroids:15/AP3A.241005.015.A1/Asteroids.241005.001:user/release-keys"

[templates."nothing_a001t"]
manufacturer = "Nothing"
brand = "Nothing"
model = "A001T"
device = "Galaxian"
product = "Galaxian"
name = "Galaxian"
marketname = "Nothing Phone Lite"
fingerprint = "Nothing/Galaxian/Galaxian:15/AP3A.241005.015.A1/Galaxian.241005.001:user/release-keys"

[templates."nothing_a015"]
manufacturer = "Nothing"
brand = "Nothing"
model = "A015"
device = "Tetris"
product = "Tetris"
name = "Tetris"
marketname = "Nothing CMF Phone 1"
fingerprint = "Nothing/Tetris/Tetris:15/AP3A.241005.015.A1/Tetris.241005.001:user/release-keys"

[templates."nothing_a001"]
manufacturer = "Nothing"
brand = "Nothing"
model = "A001"
device = "Galaga"
product = "Galaga"
name = "Galaga"
marketname = "Nothing CMF Phone 2 Pro"
fingerprint = "Nothing/Galaga/Galaga:15/AP3A.241005.015.A1/Galaga.241005.001:user/release-keys"

[templates."blackshark_skr_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "SKR-A0"
device = "shark"
product = "shark"
name = "shark"
marketname = "BlackShark 游戏版"
fingerprint = "BlackShark/shark/shark:15/AP3A.241005.015.A1/shark.241005.001:user/release-keys"

[templates."blackshark_awm_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "AWM-A0"
device = "bullhead"
product = "bullhead"
name = "bullhead"
marketname = "BlackShark 游戏版 Helo"
fingerprint = "BlackShark/bullhead/bullhead:15/AP3A.241005.015.A1/bullhead.241005.001:user/release-keys"

[templates."blackshark_skw_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "SKW-A0"
device = "skywalker"
product = "skywalker"
name = "skywalker"
marketname = "BlackShark 游戏版 2"
fingerprint = "BlackShark/skywalker/skywalker:15/AP3A.241005.015.A1/skywalker.241005.001:user/release-keys"

[templates."blackshark_dlt_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "DLT-A0"
device = "darklighter"
product = "darklighter"
name = "darklighter"
marketname = "BlackShark 游戏版 2 Pro"
fingerprint = "BlackShark/darklighter/darklighter:15/AP3A.241005.015.A1/darklighter.241005.001:user/release-keys"

[templates."blackshark_shark_kle_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "SHARK KLE-A0"
device = "klein"
product = "klein"
name = "klein"
marketname = "BlackShark 腾讯黑鲨游戏手机 3"
fingerprint = "BlackShark/klein/klein:15/AP3A.241005.015.A1/klein.241005.001:user/release-keys"

[templates."blackshark_shark_kle_h0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "SHARK KLE-H0"
device = "klein"
product = "klein"
name = "klein"
marketname = "BlackShark 游戏版 3"
fingerprint = "BlackShark/klein/klein:15/AP3A.241005.015.A1/klein.241005.001:user/release-keys"

[templates."blackshark_shark_mbu_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "SHARK MBU-A0"
device = "mobius"
product = "mobius"
name = "mobius"
marketname = "BlackShark 腾讯黑鲨游戏手机 3 Pro"
fingerprint = "BlackShark/mobius/mobius:15/AP3A.241005.015.A1/mobius.241005.001:user/release-keys"

[templates."blackshark_shark_mbu_h0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "SHARK MBU-H0"
device = "mobius"
product = "mobius"
name = "mobius"
marketname = "BlackShark 游戏版 3 Pro"
fingerprint = "BlackShark/mobius/mobius:15/AP3A.241005.015.A1/mobius.241005.001:user/release-keys"

[templates."blackshark_shark_prs_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "SHARK PRS-A0"
device = "penrose"
product = "penrose"
name = "penrose"
marketname = "BlackShark 4"
fingerprint = "BlackShark/penrose/penrose:15/AP3A.241005.015.A1/penrose.241005.001:user/release-keys"

[templates."blackshark_shark_ksr_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "SHARK KSR-A0"
device = "kaiser"
product = "kaiser"
name = "kaiser"
marketname = "BlackShark 4 Pro"
fingerprint = "BlackShark/kaiser/kaiser:15/AP3A.241005.015.A1/kaiser.241005.001:user/release-keys"

[templates."blackshark_shark_par_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "SHARK PAR-A0"
device = "patriot"
product = "patriot"
name = "patriot"
marketname = "BlackShark 5"
fingerprint = "BlackShark/patriot/patriot:15/AP3A.241005.015.A1/patriot.241005.001:user/release-keys"

[templates."blackshark_shark_ktus_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "SHARK KTUS-A0"
device = "katyusha"
product = "katyusha"
name = "katyusha"
marketname = "BlackShark 5 Pro"
fingerprint = "BlackShark/katyusha/katyusha:15/AP3A.241005.015.A1/katyusha.241005.001:user/release-keys"

[templates."asus_asus_z01qd"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS_Z01QD"
device = "ZS600KL"
product = "ZS600KL"
name = "ZS600KL"
marketname = "ROG 游戏版"
fingerprint = "ASUS/ZS600KL/ZS600KL:15/AP3A.241005.015.A1/ZS600KL.241005.001:user/release-keys"

[templates."asus_asus_i001da"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS_I001DA"
device = "ZS660KL"
product = "ZS660KL"
name = "ZS660KL"
marketname = "ROG 游戏版 2"
fingerprint = "ASUS/ZS660KL/ZS660KL:15/AP3A.241005.015.A1/ZS660KL.241005.001:user/release-keys"

[templates."asus_asus_i003dd"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS_I003DD"
device = "ZS661KS"
product = "ZS661KS"
name = "ZS661KS"
marketname = "ROG 游戏版 3"
fingerprint = "ASUS/ZS661KS/ZS661KS:15/AP3A.241005.015.A1/ZS661KS.241005.001:user/release-keys"

[templates."asus_asus_i005da"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS_I005DA"
device = "ZS676KS"
product = "ZS676KS"
name = "ZS676KS"
marketname = "ASUS 腾讯 ROG 游戏版 5"
fingerprint = "ASUS/ZS676KS/ZS676KS:15/AP3A.241005.015.A1/ZS676KS.241005.001:user/release-keys"

[templates."asus_asus_i005db"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS_I005DB"
device = "ZS676KS"
product = "ZS676KS"
name = "ZS676KS"
marketname = "ASUS 腾讯 ROG 游戏版 5 Pro"
fingerprint = "ASUS/ZS676KS/ZS676KS:15/AP3A.241005.015.A1/ZS676KS.241005.001:user/release-keys"

[templates."asus_asus_ai2201_a"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS_AI2201_A"
device = "AI2201"
product = "AI2201"
name = "AI2201"
marketname = "ASUS 腾讯 ROG 游戏版 6"
fingerprint = "ASUS/AI2201/AI2201:15/AP3A.241005.015.A1/AI2201.241005.001:user/release-keys"

[templates."asus_asus_ai2201_b"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS_AI2201_B"
device = "AI2201"
product = "AI2201"
name = "AI2201"
marketname = "ASUS 腾讯 ROG 游戏版 6 Pro"
fingerprint = "ASUS/AI2201/AI2201:15/AP3A.241005.015.A1/AI2201.241005.001:user/release-keys"

[templates."asus_asus_ai2203_a"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS_AI2203_A"
device = "AI2203"
product = "AI2203"
name = "AI2203"
marketname = "ASUS 腾讯 ROG 游戏版 6 天玑版"
fingerprint = "ASUS/AI2203/AI2203:15/AP3A.241005.015.A1/AI2203.241005.001:user/release-keys"

[templates."asus_asus_ai2203_b"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS_AI2203_B"
device = "AI2203"
product = "AI2203"
name = "AI2203"
marketname = "ASUS 腾讯 ROG 游戏版 6 天玑至尊版"
fingerprint = "ASUS/AI2203/AI2203:15/AP3A.241005.015.A1/AI2203.241005.001:user/release-keys"

[templates."asus_asus_ai2205_a"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS_AI2205_A"
device = "AI2205"
product = "AI2205"
name = "AI2205"
marketname = "ASUS 腾讯 ROG 游戏版 7"
fingerprint = "ASUS/AI2205/AI2205:15/AP3A.241005.015.A1/AI2205.241005.001:user/release-keys"

[templates."asus_asus_ai2205_b"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS_AI2205_B"
device = "AI2205"
product = "AI2205"
name = "AI2205"
marketname = "ASUS 腾讯 ROG 游戏版 7 Pro"
fingerprint = "ASUS/AI2205/AI2205:15/AP3A.241005.015.A1/AI2205.241005.001:user/release-keys"

[templates."asus_asus_ai2401_a"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS_AI2401_A"
device = "AI2401"
product = "AI2401"
name = "AI2401"
marketname = "ROG 游戏版 8"
fingerprint = "ASUS/AI2401/AI2401:15/AP3A.241005.015.A1/AI2401.241005.001:user/release-keys"

[templates."asus_asusai2501a"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUSAI2501A"
device = "AI2501"
product = "AI2501"
name = "AI2501"
marketname = "ROG 游戏版 9"
fingerprint = "ASUS/AI2501/AI2501:15/AP3A.241005.015.A1/AI2501.241005.001:user/release-keys"

[templates."asus_asus_i007d"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS_I007D"
device = "ASUS_I007D"
product = "ASUS_I007D"
marketname = "ASUS Smartphone for Snapdragon Insiders"
fingerprint = "ASUS/ASUS_I007D/ASUS_I007D:15/AP3A.241005.015.A1/ASUS_I007D.241005.001:user/release-keys"

[templates."nokia_ta_1000"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1000"
device = "plate"
product = "plate"
name = "plate"
marketname = "Nokia 6"
fingerprint = "Nokia/plate/plate:15/AP3A.241005.015.A1/plate.241005.001:user/release-keys"

[templates."nokia_ta_1041"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1041"
device = "charm"
product = "charm"
name = "charm"
marketname = "Nokia 7"
fingerprint = "Nokia/charm/charm:15/AP3A.241005.015.A1/charm.241005.001:user/release-keys"

[templates."nokia_ta_1062"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1062"
device = "onyx"
product = "onyx"
name = "onyx"
marketname = "Nokia 7 Plus"
fingerprint = "Nokia/onyx/onyx:15/AP3A.241005.015.A1/onyx.241005.001:user/release-keys"

[templates."nokia_ta_1042"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1042"
device = "avenger"
product = "avenger"
name = "avenger"
marketname = "Nokia 8 Sirocco"
fingerprint = "Nokia/avenger/avenger:15/AP3A.241005.015.A1/avenger.241005.001:user/release-keys"

[templates."nokia_ta_1094"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1094"
device = "beholder"
product = "beholder"
name = "beholder"
marketname = "Nokia 9 PureView"
fingerprint = "Nokia/beholder/beholder:15/AP3A.241005.015.A1/beholder.241005.001:user/release-keys"

[templates."nokia_ta_1109"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1109"
device = "panda"
product = "panda"
name = "panda"
marketname = "Nokia X5"
fingerprint = "Nokia/panda/panda:15/AP3A.241005.015.A1/panda.241005.001:user/release-keys"

[templates."nokia_ta_1099"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1099"
device = "dragon"
product = "dragon"
name = "dragon"
marketname = "Nokia X6"
fingerprint = "Nokia/dragon/dragon:15/AP3A.241005.015.A1/dragon.241005.001:user/release-keys"

[templates."nokia_ta_1131"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1131"
device = "phoenix"
product = "phoenix"
name = "phoenix"
marketname = "Nokia X7"
fingerprint = "Nokia/phoenix/phoenix:15/AP3A.241005.015.A1/phoenix.241005.001:user/release-keys"

[templates."nokia_ta_1172"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1172"
device = "taisun"
product = "taisun"
name = "taisun"
marketname = "Nokia X71"
fingerprint = "Nokia/taisun/taisun:15/AP3A.241005.015.A1/taisun.241005.001:user/release-keys"

[templates."nokia_ta_1117"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1117"
device = "rooster"
product = "rooster"
name = "rooster"
marketname = "Nokia 3.1 Plus"
fingerprint = "Nokia/rooster/rooster:15/AP3A.241005.015.A1/rooster.241005.001:user/release-keys"

[templates."nokia_ta_1335"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1335"
device = "yondu"
product = "yondu"
name = "yondu"
marketname = "Nokia C1 Plus"
fingerprint = "Nokia/yondu/yondu:15/AP3A.241005.015.A1/yondu.241005.001:user/release-keys"

[templates."nokia_ta_1258"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1258"
device = "gamoraplus"
product = "gamoraplus"
name = "gamoraplus"
marketname = "Nokia C3"
fingerprint = "Nokia/gamoraplus/gamoraplus:15/AP3A.241005.015.A1/gamoraplus.241005.001:user/release-keys"

[templates."nokia_ta_1388"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1388"
device = "sirius"
product = "sirius"
name = "sirius"
marketname = "Nokia C20 Plus"
fingerprint = "Nokia/sirius/sirius:15/AP3A.241005.015.A1/sirius.241005.001:user/release-keys"

[templates."nokia_ta_1361"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1361"
device = "punisher"
product = "punisher"
name = "punisher"
marketname = "Nokia G50"
fingerprint = "Nokia/punisher/punisher:15/AP3A.241005.015.A1/punisher.241005.001:user/release-keys"

[templates."nokia_ta_1392"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1392"
device = "riddler"
product = "riddler"
name = "riddler"
marketname = "Nokia T20"
fingerprint = "Nokia/riddler/riddler:15/AP3A.241005.015.A1/riddler.241005.001:user/release-keys"

[templates."nokia_ta_1511"]
manufacturer = "Nokia"
brand = "Nokia"
model = "TA-1511"
device = "vision"
product = "vision"
name = "vision"
marketname = "Nokia C31"
fingerprint = "Nokia/vision/vision:15/AP3A.241005.015.A1/vision.241005.001:user/release-keys"

[templates."smartisan_sm701"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "SM701"
device = "sfo"
product = "sfo"
name = "sfo"
marketname = "Smartisan T1"
fingerprint = "Smartisan/sfo/sfo:15/AP3A.241005.015.A1/sfo.241005.001:user/release-keys"

[templates."smartisan_sm801"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "SM801"
device = "icesky"
product = "icesky"
name = "icesky"
marketname = "Smartisan T2"
fingerprint = "Smartisan/icesky/icesky:15/AP3A.241005.015.A1/icesky.241005.001:user/release-keys"

[templates."smartisan_sm901"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "SM901"
device = "surabaya"
product = "surabaya"
name = "surabaya"
marketname = "Smartisan M1"
fingerprint = "Smartisan/surabaya/surabaya:15/AP3A.241005.015.A1/surabaya.241005.001:user/release-keys"

[templates."smartisan_sm919"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "SM919"
device = "colombo"
product = "colombo"
name = "colombo"
marketname = "Smartisan M1L"
fingerprint = "Smartisan/colombo/colombo:15/AP3A.241005.015.A1/colombo.241005.001:user/release-keys"

[templates."smartisan_yq601"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "YQ601"
device = "nut"
product = "nut"
name = "nut"
marketname = "Smartisan 手机"
fingerprint = "Smartisan/nut/nut:15/AP3A.241005.015.A1/nut.241005.001:user/release-keys"

[templates."smartisan_yq603"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "YQ603"
device = "nut"
product = "nut"
name = "nut"
marketname = "Smartisan 手机 文艺青年版"
fingerprint = "Smartisan/nut/nut:15/AP3A.241005.015.A1/nut.241005.001:user/release-keys"

[templates."smartisan_od103"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "OD103"
device = "odin"
product = "odin"
name = "odin"
marketname = "Smartisan Pro"
fingerprint = "Smartisan/odin/odin:15/AP3A.241005.015.A1/odin.241005.001:user/release-keys"

[templates."smartisan_os105"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "OS105"
device = "osborn"
product = "osborn"
name = "osborn"
marketname = "Smartisan Pro 2"
fingerprint = "Smartisan/osborn/osborn:15/AP3A.241005.015.A1/osborn.241005.001:user/release-keys"

[templates."smartisan_os103"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "OS103"
device = "oxford"
product = "oxford"
name = "oxford"
marketname = "Smartisan Pro 2 特别版"
fingerprint = "Smartisan/oxford/oxford:15/AP3A.241005.015.A1/oxford.241005.001:user/release-keys"

[templates."smartisan_oc105"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "OC105"
device = "oscar"
product = "oscar"
name = "oscar"
marketname = "Smartisan 3"
fingerprint = "Smartisan/oscar/oscar:15/AP3A.241005.015.A1/oscar.241005.001:user/release-keys"

[templates."smartisan_de106"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "DE106"
device = "trident"
product = "trident"
name = "trident"
marketname = "Smartisan R1"
fingerprint = "Smartisan/trident/trident:15/AP3A.241005.015.A1/trident.241005.001:user/release-keys"

[templates."smartisan_oe106"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "OE106"
device = "ocean"
product = "ocean"
name = "ocean"
marketname = "Smartisan Pro 2S"
fingerprint = "Smartisan/ocean/ocean:15/AP3A.241005.015.A1/ocean.241005.001:user/release-keys"

[templates."smartisan_dt1901a"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "DT1901A"
device = "delta"
product = "delta"
name = "delta"
marketname = "Smartisan Pro 3"
fingerprint = "Smartisan/delta/delta:15/AP3A.241005.015.A1/delta.241005.001:user/release-keys"

[templates."smartisan_dt2002c"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "DT2002C"
device = "darwin"
product = "darwin"
name = "darwin"
marketname = "Smartisan R2"
fingerprint = "Smartisan/darwin/darwin:15/AP3A.241005.015.A1/darwin.241005.001:user/release-keys"

[templates."smartisan_dt2003a"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "DT2003A"
device = "DT2003A"
product = "DT2003A"
marketname = "Smartisan TNT go 有线版"
fingerprint = "Smartisan/DT2003A/DT2003A:15/AP3A.241005.015.A1/DT2003A.241005.001:user/release-keys"

[templates."smartisan_dt2003c"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "DT2003C"
device = "DT2003C"
product = "DT2003C"
marketname = "Smartisan TNT go 无线版"
fingerprint = "Smartisan/DT2003C/DT2003C:15/AP3A.241005.015.A1/DT2003C.241005.001:user/release-keys"

[templates."letv_letv_x600"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv X600"
device = "Letv X600"
product = "Letv X600"
marketname = "LeTV 乐 1 通用版"
fingerprint = "Letv/Letv X600/Letv X600:15/AP3A.241005.015.A1/LetvX600.241005.001:user/release-keys"

[templates."letv_letv_x608"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv X608"
device = "Letv X608"
product = "Letv X608"
marketname = "LeTV 乐 1"
fingerprint = "Letv/Letv X608/Letv X608:15/AP3A.241005.015.A1/LetvX608.241005.001:user/release-keys"

[templates."letv_letv_x500"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv X500"
device = "Letv X500"
product = "Letv X500"
marketname = "LeTV 乐 1s 通用版"
fingerprint = "Letv/Letv X500/Letv X500:15/AP3A.241005.015.A1/LetvX500.241005.001:user/release-keys"

[templates."letv_letv_x501"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv X501"
device = "Letv X501"
product = "Letv X501"
marketname = "LeTV 乐 1s 太子妃版"
fingerprint = "Letv/Letv X501/Letv X501:15/AP3A.241005.015.A1/LetvX501.241005.001:user/release-keys"

[templates."letv_letv_x508"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv X508"
device = "Letv X508"
product = "Letv X508"
marketname = "LeTV 乐 1s"
fingerprint = "Letv/Letv X508/Letv X508:15/AP3A.241005.015.A1/LetvX508.241005.001:user/release-keys"

[templates."letv_letv_x502"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv X502"
device = "Letv X502"
product = "Letv X502"
marketname = "LeTV 乐 1s 未知版本"
fingerprint = "Letv/Letv X502/Letv X502:15/AP3A.241005.015.A1/LetvX502.241005.001:user/release-keys"

[templates."letv_letv_x800"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv X800"
device = "Letv X800"
product = "Letv X800"
marketname = "LeTV 乐 1 Pro 通用版"
fingerprint = "Letv/Letv X800/Letv X800:15/AP3A.241005.015.A1/LetvX800.241005.001:user/release-keys"

[templates."letv_letv_x900"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv X900"
device = "Letv X900"
product = "Letv X900"
marketname = "LeTV 乐 Max 通用版"
fingerprint = "Letv/Letv X900/Letv X900:15/AP3A.241005.015.A1/LetvX900.241005.001:user/release-keys"

[templates."letv_letv_x906"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv X906"
device = "Letv X906"
product = "Letv X906"
marketname = "LeTV 乐 Max"
fingerprint = "Letv/Letv X906/Letv X906:15/AP3A.241005.015.A1/LetvX906.241005.001:user/release-keys"

[templates."letv_le_x620"]
manufacturer = "Letv"
brand = "Letv"
model = "LE X620"
device = "MTK"
product = "MTK"
name = "MTK"
marketname = "LeTV 乐 2"
fingerprint = "Letv/MTK/MTK:15/AP3A.241005.015.A1/MTK.241005.001:user/release-keys"

[templates."letv_le_x625"]
manufacturer = "Letv"
brand = "Letv"
model = "Le X625"
device = "Le X625"
product = "Le X625"
marketname = "LeTV 乐 2 Pro"
fingerprint = "Letv/Le X625/Le X625:15/AP3A.241005.015.A1/LeX625.241005.001:user/release-keys"

[templates."letv_le_x520"]
manufacturer = "Letv"
brand = "Letv"
model = "Le X520"
device = "Le X520"
product = "Le X520"
marketname = "LeTV Le X525: 乐 2"
fingerprint = "Letv/Le X520/Le X520:15/AP3A.241005.015.A1/LeX520.241005.001:user/release-keys"

[templates."letv_le_x529"]
manufacturer = "Letv"
brand = "Letv"
model = "Le X529"
device = "Le X529"
product = "Le X529"
marketname = "LeTV 乐 2 未知版本"
fingerprint = "Letv/Le X529/Le X529:15/AP3A.241005.015.A1/LeX529.241005.001:user/release-keys"

[templates."letv_le_x820"]
manufacturer = "Letv"
brand = "Letv"
model = "Le X820"
device = "Le X820"
product = "Le X820"
marketname = "LeTV 乐 Max 2"
fingerprint = "Letv/Le X820/Le X820:15/AP3A.241005.015.A1/LeX820.241005.001:user/release-keys"

[templates."letv_letv_x910"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv X910"
device = "Letv X910"
product = "Letv X910"
marketname = "LeTV 乐 Max Pro"
fingerprint = "Letv/Letv X910/Letv X910:15/AP3A.241005.015.A1/LetvX910.241005.001:user/release-keys"

[templates."letv_lex622"]
manufacturer = "Letv"
brand = "Letv"
model = "LEX622"
device = "LEX622"
product = "LEX622"
marketname = "LeTV 乐 S3"
fingerprint = "Letv/LEX622/LEX622:15/AP3A.241005.015.A1/LEX622.241005.001:user/release-keys"

[templates."letv_lex623"]
manufacturer = "Letv"
brand = "Letv"
model = "LEX623"
device = "LEX623"
product = "LEX623"
marketname = "LeTV 乐 S3 未知版本"
fingerprint = "Letv/LEX623/LEX623:15/AP3A.241005.015.A1/LEX623.241005.001:user/release-keys"

[templates."letv_lex720"]
manufacturer = "Letv"
brand = "Letv"
model = "LEX720"
device = "LEX720"
product = "LEX720"
marketname = "LeTV 乐 Pro 3"
fingerprint = "Letv/LEX720/LEX720:15/AP3A.241005.015.A1/LEX720.241005.001:user/release-keys"

[templates."letv_lex722"]
manufacturer = "Letv"
brand = "Letv"
model = "LEX722"
device = "LEX722"
product = "LEX722"
marketname = "LeTV 乐 Pro 3 精英版"
fingerprint = "Letv/LEX722/LEX722:15/AP3A.241005.015.A1/LEX722.241005.001:user/release-keys"

[templates."letv_lex726"]
manufacturer = "Letv"
brand = "Letv"
model = "LEX726"
device = "LEX726"
product = "LEX726"
marketname = "LeTV 乐 Pro 3 未知版本"
fingerprint = "Letv/LEX726/LEX726:15/AP3A.241005.015.A1/LEX726.241005.001:user/release-keys"

[templates."letv_lex651"]
manufacturer = "Letv"
brand = "Letv"
model = "LEX651"
device = "LEX651"
product = "LEX651"
marketname = "LeTV 乐 Pro 3 双摄 AI 版"
fingerprint = "Letv/LEX651/LEX651:15/AP3A.241005.015.A1/LEX651.241005.001:user/release-keys"

[templates."letv_lex650"]
manufacturer = "Letv"
brand = "Letv"
model = "LEX650"
device = "LEX650"
product = "LEX650"
marketname = "LeTV 乐 Pro 3 双摄 AI 版 生态版"
fingerprint = "Letv/LEX650/LEX650:15/AP3A.241005.015.A1/LEX650.241005.001:user/release-keys"

[templates."letv_lex652"]
manufacturer = "Letv"
brand = "Letv"
model = "LEX652"
device = "LEX652"
product = "LEX652"
marketname = "LeTV 乐 Pro 3 双摄 AI 版 未知版本"
fingerprint = "Letv/LEX652/LEX652:15/AP3A.241005.015.A1/LEX652.241005.001:user/release-keys"

[templates."letv_lex850"]
manufacturer = "Letv"
brand = "Letv"
model = "LEX850"
device = "LEX850"
product = "LEX850"
marketname = "LeTV 未知机型"
fingerprint = "Letv/LEX850/LEX850:15/AP3A.241005.015.A1/LEX850.241005.001:user/release-keys"

[templates."letv_l5"]
manufacturer = "Letv"
brand = "Letv"
model = "L5"
device = "L5"
product = "L5"
marketname = "Letv S1 5G"
fingerprint = "Letv/L5/L5:15/AP3A.241005.015.A1/L5.241005.001:user/release-keys"

[templates."letv_letv_l6"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv L6"
device = "Letv L6"
product = "Letv L6"
marketname = "Letv Y1 Pro"
fingerprint = "Letv/Letv L6/Letv L6:15/AP3A.241005.015.A1/LetvL6.241005.001:user/release-keys"

[templates."letv_letv_l6b"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv L6B"
device = "Letv L6B"
product = "Letv L6B"
marketname = "Letv Y1 Pro+"
fingerprint = "Letv/Letv L6B/Letv L6B:15/AP3A.241005.015.A1/LetvL6B.241005.001:user/release-keys"

[templates."letv_letv_l7"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv L7"
device = "Letv L7"
product = "Letv L7"
marketname = "Letv Y2 Pro"
fingerprint = "Letv/Letv L7/Letv L7:15/AP3A.241005.015.A1/LetvL7.241005.001:user/release-keys"

[templates."letv_letv_l8"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv L8"
device = "Letv L8"
product = "Letv L8"
marketname = "Letv S1 Pro 5G"
fingerprint = "Letv/Letv L8/Letv L8:15/AP3A.241005.015.A1/LetvL8.241005.001:user/release-keys"

[templates."letv_letv_l9"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv L9"
device = "Letv L9"
product = "Letv L9"
marketname = "Letv S3 Pro"
fingerprint = "Letv/Letv L9/Letv L9:15/AP3A.241005.015.A1/LetvL9.241005.001:user/release-keys"

[templates."coolpad_8297"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "8297"
device = "8297"
product = "8297"
marketname = "Coolpad 大神 F1"
fingerprint = "Coolpad/8297/8297:15/AP3A.241005.015.A1/8297.241005.001:user/release-keys"

[templates."coolpad_8297d"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "8297D"
device = "8297D"
product = "8297D"
marketname = "Coolpad 大神 F1 青春版"
fingerprint = "Coolpad/8297D/8297D:15/AP3A.241005.015.A1/8297D.241005.001:user/release-keys"

[templates."coolpad_8297_w01"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "8297-W01"
device = "8297-W01"
product = "8297-W01"
marketname = "Coolpad 大神 F1 Plus"
fingerprint = "Coolpad/8297-W01/8297-W01:15/AP3A.241005.015.A1/8297-W01.241005.001:user/release-keys"

[templates."coolpad_8297_t01"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "8297-T01"
device = "8297-T01"
product = "8297-T01"
marketname = "Coolpad 大神 F1 Plus 移动 4G 版 & 酷派大神 F1 极速版"
fingerprint = "Coolpad/8297-T01/8297-T01:15/AP3A.241005.015.A1/8297-T01.241005.001:user/release-keys"

[templates."coolpad_8675_hd"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "8675-HD"
device = "8675-HD"
product = "8675-HD"
marketname = "Coolpad 大神 F2"
fingerprint = "Coolpad/8675-HD/8675-HD:15/AP3A.241005.015.A1/8675-HD.241005.001:user/release-keys"

[templates."coolpad_8675_f01"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "8675-F01"
device = "8675-F01"
product = "8675-F01"
marketname = "Coolpad 大神 F2 全高清"
fingerprint = "Coolpad/8675-F01/8675-F01:15/AP3A.241005.015.A1/8675-F01.241005.001:user/release-keys"

[templates."coolpad_8690"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "8690"
device = "8690"
product = "8690"
marketname = "Coolpad 大神 X7 双网通版"
fingerprint = "Coolpad/8690/8690:15/AP3A.241005.015.A1/8690.241005.001:user/release-keys"

[templates."coolpad_8690_t00"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "8690-T00"
device = "8690-T00"
product = "8690-T00"
marketname = "Coolpad 大神 X7"
fingerprint = "Coolpad/8690-T00/8690-T00:15/AP3A.241005.015.A1/8690-T00.241005.001:user/release-keys"

[templates."coolpad_8670"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "8670"
device = "8670"
product = "8670"
marketname = "Coolpad 大神 Note"
fingerprint = "Coolpad/8670/8670:15/AP3A.241005.015.A1/8670.241005.001:user/release-keys"

[templates."coolpad_c105"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "C105"
device = "C105"
product = "C105"
marketname = "Coolpad COOL Changer S1"
fingerprint = "Coolpad/C105/C105:15/AP3A.241005.015.A1/C105.241005.001:user/release-keys"

[templates."coolpad_c106"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "C106"
device = "C106"
product = "C106"
marketname = "Coolpad C106-7 C106-8 C106-9: 酷派 COOL 1 dual"
fingerprint = "Coolpad/C106/C106:15/AP3A.241005.015.A1/C106.241005.001:user/release-keys"

[templates."coolpad_c107"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "C107"
device = "C107"
product = "C107"
marketname = "Coolpad COOL 1C"
fingerprint = "Coolpad/C107/C107:15/AP3A.241005.015.A1/C107.241005.001:user/release-keys"

[templates."coolpad_pol_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "POL-A0"
device = "POL-A0"
product = "POL-A0"
marketname = "Coolpad COOL M7"
fingerprint = "Coolpad/POL-A0/POL-A0:15/AP3A.241005.015.A1/POL-A0.241005.001:user/release-keys"

[templates."coolpad_vcr_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "VCR-A0"
device = "VCR-A0"
product = "VCR-A0"
marketname = "Coolpad 酷玩 6"
fingerprint = "Coolpad/VCR-A0/VCR-A0:15/AP3A.241005.015.A1/VCR-A0.241005.001:user/release-keys"

[templates."coolpad_gra_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "GRA-A0"
device = "GRA-A0"
product = "GRA-A0"
marketname = "Coolpad 酷玩 6C"
fingerprint = "Coolpad/GRA-A0/GRA-A0:15/AP3A.241005.015.A1/GRA-A0.241005.001:user/release-keys"

[templates."coolpad_1871_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "1871-A0"
device = "1871-A0"
product = "1871-A0"
marketname = "Coolpad COOL 2"
fingerprint = "Coolpad/1871-A0/1871-A0:15/AP3A.241005.015.A1/1871-A0.241005.001:user/release-keys"

[templates."coolpad_mts_t0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "MTS-T0"
device = "MTS-T0"
product = "MTS-T0"
marketname = "Coolpad 锋尚 N2M"
fingerprint = "Coolpad/MTS-T0/MTS-T0:15/AP3A.241005.015.A1/MTS-T0.241005.001:user/release-keys"

[templates."coolpad_art_t0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "ART-T0"
device = "ART-T0"
product = "ART-T0"
marketname = "Coolpad 锋尚 N2D"
fingerprint = "Coolpad/ART-T0/ART-T0:15/AP3A.241005.015.A1/ART-T0.241005.001:user/release-keys"

[templates."coolpad_1802_t0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "1802-T0"
device = "1802-T0"
product = "1802-T0"
marketname = "Coolpad 锋尚 K2"
fingerprint = "Coolpad/1802-T0/1802-T0:15/AP3A.241005.015.A1/1802-T0.241005.001:user/release-keys"

[templates."coolpad_1812_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "1812-A0"
device = "1812-A0"
product = "1812-A0"
marketname = "Coolpad 锋尚 K2 Max"
fingerprint = "Coolpad/1812-A0/1812-A0:15/AP3A.241005.015.A1/1812-A0.241005.001:user/release-keys"

[templates."coolpad_1841_c0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "1841-C0"
device = "1841-C0"
product = "1841-C0"
marketname = "Coolpad 锋尚 N3"
fingerprint = "Coolpad/1841-C0/1841-C0:15/AP3A.241005.015.A1/1841-C0.241005.001:user/release-keys"

[templates."coolpad_1801_t0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "1801-T0"
device = "1801-T0"
product = "1801-T0"
marketname = "Coolpad 锋尚 N3M"
fingerprint = "Coolpad/1801-T0/1801-T0:15/AP3A.241005.015.A1/1801-T0.241005.001:user/release-keys"

[templates."coolpad_1822_c0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "1822-C0"
device = "1822-C0"
product = "1822-C0"
marketname = "Coolpad 锋尚 N3C"
fingerprint = "Coolpad/1822-C0/1822-C0:15/AP3A.241005.015.A1/1822-C0.241005.001:user/release-keys"

[templates."coolpad_1821_t0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "1821-T0"
device = "1821-T0"
product = "1821-T0"
marketname = "Coolpad 锋尚 N3D"
fingerprint = "Coolpad/1821-T0/1821-T0:15/AP3A.241005.015.A1/1821-T0.241005.001:user/release-keys"

[templates."coolpad_1872_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "1872-A0"
device = "1872-A0"
product = "1872-A0"
marketname = "Coolpad 酷玩 7"
fingerprint = "Coolpad/1872-A0/1872-A0:15/AP3A.241005.015.A1/1872-A0.241005.001:user/release-keys"

[templates."coolpad_1831_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "1831-A0"
device = "1831-A0"
product = "1831-A0"
marketname = "Coolpad 酷玩 7C"
fingerprint = "Coolpad/1831-A0/1831-A0:15/AP3A.241005.015.A1/1831-A0.241005.001:user/release-keys"

[templates."coolpad_1873_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "1873-A0"
device = "1873-A0"
product = "1873-A0"
marketname = "Coolpad 酷玩 8"
fingerprint = "Coolpad/1873-A0/1873-A0:15/AP3A.241005.015.A1/1873-A0.241005.001:user/release-keys"

[templates."coolpad_1832_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "1832-A0"
device = "1832-A0"
product = "1832-A0"
marketname = "Coolpad 酷玩 8 Lite"
fingerprint = "Coolpad/1832-A0/1832-A0:15/AP3A.241005.015.A1/1832-A0.241005.001:user/release-keys"

[templates."coolpad_orl_c0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "ORL-C0"
device = "ORL-C0"
product = "ORL-C0"
marketname = "Coolpad COOL 9"
fingerprint = "Coolpad/ORL-C0/ORL-C0:15/AP3A.241005.015.A1/ORL-C0.241005.001:user/release-keys"

[templates."coolpad_orl_t0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "ORL-T0"
device = "ORL-T0"
product = "ORL-T0"
marketname = "Coolpad COOL 9A"
fingerprint = "Coolpad/ORL-T0/ORL-T0:15/AP3A.241005.015.A1/ORL-T0.241005.001:user/release-keys"

[templates."coolpad_sac_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "SAC-A0"
device = "SAC-A0"
product = "SAC-A0"
marketname = "Coolpad 26"
fingerprint = "Coolpad/SAC-A0/SAC-A0:15/AP3A.241005.015.A1/SAC-A0.241005.001:user/release-keys"

[templates."coolpad_cha_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CHA-A0"
device = "CHA-A0"
product = "CHA-A0"
marketname = "Coolpad 酷玩 10"
fingerprint = "Coolpad/CHA-A0/CHA-A0:15/AP3A.241005.015.A1/CHA-A0.241005.001:user/release-keys"

[templates."coolpad_sea_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "SEA-A0"
device = "SEA-A0"
product = "SEA-A0"
marketname = "Coolpad COOL 10"
fingerprint = "Coolpad/SEA-A0/SEA-A0:15/AP3A.241005.015.A1/SEA-A0.241005.001:user/release-keys"

[templates."coolpad_det_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "DET-A0"
device = "DET-A0"
product = "DET-A0"
marketname = "Coolpad COOL 10C"
fingerprint = "Coolpad/DET-A0/DET-A0:15/AP3A.241005.015.A1/DET-A0.241005.001:user/release-keys"

[templates."coolpad_bos_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "BOS-A0"
device = "BOS-A0"
product = "BOS-A0"
marketname = "Coolpad COOL 10 青春版"
fingerprint = "Coolpad/BOS-A0/BOS-A0:15/AP3A.241005.015.A1/BOS-A0.241005.001:user/release-keys"

[templates."coolpad_hou_5ga"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "HOU-5GA"
device = "HOU-5GA"
product = "HOU-5GA"
marketname = "Coolpad X10 5G"
fingerprint = "Coolpad/HOU-5GA/HOU-5GA:15/AP3A.241005.015.A1/HOU-5GA.241005.001:user/release-keys"

[templates."coolpad_pho_5gt"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "PHO-5GT"
device = "PHO-5GT"
product = "PHO-5GT"
marketname = "Coolpad 锋尚 A11 5G"
fingerprint = "Coolpad/PHO-5GT/PHO-5GT:15/AP3A.241005.015.A1/PHO-5GT.241005.001:user/release-keys"

[templates."coolpad_cp03"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP03"
device = "CP03"
product = "CP03"
marketname = "Coolpad COOL 20"
fingerprint = "Coolpad/CP03/CP03:15/AP3A.241005.015.A1/CP03.241005.001:user/release-keys"

[templates."coolpad_cp05"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP05"
device = "CP05"
product = "CP05"
marketname = "Coolpad 大观 40 Pro 5G"
fingerprint = "Coolpad/CP05/CP05:15/AP3A.241005.015.A1/CP05.241005.001:user/release-keys"

[templates."coolpad_cp07"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP07"
device = "CP07"
product = "CP07"
marketname = "Coolpad COOL 20s 5G"
fingerprint = "Coolpad/CP07/CP07:15/AP3A.241005.015.A1/CP07.241005.001:user/release-keys"

[templates."coolpad_cp13"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP13"
device = "CP13"
product = "CP13"
marketname = "Coolpad COOL 30"
fingerprint = "Coolpad/CP13/CP13:15/AP3A.241005.015.A1/CP13.241005.001:user/release-keys"

[templates."coolpad_cp15"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP15"
device = "CP15"
product = "CP15"
marketname = "Coolpad COOL 30 Pro 5G"
fingerprint = "Coolpad/CP15/CP15:15/AP3A.241005.015.A1/CP15.241005.001:user/release-keys"

[templates."coolpad_cpdm1y"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CPDM1Y"
device = "CPDM1Y"
product = "CPDM1Y"
marketname = "Coolpad COOL 50"
fingerprint = "Coolpad/CPDM1Y/CPDM1Y:15/AP3A.241005.015.A1/CPDM1Y.241005.001:user/release-keys"

[templates."coolpad_cp3nv2"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP3NV2"
device = "CP3NV2"
product = "CP3NV2"
marketname = "Coolpad COOL 60 5G"
fingerprint = "Coolpad/CP3NV2/CP3NV2:15/AP3A.241005.015.A1/CP3NV2.241005.001:user/release-keys"

[templates."coolpad_cp16t"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP16t"
device = "CP16t"
product = "CP16t"
marketname = "Coolpad 大观 40s 5G"
fingerprint = "Coolpad/CP16t/CP16t:15/AP3A.241005.015.A1/CP16t.241005.001:user/release-keys"

[templates."coolpad_cp17"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP17"
device = "CP17"
product = "CP17"
marketname = "Coolpad 大观 50s 5G"
fingerprint = "Coolpad/CP17/CP17:15/AP3A.241005.015.A1/CP17.241005.001:user/release-keys"

[templates."coolpad_cp27"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP27"
device = "CP27"
product = "CP27"
marketname = "Coolpad 大观 Y60 5G"
fingerprint = "Coolpad/CP27/CP27:15/AP3A.241005.015.A1/CP27.241005.001:user/release-keys"

[templates."coolpad_cp3at2"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP3AT2"
device = "CP3AT2"
product = "CP3AT2"
marketname = "Coolpad 大观 Y60 Lite 5G"
fingerprint = "Coolpad/CP3AT2/CP3AT2:15/AP3A.241005.015.A1/CP3AT2.241005.001:user/release-keys"

[templates."coolpad_cp3ct1"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP3CT1"
device = "CP3CT1"
product = "CP3CT1"
marketname = "Coolpad 大观 Y60s 5G"
fingerprint = "Coolpad/CP3CT1/CP3CT1:15/AP3A.241005.015.A1/CP3CT1.241005.001:user/release-keys"

[templates."coolpad_cp3at5"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP3AT5"
device = "CP3AT5"
product = "CP3AT5"
marketname = "Coolpad 大观 C60 5G"
fingerprint = "Coolpad/CP3AT5/CP3AT5:15/AP3A.241005.015.A1/CP3AT5.241005.001:user/release-keys"

[templates."coolpad_cp3nv1"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP3NV1"
device = "CP3NV1"
product = "CP3NV1"
marketname = "Coolpad 大观 3 5G"
fingerprint = "Coolpad/CP3NV1/CP3NV1:15/AP3A.241005.015.A1/CP3NV1.241005.001:user/release-keys"

[templates."coolpad_cpday3"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CPDAY3"
device = "CPDAY3"
product = "CPDAY3"
marketname = "Coolpad 锋尚 60 Lite"
fingerprint = "Coolpad/CPDAY3/CPDAY3:15/AP3A.241005.015.A1/CPDAY3.241005.001:user/release-keys"

[templates."coolpad_cp2fm1"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP2FM1"
device = "CP2FM1"
product = "CP2FM1"
marketname = "Coolpad Y70 Lite 5G"
fingerprint = "Coolpad/CP2FM1/CP2FM1:15/AP3A.241005.015.A1/CP2FM1.241005.001:user/release-keys"

[templates."coolpad_cp23nv3"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP23NV3"
device = "CP23NV3"
product = "CP23NV3"
marketname = "Coolpad 金世纪 Y60 5G"
fingerprint = "Coolpad/CP23NV3/CP23NV3:15/AP3A.241005.015.A1/CP23NV3.241005.001:user/release-keys"

[templates."coolpad_cp2fm2"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CP2FM2"
device = "CP2FM2"
product = "CP2FM2"
marketname = "Coolpad Y77 5G"
fingerprint = "Coolpad/CP2FM2/CP2FM2:15/AP3A.241005.015.A1/CP2FM2.241005.001:user/release-keys"

[templates."coolpad_cpday6"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "CPDAY6"
device = "CPDAY6"
product = "CPDAY6"
marketname = "Coolpad 锋尚 60 Pro"
fingerprint = "Coolpad/CPDAY6/CPDAY6:15/AP3A.241005.015.A1/CPDAY6.241005.001:user/release-keys"

[templates."oneplus_pad"]
manufacturer = "OPPO"
brand = "OnePlus"
model = "PAD"
device = "aries-o"
product = "aries-o"
name = "aries-o"
marketname = "OnePlus Pad"
fingerprint = "OPPO/aries-o/aries-o:15/AP3A.241005.015.A1/aries-o.241005.001:user/release-keys"
characteristics = "tablet"


[templates."oneplus_pad_2"]
manufacturer = "OPPO"
brand = "OnePlus"
model = "PAD-2"
device = "rainbow"
product = "rainbow"
name = "rainbow"
marketname = "OnePlus Pad 2"
fingerprint = "OPPO/rainbow/rainbow:15/AP3A.241005.015.A1/rainbow.241005.001:user/release-keys"
characteristics = "tablet"


[templates."oneplus_pad_2_pro"]
manufacturer = "OPPO"
brand = "OnePlus"
model = "PAD-2-PRO"
device = "erhai-o"
product = "erhai-o"
name = "erhai-o"
marketname = "OnePlus Pad 2 Pro"
fingerprint = "OPPO/erhai-o/erhai-o:15/AP3A.241005.015.A1/erhai-o.241005.001:user/release-keys"
characteristics = "tablet"


[templates."oneplus_pad_3"]
manufacturer = "OPPO"
brand = "OnePlus"
model = "PAD-3"
device = "OPD2503"
product = "OPD2503"
marketname = "OnePlus Pad 3"
fingerprint = "OPPO/OPD2503/OPD2503:15/AP3A.241005.015.A1/OPD2503.241005.001:user/release-keys"
characteristics = "tablet"


[templates."oneplus_pad_3_pro"]
manufacturer = "OPPO"
brand = "OnePlus"
model = "PAD-3-PRO"
device = "iceland-o"
product = "iceland-o"
name = "iceland-o"
marketname = "OnePlus Pad 3 Pro"
fingerprint = "OPPO/iceland-o/iceland-o:15/AP3A.241005.015.A1/iceland-o.241005.001:user/release-keys"
characteristics = "tablet"


[templates."oneplus_pad_go"]
manufacturer = "OPPO"
brand = "OnePlus"
model = "PAD-GO"
device = "bluey-o"
product = "bluey-o"
name = "bluey-o"
marketname = "OnePlus Pad Go"
fingerprint = "OPPO/bluey-o/bluey-o:15/AP3A.241005.015.A1/bluey-o.241005.001:user/release-keys"
characteristics = "tablet"


[templates."oneplus_pad_lite"]
manufacturer = "OPPO"
brand = "OnePlus"
model = "PAD-LITE"
device = "rainbow"
product = "rainbow"
name = "rainbow"
marketname = "OnePlus Pad Lite"
fingerprint = "OPPO/rainbow/rainbow:15/AP3A.241005.015.A1/rainbow.241005.001:user/release-keys"
characteristics = "tablet"
YJ_LOCAL_TPL_EOF
  tr -d '\r' < "$_want" > "$_want.lf" 2>/dev/null && mv -f "$_want.lf" "$_want" 2>/dev/null
  if [ -s "$YJ_TL_FILE" ] && cmp -s "$_want" "$YJ_TL_FILE" 2>/dev/null; then
    rm -f "$_want" 2>/dev/null
    return 0
  fi
  mv -f "$_want" "$YJ_TL_FILE" 2>/dev/null
  chmod 0644 "$YJ_TL_FILE" 2>/dev/null
  return 0
}

yj_tl_count() {
  yj_tl_seed
  [ -f "$YJ_TL_FILE" ] || { echo 0; return; }
  grep -c '^\[templates\.' "$YJ_TL_FILE" 2>/dev/null || echo 0
}

yj_tl_status() {
  yj_tl_seed
  yj_tl_say "  内置模板：$(yj_tl_count) 个"
  yj_tl_say "  文件：$YJ_TL_FILE"
  return 0
}

yj_tl_list_all() {
  yj_tl_seed
  [ -f "$YJ_TL_FILE" ] || return 1
  yj_tl_say "  ── 内置模板 ──"
  tr -d '\r' < "$YJ_TL_FILE" 2>/dev/null | awk '
    /^\[templates\./ {
      if (name != "") printf "    %-28s %s\n", name, (mk != "" ? mk : name)
      name = $0; sub(/^\[templates\./,"",name); sub(/\]$/,"",name); gsub(/"/,"",name)
      mk = ""; next
    }
    /^\[/ { if (name != "") printf "    %-28s %s\n", name, (mk != "" ? mk : name); name=""; next }
    /^[ \t]*marketname *=/ { mk = $0; sub(/^[ \t]*marketname *= *"/,"",mk); sub(/"$/,"",mk) }
    END { if (name != "") printf "    %-28s %s\n", name, (mk != "" ? mk : name) }
  ' 2>/dev/null
  return 0
}

yj_tl_search() {
  _kw="$1"
  yj_tl_seed
  [ -n "$_kw" ] || return 1
  [ -f "$YJ_TL_FILE" ] || return 1

  tr -d '\r' < "$YJ_TL_FILE" 2>/dev/null | awk -v kw="$_kw" '
    function low(s) { return tolower(s) }
    BEGIN { K = low(kw); KL = length(K) }
    /^\[templates\./ {
      if (name != "" && hit) printf "    %-28s %s\n", name, (mk != "" ? mk : name)
      name = $0
      sub(/^\[templates\./, "", name)
      sub(/\]$/, "", name)
      gsub(/"/, "", name)
      mk = ""; hit = 0
      # 模板名匹配（不区分大小写）
      if (index(low(name), K) > 0) hit = 1
      next
    }
    /^\[/ {
      if (name != "" && hit) printf "    %-28s %s\n", name, (mk != "" ? mk : name)
      name = ""; hit = 0; next
    }
    /^[ \t]*marketname *=/ {
      mk = $0
      sub(/^[ \t]*marketname *= *"/, "", mk)
      sub(/"$/, "", mk)
      if (index(low(mk), K) > 0) hit = 1
    }
    /^[ \t]*brand *=/ {
      v = $0
      sub(/^[ \t]*brand *= *"/, "", v)
      sub(/"$/, "", v)
      # 双保险：小写比较 + 原始比较
      if (low(v) == K || v == kw) hit = 1
      if (index(low(v), K) > 0) hit = 1
    }
    /^[ \t]*model *=/ {
      v = $0
      sub(/^[ \t]*model *= *"/, "", v)
      sub(/"$/, "", v)
      if (index(low(v), K) > 0) hit = 1
    }
    END { if (name != "" && hit) printf "    %-28s %s\n", name, (mk != "" ? mk : name) }
  ' 2>/dev/null
  return 0
}

yj_tl_field() {
  _name="$1"; _f="$2"
  yj_tl_seed
  [ -f "$YJ_TL_FILE" ] || return 1
  tr -d '\r' < "$YJ_TL_FILE" 2>/dev/null | awk -v k="$_name" -v fld="$_f" '
    $0 ~ "^\\[templates\\.\"?"k"\"?\\]$" { inside=1; next }
    inside && /^\[/ { exit }
    inside && $0 ~ "^"fld" *=" {
      v = $0; sub("^"fld" *= *\"?", "", v); sub(/\"$/, "", v); print v; exit
    }
  ' 2>/dev/null
}
