#!/system/bin/sh
MODDIR=${0%/*}

. "$MODDIR/lib/common.sh"
[ -f "$MODDIR/lib/spoof_ext.sh" ] && . "$MODDIR/lib/spoof_ext.sh"
[ -f "$MODDIR/lib/tpl_ext.sh" ] && . "$MODDIR/lib/tpl_ext.sh"
[ -f "$MODDIR/lib/tpl_local.sh" ] && . "$MODDIR/lib/tpl_local.sh"

yj_init

case "${1:-status}" in
  spoof-save)   yj_spoof_save_and_apply "${2:-}" "${3:-}" "${4:-}" "${5:-}" "${6:-}" "${7:-}" "${8:-}" ;;
  spoof-apply)  yj_spoof_apply ;;
  spoof-status) yj_spoof_status ;;
  spoof-clear)  yj_spoof_clear ;;
  df-add)       yj_df_add "${2:-}" "${3:-}" "${4:-}" "${5:-}" "${6:-}" "${7:-}" "${8:-}" "${9:-}" "${10:-}" ;;
  df-del)       yj_df_del "${2:-}" ;;
  df-list)      yj_df_list ;;
  df-clear)     yj_df_clear ;;
  df-batch)
    # 批量套用模板：df-batch <模板名> <包名1> <包名2> ...
    _tpl="${2:-}"; shift 2 2>/dev/null || true
    _tpl="$_tpl"
    _pkgs=""
    for _p in "$@"; do
      case "$_p" in
        ''|--) ;;
        *) _pkgs="$_pkgs $_p" ;;
      esac
    done
    if [ -z "$_tpl" ] || [ -z "$_pkgs" ]; then
      echo "用法: sh action.sh df-batch <模板名> <包名1> <包名2> ..."
      exit 1
    fi
    _ok=0; _fail=0
    for _p in $_pkgs; do
      echo "── 套用「$_tpl」→ $_p ──"
      yj_tpl_apply "$_tpl" "$_p" && _ok=$((_ok+1)) || _fail=$((_fail+1))
    done
    echo ""
    echo "批量完成：成功 $_ok 个，失败 $_fail 个"
    ;;
  df-apps)      yj_df_list_apps ;;
  df-apps-all)  yj_df_list_apps_all ;;
  tpl-status)   yj_tpl_status ;;
  tpl-list)     yj_tpl_list "${2:-0}" ;;
  tpl-search)   yj_tpl_search "${2:-}" "${3:-0}" ;;
  tpl-apply)    yj_tpl_apply "${2:-}" "${3:-}" ;;
  tpl-local)    yj_tl_status; yj_tl_list_all ;;
  tpl-local-count) yj_tl_count ;;
  status)       yj_spoof_status ;;
  *)            yj_spoof_status ;;
esac
