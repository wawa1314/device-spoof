#!/system/bin/sh
MODDIR=${0%/*}
YJ_PREFIX="${YJ_PREFIX:-}"

[ -f "$MODDIR/lib/common.sh" ] || exit 0
. "$MODDIR/lib/common.sh" 2>/dev/null || exit 0

mkdir -p "$YJ_HOME" 2>/dev/null
yj_init

[ -f "$MODDIR/lib/spoof_ext.sh" ] && . "$MODDIR/lib/spoof_ext.sh" 2>/dev/null
yj_spoof_apply_quiet 2>/dev/null || true

exit 0
