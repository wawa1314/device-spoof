#!/system/bin/sh
MODDIR=${0%/*}
YJ_PREFIX="${YJ_PREFIX:-}"
. "$MODDIR/lib/common.sh" 2>/dev/null
yj_init

P="${YJ_PREFIX}"

echo "SPOOF_CUR_MFR=$(getprop ro.product.manufacturer 2>/dev/null)"
echo "SPOOF_CUR_BRAND=$(getprop ro.product.brand 2>/dev/null)"
echo "SPOOF_CUR_MODEL=$(getprop ro.product.model 2>/dev/null)"
echo "SPOOF_CUR_MARKET=$(getprop ro.vendor.oplus.market.name 2>/dev/null)"

_f="${P}/data/adb/device_spoof/spoof.conf"
if [ -s "$_f" ]; then
  echo "SPOOF_SAVED=$(sed -n 's/^model=//p' "$_f" 2>/dev/null | head -1)"
  echo "SPOOF_HAS=1"
else
  echo "SPOOF_SAVED="
  echo "SPOOF_HAS=0"
fi

_dfc="${P}/data/adb/knjw_spoof01/config/config.toml"
if [ -s "$_dfc" ]; then
  echo "DF_COUNT=$(grep -c '^\[\[apps\]\]' "$_dfc" 2>/dev/null || echo 0)"
else
  echo "DF_COUNT=0"
fi

_tpl="${P}/data/adb/device_spoof/templates.toml"
if [ -s "$_tpl" ]; then
  echo "TPL_COUNT=$(grep -c '^\[templates\.' "$_tpl" 2>/dev/null || echo 0)"
else
  echo "TPL_COUNT=0"
fi

_tll="${P}/data/adb/device_spoof/templates_local.toml"
if [ -s "$_tll" ]; then
  echo "TL_COUNT=$(grep -c '^\[templates\.' "$_tll" 2>/dev/null || echo 0)"
else
  echo "TL_COUNT=$(grep -c '^\[templates\.' "$MODDIR/lib/tpl_local.sh" 2>/dev/null || echo 0)"
fi

echo "MOD_VER=1.0"
