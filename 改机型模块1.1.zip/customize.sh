#!/system/bin/sh
SKIPUNZIP=1

ui_print "*******************************"
ui_print "        改机型模块 v3.6        "
ui_print "    全局改机型 + 单应用改机型    "
ui_print "*******************************"

unzip -o "$ZIPFILE" -x 'META-INF/*' -d "$MODPATH" >/dev/null 2>&1

chmod 0755 "$MODPATH"/*.sh 2>/dev/null
chmod 0644 "$MODPATH"/module.prop 2>/dev/null
chmod 0755 "$MODPATH/zygisk" 2>/dev/null
chmod 0644 "$MODPATH"/zygisk/*.so 2>/dev/null
chmod 0644 "$MODPATH"/lib/*.sh 2>/dev/null
chmod 0644 "$MODPATH"/webroot/* 2>/dev/null

if [ -f "$MODPATH/zygisk/arm64-v8a.so" ]; then
  _sz=$(wc -c < "$MODPATH/zygisk/arm64-v8a.so" 2>/dev/null | tr -d ' ')
  ui_print "- 单应用伪装引擎已就位（$_sz 字节）"
else
  ui_print "! 警告：引擎未解压，单应用改机型将不可用"
fi

_rp=""
for d in /data/adb/ksu/bin /data/adb/ap/bin /data/adb/magisk /debug_ramdisk; do
  if [ -x "$d/resetprop" ]; then _rp="$d"; break; fi
done
if [ -n "$_rp" ]; then
  ui_print "- resetprop 位于 $_rp，全局改机型可用"
else
  ui_print "! 未找到 resetprop，全局改机型不可用"
fi

mkdir -p /data/adb/knjw_spoof01/config 2>/dev/null
mkdir -p /data/adb/device_spoof 2>/dev/null
chmod 0755 /data/adb/knjw_spoof01 /data/adb/knjw_spoof01/config 2>/dev/null
chmod 0755 /data/adb/device_spoof 2>/dev/null

ui_print "- 安装完成，重启后生效"
ui_print "- 重启后到模块管理器打开 WebUI 使用"
