#!/system/bin/sh

YJ_TPL_HOME="${YJ_PREFIX}/data/adb/device_spoof"
YJ_TPL_FILE="${YJ_TPL_HOME}/templates.toml"
YJ_TPL_META="${YJ_TPL_HOME}/templates.meta"

yj_tpl_say() { command -v yj_say >/dev/null 2>&1 && yj_say "$*" || echo "$*"; }
yj_tpl_warn() { command -v yj_warn >/dev/null 2>&1 && yj_warn "$*" || echo "! $*"; }

yj_tpl_count() {
  [ -f "$YJ_TPL_FILE" ] || { echo 0; return; }
  grep -c '^\[templates\.' "$YJ_TPL_FILE" 2>/dev/null || echo 0
}

yj_tpl_status() {
  _n="$(yj_tpl_count)"
  if [ "$_n" -gt 0 ]; then
    yj_tpl_say "  内置模板库：$_n 个"
  else
    yj_tpl_say "  内置模板库，无需联网"
  fi
  return 0
}

yj_tpl_update() {
  yj_tpl_say "  本模块已内置 $(yj_tpl_count) 个真实机型模板，无需联网更新"
  return 0
}

yj_tpl_list() {
  if [ ! -f "$YJ_TPL_FILE" ]; then
    if command -v yj_tl_count >/dev/null 2>&1 && [ "$(yj_tl_count)" -gt 0 ]; then
      yj_tpl_say ""
      yj_tpl_say "  （以上是内置模板）"
      return 0
    fi
    yj_tpl_warn "  还没有模板库"
    return 1
  fi
  if command -v yj_tl_list_all >/dev/null 2>&1; then
    yj_tl_list_all
    yj_tpl_say ""
  fi
  _off="${1:-0}"
  case "$_off" in ''|*[!0-9]*) _off=0 ;; esac
  _max="${YJ_TPL_PAGE:-400}"
  _all="$(yj_tpl_count)"
  grep '^\[templates\.' "$YJ_TPL_FILE" 2>/dev/null | sed 's/^\[templates\."\{0,1\}//; s/"\{0,1\}\]$//' | tail -n +$((_off + 1)) | head -n "$_max" | while IFS= read -r _n; do
    _mk=$(awk -v k="$_n" '
      $0 ~ "^\\[templates\\.\"?"k"\"?\\]$" { f=1; next }
      f && /^\[/ { exit }
      f && /^[ \t]*marketname *=/ { gsub(/^[ \t]*marketname *= *"|"$/,""); print; exit }
    ' "$YJ_TPL_FILE" 2>/dev/null)
    [ -n "$_mk" ] && printf '    %-34s %s\n' "$_n" "$_mk" || printf '    %s\n' "$_n"
  done
  _shown=$((_all - _off))
  [ "$_shown" -gt "$_max" ] && _shown="$_max"
  [ "$_shown" -lt 0 ] && _shown=0
  yj_tpl_say ""
  yj_tpl_say "  TOTAL=$_all SHOWN=$_shown NEXT=$((_off + _shown))"
  return 0
}

# 中文品牌名 -> 模板库里的英文 brand 值
yj_tpl_alias() {
  case "$1" in
    *小米红米*|*红米小米*) echo "Xiaomi Redmi" ;;
    *小米*)            echo "Xiaomi" ;;
    *红米*)            echo "Redmi" ;;
    *华为*)            echo "HUAWEI" ;;
    *荣耀*)            echo "HONOR" ;;
    *苹果*|*iPhone*)   echo "Apple" ;;
    *一加平板*|*OnePlus*Pad*|*oneplus*pad*) echo "OnePlus" ;;
    *一加*)            echo "OnePlus" ;;
    *魅族*)            echo "meizu" ;;
    *三星*)            echo "samsung" ;;
    *谷歌*|*谷哥*|*Pixel*|*pixel*) echo "Google google" ;;
    *联想*|*乐檬*)     echo "LENOVO" ;;
    *摩托*|*moto*|*Moto*|*MOTO*) echo "motorola" ;;
    *真我*)            echo "realme" ;;
    *红魔*|*RedMagic*|*redmagic*|*努比亚红魔*) echo "redmagic" ;;
    *vivo*|*VIVO*|*维沃*) echo "vivo" ;;
    *oppo*|*OPPO*|*欧珀*) echo "OPPO" ;;
    *iqoo*|*IQOO*|*iQOO*) echo "iQOO" ;;
    *索尼*|*Sony*|*sony*|*Xperia*|*xperia*) echo "Sony" ;;
    *锤子*|*Smartisan*|*smartisan*|*坚果*) echo "Smartisan" ;;
    *黑鲨*|*BlackShark*|*blackshark*|*Blackshark*) echo "BlackShark" ;;
    *诺基亚*|*Nokia*|*nokia*) echo "Nokia" ;;
    *Nothing*|*nothing*) echo "Nothing" ;;
    *华硕*|*ASUS*|*Asus*|*asus*|*ROG*) echo "ASUS" ;;
    *中兴*|*ZTE*|*zte*) echo "ZTE" ;;
    *酷派*|*Coolpad*|*coolpad*) echo "Coolpad" ;;
    *乐视*|*Letv*|*letv*|*乐视手机*) echo "Letv" ;;
    *努比亚*|*nubia*|*Nubia*) echo "nubia" ;;
    *)                 echo "" ;;
  esac
}

yj_tpl_search() {
  _kw="$1"; _off="${2:-0}"
  if command -v yj_tl_seed >/dev/null 2>&1; then yj_tl_seed 2>/dev/null; fi
  case "$_off" in ''|*[!0-9]*) _off=0 ;; esac
  _max="${YJ_TPL_PAGE:-400}"
  [ -n "$_kw" ] || { yj_tpl_warn "  用法：搜索模板 关键词（如 小米、华为、OPPO、Pixel）"; return 1; }

  # 本地补充模板先搜（先用别名展开成英文，再搜）
  if [ "$_off" -eq 0 ] && command -v yj_tl_search >/dev/null 2>&1; then
    _alk="$(yj_tpl_alias "$_kw")"
    if [ -n "$_alk" ]; then
      for _b in $_alk; do yj_tl_search "$_b"; done
    else
      yj_tl_search "$_kw"
    fi
  fi

  if [ ! -f "$YJ_TPL_FILE" ]; then
    if command -v yj_tl_count >/dev/null 2>&1 && [ "$(yj_tl_count)" -gt 0 ]; then
      yj_tpl_say ""
      yj_tpl_say "  （以上是内置模板）"
      return 0
    fi
    yj_tpl_warn "  还没有模板库"
    return 1
  fi

  _tmpf="$YJ_TPL_HOME/_s.$$"

  # ---------- 中文别名展开 ----------
  _al="$(yj_tpl_alias "$_kw")"
  if [ -n "$_al" ]; then
    [ "$_off" -eq 0 ] && yj_tpl_say "  ── 搜索「$_kw」→ $_al ──"
    [ "$_off" -eq 0 ] && command -v yj_tl_search >/dev/null 2>&1 && {
      for _b in $_al; do yj_tl_search "$_b"; done
    }
    : > "$_tmpf"
    for _b in $_al; do
      awk -v kw="$_b" '
        /^\[templates\./ {
          if (name != "" && hit) printf "    %-34s %s\n", name, (mk != "" ? mk : name)
          name = $0; sub(/^\[templates\./,"",name); sub(/\]$/,"",name); gsub(/"/,"",name)
          mk = ""; hit = 0; next
        }
        /^\[/ { if (name != "" && hit) printf "    %-34s %s\n", name, (mk != "" ? mk : name); name=""; hit=0; next }
        /^[ \t]*brand *=/ {
          v = $0; sub(/^[ \t]*brand *= *"/,"",v); sub(/"$/,"",v)
          if (tolower(v) == tolower(kw)) hit = 1
        }
        /^[ \t]*marketname *=/ { mk = $0; sub(/^[ \t]*marketname *= *"/,"",mk); sub(/"$/,"",mk) }
        END { if (name != "" && hit) printf "    %-34s %s\n", name, (mk != "" ? mk : name) }
      ' "$YJ_TPL_FILE" 2>/dev/null >> "$_tmpf"
    done
  else
    [ "$_off" -eq 0 ] && yj_tpl_say "  ── 搜索「$_kw」──"
    # 中文关键词用 grep（设备 awk 对中文不可靠）；英文走 awk
    case "$_kw" in
      *[!a-zA-Z0-9_.\ -]*)
        grep -i "$_kw" "$YJ_TPL_FILE" 2>/dev/null \
          | grep -E '^[ \t]*marketname|^\[templates\.' > "$_tmpf"
        ;;
      *)
        awk -v kw="$_kw" '
          /^\[templates\./ {
            if (name != "" && hit) printf "    %-34s %s\n", name, mk ? mk : name
            name = $0; sub(/^\[templates\./,"",name); sub(/\]$/,"",name); gsub(/"/,"",name)
            mk = ""; hit = 0
            if (index(tolower(name), tolower(kw)) > 0) hit = 1
            next
          }
          /^\[/ { if (name != "" && hit) printf "    %-34s %s\n", name, mk ? mk : name; name=""; hit=0; next }
          /^[ \t]*marketname *=/ { mk = $0; sub(/^[ \t]*marketname *= *"/,"",mk); sub(/"$/,"",mk); if (index(tolower(mk), tolower(kw)) > 0) hit = 1 }
          /^[ \t]*brand *=/ { br = $0; sub(/^[ \t]*brand *= *"/,"",br); sub(/"$/,"",br); if (index(tolower(br), tolower(kw)) > 0) hit = 1 }
          /^[ \t]*model *=/ { md = $0; sub(/^[ \t]*model *= *"/,"",md); sub(/"$/,"",md); if (index(tolower(md), tolower(kw)) > 0) hit = 1 }
          END { if (name != "" && hit) printf "    %-34s %s\n", name, mk ? mk : name }
        ' "$YJ_TPL_FILE" 2>/dev/null > "$_tmpf"
        ;;
    esac
  fi

  # ---------- 统一分页输出 ----------
  _all=$(wc -l < "$_tmpf" 2>/dev/null | tr -d ' ')
  case "$_all" in ''|*[!0-9]*) _all=0 ;; esac
  tail -n +$((_off + 1)) "$_tmpf" 2>/dev/null | head -n "$_max"
  _shown=$((_all - _off))
  [ "$_shown" -gt "$_max" ] && _shown="$_max"
  [ "$_shown" -lt 0 ] && _shown=0
  rm -f "$_tmpf" 2>/dev/null

  yj_tpl_say ""
  yj_tpl_say "  TOTAL=$_all SHOWN=$_shown NEXT=$((_off + _shown))"
  yj_tpl_say "  用「套用模板 模板名 包名」或直接在页面点卡片"
  return 0
}

yj_tpl_field() {
  _name="$1"; _f="$2"
  [ -f "$YJ_TPL_FILE" ] || return 1
  awk -v k="$_name" -v fld="$_f" '
    $0 ~ "^\\[templates\\.\"?"k"\"?\\]$" { inside=1; next }
    inside && /^\[/ { exit }
    inside && $0 ~ "^"fld" *=" {
      v = $0; sub("^"fld" *= *\"?", "", v); sub(/\"$/, "", v); print v; exit
    }
  ' "$YJ_TPL_FILE" 2>/dev/null
}

yj_tpl_apply() {
  _name="$1"; _pkg="$2"
  [ -n "$_name" ] || { yj_tpl_warn "  用法：套用模板 <模板名> <包名>"; return 1; }
  # __fill__ = 只回显字段供前端填表，不写入配置
  if [ "$_pkg" != "__fill__" ] && [ -z "$_pkg" ]; then
    yj_tpl_warn "  还要给个包名"; return 1
  fi
  if [ "$_pkg" = "__fill__" ]; then
    _lm=""
    command -v yj_tl_field >/dev/null 2>&1 && _lm="$(yj_tl_field "$_name" marketname)"
    if [ -n "$_lm" ]; then
      yj_tpl_say "  ── 模板「$_lm」字段 ──"
      yj_tpl_say "    厂商 : $(yj_tl_field "$_name" manufacturer)"
      yj_tpl_say "    品牌 : $(yj_tl_field "$_name" brand)"
      yj_tpl_say "    机型 : $(yj_tl_field "$_name" model)"
      yj_tpl_say "    设备 : $(yj_tl_field "$_name" device)"
      yj_tpl_say "    产品 : $(yj_tl_field "$_name" product)"
      yj_tpl_say "    市场名 : $(yj_tl_field "$_name" marketname)"
      yj_tpl_say "    指纹 : $(yj_tl_field "$_name" fingerprint)"
      return 0
    fi
    yj_tpl_say "  ── 模板「$_name」字段 ──"
    yj_tpl_say "    厂商 : $(yj_tpl_field "$_name" manufacturer)"
    yj_tpl_say "    品牌 : $(yj_tpl_field "$_name" brand)"
    yj_tpl_say "    机型 : $(yj_tpl_field "$_name" model)"
    yj_tpl_say "    设备 : $(yj_tpl_field "$_name" device)"
    yj_tpl_say "    产品 : $(yj_tpl_field "$_name" product)"
    yj_tpl_say "    指纹 : $(yj_tpl_field "$_name" fingerprint)"
    return 0
  fi
  # 纯本地库：在线库 templates.toml 不存在时，直接用本地补充模板
  # 只有「在线库和本地库都没有」才报错
  if [ ! -f "$YJ_TPL_FILE" ]; then
    if ! command -v yj_tl_count >/dev/null 2>&1 || [ "$(yj_tl_count)" -le 0 ]; then
      yj_tpl_warn "  还没有模板库"
      return 1
    fi
  fi

  # 先查本地补充模板
  if command -v yj_tl_field >/dev/null 2>&1; then
    _lm="$(yj_tl_field "$_name" marketname)"
    if [ -n "$_lm" ]; then
      _mfr="$(yj_tl_field "$_name" manufacturer)"
      _br="$(yj_tl_field "$_name" brand)"
      _md="$(yj_tl_field "$_name" model)"
      _dev="$(yj_tl_field "$_name" device)"
      _pr="$(yj_tl_field "$_name" product)"
      _nm="$(yj_tl_field "$_name" name)"
      _fp="$(yj_tl_field "$_name" fingerprint)"
      yj_tpl_say "  ── 套用模板「$_lm」（本地补充）→ $_pkg ──"
      yj_tpl_say "    厂商 : $_mfr"
      yj_tpl_say "    品牌 : $_br"
      yj_tpl_say "    机型 : $_md"
      [ -n "$_dev" ] && yj_tpl_say "    设备 : $_dev"
      [ -n "$_pr" ]  && yj_tpl_say "    产品 : $_pr"
      [ -n "$_fp" ]  && yj_tpl_say "    指纹 : $(printf '%.60s' "$_fp")…"
      yj_tpl_say ""
      yj_df_add "$_pkg" "$_mfr" "$_br" "$_md" "$_dev" "$_pr" "$_fp" "$_lm" "$_nm"
      return $?
    fi
  fi

  _mfr="$(yj_tpl_field "$_name" manufacturer)"
  _br="$(yj_tpl_field "$_name" brand)"
  _md="$(yj_tpl_field "$_name" model)"
  _dev="$(yj_tpl_field "$_name" device)"
  _pr="$(yj_tpl_field "$_name" product)"
  _nm="$(yj_tpl_field "$_name" name)"
  _fp="$(yj_tpl_field "$_name" fingerprint)"
  _mk="$(yj_tpl_field "$_name" marketname)"

  if [ -z "$_md" ] && [ -z "$_mfr" ] && [ -z "$_br" ]; then
    yj_tpl_warn "  模板「$_name」不存在或没有机型字段"
    return 1
  fi

  yj_tpl_say "  ── 套用模板「${_mk:-$_name}」→ $_pkg ──"
  yj_tpl_say "    厂商 : $_mfr"
  yj_tpl_say "    品牌 : $_br"
  yj_tpl_say "    机型 : $_md"
  [ -n "$_dev" ] && yj_tpl_say "    设备 : $_dev"
  [ -n "$_pr" ]  && yj_tpl_say "    产品 : $_pr"
  [ -n "$_fp" ]  && yj_tpl_say "    指纹 : $(printf '%.60s' "$_fp")…"
  yj_tpl_say ""

  yj_df_add "$_pkg" "$_mfr" "$_br" "$_md" "$_dev" "$_pr" "$_fp" "$_mk" "$_nm"
  return $?
}
