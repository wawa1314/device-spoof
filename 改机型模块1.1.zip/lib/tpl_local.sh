#!/system/bin/sh

YJ_TL_HOME="${YJ_PREFIX}/data/adb/device_spoof"
YJ_TL_FILE="${YJ_TL_HOME}/templates_local.toml"

yj_tl_say() { command -v yj_say >/dev/null 2>&1 && yj_say "$*" || echo "$*"; }
yj_tl_warn() { command -v yj_warn >/dev/null 2>&1 && yj_warn "$*" || echo "! $*"; }

yj_tl_seed() {
  mkdir -p "$YJ_TL_HOME" 2>/dev/null
  _want="$YJ_TL_HOME/.tl_want.$$"
  cat > "$_want" <<'YJ_LOCAL_TPL_EOF'
[templates."xiaomi_mi_one_plus"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 1"
device = "mione_plus"
product = "mione_plus"
name = "mione_plus"
marketname = "Xiaomi 1"
fingerprint = ""

[templates."xiaomi_mi_one"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 1 青春版"
device = "mione_plus"
product = "mione_plus"
name = "mione_plus"
marketname = "Xiaomi 1 青春版"
fingerprint = ""

[templates."xiaomi_2012051"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 1S"
device = "mione_plus"
product = "mione_plus"
name = "mione_plus"
marketname = "Xiaomi 1S"
fingerprint = ""

[templates."xiaomi_2012052"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 1S 青春版"
device = "mione_plus"
product = "mione_plus"
name = "mione_plus"
marketname = "Xiaomi 1S 青春版"
fingerprint = ""

[templates."xiaomi_2012061"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 2"
device = "aries"
product = "aries"
name = "aries"
marketname = "Xiaomi 2"
fingerprint = ""

[templates."xiaomi_2013012"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 2S"
device = "aries"
product = "aries"
name = "aries"
marketname = "Xiaomi 2S"
fingerprint = ""

[templates."xiaomi_2012121"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 2A"
device = "taurus"
product = "taurus"
name = "taurus"
marketname = "Xiaomi 2A"
fingerprint = ""

[templates."xiaomi_2013061"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 3"
device = "pisces"
product = "pisces"
name = "pisces"
marketname = "Xiaomi 3"
fingerprint = ""

[templates."xiaomi_2014215"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 4"
device = "cancro"
product = "cancro"
name = "cancro"
marketname = "Xiaomi 4"
fingerprint = ""

[templates."xiaomi_2015561"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 4c"
device = "libra"
product = "libra"
name = "libra"
marketname = "Xiaomi 4c"
fingerprint = ""

[templates."xiaomi_2015911"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 4S"
device = "aqua"
product = "aqua"
name = "aqua"
marketname = "Xiaomi 4S"
fingerprint = ""

[templates."xiaomi_2015201"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 5"
device = "gemini"
product = "gemini"
name = "gemini"
marketname = "Xiaomi 5"
fingerprint = ""

[templates."xiaomi_2015711"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 5s"
device = "capricorn"
product = "capricorn"
name = "capricorn"
marketname = "Xiaomi 5s"
fingerprint = ""

[templates."xiaomi_2016070"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 5s Plus"
device = "natrium"
product = "natrium"
name = "natrium"
marketname = "Xiaomi 5s Plus"
fingerprint = ""

[templates."xiaomi_2016089"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 5c"
device = "meri"
product = "meri"
name = "meri"
marketname = "Xiaomi 5c"
fingerprint = ""

[templates."xiaomi_mde2"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 5X"
device = "tiffany"
product = "tiffany"
name = "tiffany"
marketname = "Xiaomi 5X"
fingerprint = ""

[templates."xiaomi_mce16"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 6"
device = "sagit"
product = "sagit"
name = "sagit"
marketname = "Xiaomi 6"
fingerprint = ""

[templates."xiaomi_m1804d2se"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 6X"
device = "wayne"
product = "wayne"
name = "wayne"
marketname = "Xiaomi 6X"
fingerprint = ""

[templates."xiaomi_m1803e1a"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 8"
device = "dipper"
product = "dipper"
name = "dipper"
marketname = "Xiaomi 8"
fingerprint = ""

[templates."xiaomi_m1807e8s"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 8 透明探索版"
device = "ursa"
product = "ursa"
name = "ursa"
marketname = "Xiaomi 8 透明探索版"
fingerprint = ""

[templates."xiaomi_m1807e8a"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 8 屏幕指纹版"
device = "equuleus"
product = "equuleus"
name = "equuleus"
marketname = "Xiaomi 8 屏幕指纹版"
fingerprint = ""

[templates."xiaomi_m1805e2a"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 8 SE"
device = "sirius"
product = "sirius"
name = "sirius"
marketname = "Xiaomi 8 SE"
fingerprint = ""

[templates."xiaomi_m1808d2te"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 8 青春版"
device = "platina"
product = "platina"
name = "platina"
marketname = "Xiaomi 8 青春版"
fingerprint = ""

[templates."xiaomi_m1902f1a"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 9"
device = "cepheus"
product = "cepheus"
name = "cepheus"
marketname = "Xiaomi 9"
fingerprint = ""

[templates."xiaomi_m1908f1xe"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 9 Pro 5G"
device = "crux"
product = "crux"
name = "crux"
marketname = "Xiaomi 9 Pro 5G"
fingerprint = ""

[templates."xiaomi_m1903f2a"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 9 SE"
device = "grus"
product = "grus"
name = "grus"
marketname = "Xiaomi 9 SE"
fingerprint = ""

[templates."xiaomi_m2001j2e"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 10"
device = "umi"
product = "umi"
name = "umi"
marketname = "Xiaomi 10"
fingerprint = ""

[templates."xiaomi_m2001j1e"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 10 Pro"
device = "cmi"
product = "cmi"
name = "cmi"
marketname = "Xiaomi 10 Pro"
fingerprint = ""

[templates."xiaomi_m2002j9e"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 10 青春版"
device = "vangogh"
product = "vangogh"
name = "vangogh"
marketname = "Xiaomi 10 青春版"
fingerprint = ""

[templates."xiaomi_m2007j1sc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 10 至尊纪念版"
device = "cas"
product = "cas"
name = "cas"
marketname = "Xiaomi 10 至尊纪念版"
fingerprint = ""

[templates."xiaomi_m2102j2sc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 10S"
device = "thyme"
product = "thyme"
name = "thyme"
marketname = "Xiaomi 10S"
fingerprint = ""

[templates."xiaomi_m2011k2c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 11"
device = "venus"
product = "venus"
name = "venus"
marketname = "Xiaomi 11"
fingerprint = ""

[templates."xiaomi_m2102k1ac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 11 Pro"
device = "star"
product = "star"
name = "star"
marketname = "Xiaomi 11 Pro"
fingerprint = ""

[templates."xiaomi_m2102k1c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 11 Ultra"
device = "star"
product = "star"
name = "star"
marketname = "Xiaomi 11 Ultra"
fingerprint = ""

[templates."xiaomi_m2101k9c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 11 青春版"
device = "renoir"
product = "renoir"
name = "renoir"
marketname = "Xiaomi 11 青春版"
fingerprint = ""

[templates."xiaomi_2107119dc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 11 青春活力版"
device = "lisa"
product = "lisa"
name = "lisa"
marketname = "Xiaomi 11 青春活力版"
fingerprint = ""

[templates."xiaomi_2201123c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 12"
device = "cupid"
product = "cupid"
name = "cupid"
marketname = "Xiaomi 12"
fingerprint = ""

[templates."xiaomi_2112123ac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 12X"
device = "psyche"
product = "psyche"
name = "psyche"
marketname = "Xiaomi 12X"
fingerprint = ""

[templates."xiaomi_2201122c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 12 Pro"
device = "zeus"
product = "zeus"
name = "zeus"
marketname = "Xiaomi 12 Pro"
fingerprint = ""

[templates."xiaomi_2207122mc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 12 Pro 天玑版"
device = "daumier"
product = "daumier"
name = "daumier"
marketname = "Xiaomi 12 Pro 天玑版"
fingerprint = ""

[templates."xiaomi_2206123sc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 12S"
device = "mayfly"
product = "mayfly"
name = "mayfly"
marketname = "Xiaomi 12S"
fingerprint = ""

[templates."xiaomi_2206122sc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 12S Pro"
device = "unicorn"
product = "unicorn"
name = "unicorn"
marketname = "Xiaomi 12S Pro"
fingerprint = ""

[templates."xiaomi_2203121c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 12S Ultra"
device = "thor"
product = "thor"
name = "thor"
marketname = "Xiaomi 12S Ultra"
fingerprint = ""

[templates."xiaomi_2211133c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 13"
device = "fuxi"
product = "fuxi"
name = "fuxi"
marketname = "Xiaomi 13"
fingerprint = ""

[templates."xiaomi_2210132c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 13 Pro"
device = "nuwa"
product = "nuwa"
name = "nuwa"
marketname = "Xiaomi 13 Pro"
fingerprint = ""

[templates."xiaomi_2304fpn6dc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 13 Ultra"
device = "ishtar"
product = "ishtar"
name = "ishtar"
marketname = "Xiaomi 13 Ultra"
fingerprint = ""

[templates."xiaomi_23127pn0cc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 14"
device = "houji"
product = "houji"
name = "houji"
marketname = "Xiaomi 14"
fingerprint = ""

[templates."xiaomi_23116pn5bc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 14 Pro"
device = "shennong"
product = "shennong"
name = "shennong"
marketname = "Xiaomi 14 Pro"
fingerprint = ""

[templates."xiaomi_2311bpn23c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 14 Pro 钛金属版"
device = "shennong"
product = "shennong"
name = "shennong"
marketname = "Xiaomi 14 Pro 钛金属版"
fingerprint = ""

[templates."xiaomi_24031pn0dc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 14 Ultra"
device = "aurora"
product = "aurora"
name = "aurora"
marketname = "Xiaomi 14 Ultra"
fingerprint = ""

[templates."xiaomi_24129pn74c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 15"
device = "dada"
product = "dada"
name = "dada"
marketname = "Xiaomi 15"
fingerprint = ""

[templates."xiaomi_2410dpn6cc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 15 Pro"
device = "haotian"
product = "haotian"
name = "haotian"
marketname = "Xiaomi 15 Pro"
fingerprint = ""

[templates."xiaomi_25019pnf3c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 15 Ultra"
device = "xuanyuan"
product = "xuanyuan"
name = "xuanyuan"
marketname = "Xiaomi 15 Ultra"
fingerprint = ""

[templates."xiaomi_25010pn30c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 15 Ultra 双卫星版"
device = "xuanyuan"
product = "xuanyuan"
name = "xuanyuan"
marketname = "Xiaomi 15 Ultra 双卫星版"
fingerprint = ""

[templates."xiaomi_25042pn24c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 15S Pro"
device = "dijun"
product = "dijun"
name = "dijun"
marketname = "Xiaomi 15S Pro"
fingerprint = ""

[templates."xiaomi_25113pn0ec"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 17"
device = "pudding"
product = "pudding"
name = "pudding"
marketname = "Xiaomi 17"
fingerprint = ""

[templates."xiaomi_25098pn5ac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 17 Pro"
device = "pandora"
product = "pandora"
name = "pandora"
marketname = "Xiaomi 17 Pro"
fingerprint = ""

[templates."xiaomi_2509fpn0bc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 17 Pro Max"
device = "popsicle"
product = "popsicle"
name = "popsicle"
marketname = "Xiaomi 17 Pro Max"
fingerprint = ""

[templates."xiaomi_2512bpndac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 17 Ultra"
device = "nezha"
product = "nezha"
name = "nezha"
marketname = "Xiaomi 17 Ultra"
fingerprint = ""

[templates."xiaomi_25128pna1c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 17 Ultra by Leica"
device = "nezha"
product = "nezha"
name = "nezha"
marketname = "Xiaomi 17 Ultra by Leica"
fingerprint = ""

[templates."xiaomi_2605epn8ec"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 17 Max"
device = "byron"
product = "byron"
name = "byron"
marketname = "Xiaomi 17 Max"
fingerprint = ""

[templates."xiaomi_m531da"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 17T"
device = "chagall"
product = "chagall"
name = "chagall"
marketname = "Xiaomi 17T"
fingerprint = ""

[templates."xiaomi_m025ec"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 17T Pro"
device = "warhol"
product = "warhol"
name = "warhol"
marketname = "Xiaomi 17T Pro"
fingerprint = ""

[templates."xiaomi_m610bb"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 18 Pro"
device = "hongkong"
product = "hongkong"
name = "hongkong"
marketname = "Xiaomi 18 Pro"
fingerprint = ""

[templates."xiaomi_m154ff"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 18 Pro Max"
device = "madrid"
product = "madrid"
name = "madrid"
marketname = "Xiaomi 18 Pro Max"
fingerprint = ""

[templates."xiaomi_2608bpx34c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 18 Fold"
device = "lhasa"
product = "lhasa"
name = "lhasa"
marketname = "Xiaomi 18 Fold"
fingerprint = ""

[templates."xiaomi_2014616"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Note 双网通版"
device = "virgo"
product = "virgo"
name = "virgo"
marketname = "Xiaomi Note 双网通版"
fingerprint = ""

[templates."xiaomi_2014619"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Note"
device = "virgo"
product = "virgo"
name = "virgo"
marketname = "Xiaomi Note"
fingerprint = ""

[templates."xiaomi_2015021"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Note 顶配版 双网通版"
device = "leo"
product = "leo"
name = "leo"
marketname = "Xiaomi Note 顶配版 双网通版"
fingerprint = ""

[templates."xiaomi_2015211"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Note 2"
device = "scorpio"
product = "scorpio"
name = "scorpio"
marketname = "Xiaomi Note 2"
fingerprint = ""

[templates."xiaomi_mce8"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Note 3"
device = "jason"
product = "jason"
name = "jason"
marketname = "Xiaomi Note 3"
fingerprint = ""

[templates."xiaomi_2016080"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi MIX"
device = "lithium"
product = "lithium"
name = "lithium"
marketname = "Xiaomi MIX"
fingerprint = ""

[templates."xiaomi_mde5"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi MIX 2 黑色陶瓷版"
device = "chiron"
product = "chiron"
name = "chiron"
marketname = "Xiaomi MIX 2 黑色陶瓷版"
fingerprint = ""

[templates."xiaomi_mde5s"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi MIX 2 全陶瓷"
device = "chiron"
product = "chiron"
name = "chiron"
marketname = "Xiaomi MIX 2 全陶瓷"
fingerprint = ""

[templates."xiaomi_m1803d5xe"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi MIX 2S"
device = "polaris"
product = "polaris"
name = "polaris"
marketname = "Xiaomi MIX 2S"
fingerprint = ""

[templates."xiaomi_m1810e5e"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi MIX 3"
device = "perseus"
product = "perseus"
name = "perseus"
marketname = "Xiaomi MIX 3"
fingerprint = ""

[templates."xiaomi_m1810e5gg"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi MIX 3 5G"
device = "andromeda"
product = "andromeda"
name = "andromeda"
marketname = "Xiaomi MIX 3 5G"
fingerprint = ""

[templates."xiaomi_2106118c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi MIX 4"
device = "odin"
product = "odin"
name = "odin"
marketname = "Xiaomi MIX 4"
fingerprint = ""

[templates."xiaomi_m2011j18c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi MIX FOLD 小米折叠屏手机"
device = "cetus"
product = "cetus"
name = "cetus"
marketname = "Xiaomi MIX FOLD 小米折叠屏手机"
fingerprint = ""

[templates."xiaomi_22061218c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi MIX Fold 2"
device = "zizhan"
product = "zizhan"
name = "zizhan"
marketname = "Xiaomi MIX Fold 2"
fingerprint = ""

[templates."xiaomi_2308cpxd0c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi MIX Fold 3"
device = "babylon"
product = "babylon"
name = "babylon"
marketname = "Xiaomi MIX Fold 3"
fingerprint = ""

[templates."xiaomi_24072px77c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi MIX Fold 4"
device = "goku"
product = "goku"
name = "goku"
marketname = "Xiaomi MIX Fold 4"
fingerprint = ""

[templates."xiaomi_2405cpx3dc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi MIX Flip"
device = "ruyi"
product = "ruyi"
name = "ruyi"
marketname = "Xiaomi MIX Flip"
fingerprint = ""

[templates."xiaomi_2505apx7bc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi MIX Flip 2"
device = "bixi"
product = "bixi"
name = "bixi"
marketname = "Xiaomi MIX Flip 2"
fingerprint = ""

[templates."xiaomi_2016001"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Max"
device = "hydrogen"
product = "hydrogen"
name = "hydrogen"
marketname = "Xiaomi Max"
fingerprint = ""

[templates."xiaomi_mde40"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Max 2"
device = "oxygen"
product = "oxygen"
name = "oxygen"
marketname = "Xiaomi Max 2"
fingerprint = ""

[templates."xiaomi_m1804e4a"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Max 3"
device = "nitrogen"
product = "nitrogen"
name = "nitrogen"
marketname = "Xiaomi Max 3"
fingerprint = ""

[templates."xiaomi_m1904f3bc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi CC9"
device = "pyxis"
product = "pyxis"
name = "pyxis"
marketname = "Xiaomi CC9"
fingerprint = ""

[templates."xiaomi_m1904f3bt"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi CC9 美图"
device = "vela"
product = "vela"
name = "vela"
marketname = "Xiaomi CC9 美图"
fingerprint = ""

[templates."xiaomi_m1906f9sc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi CC9e"
device = "laurus"
product = "laurus"
name = "laurus"
marketname = "Xiaomi CC9e"
fingerprint = ""

[templates."xiaomi_m1910f4e"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi CC9 Pro"
device = "tucana"
product = "tucana"
name = "tucana"
marketname = "Xiaomi CC9 Pro"
fingerprint = ""

[templates."xiaomi_2109119bc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Civi"
device = "zijin"
product = "zijin"
name = "zijin"
marketname = "Xiaomi Civi"
fingerprint = ""

[templates."xiaomi_2209129sc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Civi 2"
device = "ziyi"
product = "ziyi"
name = "ziyi"
marketname = "Xiaomi Civi 2"
fingerprint = ""

[templates."xiaomi_23046pnc9c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Civi 3"
device = "yuechu"
product = "yuechu"
name = "yuechu"
marketname = "Xiaomi Civi 3"
fingerprint = ""

[templates."xiaomi_24053py09c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Civi 4 Pro"
device = "chenfeng"
product = "chenfeng"
name = "chenfeng"
marketname = "Xiaomi Civi 4 Pro"
fingerprint = ""

[templates."xiaomi_25067pye3c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Civi 5 Pro"
device = "luming"
product = "luming"
name = "luming"
marketname = "Xiaomi Civi 5 Pro"
fingerprint = ""

[templates."xiaomi_m1901f9e"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Play"
device = "lotus"
product = "lotus"
name = "lotus"
marketname = "Xiaomi Play"
fingerprint = ""

[templates."xiaomi_a0101"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 平板"
device = "mocha"
product = "mocha"
name = "mocha"
marketname = "Xiaomi 平板"
fingerprint = ""

[templates."xiaomi_2015716"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 平板 2"
device = "latte"
product = "latte"
name = "latte"
marketname = "Xiaomi 平板 2"
fingerprint = ""

[templates."xiaomi_mce91"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 平板 3"
device = "cappu"
product = "cappu"
name = "cappu"
marketname = "Xiaomi 平板 3"
fingerprint = ""

[templates."xiaomi_m1806d9w"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 平板 4"
device = "clover"
product = "clover"
name = "clover"
marketname = "Xiaomi 平板 4"
fingerprint = ""

[templates."xiaomi_m1806d9pe"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 平板 4 Plus"
device = "clover"
product = "clover"
name = "clover"
marketname = "Xiaomi 平板 4 Plus"
fingerprint = ""

[templates."xiaomi_21051182c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 平板 5"
device = "nabu"
product = "nabu"
name = "nabu"
marketname = "Xiaomi 平板 5"
fingerprint = ""

[templates."xiaomi_m2105k81ac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 平板 5 Pro"
device = "elish"
product = "elish"
name = "elish"
marketname = "Xiaomi 平板 5 Pro"
fingerprint = ""

[templates."xiaomi_m2105k81c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 平板 5 Pro 5G"
device = "enuma"
product = "enuma"
name = "enuma"
marketname = "Xiaomi 平板 5 Pro 5G"
fingerprint = ""

[templates."xiaomi_22081281ac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 平板 5 Pro 12.4 英寸"
device = "dagu"
product = "dagu"
name = "dagu"
marketname = "Xiaomi 平板 5 Pro 12.4 英寸"
fingerprint = ""

[templates."xiaomi_23043rp34c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Pad 6"
device = "pipa"
product = "pipa"
name = "pipa"
marketname = "Xiaomi Pad 6"
fingerprint = ""

[templates."xiaomi_23046rp50c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Pad 6 Pro"
device = "liuqin"
product = "liuqin"
name = "liuqin"
marketname = "Xiaomi Pad 6 Pro"
fingerprint = ""

[templates."xiaomi_2307brpdcc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Pad 6 Max 14"
device = "yudi"
product = "yudi"
name = "yudi"
marketname = "Xiaomi Pad 6 Max 14"
fingerprint = ""

[templates."xiaomi_24018rpacc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Pad 6S Pro 12.4"
device = "sheng"
product = "sheng"
name = "sheng"
marketname = "Xiaomi Pad 6S Pro 12.4"
fingerprint = ""

[templates."xiaomi_2410crp4cc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Pad 7"
device = "uke"
product = "uke"
name = "uke"
marketname = "Xiaomi Pad 7"
fingerprint = ""

[templates."xiaomi_24091rpadc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Pad 7 Pro"
device = "muyu"
product = "muyu"
name = "muyu"
marketname = "Xiaomi Pad 7 Pro"
fingerprint = ""

[templates."xiaomi_25032rp42c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Pad 7 Ultra"
device = "jinghu"
product = "jinghu"
name = "jinghu"
marketname = "Xiaomi Pad 7 Ultra"
fingerprint = ""

[templates."xiaomi_25053rp5cc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Pad 7S Pro 12.5"
device = "violin"
product = "violin"
name = "violin"
marketname = "Xiaomi Pad 7S Pro 12.5"
fingerprint = ""

[templates."xiaomi_25097rp43c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Pad 8"
device = "yupei"
product = "yupei"
name = "yupei"
marketname = "Xiaomi Pad 8"
fingerprint = ""

[templates."xiaomi_25091rp04c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Pad 8 Pro"
device = "piano"
product = "piano"
name = "piano"
marketname = "Xiaomi Pad 8 Pro"
fingerprint = ""

[templates."xiaomi_m656ba"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Pad 9"
device = "yupei"
product = "yupei"
name = "yupei"
marketname = "Xiaomi Pad 9"
fingerprint = ""

[templates."xiaomi_2612crpffc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Pad 9 Pro"
device = "shuntian"
product = "shuntian"
name = "shuntian"
marketname = "Xiaomi Pad 9 Pro"
fingerprint = ""

[templates."xiaomi_m367fc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi Pad 9 Pro Max"
device = "yingtian"
product = "yingtian"
name = "yingtian"
marketname = "Xiaomi Pad 9 Pro Max"
fingerprint = ""

[templates."xiaomi_2013022"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 手机"
device = "wt93007"
product = "wt93007"
name = "wt93007"
marketname = "Redmi 手机"
fingerprint = ""

[templates."xiaomi_2013029"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 1S"
device = "armani"
product = "armani"
name = "armani"
marketname = "Redmi 1S"
fingerprint = ""

[templates."xiaomi_2014813"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 2"
device = "wt86047"
product = "wt86047"
name = "wt86047"
marketname = "Redmi 2"
fingerprint = ""

[templates."xiaomi_2014502"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 2A"
device = "LC"
product = "LC"
name = "LC"
marketname = "Redmi 2A"
fingerprint = ""

[templates."xiaomi_2014512"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 2A 增强版"
device = "LC"
product = "LC"
name = "LC"
marketname = "Redmi 2A 增强版"
fingerprint = ""

[templates."xiaomi_2015811"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 3"
device = "ido_xhdpi"
product = "ido_xhdpi"
name = "ido_xhdpi"
marketname = "Redmi 3"
fingerprint = ""

[templates."xiaomi_2015812"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 3 移动合约"
device = "ido_xhdpi"
product = "ido_xhdpi"
name = "ido_xhdpi"
marketname = "Redmi 3 移动合约"
fingerprint = ""

[templates."xiaomi_2015810"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 3 联通合约"
device = "ido_xhdpi"
product = "ido_xhdpi"
name = "ido_xhdpi"
marketname = "Redmi 3 联通合约"
fingerprint = ""

[templates."xiaomi_2016030"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 3S"
device = "land"
product = "land"
name = "land"
marketname = "Redmi 3S"
fingerprint = ""

[templates."xiaomi_2016036"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 3X"
device = "land"
product = "land"
name = "land"
marketname = "Redmi 3X"
fingerprint = ""

[templates."xiaomi_2016090"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 4"
device = "prada"
product = "prada"
name = "prada"
marketname = "Redmi 4"
fingerprint = ""

[templates."xiaomi_2016111"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 4A"
device = "rolex"
product = "rolex"
name = "rolex"
marketname = "Redmi 4A"
fingerprint = ""

[templates."xiaomi_mae136"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 4X"
device = "santoni"
product = "santoni"
name = "santoni"
marketname = "Redmi 4X"
fingerprint = ""

[templates."xiaomi_mde1"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 5"
device = "rosy"
product = "rosy"
name = "rosy"
marketname = "Redmi 5"
fingerprint = ""

[templates."xiaomi_mee7"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 5 Plus"
device = "vince"
product = "vince"
name = "vince"
marketname = "Redmi 5 Plus"
fingerprint = ""

[templates."xiaomi_mce3b"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 5A"
device = "riva"
product = "riva"
name = "riva"
marketname = "Redmi 5A"
fingerprint = ""

[templates."xiaomi_m1804c3de"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 6"
device = "cereus"
product = "cereus"
name = "cereus"
marketname = "Redmi 6"
fingerprint = ""

[templates."xiaomi_m1805d1se"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 6 Pro"
device = "sakura"
product = "sakura"
name = "sakura"
marketname = "Redmi 6 Pro"
fingerprint = ""

[templates."xiaomi_m1804c3ce"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 6A"
device = "cactus"
product = "cactus"
name = "cactus"
marketname = "Redmi 6A"
fingerprint = ""

[templates."xiaomi_m1810f6le"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 7"
device = "onclite"
product = "onclite"
name = "onclite"
marketname = "Redmi 7"
fingerprint = ""

[templates."xiaomi_m1810f6lt"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 7 运营商"
device = "onclite"
product = "onclite"
name = "onclite"
marketname = "Redmi 7 运营商"
fingerprint = ""

[templates."xiaomi_m1903c3ee"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 7A"
device = "pine"
product = "pine"
name = "pine"
marketname = "Redmi 7A"
fingerprint = ""

[templates."xiaomi_m1908c3ie"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 8"
device = "olive"
product = "olive"
name = "olive"
marketname = "Redmi 8"
fingerprint = ""

[templates."xiaomi_m1908c3ic"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 8 运营商"
device = "olive"
product = "olive"
name = "olive"
marketname = "Redmi 8 运营商"
fingerprint = ""

[templates."xiaomi_m1908c3ke"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 8A"
device = "olivelite"
product = "olivelite"
name = "olivelite"
marketname = "Redmi 8A"
fingerprint = ""

[templates."xiaomi_m2004j19c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 9"
device = "lancelot"
product = "lancelot"
name = "lancelot"
marketname = "Redmi 9"
fingerprint = ""

[templates."xiaomi_m2006c3lc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 9A"
device = "dandelion"
product = "dandelion"
name = "dandelion"
marketname = "Redmi 9A"
fingerprint = ""

[templates."xiaomi_220233l2c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 10A"
device = "dandelion_c3l2"
product = "dandelion_c3l2"
name = "dandelion_c3l2"
marketname = "Redmi 10A"
fingerprint = ""

[templates."xiaomi_23077rabdc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 12 5G"
device = "sky"
product = "sky"
name = "sky"
marketname = "Redmi 12 5G"
fingerprint = ""

[templates."xiaomi_23076ra4bc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 12R"
device = "sky"
product = "sky"
name = "sky"
marketname = "Redmi 12R"
fingerprint = ""

[templates."xiaomi_22120rn86c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 12C"
device = "earth"
product = "earth"
name = "earth"
marketname = "Redmi 12C"
fingerprint = ""

[templates."xiaomi_23124rn87c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 13C 5G"
device = "air"
product = "air"
name = "air"
marketname = "Redmi 13C 5G"
fingerprint = ""

[templates."xiaomi_2409brn2cc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 14C"
device = "lake"
product = "lake"
name = "lake"
marketname = "Redmi 14C"
fingerprint = ""

[templates."xiaomi_2411drn47c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 14R 5G"
device = "flame"
product = "flame"
name = "flame"
marketname = "Redmi 14R 5G"
fingerprint = ""

[templates."xiaomi_25082rnc1c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI 15R 5G"
device = "tornado"
product = "tornado"
name = "tornado"
marketname = "REDMI 15R 5G"
fingerprint = ""

[templates."xiaomi_2602brna4c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI 17 5G"
device = "somalia"
product = "somalia"
name = "somalia"
marketname = "REDMI 17 5G"
fingerprint = ""

[templates."xiaomi_2014018"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 联通 3G"
device = "lcsh92_wet_gb9"
product = "lcsh92_wet_gb9"
name = "lcsh92_wet_gb9"
marketname = "Redmi Note 联通 3G"
fingerprint = ""

[templates."xiaomi_2013121"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 联通 3G 增强版"
device = "lcsh92_wet_gb9"
product = "lcsh92_wet_gb9"
name = "lcsh92_wet_gb9"
marketname = "Redmi Note 联通 3G 增强版"
fingerprint = ""

[templates."xiaomi_2014017"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 移动 3G"
device = "lcsh92_wet_xm_td"
product = "lcsh92_wet_xm_td"
name = "lcsh92_wet_xm_td"
marketname = "Redmi Note 移动 3G"
fingerprint = ""

[templates."xiaomi_2013122"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 移动 3G 增强版"
device = "lcsh92_wet_xm_td"
product = "lcsh92_wet_xm_td"
name = "lcsh92_wet_xm_td"
marketname = "Redmi Note 移动 3G 增强版"
fingerprint = ""

[templates."xiaomi_2014022"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 移动 4G 增强版"
device = "dior"
product = "dior"
name = "dior"
marketname = "Redmi Note 移动 4G 增强版"
fingerprint = ""

[templates."xiaomi_2014021"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 联通 4G 增强版"
device = "dior"
product = "dior"
name = "dior"
marketname = "Redmi Note 联通 4G 增强版"
fingerprint = ""

[templates."xiaomi_2014915"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note"
device = "gucci"
product = "gucci"
name = "gucci"
marketname = "Redmi Note"
fingerprint = ""

[templates."xiaomi_2014911"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 移动 4G 双卡"
device = "gucci"
product = "gucci"
name = "gucci"
marketname = "Redmi Note 移动 4G 双卡"
fingerprint = ""

[templates."xiaomi_2014910"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 电信 4G 双卡"
device = "gucci"
product = "gucci"
name = "gucci"
marketname = "Redmi Note 电信 4G 双卡"
fingerprint = ""

[templates."xiaomi_2015052"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 2"
device = "hermes"
product = "hermes"
name = "hermes"
marketname = "Redmi Note 2"
fingerprint = ""

[templates."xiaomi_2015051"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 2 双网通版"
device = "hermes"
product = "hermes"
name = "hermes"
marketname = "Redmi Note 2 双网通版"
fingerprint = ""

[templates."xiaomi_2015712"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 2 双网通"
device = "hermes"
product = "hermes"
name = "hermes"
marketname = "Redmi Note 2 双网通"
fingerprint = ""

[templates."xiaomi_2015056"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 2 移动合约"
device = "hermes"
product = "hermes"
name = "hermes"
marketname = "Redmi Note 2 移动合约"
fingerprint = ""

[templates."xiaomi_2015617"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 3 双网通版"
device = "hennessy"
product = "hennessy"
name = "hennessy"
marketname = "Redmi Note 3 双网通版"
fingerprint = ""

[templates."xiaomi_2015611"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 3"
device = "hennessy"
product = "hennessy"
name = "hennessy"
marketname = "Redmi Note 3"
fingerprint = ""

[templates."xiaomi_2016050"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 4"
device = "nikel"
product = "nikel"
name = "nikel"
marketname = "Redmi Note 4"
fingerprint = ""

[templates."xiaomi_2016101"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 4X 高通"
device = "mido"
product = "mido"
name = "mido"
marketname = "Redmi Note 4X 高通"
fingerprint = ""

[templates."xiaomi_mbe6a5"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 4X MTK"
device = "nikel"
product = "nikel"
name = "nikel"
marketname = "Redmi Note 4X MTK"
fingerprint = ""

[templates."xiaomi_mee7s"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 5"
device = "whyred"
product = "whyred"
name = "whyred"
marketname = "Redmi Note 5"
fingerprint = ""

[templates."xiaomi_mde6"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 5A"
device = "ugglite"
product = "ugglite"
name = "ugglite"
marketname = "Redmi Note 5A"
fingerprint = ""

[templates."xiaomi_mdt6"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 5A 移动 4G+"
device = "ugglite"
product = "ugglite"
name = "ugglite"
marketname = "Redmi Note 5A 移动 4G+"
fingerprint = ""

[templates."xiaomi_m1901f7e"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 7"
device = "lavender"
product = "lavender"
name = "lavender"
marketname = "Redmi Note 7"
fingerprint = ""

[templates."xiaomi_m1901f7be"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 7 Pro"
device = "violet"
product = "violet"
name = "violet"
marketname = "Redmi Note 7 Pro"
fingerprint = ""

[templates."xiaomi_m1908c3je"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 8"
device = "ginkgo"
product = "ginkgo"
name = "ginkgo"
marketname = "Redmi Note 8"
fingerprint = ""

[templates."xiaomi_m1908c3jc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 8 运营商"
device = "ginkgo"
product = "ginkgo"
name = "ginkgo"
marketname = "Redmi Note 8 运营商"
fingerprint = ""

[templates."xiaomi_m1906g7e"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 8 Pro"
device = "begonia"
product = "begonia"
name = "begonia"
marketname = "Redmi Note 8 Pro"
fingerprint = ""

[templates."xiaomi_m1906g7t"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 8 Pro 运营商"
device = "begonia"
product = "begonia"
name = "begonia"
marketname = "Redmi Note 8 Pro 运营商"
fingerprint = ""

[templates."xiaomi_m2010j19sc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 9 4G"
device = "lime"
product = "lime"
name = "lime"
marketname = "Redmi Note 9 4G"
fingerprint = ""

[templates."xiaomi_m2007j22c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 9 5G"
device = "cannon"
product = "cannon"
name = "cannon"
marketname = "Redmi Note 9 5G"
fingerprint = ""

[templates."xiaomi_m2007j17c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 9 Pro 5G"
device = "gauguin"
product = "gauguin"
name = "gauguin"
marketname = "Redmi Note 9 Pro 5G"
fingerprint = ""

[templates."xiaomi_m2103k19c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 10 5G"
device = "camellia"
product = "camellia"
name = "camellia"
marketname = "Redmi Note 10 5G"
fingerprint = ""

[templates."xiaomi_m2104k10ac"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 10 Pro"
device = "chopin"
product = "chopin"
name = "chopin"
marketname = "Redmi Note 10 Pro"
fingerprint = ""

[templates."xiaomi_21121119sc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 11 4G"
device = "selene"
product = "selene"
name = "selene"
marketname = "Redmi Note 11 4G"
fingerprint = ""

[templates."xiaomi_21091116ac"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 11 5G"
device = "evergo"
product = "evergo"
name = "evergo"
marketname = "Redmi Note 11 5G"
fingerprint = ""

[templates."xiaomi_22041219c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 11E 5G"
device = "light"
product = "light"
name = "light"
marketname = "Redmi Note 11E 5G"
fingerprint = ""

[templates."xiaomi_21091116c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 11 Pro"
device = "pissarro"
product = "pissarro"
name = "pissarro"
marketname = "Redmi Note 11 Pro"
fingerprint = ""

[templates."xiaomi_2201116sc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 11E Pro"
device = "veux"
product = "veux"
name = "veux"
marketname = "Redmi Note 11E Pro"
fingerprint = ""

[templates."xiaomi_21091116uc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 11 Pro+"
device = "pissarro"
product = "pissarro"
name = "pissarro"
marketname = "Redmi Note 11 Pro+"
fingerprint = ""

[templates."xiaomi_22041216c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 11T Pro"
device = "xaga"
product = "xaga"
name = "xaga"
marketname = "Redmi Note 11T Pro"
fingerprint = ""

[templates."xiaomi_22041216uc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 11T Pro+"
device = "xaga"
product = "xaga"
name = "xaga"
marketname = "Redmi Note 11T Pro+"
fingerprint = ""

[templates."xiaomi_22095ra98c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 11R 5G"
device = "lightcm"
product = "lightcm"
name = "lightcm"
marketname = "Redmi Note 11R 5G"
fingerprint = ""

[templates."xiaomi_22101317c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 12 5G"
device = "sunstone"
product = "sunstone"
name = "sunstone"
marketname = "Redmi Note 12 5G"
fingerprint = ""

[templates."xiaomi_22101316c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 12 Pro"
device = "ruby"
product = "ruby"
name = "ruby"
marketname = "Redmi Note 12 Pro"
fingerprint = ""

[templates."xiaomi_22101316ucp"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 12 Pro+"
device = "ruby"
product = "ruby"
name = "ruby"
marketname = "Redmi Note 12 Pro+"
fingerprint = ""

[templates."xiaomi_22101316uc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 12 探索版"
device = "ruby"
product = "ruby"
name = "ruby"
marketname = "Redmi Note 12 探索版"
fingerprint = ""

[templates."xiaomi_22101320c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 12 Pro 极速版"
device = "redwood"
product = "redwood"
name = "redwood"
marketname = "Redmi Note 12 Pro 极速版"
fingerprint = ""

[templates."xiaomi_23054ra19c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 12T Pro"
device = "pearl"
product = "pearl"
name = "pearl"
marketname = "Redmi Note 12T Pro"
fingerprint = ""

[templates."xiaomi_23049rad8c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 12 Turbo"
device = "marble"
product = "marble"
name = "marble"
marketname = "Redmi Note 12 Turbo"
fingerprint = ""

[templates."xiaomi_2312draabc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 13 5G"
device = "gold"
product = "gold"
name = "gold"
marketname = "Redmi Note 13 5G"
fingerprint = ""

[templates."xiaomi_2312dra50c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 13 Pro"
device = "garnet"
product = "garnet"
name = "garnet"
marketname = "Redmi Note 13 Pro"
fingerprint = ""

[templates."xiaomi_23090ra98c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 13 Pro+"
device = "zircon"
product = "zircon"
name = "zircon"
marketname = "Redmi Note 13 Pro+"
fingerprint = ""

[templates."xiaomi_2406ern9cc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 13R"
device = "breeze"
product = "breeze"
name = "breeze"
marketname = "Redmi Note 13R"
fingerprint = ""

[templates."xiaomi_2311frafdc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 13R Pro"
device = "gold"
product = "gold"
name = "gold"
marketname = "Redmi Note 13R Pro"
fingerprint = ""

[templates."xiaomi_24094rad4c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 14 5G"
device = "beryl"
product = "beryl"
name = "beryl"
marketname = "Redmi Note 14 5G"
fingerprint = ""

[templates."xiaomi_24090ra29c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 14 Pro"
device = "malachite"
product = "malachite"
name = "malachite"
marketname = "Redmi Note 14 Pro"
fingerprint = ""

[templates."xiaomi_24115ra8ec"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Note 14 Pro+"
device = "amethyst"
product = "amethyst"
name = "amethyst"
marketname = "Redmi Note 14 Pro+"
fingerprint = ""

[templates."xiaomi_25098ra98c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Note 15"
device = "kunzite"
product = "kunzite"
name = "kunzite"
marketname = "REDMI Note 15"
fingerprint = ""

[templates."xiaomi_25080rabdc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Note 15 Pro"
device = "lapis"
product = "lapis"
name = "lapis"
marketname = "REDMI Note 15 Pro"
fingerprint = ""

[templates."xiaomi_2510era8bc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Note 15 Pro+"
device = "flourite"
product = "flourite"
name = "flourite"
marketname = "REDMI Note 15 Pro+"
fingerprint = ""

[templates."xiaomi_25104radac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Note 15 Pro+ 卫星消息版"
device = "flourite"
product = "flourite"
name = "flourite"
marketname = "REDMI Note 15 Pro+ 卫星消息版"
fingerprint = ""

[templates."xiaomi_25057ra09c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Note 15R"
device = "spring"
product = "spring"
name = "spring"
marketname = "REDMI Note 15R"
fingerprint = ""

[templates."xiaomi_26021rn18c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Note 17"
device = "mist"
product = "mist"
name = "mist"
marketname = "REDMI Note 17"
fingerprint = ""

[templates."xiaomi_2607dra18c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Note 17 Pro"
device = "iolite"
product = "iolite"
name = "iolite"
marketname = "REDMI Note 17 Pro"
fingerprint = ""

[templates."xiaomi_m2004j7ac"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 10X 5G"
device = "atom"
product = "atom"
name = "atom"
marketname = "Redmi 10X 5G"
fingerprint = ""

[templates."xiaomi_m2004j7bc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 10X Pro 5G"
device = "bomb"
product = "bomb"
name = "bomb"
marketname = "Redmi 10X Pro 5G"
fingerprint = ""

[templates."xiaomi_m2003j15sc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi 10X 4G"
device = "merlin"
product = "merlin"
name = "merlin"
marketname = "Redmi 10X 4G"
fingerprint = ""

[templates."xiaomi_24069ra21c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Turbo 3"
device = "peridot"
product = "peridot"
name = "peridot"
marketname = "Redmi Turbo 3"
fingerprint = ""

[templates."xiaomi_24129rt7cc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Turbo 4"
device = "rodin"
product = "rodin"
name = "rodin"
marketname = "REDMI Turbo 4"
fingerprint = ""

[templates."xiaomi_25053rt47c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Turbo 4 Pro"
device = "onyx"
product = "onyx"
name = "onyx"
marketname = "REDMI Turbo 4 Pro"
fingerprint = ""

[templates."xiaomi_2511frt34c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Turbo 5"
device = "klee"
product = "klee"
name = "klee"
marketname = "REDMI Turbo 5"
fingerprint = ""

[templates."xiaomi_2602brt18c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Turbo 5 Max"
device = "dash"
product = "dash"
name = "dash"
marketname = "REDMI Turbo 5 Max"
fingerprint = ""

[templates."xiaomi_m1903f10a"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K20"
device = "davinci"
product = "davinci"
name = "davinci"
marketname = "Redmi K20"
fingerprint = ""

[templates."xiaomi_m1903f10c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K20 运营商"
device = "davinci"
product = "davinci"
name = "davinci"
marketname = "Redmi K20 运营商"
fingerprint = ""

[templates."xiaomi_m1903f11a"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K20 Pro"
device = "raphael"
product = "raphael"
name = "raphael"
marketname = "Redmi K20 Pro"
fingerprint = ""

[templates."xiaomi_m1903f11c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K20 Pro 运营商"
device = "raphael"
product = "raphael"
name = "raphael"
marketname = "Redmi K20 Pro 运营商"
fingerprint = ""

[templates."xiaomi_m2001g7ae"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K30 5G"
device = "picasso"
product = "picasso"
name = "picasso"
marketname = "Redmi K30 5G"
fingerprint = ""

[templates."xiaomi_m1912g7be"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K30 4G"
device = "phoenix"
product = "phoenix"
name = "phoenix"
marketname = "Redmi K30 4G"
fingerprint = ""

[templates."xiaomi_m1912g7bc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K30 4G 运营商"
device = "phoenix"
product = "phoenix"
name = "phoenix"
marketname = "Redmi K30 4G 运营商"
fingerprint = ""

[templates."xiaomi_m2001j11c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K30 Pro"
device = "lmi"
product = "lmi"
name = "lmi"
marketname = "Redmi K30 Pro"
fingerprint = ""

[templates."xiaomi_m2006j10c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K30 至尊纪念版"
device = "cezanne"
product = "cezanne"
name = "cezanne"
marketname = "Redmi K30 至尊纪念版"
fingerprint = ""

[templates."xiaomi_m2007j3sc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K30S 至尊纪念版"
device = "apollo"
product = "apollo"
name = "apollo"
marketname = "Redmi K30S 至尊纪念版"
fingerprint = ""

[templates."xiaomi_m2012k11ac"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K40"
device = "alioth"
product = "alioth"
name = "alioth"
marketname = "Redmi K40"
fingerprint = ""

[templates."xiaomi_m2012k11c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K40 Pro"
device = "haydn"
product = "haydn"
name = "haydn"
marketname = "Redmi K40 Pro"
fingerprint = ""

[templates."xiaomi_m2012k10c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K40 游戏增强版"
device = "ares"
product = "ares"
name = "ares"
marketname = "Redmi K40 游戏增强版"
fingerprint = ""

[templates."xiaomi_22021211rc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K40S"
device = "munch"
product = "munch"
name = "munch"
marketname = "Redmi K40S"
fingerprint = ""

[templates."xiaomi_22041211ac"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K50"
device = "rubens"
product = "rubens"
name = "rubens"
marketname = "Redmi K50"
fingerprint = ""

[templates."xiaomi_22011211c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K50 Pro"
device = "matisse"
product = "matisse"
name = "matisse"
marketname = "Redmi K50 Pro"
fingerprint = ""

[templates."xiaomi_21121210c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K50 电竞版"
device = "ingres"
product = "ingres"
name = "ingres"
marketname = "Redmi K50 电竞版"
fingerprint = ""

[templates."xiaomi_22081212c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K50 至尊版"
device = "diting"
product = "diting"
name = "diting"
marketname = "Redmi K50 至尊版"
fingerprint = ""

[templates."xiaomi_23013rk75c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K60"
device = "mondrian"
product = "mondrian"
name = "mondrian"
marketname = "Redmi K60"
fingerprint = ""

[templates."xiaomi_22127rk46c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K60 Pro"
device = "socrates"
product = "socrates"
name = "socrates"
marketname = "Redmi K60 Pro"
fingerprint = ""

[templates."xiaomi_22122rk93c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K60E"
device = "rembrandt"
product = "rembrandt"
name = "rembrandt"
marketname = "Redmi K60E"
fingerprint = ""

[templates."xiaomi_23078rkd5c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K60 至尊版"
device = "corot"
product = "corot"
name = "corot"
marketname = "Redmi K60 至尊版"
fingerprint = ""

[templates."xiaomi_23113rkc6c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K70"
device = "vermeer"
product = "vermeer"
name = "vermeer"
marketname = "Redmi K70"
fingerprint = ""

[templates."xiaomi_23117rk66c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K70 Pro"
device = "manet"
product = "manet"
name = "manet"
marketname = "Redmi K70 Pro"
fingerprint = ""

[templates."xiaomi_2311drk48c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K70E"
device = "duchamp"
product = "duchamp"
name = "duchamp"
marketname = "Redmi K70E"
fingerprint = ""

[templates."xiaomi_2407frk8ec"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi K70 至尊版"
device = "rothko"
product = "rothko"
name = "rothko"
marketname = "Redmi K70 至尊版"
fingerprint = ""

[templates."xiaomi_24117rk2cc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI K80"
device = "zorn"
product = "zorn"
name = "zorn"
marketname = "REDMI K80"
fingerprint = ""

[templates."xiaomi_24122rkc7c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI K80 Pro"
device = "miro"
product = "miro"
name = "miro"
marketname = "REDMI K80 Pro"
fingerprint = ""

[templates."xiaomi_24127rk2cc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI K80 Pro 冠军版"
device = "miro"
product = "miro"
name = "miro"
marketname = "REDMI K80 Pro 冠军版"
fingerprint = ""

[templates."xiaomi_25060rk16c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI K80 至尊版"
device = "dali"
product = "dali"
name = "dali"
marketname = "REDMI K80 至尊版"
fingerprint = ""

[templates."xiaomi_2510drk44c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI K90"
device = "annibale"
product = "annibale"
name = "annibale"
marketname = "REDMI K90"
fingerprint = ""

[templates."xiaomi_25102rkbec"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI K90 Pro Max"
device = "myron"
product = "myron"
name = "myron"
marketname = "REDMI K90 Pro Max"
fingerprint = ""

[templates."xiaomi_25102rk69c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI K90 Pro Max 冠军版"
device = "myron"
product = "myron"
name = "myron"
marketname = "REDMI K90 Pro Max 冠军版"
fingerprint = ""

[templates."xiaomi_2604frk1ec"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI K90 Max"
device = "prague"
product = "prague"
name = "prague"
marketname = "REDMI K90 Max"
fingerprint = ""

[templates."xiaomi_m332bf"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI K90 至尊版"
device = "warsaw"
product = "warsaw"
name = "warsaw"
marketname = "REDMI K90 至尊版"
fingerprint = ""

[templates."xiaomi_m786bc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI K100"
device = "warsaw"
product = "warsaw"
name = "warsaw"
marketname = "REDMI K100"
fingerprint = ""

[templates."xiaomi_m511cd"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI K100 Pro"
device = "athens"
product = "athens"
name = "athens"
marketname = "REDMI K100 Pro"
fingerprint = ""

[templates."xiaomi_m098fe"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI K100 Pro Max"
device = "songyuan"
product = "songyuan"
name = "songyuan"
marketname = "REDMI K100 Pro Max"
fingerprint = ""

[templates."xiaomi_2016020"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Pro"
device = "omega"
product = "omega"
name = "omega"
marketname = "Redmi Pro"
fingerprint = ""

[templates."xiaomi_m1803e6e"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi S2"
device = "ysl"
product = "ysl"
name = "ysl"
marketname = "Redmi S2"
fingerprint = ""

[templates."xiaomi_26020rn1ac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI R70 5G"
device = "somalia"
product = "somalia"
name = "somalia"
marketname = "REDMI R70 5G"
fingerprint = ""

[templates."xiaomi_26062rn92c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI M100"
device = "steppe"
product = "steppe"
name = "steppe"
marketname = "REDMI M100"
fingerprint = ""

[templates."xiaomi_22081283c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Pad"
device = "yunluo"
product = "yunluo"
name = "yunluo"
marketname = "Redmi Pad"
fingerprint = ""

[templates."xiaomi_23073rpbfc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Pad SE"
device = "xun"
product = "xun"
name = "xun"
marketname = "Redmi Pad SE"
fingerprint = ""

[templates."xiaomi_2405crpfdc"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Pad Pro"
device = "dizi"
product = "dizi"
name = "dizi"
marketname = "Redmi Pad Pro"
fingerprint = ""

[templates."xiaomi_24074rpd2c"]
manufacturer = "Xiaomi"
brand = "Redmi"
model = "Redmi Pad Pro 5G"
device = "ruan"
product = "ruan"
name = "ruan"
marketname = "Redmi Pad Pro 5G"
fingerprint = ""

[templates."xiaomi_25040rp0ac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Pad 2"
device = "taiko"
product = "taiko"
name = "taiko"
marketname = "REDMI Pad 2"
fingerprint = ""

[templates."xiaomi_25099rp13c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Pad 2 Pro"
device = "flute"
product = "flute"
name = "flute"
marketname = "REDMI Pad 2 Pro"
fingerprint = ""

[templates."xiaomi_2509brp2dc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Pad 2 Pro 5G"
device = "organ"
product = "organ"
name = "organ"
marketname = "REDMI Pad 2 Pro 5G"
fingerprint = ""

[templates."xiaomi_2603arp14c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Pad 2 SE"
device = "guitar"
product = "guitar"
name = "guitar"
marketname = "REDMI Pad 2 SE"
fingerprint = ""

[templates."xiaomi_2604erp4dc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI Pad 2 SE 4G"
device = "erhu"
product = "erhu"
name = "erhu"
marketname = "REDMI Pad 2 SE 4G"
fingerprint = ""

[templates."xiaomi_25079rpdcc"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI K Pad"
device = "turner"
product = "turner"
name = "turner"
marketname = "REDMI K Pad"
fingerprint = ""

[templates."xiaomi_26048rp6ac"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "REDMI K Pad 2"
device = "yili"
product = "yili"
name = "yili"
marketname = "REDMI K Pad 2"
fingerprint = ""

[templates."xiaomi_fyj01qp"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 米家翻译机"
device = "Babel"
product = "Babel"
name = "Babel"
marketname = "Xiaomi 米家翻译机"
fingerprint = ""

[templates."xiaomi_21051191c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi CyberDog 仿生四足机器人"
device = "21051191C"
product = "21051191C"
marketname = "Xiaomi CyberDog 仿生四足机器人"
fingerprint = ""

[templates."xiaomi_2405avpb7c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 澎湃智能座舱"
device = "2405AVPB7C"
product = "2405AVPB7C"
marketname = "Xiaomi 澎湃智能座舱"
fingerprint = ""

[templates."xiaomi_2503cvpc6c"]
manufacturer = "Xiaomi"
brand = "Xiaomi"
model = "Xiaomi 汽车后排移动控制屏"
device = "konghou"
product = "konghou"
name = "konghou"
marketname = "Xiaomi 汽车后排移动控制屏"
fingerprint = ""

[templates."honor_nts_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic"
device = "Natasha"
product = "Natasha"
name = "Natasha"
marketname = "HONOR Magic"
fingerprint = ""

[templates."honor_tny_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic2"
device = "Tony"
product = "Tony"
name = "Tony"
marketname = "HONOR Magic2"
fingerprint = ""

[templates."honor_tny_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic2 3D 感光版"
device = "Tony"
product = "Tony"
name = "Tony"
marketname = "HONOR Magic2 3D 感光版"
fingerprint = ""

[templates."honor_elz_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic3"
device = "Elizabeth"
product = "Elizabeth"
name = "Elizabeth"
marketname = "HONOR Magic3"
fingerprint = ""

[templates."honor_elz_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic3 Pro"
device = "Elizabeth"
product = "Elizabeth"
name = "Elizabeth"
marketname = "HONOR Magic3 Pro"
fingerprint = ""

[templates."honor_elz_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic3 至臻版"
device = "Elizabeth"
product = "Elizabeth"
name = "Elizabeth"
marketname = "HONOR Magic3 至臻版"
fingerprint = ""

[templates."honor_mgi_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic V"
device = "Maggie"
product = "Maggie"
name = "Maggie"
marketname = "HONOR Magic V"
fingerprint = ""

[templates."honor_lge_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic4"
device = "Lange"
product = "Lange"
name = "Lange"
marketname = "HONOR Magic4"
fingerprint = ""

[templates."honor_lge_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic4 Pro"
device = "Lange"
product = "Lange"
name = "Lange"
marketname = "HONOR Magic4 Pro"
fingerprint = ""

[templates."honor_lge_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic4 至臻版"
device = "Lange"
product = "Lange"
name = "Lange"
marketname = "HONOR Magic4 至臻版"
fingerprint = ""

[templates."honor_fri_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic Vs"
device = "Ferrari"
product = "Ferrari"
name = "Ferrari"
marketname = "HONOR Magic Vs"
fingerprint = ""

[templates."honor_fri_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic Vs 至臻版"
device = "Ferrari"
product = "Ferrari"
name = "Ferrari"
marketname = "HONOR Magic Vs 至臻版"
fingerprint = ""

[templates."honor_pgt_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic5"
device = "Piaget"
product = "Piaget"
name = "Piaget"
marketname = "HONOR Magic5"
fingerprint = ""

[templates."honor_pgt_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic5 Pro"
device = "Piaget"
product = "Piaget"
name = "Piaget"
marketname = "HONOR Magic5 Pro"
fingerprint = ""

[templates."honor_pgt_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic5 至臻版"
device = "Piaget"
product = "Piaget"
name = "Piaget"
marketname = "HONOR Magic5 至臻版"
fingerprint = ""

[templates."honor_ver_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic V2"
device = "Veyron"
product = "Veyron"
name = "Veyron"
marketname = "HONOR Magic V2"
fingerprint = ""

[templates."honor_ver_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic Vs2"
device = "VeyronS"
product = "VeyronS"
name = "VeyronS"
marketname = "HONOR Magic Vs2"
fingerprint = ""

[templates."honor_bvl_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic6"
device = "Bvlgari"
product = "Bvlgari"
name = "Bvlgari"
marketname = "HONOR Magic6"
fingerprint = ""

[templates."honor_bvl_an16"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic6 Pro"
device = "Bvlgari"
product = "Bvlgari"
name = "Bvlgari"
marketname = "HONOR Magic6 Pro"
fingerprint = ""

[templates."honor_bvl_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic6 至臻版"
device = "Bvlgari"
product = "Bvlgari"
name = "Bvlgari"
marketname = "HONOR Magic6 至臻版"
fingerprint = ""

[templates."honor_lra_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic V Flip"
device = "Lyra"
product = "Lyra"
name = "Lyra"
marketname = "HONOR Magic V Flip"
fingerprint = ""

[templates."honor_fcp_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic V3"
device = "FalconP"
product = "FalconP"
name = "FalconP"
marketname = "HONOR Magic V3"
fingerprint = ""

[templates."honor_fcp_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic V3 双卫星版"
device = "FalconP"
product = "FalconP"
name = "FalconP"
marketname = "HONOR Magic V3 双卫星版"
fingerprint = ""

[templates."honor_flc_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic Vs3"
device = "Falcon"
product = "Falcon"
name = "Falcon"
marketname = "HONOR Magic Vs3"
fingerprint = ""

[templates."honor_ptp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic7"
device = "Philippe"
product = "Philippe"
name = "Philippe"
marketname = "HONOR Magic7"
fingerprint = ""

[templates."honor_ptp_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic7 Pro"
device = "Patek"
product = "Patek"
name = "Patek"
marketname = "HONOR Magic7 Pro"
fingerprint = ""

[templates."honor_ptp_an70"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic7 Pro 卫星通信版"
device = "Patek"
product = "Patek"
name = "Patek"
marketname = "HONOR Magic7 Pro 卫星通信版"
fingerprint = ""

[templates."honor_ptp_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic7 RSR 保时捷设计"
device = "Patek"
product = "Patek"
name = "Patek"
marketname = "HONOR Magic7 RSR 保时捷设计"
fingerprint = ""

[templates."honor_mbh_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic V5"
device = "Maybach"
product = "Maybach"
name = "Maybach"
marketname = "HONOR Magic V5"
fingerprint = ""

[templates."honor_cle_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic V Flip2"
device = "Celine"
product = "Celine"
name = "Celine"
marketname = "HONOR Magic V Flip2"
fingerprint = ""

[templates."honor_bkq_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic8"
device = "Birkin"
product = "Birkin"
name = "Birkin"
marketname = "HONOR Magic8"
fingerprint = ""

[templates."honor_bkq_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic8 Pro"
device = "Birkin"
product = "Birkin"
name = "Birkin"
marketname = "HONOR Magic8 Pro"
fingerprint = ""

[templates."honor_ldy_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic8 Pro Air"
device = "Lindy"
product = "Lindy"
name = "Lindy"
marketname = "HONOR Magic8 Pro Air"
fingerprint = ""

[templates."honor_bkq_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic8 RSR 保时捷设计"
device = "Birkin"
product = "Birkin"
name = "Birkin"
marketname = "HONOR Magic8 RSR 保时捷设计"
fingerprint = ""

[templates."honor_pnm_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic V6"
device = "Phenom"
product = "Phenom"
name = "Phenom"
marketname = "HONOR Magic V6"
fingerprint = ""

[templates."honor_mly_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic9"
device = "Molly"
product = "Molly"
name = "Molly"
marketname = "HONOR Magic9"
fingerprint = ""

[templates."honor_mlm_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic9 超能版"
device = "MollyM"
product = "MollyM"
name = "MollyM"
marketname = "HONOR Magic9 超能版"
fingerprint = ""

[templates."honor_wkl_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Magic9 Pro Max"
device = "Twinkle"
product = "Twinkle"
name = "Twinkle"
marketname = "HONOR Magic9 Pro Max"
fingerprint = ""

[templates."honor_aph_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Robot Phone"
device = "Alpha"
product = "Alpha"
name = "Alpha"
marketname = "HONOR Robot Phone"
fingerprint = ""

[templates."honor_h60_l01"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 6"
device = "Mogolia"
product = "Mogolia"
name = "Mogolia"
marketname = "HONOR 6"
fingerprint = ""

[templates."honor_h60_l21"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 6 至尊版"
device = "Mogolia"
product = "Mogolia"
name = "Mogolia"
marketname = "HONOR 6 至尊版"
fingerprint = ""

[templates."honor_pe_tl00m"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 6 Plus"
device = "Pine"
product = "Pine"
name = "Pine"
marketname = "HONOR 6 Plus"
fingerprint = ""

[templates."honor_pe_tl10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 6 Plus 双 4G"
device = "Pine"
product = "Pine"
name = "Pine"
marketname = "HONOR 6 Plus 双 4G"
fingerprint = ""

[templates."honor_pe_tl20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 6 Plus 移动渠道版"
device = "Pine"
product = "Pine"
name = "Pine"
marketname = "HONOR 6 Plus 移动渠道版"
fingerprint = ""

[templates."honor_plk_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 7"
device = "Plank"
product = "Plank"
name = "Plank"
marketname = "HONOR 7"
fingerprint = ""

[templates."honor_plk_tl01h"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 7 移动渠道版"
device = "Plank"
product = "Plank"
name = "Plank"
marketname = "HONOR 7 移动渠道版"
fingerprint = ""

[templates."honor_plk_tl11h"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 7 移动增强版"
device = "Plank"
product = "Plank"
name = "Plank"
marketname = "HONOR 7 移动增强版"
fingerprint = ""

[templates."honor_ath_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 7i"
device = "ATH-AL00"
product = "ATH-AL00"
marketname = "HONOR 7i"
fingerprint = ""

[templates."honor_ath_tl00h"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 7i 移动渠道版"
device = "ATH-TL00H"
product = "ATH-TL00H"
marketname = "HONOR 7i 移动渠道版"
fingerprint = ""

[templates."honor_frd_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 8"
device = "Faraday"
product = "Faraday"
name = "Faraday"
marketname = "HONOR 8"
fingerprint = ""

[templates."honor_pra_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 8 青春版"
device = "Prague"
product = "Prague"
name = "Prague"
marketname = "HONOR 8 青春版"
fingerprint = ""

[templates."honor_stf_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 9"
device = "Stanford"
product = "Stanford"
name = "Stanford"
marketname = "HONOR 9"
fingerprint = ""

[templates."honor_lld_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 9 青春版"
device = "Leland"
product = "Leland"
name = "Leland"
marketname = "HONOR 9 青春版"
fingerprint = ""

[templates."honor_lld_al20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 9i"
device = "LelandP"
product = "LelandP"
name = "LelandP"
marketname = "HONOR 9i"
fingerprint = ""

[templates."honor_col_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 10"
device = "Columbia"
product = "Columbia"
name = "Columbia"
marketname = "HONOR 10"
fingerprint = ""

[templates."honor_col_tl00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 10 移动 4G+"
device = "Columbia"
product = "Columbia"
name = "Columbia"
marketname = "HONOR 10 移动 4G+"
fingerprint = ""

[templates."honor_hry_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 10 青春版"
device = "Harry"
product = "Harry"
name = "Harry"
marketname = "HONOR 10 青春版"
fingerprint = ""

[templates."honor_hry_al00t"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 20i"
device = "Harrypro"
product = "Harrypro"
name = "Harrypro"
marketname = "HONOR 20i"
fingerprint = ""

[templates."honor_yal_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 20"
device = "Yale"
product = "Yale"
name = "Yale"
marketname = "HONOR 20"
fingerprint = ""

[templates."honor_yal_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 20 PRO"
device = "Yale"
product = "Yale"
name = "Yale"
marketname = "HONOR 20 PRO"
fingerprint = ""

[templates."honor_yal_al50"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 20S"
device = "Yalese"
product = "Yalese"
name = "Yalese"
marketname = "HONOR 20S"
fingerprint = ""

[templates."honor_lra_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 20 青春版"
device = "Laura"
product = "Laura"
name = "Laura"
marketname = "HONOR 20 青春版"
fingerprint = ""

[templates."honor_bmh_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 30 5G"
device = "Birmingham"
product = "Birmingham"
name = "Birmingham"
marketname = "HONOR 30 5G"
fingerprint = ""

[templates."honor_ebg_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 30 Pro 5G"
device = "Edinburgh"
product = "Edinburgh"
name = "Edinburgh"
marketname = "HONOR 30 Pro 5G"
fingerprint = ""

[templates."honor_ebg_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 30 Pro+ 5G"
device = "Edinburgh"
product = "Edinburgh"
name = "Edinburgh"
marketname = "HONOR 30 Pro+ 5G"
fingerprint = ""

[templates."honor_cdy_an90"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 30S 5G"
device = "CindyH"
product = "CindyH"
name = "CindyH"
marketname = "HONOR 30S 5G"
fingerprint = ""

[templates."honor_mxw_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 30 青春版 5G"
device = "Maxwell"
product = "Maxwell"
name = "Maxwell"
marketname = "HONOR 30 青春版 5G"
fingerprint = ""

[templates."honor_nth_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 50 5G"
device = "Nottingham"
product = "Nottingham"
name = "Nottingham"
marketname = "HONOR 50 5G"
fingerprint = ""

[templates."honor_rna_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 50 Pro 5G"
device = "Rena"
product = "Rena"
name = "Rena"
marketname = "HONOR 50 Pro 5G"
fingerprint = ""

[templates."honor_jlh_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 50 SE 5G"
device = "JuliaH"
product = "JuliaH"
name = "JuliaH"
marketname = "HONOR 50 SE 5G"
fingerprint = ""

[templates."honor_lsa_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 60 5G"
device = "Lisa"
product = "Lisa"
name = "Lisa"
marketname = "HONOR 60 5G"
fingerprint = ""

[templates."honor_tna_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 60 Pro 5G"
device = "Tina"
product = "Tina"
name = "Tina"
marketname = "HONOR 60 Pro 5G"
fingerprint = ""

[templates."honor_gia_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 60 SE 5G"
device = "Gina"
product = "Gina"
name = "Gina"
marketname = "HONOR 60 SE 5G"
fingerprint = ""

[templates."honor_fne_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 70"
device = "Fennie"
product = "Fennie"
name = "Fennie"
marketname = "HONOR 70"
fingerprint = ""

[templates."honor_sdy_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 70 Pro"
device = "Sandy"
product = "Sandy"
name = "Sandy"
marketname = "HONOR 70 Pro"
fingerprint = ""

[templates."honor_hpb_tn00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 70 Pro+"
device = "Hepburn"
product = "Hepburn"
name = "Hepburn"
marketname = "HONOR 70 Pro+"
fingerprint = ""

[templates."honor_ann_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 80"
device = "Anna"
product = "Anna"
name = "Anna"
marketname = "HONOR 80"
fingerprint = ""

[templates."honor_anp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 80 Pro"
device = "AnnaP"
product = "AnnaP"
name = "AnnaP"
marketname = "HONOR 80 Pro"
fingerprint = ""

[templates."honor_anb_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 80 Pro 直屏版"
device = "AnnaB"
product = "AnnaB"
name = "AnnaB"
marketname = "HONOR 80 Pro 直屏版"
fingerprint = ""

[templates."honor_gia_an80"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 80 SE"
device = "Gina"
product = "Gina"
name = "Gina"
marketname = "HONOR 80 SE"
fingerprint = ""

[templates."honor_agt_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 80 GT"
device = "AnnaGT"
product = "AnnaGT"
name = "AnnaGT"
marketname = "HONOR 80 GT"
fingerprint = ""

[templates."honor_rea_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 90"
device = "Rhea"
product = "Rhea"
name = "Rhea"
marketname = "HONOR 90"
fingerprint = ""

[templates."honor_rep_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 90 Pro"
device = "RheaP"
product = "RheaP"
name = "RheaP"
marketname = "HONOR 90 Pro"
fingerprint = ""

[templates."honor_mag_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 90 GT"
device = "MiaGT"
product = "MiaGT"
name = "MiaGT"
marketname = "HONOR 90 GT"
fingerprint = ""

[templates."honor_maa_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 100"
device = "Mia"
product = "Mia"
name = "Mia"
marketname = "HONOR 100"
fingerprint = ""

[templates."honor_maa_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 100 Pro"
device = "MiaP"
product = "MiaP"
name = "MiaP"
marketname = "HONOR 100 Pro"
fingerprint = ""

[templates."honor_eli_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 200"
device = "Ellie"
product = "Ellie"
name = "Ellie"
marketname = "HONOR 200"
fingerprint = ""

[templates."honor_elp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 200 Pro"
device = "EllieP"
product = "EllieP"
name = "EllieP"
marketname = "HONOR 200 Pro"
fingerprint = ""

[templates."honor_amm_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 300"
device = "Mina"
product = "Mina"
name = "Mina"
marketname = "HONOR 300"
fingerprint = ""

[templates."honor_amp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 300 Pro"
device = "MinaP"
product = "MinaP"
name = "MinaP"
marketname = "HONOR 300 Pro"
fingerprint = ""

[templates."honor_amp_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 300 Ultra"
device = "MinaP"
product = "MinaP"
name = "MinaP"
marketname = "HONOR 300 Ultra"
fingerprint = ""

[templates."honor_dnn_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 400"
device = "Danny"
product = "Danny"
name = "Danny"
marketname = "HONOR 400"
fingerprint = ""

[templates."honor_dnp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 400 Pro"
device = "DannyP"
product = "DannyP"
name = "DannyP"
marketname = "HONOR 400 Pro"
fingerprint = ""

[templates."honor_mey_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 500"
device = "Merry"
product = "Merry"
name = "Merry"
marketname = "HONOR 500"
fingerprint = ""

[templates."honor_mep_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 500 Pro"
device = "MerryP"
product = "MerryP"
name = "MerryP"
marketname = "HONOR 500 Pro"
fingerprint = ""

[templates."honor_vkj_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 600 超级版"
device = "Vicky"
product = "Vicky"
name = "Vicky"
marketname = "HONOR 600 超级版"
fingerprint = ""

[templates."honor_vkj_an90"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 600 元气版"
device = "Vicky"
product = "Vicky"
name = "Vicky"
marketname = "HONOR 600 元气版"
fingerprint = ""

[templates."honor_vki_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 600 Pro"
device = "Vicky"
product = "Vicky"
name = "Vicky"
marketname = "HONOR 600 Pro"
fingerprint = ""

[templates."honor_faa_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 700"
device = "Flora"
product = "Flora"
name = "Flora"
marketname = "HONOR 700"
fingerprint = ""

[templates."honor_fas_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 700S"
device = "FloraS"
product = "FloraS"
name = "FloraS"
marketname = "HONOR 700S"
fingerprint = ""

[templates."honor_fap_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 700 Pro"
device = "FloraP"
product = "FloraP"
name = "FloraP"
marketname = "HONOR 700 Pro"
fingerprint = ""

[templates."honor_knt_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR V8"
device = "Knight"
product = "Knight"
name = "Knight"
marketname = "HONOR V8"
fingerprint = ""

[templates."honor_duk_al20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR V9"
device = "Duke"
product = "Duke"
name = "Duke"
marketname = "HONOR V9"
fingerprint = ""

[templates."honor_bkl_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR V10"
device = "Berkeley"
product = "Berkeley"
name = "Berkeley"
marketname = "HONOR V10"
fingerprint = ""

[templates."honor_pct_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR V20"
device = "Princeton"
product = "Princeton"
name = "Princeton"
marketname = "HONOR V20"
fingerprint = ""

[templates."honor_oxf_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR V30 5G"
device = "OxfordS"
product = "OxfordS"
name = "OxfordS"
marketname = "HONOR V30 5G"
fingerprint = ""

[templates."honor_oxf_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR V30 PRO 5G"
device = "OxfordP"
product = "OxfordP"
name = "OxfordP"
marketname = "HONOR V30 PRO 5G"
fingerprint = ""

[templates."honor_yok_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR V40 5G"
device = "York"
product = "York"
name = "York"
marketname = "HONOR V40 5G"
fingerprint = ""

[templates."honor_ala_an70"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR V40 轻奢版 5G"
device = "ALA-AN70"
product = "ALA-AN70"
marketname = "HONOR V40 轻奢版 5G"
fingerprint = ""

[templates."honor_vca_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR V Purse"
device = "Victoria"
product = "Victoria"
name = "Victoria"
marketname = "HONOR V Purse"
fingerprint = ""

[templates."honor_amg_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR GT"
device = "MinaGT"
product = "MinaGT"
name = "MinaGT"
marketname = "HONOR GT"
fingerprint = ""

[templates."honor_ppg_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR GT Pro"
device = "PhilippeGT"
product = "PhilippeGT"
name = "PhilippeGT"
marketname = "HONOR GT Pro"
fingerprint = ""

[templates."honor_aap_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR WIN"
device = "AAP-AN00"
product = "AAP-AN00"
marketname = "HONOR WIN"
fingerprint = ""

[templates."honor_aak_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR WIN RT"
device = "AAK-AN00"
product = "AAK-AN00"
marketname = "HONOR WIN RT"
fingerprint = ""

[templates."honor_ser_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR WIN Turbo"
device = "Saber"
product = "Saber"
name = "Saber"
marketname = "HONOR WIN Turbo"
fingerprint = ""

[templates."honor_brm_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR WIN2"
device = "BarrettM"
product = "BarrettM"
name = "BarrettM"
marketname = "HONOR WIN2"
fingerprint = ""

[templates."honor_brt_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR WIN RT2"
device = "Barrett"
product = "Barrett"
name = "Barrett"
marketname = "HONOR WIN RT2"
fingerprint = ""

[templates."honor_brs_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR WIN Turbo2"
device = "BarrettS"
product = "BarrettS"
name = "BarrettS"
marketname = "HONOR WIN Turbo2"
fingerprint = ""

[templates."honor_g750_t00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 3X 双"
device = "G750-T00"
product = "G750-T00"
marketname = "HONOR 3X 双"
fingerprint = ""

[templates."honor_g750_u00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 3X"
device = "G750-U00"
product = "G750-U00"
marketname = "HONOR 3X"
fingerprint = ""

[templates."honor_g750_t20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 3X Pro"
device = "G750-T20"
product = "G750-T20"
marketname = "HONOR 3X Pro"
fingerprint = ""

[templates."honor_g750_t01"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 真八核畅玩版"
device = "G750-T01"
product = "G750-T01"
marketname = "HONOR 真八核畅玩版"
fingerprint = ""

[templates."honor_che1_cl20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 4X"
device = "Cherry"
product = "Cherry"
name = "Cherry"
marketname = "HONOR 畅玩 4X"
fingerprint = ""

[templates."honor_che2_tl00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 4X 移动渠道版"
device = "Cherryplus"
product = "Cherryplus"
name = "Cherryplus"
marketname = "HONOR 畅玩 4X 移动渠道版"
fingerprint = ""

[templates."honor_kiw_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 5X"
device = "Kiwi"
product = "Kiwi"
name = "Kiwi"
marketname = "HONOR 畅玩 5X"
fingerprint = ""

[templates."honor_bln_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 6X"
device = "Berlin"
product = "Berlin"
name = "Berlin"
marketname = "HONOR 畅玩 6X"
fingerprint = ""

[templates."honor_bnd_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 7X"
device = "Bond"
product = "Bond"
name = "Bond"
marketname = "HONOR 畅玩 7X"
fingerprint = ""

[templates."honor_jsn_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 8X"
device = "Johnson"
product = "Johnson"
name = "Johnson"
marketname = "HONOR 8X"
fingerprint = ""

[templates."honor_are_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 8X Max"
device = "Ares"
product = "Ares"
name = "Ares"
marketname = "HONOR 8X Max"
fingerprint = ""

[templates."honor_hlk_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 9X"
device = "Hulk"
product = "Hulk"
name = "Hulk"
marketname = "HONOR 9X"
fingerprint = ""

[templates."honor_hlk_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 9X PRO"
device = "Hulk"
product = "Hulk"
name = "Hulk"
marketname = "HONOR 9X PRO"
fingerprint = ""

[templates."honor_tel_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X10 5G"
device = "Teller"
product = "Teller"
name = "Teller"
marketname = "HONOR X10 5G"
fingerprint = ""

[templates."honor_kkg_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X10 Max 5G"
device = "Kingkong"
product = "Kingkong"
name = "Kingkong"
marketname = "HONOR X10 Max 5G"
fingerprint = ""

[templates."honor_ntn_an20"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X20 5G"
device = "NewtonH"
product = "NewtonH"
name = "NewtonH"
marketname = "HONOR X20 5G"
fingerprint = ""

[templates."honor_chl_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X20 SE 5G"
device = "Chanel"
product = "Chanel"
name = "Chanel"
marketname = "HONOR X20 SE 5G"
fingerprint = ""

[templates."honor_any_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X30 5G"
device = "Andy"
product = "Andy"
name = "Andy"
marketname = "HONOR X30 5G"
fingerprint = ""

[templates."honor_tfy_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X30i 5G"
device = "Tiffany"
product = "Tiffany"
name = "Tiffany"
marketname = "HONOR X30i 5G"
fingerprint = ""

[templates."honor_kkg_an70"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X30 Max 5G"
device = "Kingkong"
product = "Kingkong"
name = "Kingkong"
marketname = "HONOR X30 Max 5G"
fingerprint = ""

[templates."honor_rmo_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X40"
device = "Rambo"
product = "Rambo"
name = "Rambo"
marketname = "HONOR X40"
fingerprint = ""

[templates."honor_dio_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X40i"
device = "Dior"
product = "Dior"
name = "Dior"
marketname = "HONOR X40i"
fingerprint = ""

[templates."honor_adt_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X40 GT"
device = "AndyGT"
product = "AndyGT"
name = "AndyGT"
marketname = "HONOR X40 GT"
fingerprint = ""

[templates."honor_ali_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X50"
device = "Ali"
product = "Ali"
name = "Ali"
marketname = "HONOR X50"
fingerprint = ""

[templates."honor_alp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X50 Pro"
device = "AliP"
product = "AliP"
name = "AliP"
marketname = "HONOR X50 Pro"
fingerprint = ""

[templates."honor_crt_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X50i"
device = "Cartier"
product = "Cartier"
name = "Cartier"
marketname = "HONOR X50i"
fingerprint = ""

[templates."honor_lly_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X50i+"
device = "Lily"
product = "Lily"
name = "Lily"
marketname = "HONOR X50i+"
fingerprint = ""

[templates."honor_brc_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X60"
device = "Bruce"
product = "Bruce"
name = "Bruce"
marketname = "HONOR X60"
fingerprint = ""

[templates."honor_brp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X60 Pro"
device = "BruceP"
product = "BruceP"
name = "BruceP"
marketname = "HONOR X60 Pro"
fingerprint = ""

[templates."honor_brp_an80"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X60 Pro 卫星版"
device = "BruceP"
product = "BruceP"
name = "BruceP"
marketname = "HONOR X60 Pro 卫星版"
fingerprint = ""

[templates."honor_lyn_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X60i"
device = "LilyN"
product = "LilyN"
name = "LilyN"
marketname = "HONOR X60i"
fingerprint = ""

[templates."honor_agi_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X60 GT"
device = "MinaGTI"
product = "MinaGTI"
name = "MinaGTI"
marketname = "HONOR X60 GT"
fingerprint = ""

[templates."honor_mtn_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X70"
device = "MTN-AN00"
product = "MTN-AN00"
marketname = "HONOR X70"
fingerprint = ""

[templates."honor_abr_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X70i"
device = "Amber"
product = "Amber"
name = "Amber"
marketname = "HONOR X70i"
fingerprint = ""

[templates."honor_bsn_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X80 Pro Max"
device = "BSN-AN00"
product = "BSN-AN00"
marketname = "HONOR X80 Pro Max"
fingerprint = ""

[templates."honor_lna_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X80i"
device = "Luna"
product = "Luna"
name = "Luna"
marketname = "HONOR X80i"
fingerprint = ""

[templates."honor_jmm_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR V9 Play"
device = "Jimmy"
product = "Jimmy"
name = "Jimmy"
marketname = "HONOR V9 Play"
fingerprint = ""

[templates."honor_jmm_tl00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR V9 Play 移动定制"
device = "Jimmy"
product = "Jimmy"
name = "Jimmy"
marketname = "HONOR V9 Play 移动定制"
fingerprint = ""

[templates."honor_cor_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play"
device = "Cornell"
product = "Cornell"
name = "Cornell"
marketname = "HONOR Play"
fingerprint = ""

[templates."honor_cor_tl10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play 移动 4G+"
device = "Cornell"
product = "Cornell"
name = "Cornell"
marketname = "HONOR Play 移动 4G+"
fingerprint = ""

[templates."honor_ask_al00x"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play3"
device = "Asoka"
product = "Asoka"
name = "Asoka"
marketname = "HONOR Play3"
fingerprint = ""

[templates."honor_ksa_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play3e"
device = "Katyusha"
product = "Katyusha"
name = "Katyusha"
marketname = "HONOR Play3e"
fingerprint = ""

[templates."honor_aka_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play4T"
device = "Asoka"
product = "Asoka"
name = "Asoka"
marketname = "HONOR Play4T"
fingerprint = ""

[templates."honor_aqm_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play4T Pro"
device = "Aquaman"
product = "Aquaman"
name = "Aquaman"
marketname = "HONOR Play4T Pro"
fingerprint = ""

[templates."honor_tnnh_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play4 5G"
device = "TianshanH"
product = "TianshanH"
name = "TianshanH"
marketname = "HONOR Play4 5G"
fingerprint = ""

[templates."honor_oxp_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play4 Pro 5G"
device = "OxfordPL"
product = "OxfordPL"
name = "OxfordPL"
marketname = "HONOR Play4 Pro 5G"
fingerprint = ""

[templates."honor_hjc_an90"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play5 5G"
device = "JessicaH"
product = "JessicaH"
name = "JessicaH"
marketname = "HONOR Play5 5G"
fingerprint = ""

[templates."honor_new_an90"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play5 活力版 5G"
device = "NewtonH"
product = "NewtonH"
name = "NewtonH"
marketname = "HONOR Play5 活力版 5G"
fingerprint = ""

[templates."honor_koz_al40"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play5T"
device = "KonanZ"
product = "KonanZ"
name = "KonanZ"
marketname = "HONOR Play5T"
fingerprint = ""

[templates."honor_nza_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play5T 活力版"
device = "Nezha"
product = "Nezha"
name = "Nezha"
marketname = "HONOR Play5T 活力版"
fingerprint = ""

[templates."honor_chl_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play5T Pro"
device = "Chanel"
product = "Chanel"
name = "Chanel"
marketname = "HONOR Play5T Pro"
fingerprint = ""

[templates."honor_cma_an40"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play6T 5G"
device = "Carmella"
product = "Carmella"
name = "Carmella"
marketname = "HONOR Play6T 5G"
fingerprint = ""

[templates."honor_tfy_an40"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play6T Pro 5G"
device = "Tiffany"
product = "Tiffany"
name = "Tiffany"
marketname = "HONOR Play6T Pro 5G"
fingerprint = ""

[templates."honor_vne_an40"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play6C 5G"
device = "Vinnie"
product = "Vinnie"
name = "Vinnie"
marketname = "HONOR Play6C 5G"
fingerprint = ""

[templates."honor_rky_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play7T 5G"
device = "Rocky"
product = "Rocky"
name = "Rocky"
marketname = "HONOR Play7T 5G"
fingerprint = ""

[templates."honor_clk_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play8T 5G"
device = "Clark"
product = "Clark"
name = "Clark"
marketname = "HONOR Play8T 5G"
fingerprint = ""

[templates."honor_alt_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play9T 5G"
device = "Alita"
product = "Alita"
name = "Alita"
marketname = "HONOR Play9T 5G"
fingerprint = ""

[templates."honor_jdy_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play9C 5G"
device = "Judy"
product = "Judy"
name = "Judy"
marketname = "HONOR Play9C 5G"
fingerprint = ""

[templates."honor_log_an10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play10 5G"
device = "Logan"
product = "Logan"
name = "Logan"
marketname = "HONOR Play10 5G"
fingerprint = ""

[templates."honor_nic_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play10C 5G"
device = "Nick"
product = "Nick"
name = "Nick"
marketname = "HONOR Play10C 5G"
fingerprint = ""

[templates."honor_nla_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play10A 5G"
device = "Nala"
product = "Nala"
name = "Nala"
marketname = "HONOR Play10A 5G"
fingerprint = ""

[templates."honor_mrk_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play11 5G"
device = "Mark"
product = "Mark"
name = "Mark"
marketname = "HONOR Play11 5G"
fingerprint = ""

[templates."honor_lab_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Play11T 5G"
device = "Labu"
product = "Labu"
name = "Labu"
marketname = "HONOR Play11T 5G"
fingerprint = ""

[templates."honor_dvd_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Power"
device = "David"
product = "David"
name = "David"
marketname = "HONOR Power"
fingerprint = ""

[templates."honor_dvd_an80"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Power 卫星版"
device = "David"
product = "David"
name = "David"
marketname = "HONOR Power 卫星版"
fingerprint = ""

[templates."honor_edi_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Note8"
device = "Edison"
product = "Edison"
name = "Edison"
marketname = "HONOR Note8"
fingerprint = ""

[templates."honor_rvl_al09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Note10"
device = "Ravel"
product = "Ravel"
name = "Ravel"
marketname = "HONOR Note10"
fingerprint = ""

[templates."honor_h30_t00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 3C"
device = "H30-T00"
product = "H30-T00"
marketname = "HONOR 3C"
fingerprint = ""

[templates."honor_hol_t00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 3C 畅玩版"
device = "Holly"
product = "Holly"
name = "Holly"
marketname = "HONOR 3C 畅玩版"
fingerprint = ""

[templates."honor_chm_tl00h"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 4C 移动渠道版"
device = "Cherrymini"
product = "Cherrymini"
name = "Cherrymini"
marketname = "HONOR 畅玩 4C 移动渠道版"
fingerprint = ""

[templates."honor_chm_tl00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 4C"
device = "Cherrymini"
product = "Cherrymini"
name = "Cherrymini"
marketname = "HONOR 畅玩 4C"
fingerprint = ""

[templates."honor_scl_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 4A"
device = "Scale"
product = "Scale"
name = "Scale"
marketname = "HONOR 4A"
fingerprint = ""

[templates."honor_scl_tl00h"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 4A 移动渠道版"
device = "Scale"
product = "Scale"
name = "Scale"
marketname = "HONOR 4A 移动渠道版"
fingerprint = ""

[templates."honor_g621_tl00m"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 4 移动渠道版"
device = "G621-TL00M"
product = "G621-TL00M"
marketname = "HONOR 畅玩 4 移动渠道版"
fingerprint = ""

[templates."honor_g621_tl00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 4"
device = "G621-TL00"
product = "G621-TL00"
marketname = "HONOR 畅玩 4"
fingerprint = ""

[templates."honor_nem_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 5C"
device = "Nemo"
product = "Nemo"
name = "Nemo"
marketname = "HONOR 畅玩 5C"
fingerprint = ""

[templates."honor_cam_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 5A"
device = "Cambodia"
product = "Cambodia"
name = "Cambodia"
marketname = "HONOR 畅玩 5A"
fingerprint = ""

[templates."honor_cam_tl00h"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 5A 移动渠道版"
device = "Cambodia"
product = "Cambodia"
name = "Cambodia"
marketname = "HONOR 畅玩 5A 移动渠道版"
fingerprint = ""

[templates."honor_cam_tl00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 5A 移动增强版"
device = "Cambodia"
product = "Cambodia"
name = "Cambodia"
marketname = "HONOR 畅玩 5A 移动增强版"
fingerprint = ""

[templates."honor_cun_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 5"
device = "Cancun"
product = "Cancun"
name = "Cancun"
marketname = "HONOR 畅玩 5"
fingerprint = ""

[templates."honor_dli_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 6A"
device = "Delhi"
product = "Delhi"
name = "Delhi"
marketname = "HONOR 畅玩 6A"
fingerprint = ""

[templates."honor_mya_al10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 6"
device = "Maya"
product = "Maya"
name = "Maya"
marketname = "HONOR 畅玩 6"
fingerprint = ""

[templates."honor_lnd_al30"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 7C"
device = "London"
product = "London"
name = "London"
marketname = "HONOR 畅玩 7C"
fingerprint = ""

[templates."honor_lnd_tl30"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 7C 移动 4G+"
device = "London"
product = "London"
name = "London"
marketname = "HONOR 畅玩 7C 移动 4G+"
fingerprint = ""

[templates."honor_aum_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 7A"
device = "Atomu"
product = "Atomu"
name = "Atomu"
marketname = "HONOR 畅玩 7A"
fingerprint = ""

[templates."honor_aum_tl00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 7A 移动 4G+"
device = "Atomu"
product = "Atomu"
name = "Atomu"
marketname = "HONOR 畅玩 7A 移动 4G+"
fingerprint = ""

[templates."honor_dua_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 7"
device = "Dura"
product = "Dura"
name = "Dura"
marketname = "HONOR 畅玩 7"
fingerprint = ""

[templates."honor_bkk_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 8C"
device = "Bangkok"
product = "Bangkok"
name = "Bangkok"
marketname = "HONOR 畅玩 8C"
fingerprint = ""

[templates."honor_jat_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 8A"
device = "Jakarta"
product = "Jakarta"
name = "Jakarta"
marketname = "HONOR 畅玩 8A"
fingerprint = ""

[templates."honor_ksa_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 8"
device = "Katyusha"
product = "Katyusha"
name = "Katyusha"
marketname = "HONOR 畅玩 8"
fingerprint = ""

[templates."honor_moa_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 9A"
device = "Moana"
product = "Moana"
name = "Moana"
marketname = "HONOR 畅玩 9A"
fingerprint = ""

[templates."honor_koz_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 20"
device = "KonanZ"
product = "KonanZ"
name = "KonanZ"
marketname = "HONOR 畅玩 20"
fingerprint = ""

[templates."honor_koz_al00cm"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 20a"
device = "KonanZ"
product = "KonanZ"
name = "KonanZ"
marketname = "HONOR 畅玩 20a"
fingerprint = ""

[templates."honor_hjc_lx9"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 20 Pro"
device = "JessicaH"
product = "JessicaH"
name = "JessicaH"
marketname = "HONOR 畅玩 20 Pro"
fingerprint = ""

[templates."honor_vne_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 30 5G"
device = "Vinnie"
product = "Vinnie"
name = "Vinnie"
marketname = "HONOR 畅玩 30 5G"
fingerprint = ""

[templates."honor_cma_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 30 Plus 5G"
device = "Carmella"
product = "Carmella"
name = "Carmella"
marketname = "HONOR 畅玩 30 Plus 5G"
fingerprint = ""

[templates."honor_wdy_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 40 5G"
device = "Woody"
product = "Woody"
name = "Woody"
marketname = "HONOR 畅玩 40 5G"
fingerprint = ""

[templates."honor_rky_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 40 Plus 5G"
device = "Rocky"
product = "Rocky"
name = "Rocky"
marketname = "HONOR 畅玩 40 Plus 5G"
fingerprint = ""

[templates."honor_log_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 70 Plus 5G"
device = "Logan"
product = "Logan"
name = "Logan"
marketname = "HONOR 畅玩 70 Plus 5G"
fingerprint = ""

[templates."honor_nla_al00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩 70C"
device = "Nala"
product = "Nala"
name = "Nala"
marketname = "HONOR 畅玩 70C"
fingerprint = ""

[templates."honor_s8_701w"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板"
device = "S8-701w"
product = "S8-701w"
marketname = "HONOR 平板"
fingerprint = ""

[templates."honor_t1_821w"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板优享版"
device = "T1-821w"
product = "T1-821w"
marketname = "HONOR 平板优享版"
fingerprint = ""

[templates."honor_jdn_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 2"
device = "Jordan"
product = "Jordan"
name = "Jordan"
marketname = "HONOR 平板 2"
fingerprint = ""

[templates."honor_ags2_w09hn"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 5 10.1 英寸"
device = "Agassi2"
product = "Agassi2"
name = "Agassi2"
marketname = "HONOR 平板 5 10.1 英寸"
fingerprint = ""

[templates."honor_jdn2_w09hn"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 5 8 英寸"
device = "Jordan2"
product = "Jordan2"
name = "Jordan2"
marketname = "HONOR 平板 5 8 英寸"
fingerprint = ""

[templates."honor_ags3_w09hn"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 6 10.1 英寸"
device = "Agassi3"
product = "Agassi3"
name = "Agassi3"
marketname = "HONOR 平板 6 10.1 英寸"
fingerprint = ""

[templates."honor_agm3_w09hn"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 7 10.1 英寸"
device = "Agassi3M"
product = "Agassi3M"
name = "Agassi3M"
marketname = "HONOR 平板 7 10.1 英寸"
fingerprint = ""

[templates."honor_hey_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 8 12 英寸"
device = "Hendry"
product = "Hendry"
name = "Hendry"
marketname = "HONOR 平板 8 12 英寸"
fingerprint = ""

[templates."honor_hey2_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 9 12.1 英寸"
device = "Hendry2"
product = "Hendry2"
name = "Hendry2"
marketname = "HONOR 平板 9 12.1 英寸"
fingerprint = ""

[templates."honor_hey2_w19"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 9 柔光版 12.1 英寸"
device = "Hendry2"
product = "Hendry2"
name = "Hendry2"
marketname = "HONOR 平板 9 柔光版 12.1 英寸"
fingerprint = ""

[templates."honor_rod_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 9 Pro 12.1 英寸"
device = "Rolland"
product = "Rolland"
name = "Rolland"
marketname = "HONOR 平板 9 Pro 12.1 英寸"
fingerprint = ""

[templates."honor_rod_w19"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 9 Pro 柔光版 12.1 英寸"
device = "Rolland"
product = "Rolland"
name = "Rolland"
marketname = "HONOR 平板 9 Pro 柔光版 12.1 英寸"
fingerprint = ""

[templates."honor_hey3_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 10 12.1 英寸"
device = "Hendry3"
product = "Hendry3"
name = "Hendry3"
marketname = "HONOR 平板 10 12.1 英寸"
fingerprint = ""

[templates."honor_hey3_w10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 10 柔光版 12.1 英寸"
device = "Hendry3"
product = "Hendry3"
name = "Hendry3"
marketname = "HONOR 平板 10 柔光版 12.1 英寸"
fingerprint = ""

[templates."honor_rol_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 10 Pro 11.5 英寸"
device = "Rowling"
product = "Rowling"
name = "Rowling"
marketname = "HONOR 平板 10 Pro 11.5 英寸"
fingerprint = ""

[templates."honor_rol_w10"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 10 Pro 柔光版 11.5 英寸"
device = "Rowling"
product = "Rowling"
name = "Rowling"
marketname = "HONOR 平板 10 Pro 柔光版 11.5 英寸"
fingerprint = ""

[templates."honor_hey4_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 20 12.1 英寸"
device = "Hendry4"
product = "Hendry4"
name = "Hendry4"
marketname = "HONOR 平板 20 12.1 英寸"
fingerprint = ""

[templates."honor_hey4_w19"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 20 柔光版 12.1 英寸"
device = "Hendry4"
product = "Hendry4"
name = "Hendry4"
marketname = "HONOR 平板 20 柔光版 12.1 英寸"
fingerprint = ""

[templates."honor_krj_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 V6 10.4 英寸"
device = "Karajan"
product = "Karajan"
name = "Karajan"
marketname = "HONOR 平板 V6 10.4 英寸"
fingerprint = ""

[templates."honor_krj2_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 V7 10.4 英寸"
device = "Karajan2"
product = "Karajan2"
name = "Karajan2"
marketname = "HONOR 平板 V7 10.4 英寸"
fingerprint = ""

[templates."honor_brt_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 V7 Pro 11 英寸"
device = "Britten"
product = "Britten"
name = "Britten"
marketname = "HONOR 平板 V7 Pro 11 英寸"
fingerprint = ""

[templates."honor_gdi_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 MagicPad 13 英寸"
device = "Gaudi"
product = "Gaudi"
name = "Gaudi"
marketname = "HONOR 平板 MagicPad 13 英寸"
fingerprint = ""

[templates."honor_rod2_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 MagicPad 2 12.3 英寸"
device = "Rolland2"
product = "Rolland2"
name = "Rolland2"
marketname = "HONOR 平板 MagicPad 2 12.3 英寸"
fingerprint = ""

[templates."honor_cga_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 MagicPad 3 13.3 英寸"
device = "Changan"
product = "Changan"
name = "Changan"
marketname = "HONOR 平板 MagicPad 3 13.3 英寸"
fingerprint = ""

[templates."honor_cgl_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR MagicPad 3 12.5 英寸"
device = "Changle"
product = "Changle"
name = "Changle"
marketname = "HONOR MagicPad 3 12.5 英寸"
fingerprint = ""

[templates."honor_ylp_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR MagicPad 3 Pro 13.3 英寸"
device = "YongleP"
product = "YongleP"
name = "YongleP"
marketname = "HONOR MagicPad 3 Pro 13.3 英寸"
fingerprint = ""

[templates."honor_yle_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR MagicPad 3 Pro 12.3 英寸"
device = "Yongle"
product = "Yongle"
name = "Yongle"
marketname = "HONOR MagicPad 3 Pro 12.3 英寸"
fingerprint = ""

[templates."honor_mla_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR MagicPad 4 12.1 英寸"
device = "Mulan"
product = "Mulan"
name = "Mulan"
marketname = "HONOR MagicPad 4 12.1 英寸"
fingerprint = ""

[templates."honor_rol_w60"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 GT 11.5 英寸"
device = "Rowling"
product = "Rowling"
name = "Rowling"
marketname = "HONOR 平板 GT 11.5 英寸"
fingerprint = ""

[templates."honor_rod2_w69"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 GT Pro 12.3 英寸"
device = "Rolland2"
product = "Rolland2"
name = "Rolland2"
marketname = "HONOR 平板 GT Pro 12.3 英寸"
fingerprint = ""

[templates."honor_chg_w60"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 GT2 Pro 12.5 英寸"
device = "Changle"
product = "Changle"
name = "Changle"
marketname = "HONOR 平板 GT2 Pro 12.5 英寸"
fingerprint = ""

[templates."honor_hes_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR WIN 平板"
device = "Hesse"
product = "Hesse"
name = "Hesse"
marketname = "HONOR WIN 平板"
fingerprint = ""

[templates."honor_7d_501u"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X1"
device = "7D-501u"
product = "7D-501u"
marketname = "HONOR X1"
fingerprint = ""

[templates."honor_gem_703l"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR X2"
device = "GEM-703L"
product = "GEM-703L"
marketname = "HONOR X2"
fingerprint = ""

[templates."honor_t1_701u"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩平板"
device = "T1-701u"
product = "T1-701u"
marketname = "HONOR 畅玩平板"
fingerprint = ""

[templates."honor_t1_701ua"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩平板优享版"
device = "T1-701ua"
product = "T1-701ua"
marketname = "HONOR 畅玩平板优享版"
fingerprint = ""

[templates."honor_t1_a21w"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩平板 note"
device = "T1-A21w"
product = "T1-A21w"
marketname = "HONOR 畅玩平板 note"
fingerprint = ""

[templates."honor_kob_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩平板 2 8 英寸"
device = "Kobe"
product = "Kobe"
name = "Kobe"
marketname = "HONOR 畅玩平板 2 8 英寸"
fingerprint = ""

[templates."honor_ags_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩平板 2 9.6 英寸"
device = "Agassi"
product = "Agassi"
name = "Agassi"
marketname = "HONOR 畅玩平板 2 9.6 英寸"
fingerprint = ""

[templates."honor_bg2_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 畅玩平板 2 7 英寸"
device = "Baggio2"
product = "Baggio2"
name = "Baggio2"
marketname = "HONOR 畅玩平板 2 7 英寸"
fingerprint = ""

[templates."honor_agr_w09hn"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 X6 9.7 英寸"
device = "AgassiR"
product = "AgassiR"
name = "AgassiR"
marketname = "HONOR 平板 X6 9.7 英寸"
fingerprint = ""

[templates."honor_kob2_w09hn"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 X7 8 英寸"
device = "Kobe2"
product = "Kobe2"
name = "Kobe2"
marketname = "HONOR 平板 X7 8 英寸"
fingerprint = ""

[templates."honor_eln_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 X8 Pro 11.5 英寸"
device = "Eileen"
product = "Eileen"
name = "Eileen"
marketname = "HONOR 平板 X8 Pro 11.5 英寸"
fingerprint = ""

[templates."honor_ndl_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 X9 11 英寸"
device = "Nadal"
product = "Nadal"
name = "Nadal"
marketname = "HONOR 平板 X9 11 英寸"
fingerprint = ""

[templates."honor_eln2_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 X9 Pro 11.5 英寸"
device = "Eileen2"
product = "Eileen2"
name = "Eileen2"
marketname = "HONOR 平板 X9 Pro 11.5 英寸"
fingerprint = ""

[templates."honor_ndl2_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 X10 11 英寸"
device = "Nadal2"
product = "Nadal2"
name = "Nadal2"
marketname = "HONOR 平板 X10 11 英寸"
fingerprint = ""

[templates."honor_ele2_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 X10 Pro 11.5 英寸"
device = "Eileen2"
product = "Eileen2"
name = "Eileen2"
marketname = "HONOR 平板 X10 Pro 11.5 英寸"
fingerprint = ""

[templates."honor_ele2_w19"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 X10 Pro 柔光版 11.5 英寸"
device = "Eileen2"
product = "Eileen2"
name = "Eileen2"
marketname = "HONOR 平板 X10 Pro 柔光版 11.5 英寸"
fingerprint = ""

[templates."honor_yag_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 X10 Pro Max 13 英寸"
device = "Yaoming"
product = "Yaoming"
name = "Yaoming"
marketname = "HONOR 平板 X10 Pro Max 13 英寸"
fingerprint = ""

[templates."honor_yag_w19"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 X10 Pro Max 柔光版 13 英寸"
device = "Yaoming"
product = "Yaoming"
name = "Yaoming"
marketname = "HONOR 平板 X10 Pro Max 柔光版 13 英寸"
fingerprint = ""

[templates."honor_onl_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 X10 Mini 9.7 英寸"
device = "Oneal"
product = "Oneal"
name = "Oneal"
marketname = "HONOR 平板 X10 Mini 9.7 英寸"
fingerprint = ""

[templates."honor_hdn_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Waterplay 10.1 英寸"
device = "Haydn"
product = "Haydn"
name = "Haydn"
marketname = "HONOR Waterplay 10.1 英寸"
fingerprint = ""

[templates."honor_hdl_w09"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR Waterplay 8 英寸"
device = "Handel"
product = "Handel"
name = "Handel"
marketname = "HONOR Waterplay 8 英寸"
fingerprint = ""

[templates."honor_agm_w09hn"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 Z3 9.7 英寸"
device = "AgassiRM"
product = "AgassiRM"
name = "AgassiRM"
marketname = "HONOR 平板 Z3 9.7 英寸"
fingerprint = ""

[templates."honor_ndl_w00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 Z5a 11 英寸"
device = "Nadal"
product = "Nadal"
name = "Nadal"
marketname = "HONOR 平板 Z5a 11 英寸"
fingerprint = ""

[templates."honor_hey2_an00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 平板 Z7 12.1 英寸"
device = "Hendry2"
product = "Hendry2"
name = "Hendry2"
marketname = "HONOR 平板 Z7 12.1 英寸"
fingerprint = ""

[templates."honor_frd_wdg9"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 猎人游戏本 V700 i5"
device = "FRD-WDG9"
product = "FRD-WDG9"
marketname = "HONOR 猎人游戏本 V700 i5"
fingerprint = ""

[templates."honor_frd_wfd9"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 猎人游戏本 V700 i7"
device = "FRD-WFD9"
product = "FRD-WFD9"
marketname = "HONOR 猎人游戏本 V700 i7"
fingerprint = ""

[templates."honor_nwb_g"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR WIN 游戏本 H7"
device = "NWB-G"
product = "NWB-G"
marketname = "HONOR WIN 游戏本 H7"
fingerprint = ""

[templates."honor_nwc2_g"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR WIN 游戏本 H9"
device = "NWC2-G"
product = "NWC2-G"
marketname = "HONOR WIN 游戏本 H9"
fingerprint = ""

[templates."honor_cgn_a00"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 观影眼镜"
device = "CGN-A00"
product = "CGN-A00"
marketname = "HONOR 观影眼镜"
fingerprint = ""

[templates."honor_u8860"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 1"
device = "U8860"
product = "U8860"
marketname = "HONOR 1"
fingerprint = ""

[templates."honor_t8950"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 1 Plus"
device = "T8950"
product = "T8950"
marketname = "HONOR 1 Plus"
fingerprint = ""

[templates."honor_u9508"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 四核爱享版"
device = "U9508"
product = "U9508"
marketname = "HONOR 四核爱享版"
fingerprint = ""

[templates."honor_hn3_u01"]
manufacturer = "HONOR"
brand = "HONOR"
model = "HONOR 3 outdoor"
device = "HN3-U01"
product = "HN3-U01"
marketname = "HONOR 3 outdoor"
fingerprint = ""

[templates."huawei_huawei_mt1_t00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend Mate"
device = "HUAWEI MT1-T00"
product = "HUAWEI MT1-T00"
marketname = "HUAWEI Ascend Mate"
fingerprint = ""

[templates."huawei_huawei_mt2_u071"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend Mate 2"
device = "HUAWEI MT2-U071"
product = "HUAWEI MT2-U071"
marketname = "HUAWEI Ascend Mate 2"
fingerprint = ""

[templates."huawei_huawei_mt7_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend Mate 7"
device = "Jazz"
product = "Jazz"
name = "Jazz"
marketname = "HUAWEI Ascend Mate 7"
fingerprint = ""

[templates."huawei_huawei_crr_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate S 移动臻享版"
device = "Carrera"
product = "Carrera"
name = "Carrera"
marketname = "HUAWEI Mate S 移动臻享版"
fingerprint = ""

[templates."huawei_huawei_crr_ul00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate S 双 4G 臻享版"
device = "Carrera"
product = "Carrera"
name = "Carrera"
marketname = "HUAWEI Mate S 双 4G 臻享版"
fingerprint = ""

[templates."huawei_huawei_crr_ul20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate S 双 4G 臻逸版"
device = "Carrera"
product = "Carrera"
name = "Carrera"
marketname = "HUAWEI Mate S 双 4G 臻逸版"
fingerprint = ""

[templates."huawei_huawei_crr_cl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate S 电信臻享版"
device = "Carrera"
product = "Carrera"
name = "Carrera"
marketname = "HUAWEI Mate S 电信臻享版"
fingerprint = ""

[templates."huawei_huawei_crr_cl20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate S 电信臻逸版"
device = "Carrera"
product = "Carrera"
name = "Carrera"
marketname = "HUAWEI Mate S 电信臻逸版"
fingerprint = ""

[templates."huawei_huawei_nxt_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 8"
device = "Next"
product = "Next"
name = "Next"
marketname = "HUAWEI Mate 8"
fingerprint = ""

[templates."huawei_mha_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 9"
device = "Manhattan"
product = "Manhattan"
name = "Manhattan"
marketname = "HUAWEI Mate 9"
fingerprint = ""

[templates."huawei_lon_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 9 Pro"
device = "Longland"
product = "Longland"
name = "Longland"
marketname = "HUAWEI Mate 9 Pro"
fingerprint = ""

[templates."huawei_alp_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 10"
device = "Alps"
product = "Alps"
name = "Alps"
marketname = "HUAWEI Mate 10"
fingerprint = ""

[templates."huawei_bla_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 10 Pro"
device = "Blanc"
product = "Blanc"
name = "Blanc"
marketname = "HUAWEI Mate 10 Pro"
fingerprint = ""

[templates."huawei_neo_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate RS 保时捷设计"
device = "Neo"
product = "Neo"
name = "Neo"
marketname = "HUAWEI Mate RS 保时捷设计"
fingerprint = ""

[templates."huawei_hma_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 20"
device = "Hima"
product = "Hima"
name = "Hima"
marketname = "HUAWEI Mate 20"
fingerprint = ""

[templates."huawei_lya_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 20 Pro"
device = "Laya"
product = "Laya"
name = "Laya"
marketname = "HUAWEI Mate 20 Pro"
fingerprint = ""

[templates."huawei_evr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 20 X"
device = "Ever"
product = "Ever"
name = "Ever"
marketname = "HUAWEI Mate 20 X"
fingerprint = ""

[templates."huawei_evr_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 20 X 5G"
device = "Ever"
product = "Ever"
name = "Ever"
marketname = "HUAWEI Mate 20 X 5G"
fingerprint = ""

[templates."huawei_lya_al00p"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 20 RS 保时捷设计"
device = "Laya"
product = "Laya"
name = "Laya"
marketname = "HUAWEI Mate 20 RS 保时捷设计"
fingerprint = ""

[templates."huawei_tas_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 30"
device = "Taurus"
product = "Taurus"
name = "Taurus"
marketname = "HUAWEI Mate 30"
fingerprint = ""

[templates."huawei_tas_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 30 5G"
device = "Taurus"
product = "Taurus"
name = "Taurus"
marketname = "HUAWEI Mate 30 5G"
fingerprint = ""

[templates."huawei_lio_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 30 Pro"
device = "Lion"
product = "Lion"
name = "Lion"
marketname = "HUAWEI Mate 30 Pro"
fingerprint = ""

[templates."huawei_lio_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 30 Pro 5G"
device = "Lion"
product = "Lion"
name = "Lion"
marketname = "HUAWEI Mate 30 Pro 5G"
fingerprint = ""

[templates."huawei_lio_an00m"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 30E Pro 5G"
device = "Lion"
product = "Lion"
name = "Lion"
marketname = "HUAWEI Mate 30E Pro 5G"
fingerprint = ""

[templates."huawei_lio_an00p"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 30 RS 保时捷设计"
device = "Lion"
product = "Lion"
name = "Lion"
marketname = "HUAWEI Mate 30 RS 保时捷设计"
fingerprint = ""

[templates."huawei_oce_an10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 40 5G"
device = "Ocean"
product = "Ocean"
name = "Ocean"
marketname = "HUAWEI Mate 40 5G"
fingerprint = ""

[templates."huawei_oce_an50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 40E 5G"
device = "Ocean"
product = "Ocean"
name = "Ocean"
marketname = "HUAWEI Mate 40E 5G"
fingerprint = ""

[templates."huawei_oce_al50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 40E 4G"
device = "Ocean"
product = "Ocean"
name = "Ocean"
marketname = "HUAWEI Mate 40E 4G"
fingerprint = ""

[templates."huawei_noh_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 40 Pro 5G"
device = "Noah"
product = "Noah"
name = "Noah"
marketname = "HUAWEI Mate 40 Pro 5G"
fingerprint = ""

[templates."huawei_noh_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 40 Pro 4G"
device = "Noah"
product = "Noah"
name = "Noah"
marketname = "HUAWEI Mate 40 Pro 4G"
fingerprint = ""

[templates."huawei_noh_an50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 40E Pro 5G"
device = "Noah"
product = "Noah"
name = "Noah"
marketname = "HUAWEI Mate 40E Pro 5G"
fingerprint = ""

[templates."huawei_nop_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 40 Pro+ 5G"
device = "NoahP"
product = "NoahP"
name = "NoahP"
marketname = "HUAWEI Mate 40 Pro+ 5G"
fingerprint = ""

[templates."huawei_cet_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 50"
device = "Cetus"
product = "Cetus"
name = "Cetus"
marketname = "HUAWEI Mate 50"
fingerprint = ""

[templates."huawei_cet_al60"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 50E"
device = "Cetus-"
product = "Cetus-"
name = "Cetus-"
marketname = "HUAWEI Mate 50E"
fingerprint = ""

[templates."huawei_dco_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 50 Pro"
device = "Draco"
product = "Draco"
name = "Draco"
marketname = "HUAWEI Mate 50 Pro"
fingerprint = ""

[templates."huawei_bra_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 60"
device = "Barry"
product = "Barry"
name = "Barry"
marketname = "HUAWEI Mate 60"
fingerprint = ""

[templates."huawei_aln_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 60 Pro"
device = "Allen"
product = "Allen"
name = "Allen"
marketname = "HUAWEI Mate 60 Pro"
fingerprint = ""

[templates."huawei_aln_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 60 Pro+"
device = "Allen"
product = "Allen"
name = "Allen"
marketname = "HUAWEI Mate 60 Pro+"
fingerprint = ""

[templates."huawei_cls_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 70"
device = "Celestial"
product = "Celestial"
name = "Celestial"
marketname = "HUAWEI Mate 70"
fingerprint = ""

[templates."huawei_plr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 70 Pro"
device = "Pillar"
product = "Pillar"
name = "Pillar"
marketname = "HUAWEI Mate 70 Pro"
fingerprint = ""

[templates."huawei_plr_al50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 70 Pro 优享版"
device = "Pillar"
product = "Pillar"
name = "Pillar"
marketname = "HUAWEI Mate 70 Pro 优享版"
fingerprint = ""

[templates."huawei_pla_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 70 Pro+"
device = "PLA-AL10"
product = "PLA-AL10"
marketname = "HUAWEI Mate 70 Pro+"
fingerprint = ""

[templates."huawei_plu_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 70 RS 非凡大师"
device = "PillarU"
product = "PillarU"
name = "PillarU"
marketname = "HUAWEI Mate 70 RS 非凡大师"
fingerprint = ""

[templates."huawei_sup_al90"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 70 Air"
device = "Superman"
product = "Superman"
name = "Superman"
marketname = "HUAWEI Mate 70 Air"
fingerprint = ""

[templates."huawei_vyg_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 80"
device = "Voyager"
product = "Voyager"
name = "Voyager"
marketname = "HUAWEI Mate 80"
fingerprint = ""

[templates."huawei_sgt_al50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 80 Pro"
device = "Sagittarius"
product = "Sagittarius"
name = "Sagittarius"
marketname = "HUAWEI Mate 80 Pro"
fingerprint = ""

[templates."huawei_sgt_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 80 Pro Max"
device = "Sagittarius"
product = "Sagittarius"
name = "Sagittarius"
marketname = "HUAWEI Mate 80 Pro Max"
fingerprint = ""

[templates."huawei_sgu_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 80 RS 非凡大师"
device = "SagittariusU"
product = "SagittariusU"
name = "SagittariusU"
marketname = "HUAWEI Mate 80 RS 非凡大师"
fingerprint = ""

[templates."huawei_hls_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 90"
device = "Halos"
product = "Halos"
name = "Halos"
marketname = "HUAWEI Mate 90"
fingerprint = ""

[templates."huawei_cms_al20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 90 Pro"
device = "Cosmos"
product = "Cosmos"
name = "Cosmos"
marketname = "HUAWEI Mate 90 Pro"
fingerprint = ""

[templates."huawei_cmm_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 90 Pro Max"
device = "CosmosM"
product = "CosmosM"
name = "CosmosM"
marketname = "HUAWEI Mate 90 Pro Max"
fingerprint = ""

[templates."huawei_cmu_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate 90 RS 非凡大师"
device = "CosmosU"
product = "CosmosU"
name = "CosmosU"
marketname = "HUAWEI Mate 90 RS 非凡大师"
fingerprint = ""

[templates."huawei_tah_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate X"
device = "Tahiti"
product = "Tahiti"
name = "Tahiti"
marketname = "HUAWEI Mate X"
fingerprint = ""

[templates."huawei_tah_an00m"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate Xs"
device = "Tahiti"
product = "Tahiti"
name = "Tahiti"
marketname = "HUAWEI Mate Xs"
fingerprint = ""

[templates."huawei_tet_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate X2 5G"
device = "Teton"
product = "Teton"
name = "Teton"
marketname = "HUAWEI Mate X2 5G"
fingerprint = ""

[templates."huawei_tet_an50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate X2 典藏版 5G"
device = "Teton"
product = "Teton"
name = "Teton"
marketname = "HUAWEI Mate X2 典藏版 5G"
fingerprint = ""

[templates."huawei_tet_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate X2 4G"
device = "Teton"
product = "Teton"
name = "Teton"
marketname = "HUAWEI Mate X2 4G"
fingerprint = ""

[templates."huawei_pal_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate Xs 2"
device = "Palau"
product = "Palau"
name = "Palau"
marketname = "HUAWEI Mate Xs 2"
fingerprint = ""

[templates."huawei_alt_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate X3"
device = "Alta"
product = "Alta"
name = "Alta"
marketname = "HUAWEI Mate X3"
fingerprint = ""

[templates."huawei_alt_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate X5"
device = "Alta"
product = "Alta"
name = "Alta"
marketname = "HUAWEI Mate X5"
fingerprint = ""

[templates."huawei_grl_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate XT 非凡大师"
device = "Greenlan"
product = "Greenlan"
name = "Greenlan"
marketname = "HUAWEI Mate XT 非凡大师"
fingerprint = ""

[templates."huawei_icl_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate X6"
device = "Icelan"
product = "Icelan"
name = "Icelan"
marketname = "HUAWEI Mate X6"
fingerprint = ""

[templates."huawei_icl_al20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate X6 典藏版"
device = "Icelan"
product = "Icelan"
name = "Icelan"
marketname = "HUAWEI Mate X6 典藏版"
fingerprint = ""

[templates."huawei_grl_al20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate XTs 非凡大师"
device = "Greenlan"
product = "Greenlan"
name = "Greenlan"
marketname = "HUAWEI Mate XTs 非凡大师"
fingerprint = ""

[templates."huawei_del_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate X7"
device = "Delphi"
product = "Delphi"
name = "Delphi"
marketname = "HUAWEI Mate X7"
fingerprint = ""

[templates."huawei_del_al20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate X7 典藏版"
device = "Delphi"
product = "Delphi"
name = "Delphi"
marketname = "HUAWEI Mate X7 典藏版"
fingerprint = ""

[templates."huawei_lap_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Mate XT 2 非凡大师"
device = "Laptua"
product = "Laptua"
name = "Laptua"
marketname = "HUAWEI Mate XT 2 非凡大师"
fingerprint = ""

[templates."huawei_huawei_u9200"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend P1"
device = "HUAWEI U9200"
product = "HUAWEI U9200"
marketname = "HUAWEI Ascend P1"
fingerprint = ""

[templates."huawei_huawei_u9200e"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend P1 XL"
device = "HUAWEI U9200E"
product = "HUAWEI U9200E"
marketname = "HUAWEI Ascend P1 XL"
fingerprint = ""

[templates."huawei_huawei_u9200s"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend P1 S"
device = "HUAWEI U9200S"
product = "HUAWEI U9200S"
marketname = "HUAWEI Ascend P1 S"
fingerprint = ""

[templates."huawei_huawei_p2_0000"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend P2"
device = "HUAWEI P2-0000"
product = "HUAWEI P2-0000"
marketname = "HUAWEI Ascend P2"
fingerprint = ""

[templates."huawei_huawei_p6_t00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend P6 移动渠道版"
device = "Edge"
product = "Edge"
name = "Edge"
marketname = "HUAWEI Ascend P6 移动渠道版"
fingerprint = ""

[templates."huawei_huawei_p6_t00v"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend P6"
device = "Edge"
product = "Edge"
name = "Edge"
marketname = "HUAWEI Ascend P6"
fingerprint = ""

[templates."huawei_huawei_p6_s_u06"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend P6S"
device = "HUAWEI P6 S-U06"
product = "HUAWEI P6 S-U06"
marketname = "HUAWEI Ascend P6S"
fingerprint = ""

[templates."huawei_huawei_p7_l00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend P7"
device = "Sophia"
product = "Sophia"
name = "Sophia"
marketname = "HUAWEI Ascend P7"
fingerprint = ""

[templates."huawei_huawei_p7_l05"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend P7 移动渠道版"
device = "Sophia"
product = "Sophia"
name = "Sophia"
marketname = "HUAWEI Ascend P7 移动渠道版"
fingerprint = ""

[templates."huawei_huawei_gra_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P8"
device = "Grace"
product = "Grace"
name = "Grace"
marketname = "HUAWEI P8"
fingerprint = ""

[templates."huawei_huawei_gra_ul00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P8 双 4G"
device = "Grace"
product = "Grace"
name = "Grace"
marketname = "HUAWEI P8 双 4G"
fingerprint = ""

[templates."huawei_huawei_ale_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P8 青春版"
device = "Alice"
product = "Alice"
name = "Alice"
marketname = "HUAWEI P8 青春版"
fingerprint = ""

[templates."huawei_dav_703l"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P8 Max"
device = "DAV-703L"
product = "DAV-703L"
marketname = "HUAWEI P8 Max"
fingerprint = ""

[templates."huawei_eva_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P9"
device = "Eva"
product = "Eva"
name = "Eva"
marketname = "HUAWEI P9"
fingerprint = ""

[templates."huawei_vie_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P9 Plus"
device = "Vienna"
product = "Vienna"
name = "Vienna"
marketname = "HUAWEI P9 Plus"
fingerprint = ""

[templates."huawei_vtr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P10"
device = "Victoria"
product = "Victoria"
name = "Victoria"
marketname = "HUAWEI P10"
fingerprint = ""

[templates."huawei_vky_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P10 Plus"
device = "Vicky"
product = "Vicky"
name = "Vicky"
marketname = "HUAWEI P10 Plus"
fingerprint = ""

[templates."huawei_eml_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P20"
device = "Emily"
product = "Emily"
name = "Emily"
marketname = "HUAWEI P20"
fingerprint = ""

[templates."huawei_clt_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P20 Pro"
device = "Charlotte"
product = "Charlotte"
name = "Charlotte"
marketname = "HUAWEI P20 Pro"
fingerprint = ""

[templates."huawei_clt_al00l"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P20 Pro 真皮限量版"
device = "Charlotte"
product = "Charlotte"
name = "Charlotte"
marketname = "HUAWEI P20 Pro 真皮限量版"
fingerprint = ""

[templates."huawei_ele_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P30"
device = "Elle"
product = "Elle"
name = "Elle"
marketname = "HUAWEI P30"
fingerprint = ""

[templates."huawei_vog_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P30 Pro"
device = "Vogue"
product = "Vogue"
name = "Vogue"
marketname = "HUAWEI P30 Pro"
fingerprint = ""

[templates."huawei_ana_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P40 4G"
device = "Anna"
product = "Anna"
name = "Anna"
marketname = "HUAWEI P40 4G"
fingerprint = ""

[templates."huawei_ana_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P40 5G"
device = "Anna"
product = "Anna"
name = "Anna"
marketname = "HUAWEI P40 5G"
fingerprint = ""

[templates."huawei_els_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P40 Pro 5G"
device = "Elsa"
product = "Elsa"
name = "Elsa"
marketname = "HUAWEI P40 Pro 5G"
fingerprint = ""

[templates."huawei_els_an10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P40 Pro+ 5G"
device = "ElsaP"
product = "ElsaP"
name = "ElsaP"
marketname = "HUAWEI P40 Pro+ 5G"
fingerprint = ""

[templates."huawei_abr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P50"
device = "Amber"
product = "Amber"
name = "Amber"
marketname = "HUAWEI P50"
fingerprint = ""

[templates."huawei_abr_al60"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P50E"
device = "Amber"
product = "Amber"
name = "Amber"
marketname = "HUAWEI P50E"
fingerprint = ""

[templates."huawei_jad_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P50 Pro"
device = "Jade"
product = "Jade"
name = "Jade"
marketname = "HUAWEI P50 Pro"
fingerprint = ""

[templates."huawei_bal_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P50 Pocket"
device = "Bali"
product = "Bali"
name = "Bali"
marketname = "HUAWEI P50 Pocket"
fingerprint = ""

[templates."huawei_lna_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P60"
device = "Leona"
product = "Leona"
name = "Leona"
marketname = "HUAWEI P60"
fingerprint = ""

[templates."huawei_mna_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI P60 Pro"
device = "Mona"
product = "Mona"
name = "Mona"
marketname = "HUAWEI P60 Pro"
fingerprint = ""

[templates."huawei_ady_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura 70"
device = "Audrey"
product = "Audrey"
name = "Audrey"
marketname = "HUAWEI Pura 70"
fingerprint = ""

[templates."huawei_ady_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura 70 北斗卫星消息版"
device = "Audrey"
product = "Audrey"
name = "Audrey"
marketname = "HUAWEI Pura 70 北斗卫星消息版"
fingerprint = ""

[templates."huawei_hbn_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura 70 Pro"
device = "Hepburn"
product = "Hepburn"
name = "Hepburn"
marketname = "HUAWEI Pura 70 Pro"
fingerprint = ""

[templates."huawei_hbn_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura 70 Pro+"
device = "Hepburn"
product = "Hepburn"
name = "Hepburn"
marketname = "HUAWEI Pura 70 Pro+"
fingerprint = ""

[templates."huawei_hbp_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura 70 Ultra"
device = "HepburnP"
product = "HepburnP"
name = "HepburnP"
marketname = "HUAWEI Pura 70 Ultra"
fingerprint = ""

[templates."huawei_hed_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura 80"
device = "Hedy"
product = "Hedy"
name = "Hedy"
marketname = "HUAWEI Pura 80"
fingerprint = ""

[templates."huawei_lmr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura 80 Pro"
device = "Lamarr"
product = "Lamarr"
name = "Lamarr"
marketname = "HUAWEI Pura 80 Pro"
fingerprint = ""

[templates."huawei_lmr_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura 80 Pro+"
device = "LamarrU"
product = "LamarrU"
name = "LamarrU"
marketname = "HUAWEI Pura 80 Pro+"
fingerprint = ""

[templates."huawei_kee_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura 90"
device = "Klee"
product = "Klee"
name = "Klee"
marketname = "HUAWEI Pura 90"
fingerprint = ""

[templates."huawei_mln_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura 90 Pro"
device = "Malena"
product = "Malena"
name = "Malena"
marketname = "HUAWEI Pura 90 Pro"
fingerprint = ""

[templates."huawei_sca_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura 90 Pro Max"
device = "Sicilia"
product = "Sicilia"
name = "Sicilia"
marketname = "HUAWEI Pura 90 Pro Max"
fingerprint = ""

[templates."huawei_lci_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura 90 Plus"
device = "Lucia"
product = "Lucia"
name = "Lucia"
marketname = "HUAWEI Pura 90 Plus"
fingerprint = ""

[templates."huawei_vde_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura X"
device = "Verde"
product = "Verde"
name = "Verde"
marketname = "HUAWEI Pura X"
fingerprint = ""

[templates."huawei_vde_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura X 典藏版"
device = "Verde"
product = "Verde"
name = "Verde"
marketname = "HUAWEI Pura X 典藏版"
fingerprint = ""

[templates."huawei_hop_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura X Max"
device = "Hope"
product = "Hope"
name = "Hope"
marketname = "HUAWEI Pura X Max"
fingerprint = ""

[templates."huawei_hop_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura X Max 典藏版"
device = "Hope"
product = "Hope"
name = "Hope"
marketname = "HUAWEI Pura X Max 典藏版"
fingerprint = ""

[templates."huawei_vol_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pura X View"
device = "Volcano"
product = "Volcano"
name = "Volcano"
marketname = "HUAWEI Pura X View"
fingerprint = ""

[templates."huawei_bal_al60"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pocket S"
device = "Bali"
product = "Bali"
name = "Bali"
marketname = "HUAWEI Pocket S"
fingerprint = ""

[templates."huawei_lem_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pocket 2"
device = "Lem"
product = "Lem"
name = "Lem"
marketname = "HUAWEI Pocket 2"
fingerprint = ""

[templates."huawei_lem_al50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Pocket 2 优享版"
device = "Lem"
product = "Lem"
name = "Lem"
marketname = "HUAWEI Pocket 2 优享版"
fingerprint = ""

[templates."huawei_huawei_caz_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova"
device = "Cannes"
product = "Cannes"
name = "Cannes"
marketname = "HUAWEI nova"
fingerprint = ""

[templates."huawei_huawei_caz_tl10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 移动定制"
device = "Cannes"
product = "Cannes"
name = "Cannes"
marketname = "HUAWEI nova 移动定制"
fingerprint = ""

[templates."huawei_was_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 青春版"
device = "Warsaw"
product = "Warsaw"
name = "Warsaw"
marketname = "HUAWEI nova 青春版"
fingerprint = ""

[templates."huawei_pic_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 2"
device = "Picasso"
product = "Picasso"
name = "Picasso"
marketname = "HUAWEI nova 2"
fingerprint = ""

[templates."huawei_bac_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 2 Plus"
device = "Barca"
product = "Barca"
name = "Barca"
marketname = "HUAWEI nova 2 Plus"
fingerprint = ""

[templates."huawei_hwi_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 2s"
device = "Hawaii"
product = "Hawaii"
name = "Hawaii"
marketname = "HUAWEI nova 2s"
fingerprint = ""

[templates."huawei_ane_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 3e"
device = "Anne"
product = "Anne"
name = "Anne"
marketname = "HUAWEI nova 3e"
fingerprint = ""

[templates."huawei_par_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 3"
device = "Paris"
product = "Paris"
name = "Paris"
marketname = "HUAWEI nova 3"
fingerprint = ""

[templates."huawei_ine_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 3i"
device = "Sydneyi"
product = "Sydneyi"
name = "Sydneyi"
marketname = "HUAWEI nova 3i"
fingerprint = ""

[templates."huawei_vce_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 4"
device = "Venice"
product = "Venice"
name = "Venice"
marketname = "HUAWEI nova 4"
fingerprint = ""

[templates."huawei_mar_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 4e"
device = "Marie"
product = "Marie"
name = "Marie"
marketname = "HUAWEI nova 4e"
fingerprint = ""

[templates."huawei_sea_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 5"
device = "Seattle"
product = "Seattle"
name = "Seattle"
marketname = "HUAWEI nova 5"
fingerprint = ""

[templates."huawei_sea_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 5 Pro"
device = "Seattle"
product = "Seattle"
name = "Seattle"
marketname = "HUAWEI nova 5 Pro"
fingerprint = ""

[templates."huawei_glk_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 5i"
device = "Gelk"
product = "Gelk"
name = "Gelk"
marketname = "HUAWEI nova 5i"
fingerprint = ""

[templates."huawei_spn_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 5i Pro"
device = "Saipan"
product = "Saipan"
name = "Saipan"
marketname = "HUAWEI nova 5i Pro"
fingerprint = ""

[templates."huawei_wlz_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 6 4G"
device = "Waltz"
product = "Waltz"
name = "Waltz"
marketname = "HUAWEI nova 6 4G"
fingerprint = ""

[templates."huawei_wlz_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 6 5G"
device = "WaltzS"
product = "WaltzS"
name = "WaltzS"
marketname = "HUAWEI nova 6 5G"
fingerprint = ""

[templates."huawei_jny_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 6 SE"
device = "Jenny"
product = "Jenny"
name = "Jenny"
marketname = "HUAWEI nova 6 SE"
fingerprint = ""

[templates."huawei_jef_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 7 5G"
device = "Jennifer"
product = "Jennifer"
name = "Jennifer"
marketname = "HUAWEI nova 7 5G"
fingerprint = ""

[templates."huawei_jer_an10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 7 Pro 5G"
device = "JenniferR"
product = "JenniferR"
name = "JenniferR"
marketname = "HUAWEI nova 7 Pro 5G"
fingerprint = ""

[templates."huawei_cdy_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 7 SE 5G"
device = "CindyN"
product = "CindyN"
name = "CindyN"
marketname = "HUAWEI nova 7 SE 5G"
fingerprint = ""

[templates."huawei_cnd_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 7 SE 5G 活力版"
device = "CindyMN"
product = "CindyMN"
name = "CindyMN"
marketname = "HUAWEI nova 7 SE 5G 活力版"
fingerprint = ""

[templates."huawei_cdl_an50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 7 SE 5G 乐活版"
device = "CindyL"
product = "CindyL"
name = "CindyL"
marketname = "HUAWEI nova 7 SE 5G 乐活版"
fingerprint = ""

[templates."huawei_ang_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 8 5G"
device = "Angela"
product = "Angela"
name = "Angela"
marketname = "HUAWEI nova 8 5G"
fingerprint = ""

[templates."huawei_brq_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 8 Pro 5G"
device = "Barbie"
product = "Barbie"
name = "Barbie"
marketname = "HUAWEI nova 8 Pro 5G"
fingerprint = ""

[templates."huawei_brq_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 8 Pro 4G"
device = "Barbie"
product = "Barbie"
name = "Barbie"
marketname = "HUAWEI nova 8 Pro 4G"
fingerprint = ""

[templates."huawei_jsc_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 8 SE 5G"
device = "Jessica"
product = "Jessica"
name = "Jessica"
marketname = "HUAWEI nova 8 SE 5G"
fingerprint = ""

[templates."huawei_jsc_al50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 8 SE 4G"
device = "Jessica"
product = "Jessica"
name = "Jessica"
marketname = "HUAWEI nova 8 SE 4G"
fingerprint = ""

[templates."huawei_chl_al60"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 8 SE 活力版"
device = "Chanel"
product = "Chanel"
name = "Chanel"
marketname = "HUAWEI nova 8 SE 活力版"
fingerprint = ""

[templates."huawei_nam_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 9"
device = "NottinghamN"
product = "NottinghamN"
name = "NottinghamN"
marketname = "HUAWEI nova 9"
fingerprint = ""

[templates."huawei_rte_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 9 Pro"
device = "Rena"
product = "Rena"
name = "Rena"
marketname = "HUAWEI nova 9 Pro"
fingerprint = ""

[templates."huawei_jln_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 9 SE"
device = "JuliaQN"
product = "JuliaQN"
name = "JuliaQN"
marketname = "HUAWEI nova 9 SE"
fingerprint = ""

[templates."huawei_nco_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 10"
device = "Nicole"
product = "Nicole"
name = "Nicole"
marketname = "HUAWEI nova 10"
fingerprint = ""

[templates."huawei_gla_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 10 Pro"
device = "Gloria"
product = "Gloria"
name = "Gloria"
marketname = "HUAWEI nova 10 Pro"
fingerprint = ""

[templates."huawei_cha_al80"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 10z"
device = "Chanel"
product = "Chanel"
name = "Chanel"
marketname = "HUAWEI nova 10z"
fingerprint = ""

[templates."huawei_bne_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 10 SE"
device = "Bonnie"
product = "Bonnie"
name = "Bonnie"
marketname = "HUAWEI nova 10 SE"
fingerprint = ""

[templates."huawei_foa_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 11"
device = "Fiona"
product = "Fiona"
name = "Fiona"
marketname = "HUAWEI nova 11"
fingerprint = ""

[templates."huawei_goa_al80"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 11 Pro"
device = "Gloria"
product = "Gloria"
name = "Gloria"
marketname = "HUAWEI nova 11 Pro"
fingerprint = ""

[templates."huawei_goa_al80u"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 11 Ultra"
device = "Gloria"
product = "Gloria"
name = "Gloria"
marketname = "HUAWEI nova 11 Ultra"
fingerprint = ""

[templates."huawei_bon_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 11 SE"
device = "Bonnie"
product = "Bonnie"
name = "Bonnie"
marketname = "HUAWEI nova 11 SE"
fingerprint = ""

[templates."huawei_blk_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 12"
device = "Blake"
product = "Blake"
name = "Blake"
marketname = "HUAWEI nova 12"
fingerprint = ""

[templates."huawei_fin_al60"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 12 活力版"
device = "Fiona"
product = "Fiona"
name = "Fiona"
marketname = "HUAWEI nova 12 活力版"
fingerprint = ""

[templates."huawei_ada_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 12 Pro"
device = "Adela"
product = "Adela"
name = "Adela"
marketname = "HUAWEI nova 12 Pro"
fingerprint = ""

[templates."huawei_ada_al00u"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 12 Ultra"
device = "Adela"
product = "Adela"
name = "Adela"
marketname = "HUAWEI nova 12 Ultra"
fingerprint = ""

[templates."huawei_ada_al10u"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 12 Ultra 星耀版"
device = "Adela"
product = "Adela"
name = "Adela"
marketname = "HUAWEI nova 12 Ultra 星耀版"
fingerprint = ""

[templates."huawei_psd_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova Flip"
device = "Poseidon"
product = "Poseidon"
name = "Poseidon"
marketname = "HUAWEI nova Flip"
fingerprint = ""

[templates."huawei_blk_al80"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 13"
device = "Blake"
product = "Blake"
name = "Blake"
marketname = "HUAWEI nova 13"
fingerprint = ""

[templates."huawei_mis_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 13 Pro"
device = "MillaS"
product = "MillaS"
name = "MillaS"
marketname = "HUAWEI nova 13 Pro"
fingerprint = ""

[templates."huawei_tlr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 14"
device = "Taylor"
product = "Taylor"
name = "Taylor"
marketname = "HUAWEI nova 14"
fingerprint = ""

[templates."huawei_mia_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 14 Pro"
device = "Milla"
product = "Milla"
name = "Milla"
marketname = "HUAWEI nova 14 Pro"
fingerprint = ""

[templates."huawei_mrt_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 14 Ultra"
device = "Margaret"
product = "Margaret"
name = "Margaret"
marketname = "HUAWEI nova 14 Ultra"
fingerprint = ""

[templates."huawei_tyr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 14 活力版"
device = "Taylor"
product = "Taylor"
name = "Taylor"
marketname = "HUAWEI nova 14 活力版"
fingerprint = ""

[templates."huawei_psd_al80"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova Flip S"
device = "Poseidon"
product = "Poseidon"
name = "Poseidon"
marketname = "HUAWEI nova Flip S"
fingerprint = ""

[templates."huawei_psn_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 15"
device = "Pushkin"
product = "Pushkin"
name = "Pushkin"
marketname = "HUAWEI nova 15"
fingerprint = ""

[templates."huawei_kle_al00u"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 15 Pro"
device = "Klee"
product = "Klee"
name = "Klee"
marketname = "HUAWEI nova 15 Pro"
fingerprint = ""

[templates."huawei_sly_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 15 Ultra"
device = "Shelley"
product = "Shelley"
name = "Shelley"
marketname = "HUAWEI nova 15 Ultra"
fingerprint = ""

[templates."huawei_ema_al00u"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 16"
device = "Emilia"
product = "Emilia"
name = "Emilia"
marketname = "HUAWEI nova 16"
fingerprint = ""

[templates."huawei_crs_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 16 Pro"
device = "Chris"
product = "Chris"
name = "Chris"
marketname = "HUAWEI nova 16 Pro"
fingerprint = ""

[templates."huawei_hip_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 16 Ultra"
device = "ChrisP"
product = "ChrisP"
name = "ChrisP"
marketname = "HUAWEI nova 16 Ultra"
fingerprint = ""

[templates."huawei_pkn_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 16z"
device = "Pushkin"
product = "Pushkin"
name = "Pushkin"
marketname = "HUAWEI nova 16z"
fingerprint = ""

[templates."huawei_cas_al50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI nova 16 SE"
device = "Cangshan"
product = "Cangshan"
name = "Cangshan"
marketname = "HUAWEI nova 16 SE"
fingerprint = ""

[templates."huawei_huawei_g6_t00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend G6"
device = "HUAWEI G6-T00"
product = "HUAWEI G6-T00"
marketname = "HUAWEI Ascend G6"
fingerprint = ""

[templates."huawei_huawei_g7_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend G7"
device = "HUAWEI G7-TL00"
product = "HUAWEI G7-TL00"
marketname = "HUAWEI Ascend G7"
fingerprint = ""

[templates."huawei_huawei_rio_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI G7 Plus"
device = "Rio"
product = "Rio"
name = "Rio"
marketname = "HUAWEI G7 Plus"
fingerprint = ""

[templates."huawei_huawei_vns_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI G9 青春版"
device = "Venus"
product = "Venus"
name = "Venus"
marketname = "HUAWEI G9 青春版"
fingerprint = ""

[templates."huawei_huawei_mla_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI G9 Plus"
device = "Milan"
product = "Milan"
name = "Milan"
marketname = "HUAWEI G9 Plus"
fingerprint = ""

[templates."huawei_huawei_a199"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 麦芒 A199"
device = "HUAWEI A199"
product = "HUAWEI A199"
marketname = "HUAWEI 麦芒 A199"
fingerprint = ""

[templates."huawei_huawei_b199"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 麦芒 B199"
device = "HUAWEI B199"
product = "HUAWEI B199"
marketname = "HUAWEI 麦芒 B199"
fingerprint = ""

[templates."huawei_huawei_c199"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 麦芒 C199"
device = "HUAWEI C199"
product = "HUAWEI C199"
marketname = "HUAWEI 麦芒 C199"
fingerprint = ""

[templates."huawei_huawei_c199s"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 麦芒 3S"
device = "HUAWEI C199s"
product = "HUAWEI C199s"
marketname = "HUAWEI 麦芒 3S"
fingerprint = ""

[templates."huawei_huawei_rio_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 麦芒 4"
device = "Rio"
product = "Rio"
name = "Rio"
marketname = "HUAWEI 麦芒 4"
fingerprint = ""

[templates."huawei_huawei_mla_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 麦芒 5"
device = "Milan"
product = "Milan"
name = "Milan"
marketname = "HUAWEI 麦芒 5"
fingerprint = ""

[templates."huawei_rne_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 麦芒 6"
device = "Rhone"
product = "Rhone"
name = "Rhone"
marketname = "HUAWEI 麦芒 6"
fingerprint = ""

[templates."huawei_sne_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 麦芒 7"
device = "SydneyM"
product = "SydneyM"
name = "SydneyM"
marketname = "HUAWEI 麦芒 7"
fingerprint = ""

[templates."huawei_pot_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 麦芒 8"
device = "Potterpro"
product = "Potterpro"
name = "Potterpro"
marketname = "HUAWEI 麦芒 8"
fingerprint = ""

[templates."huawei_tnn_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 麦芒 9 5G"
device = "Tianshan"
product = "Tianshan"
name = "Tianshan"
marketname = "HUAWEI 麦芒 9 5G"
fingerprint = ""

[templates."huawei_huawei_tit_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 5"
device = "HUAWEI TIT-AL00"
product = "HUAWEI TIT-AL00"
marketname = "HUAWEI 畅享 5"
fingerprint = ""

[templates."huawei_huawei_tag_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 5S"
device = "HUAWEI TAG-AL00"
product = "HUAWEI TAG-AL00"
marketname = "HUAWEI 畅享 5S"
fingerprint = ""

[templates."huawei_nce_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 6"
device = "Nice"
product = "Nice"
name = "Nice"
marketname = "HUAWEI 畅享 6"
fingerprint = ""

[templates."huawei_dig_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 6S"
device = "Diego"
product = "Diego"
name = "Diego"
marketname = "HUAWEI 畅享 6S"
fingerprint = ""

[templates."huawei_trt_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 7 Plus"
device = "Toronto"
product = "Toronto"
name = "Toronto"
marketname = "HUAWEI 畅享 7 Plus"
fingerprint = ""

[templates."huawei_sla_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 7"
device = "Selina"
product = "Selina"
name = "Selina"
marketname = "HUAWEI 畅享 7"
fingerprint = ""

[templates."huawei_fig_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 7S"
device = "Figo"
product = "Figo"
name = "Figo"
marketname = "HUAWEI 畅享 7S"
fingerprint = ""

[templates."huawei_fig_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 7S 移动 4G+"
device = "Figo"
product = "Figo"
name = "Figo"
marketname = "HUAWEI 畅享 7S 移动 4G+"
fingerprint = ""

[templates."huawei_fla_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 8 Plus"
device = "Florida"
product = "Florida"
name = "Florida"
marketname = "HUAWEI 畅享 8 Plus"
fingerprint = ""

[templates."huawei_ldn_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 8"
device = "London"
product = "London"
name = "London"
marketname = "HUAWEI 畅享 8"
fingerprint = ""

[templates."huawei_ldn_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 8 移动 4G+"
device = "London"
product = "London"
name = "London"
marketname = "HUAWEI 畅享 8 移动 4G+"
fingerprint = ""

[templates."huawei_atu_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 8e"
device = "Atomu"
product = "Atomu"
name = "Atomu"
marketname = "HUAWEI 畅享 8e"
fingerprint = ""

[templates."huawei_dra_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 8e 青春"
device = "Dura"
product = "Dura"
name = "Dura"
marketname = "HUAWEI 畅享 8e 青春"
fingerprint = ""

[templates."huawei_jkm_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 9 Plus"
device = "Jackman"
product = "Jackman"
name = "Jackman"
marketname = "HUAWEI 畅享 9 Plus"
fingerprint = ""

[templates."huawei_ars_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 MAX"
device = "Ares"
product = "Ares"
name = "Ares"
marketname = "HUAWEI 畅享 MAX"
fingerprint = ""

[templates."huawei_dub_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 9"
device = "Dubai"
product = "Dubai"
name = "Dubai"
marketname = "HUAWEI 畅享 9"
fingerprint = ""

[templates."huawei_dub_tl00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 9 移动 4G+"
device = "Dubai"
product = "Dubai"
name = "Dubai"
marketname = "HUAWEI 畅享 9 移动 4G+"
fingerprint = ""

[templates."huawei_pot_al00a"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 9S"
device = "Potter"
product = "Potter"
name = "Potter"
marketname = "HUAWEI 畅享 9S"
fingerprint = ""

[templates."huawei_mrd_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 9e"
device = "Madrid"
product = "Madrid"
name = "Madrid"
marketname = "HUAWEI 畅享 9e"
fingerprint = ""

[templates."huawei_stk_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 10 Plus"
device = "Stark"
product = "Stark"
name = "Stark"
marketname = "HUAWEI 畅享 10 Plus"
fingerprint = ""

[templates."huawei_art_al00x"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 10"
device = "Arthur"
product = "Arthur"
name = "Arthur"
marketname = "HUAWEI 畅享 10"
fingerprint = ""

[templates."huawei_aqm_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 10S"
device = "Aquaman"
product = "Aquaman"
name = "Aquaman"
marketname = "HUAWEI 畅享 10S"
fingerprint = ""

[templates."huawei_med_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 10e"
device = "Merida"
product = "Merida"
name = "Merida"
marketname = "HUAWEI 畅享 10e"
fingerprint = ""

[templates."huawei_dvc_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 Z 5G"
device = "Davinci"
product = "Davinci"
name = "Davinci"
marketname = "HUAWEI 畅享 Z 5G"
fingerprint = ""

[templates."huawei_dvc_an20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 20 Pro 5G"
device = "Davinci"
product = "Davinci"
name = "Davinci"
marketname = "HUAWEI 畅享 20 Pro 5G"
fingerprint = ""

[templates."huawei_wkg_an00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 20 5G"
device = "Wukong"
product = "Wukong"
name = "Wukong"
marketname = "HUAWEI 畅享 20 5G"
fingerprint = ""

[templates."huawei_frl_an00a"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 20 Plus 5G"
device = "Franklin"
product = "Franklin"
name = "Franklin"
marketname = "HUAWEI 畅享 20 Plus 5G"
fingerprint = ""

[templates."huawei_ppa_al20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 20 SE"
device = "Peppa"
product = "Peppa"
name = "Peppa"
marketname = "HUAWEI 畅享 20 SE"
fingerprint = ""

[templates."huawei_mld_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 20e"
device = "MLD-AL00"
product = "MLD-AL00"
marketname = "HUAWEI 畅享 20e"
fingerprint = ""

[templates."huawei_mga_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 50"
device = "Mega"
product = "Mega"
name = "Mega"
marketname = "HUAWEI 畅享 50"
fingerprint = ""

[templates."huawei_ctr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 50 Pro"
device = "Cartier"
product = "Cartier"
name = "Cartier"
marketname = "HUAWEI 畅享 50 Pro"
fingerprint = ""

[templates."huawei_eve_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 50z"
device = "Eevee"
product = "Eevee"
name = "Eevee"
marketname = "HUAWEI 畅享 50z"
fingerprint = ""

[templates."huawei_mga_al40"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 60"
device = "Mega"
product = "Mega"
name = "Mega"
marketname = "HUAWEI 畅享 60"
fingerprint = ""

[templates."huawei_stg_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 60X"
device = "Santiago"
product = "Santiago"
name = "Santiago"
marketname = "HUAWEI 畅享 60X"
fingerprint = ""

[templates."huawei_mao_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 60 Pro"
device = "Mario"
product = "Mario"
name = "Mario"
marketname = "HUAWEI 畅享 60 Pro"
fingerprint = ""

[templates."huawei_fgd_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 70"
device = "Garfield"
product = "Garfield"
name = "Garfield"
marketname = "HUAWEI 畅享 70"
fingerprint = ""

[templates."huawei_ctr_al20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 70 Pro"
device = "Cartier"
product = "Cartier"
name = "Cartier"
marketname = "HUAWEI 畅享 70 Pro"
fingerprint = ""

[templates."huawei_gfy_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 70S"
device = "Goofy"
product = "Goofy"
name = "Goofy"
marketname = "HUAWEI 畅享 70S"
fingerprint = ""

[templates."huawei_bre_al80"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 70X"
device = "BRE-AL80"
product = "BRE-AL80"
marketname = "HUAWEI 畅享 70X"
fingerprint = ""

[templates."huawei_bre_al00a"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 70X 活力版"
device = "Bruce"
product = "Bruce"
name = "Bruce"
marketname = "HUAWEI 畅享 70X 活力版"
fingerprint = ""

[templates."huawei_juy_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 80"
device = "Judy"
product = "Judy"
name = "Judy"
marketname = "HUAWEI 畅享 80"
fingerprint = ""

[templates."huawei_juy_al80"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 90"
device = "Judy"
product = "Judy"
name = "Judy"
marketname = "HUAWEI 畅享 90"
fingerprint = ""

[templates."huawei_juy_al50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 90 Plus"
device = "Judy"
product = "Judy"
name = "Judy"
marketname = "HUAWEI 畅享 90 Plus"
fingerprint = ""

[templates."huawei_chz_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 90 Pro Max"
device = "Chenzhen"
product = "Chenzhen"
name = "Chenzhen"
marketname = "HUAWEI 畅享 90 Pro Max"
fingerprint = ""

[templates."huawei_jal_al90"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 100"
device = "JAL-AL90"
product = "JAL-AL90"
marketname = "HUAWEI 畅享 100"
fingerprint = ""

[templates."huawei_chz_al60"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 100 Pro"
device = "Chenzhen"
product = "Chenzhen"
name = "Chenzhen"
marketname = "HUAWEI 畅享 100 Pro"
fingerprint = ""

[templates."huawei_yew_al80"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享 100 Pro Max"
device = "Yewen"
product = "Yewen"
name = "Yewen"
marketname = "HUAWEI 畅享 100 Pro Max"
fingerprint = ""

[templates."huawei_s8_301w"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MediaPad M1"
device = "S8-301W"
product = "S8-301W"
marketname = "HUAWEI MediaPad M1"
fingerprint = ""

[templates."huawei_huawei_m2_801w"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 揽阅 M2 8.0"
device = "Mozart"
product = "Mozart"
name = "Mozart"
marketname = "HUAWEI 揽阅 M2 8.0"
fingerprint = ""

[templates."huawei_huawei_m2_a01w"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 揽阅 M2 10.0"
device = "HUAWEI M2-A01W"
product = "HUAWEI M2-A01W"
marketname = "HUAWEI 揽阅 M2 10.0"
fingerprint = ""

[templates."huawei_ple_703l"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 揽阅 M2 青春版 7.0 英寸"
device = "PLE-703L"
product = "PLE-703L"
marketname = "HUAWEI 揽阅 M2 青春版 7.0 英寸"
fingerprint = ""

[templates."huawei_fdr_a01w"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 揽阅 M2 青春版 10.1 英寸"
device = "FDR-A01w"
product = "FDR-A01w"
marketname = "HUAWEI 揽阅 M2 青春版 10.1 英寸"
fingerprint = ""

[templates."huawei_btv_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 M3"
device = "Beethoven"
product = "Beethoven"
name = "Beethoven"
marketname = "HUAWEI 平板 M3"
fingerprint = ""

[templates."huawei_cpn_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 M3 青春版 8.0 英寸"
device = "Chopin"
product = "Chopin"
name = "Chopin"
marketname = "HUAWEI 平板 M3 青春版 8.0 英寸"
fingerprint = ""

[templates."huawei_bah_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 M3 青春版 10.1 英寸"
device = "Bach"
product = "Bach"
name = "Bach"
marketname = "HUAWEI 平板 M3 青春版 10.1 英寸"
fingerprint = ""

[templates."huawei_sht_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 M5 8.4 英寸"
device = "Schubert"
product = "Schubert"
name = "Schubert"
marketname = "HUAWEI 平板 M5 8.4 英寸"
fingerprint = ""

[templates."huawei_cmr_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 M5 10.8 英寸"
device = "Cameron"
product = "Cameron"
name = "Cameron"
marketname = "HUAWEI 平板 M5 10.8 英寸"
fingerprint = ""

[templates."huawei_cmr_w19"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 M5 Pro"
device = "Cameron"
product = "Cameron"
name = "Cameron"
marketname = "HUAWEI 平板 M5 Pro"
fingerprint = ""

[templates."huawei_bah2_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 M5 青春版 10.1 英寸"
device = "Bach2"
product = "Bach2"
name = "Bach2"
marketname = "HUAWEI 平板 M5 青春版 10.1 英寸"
fingerprint = ""

[templates."huawei_jdn2_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 M5 青春版 8 英寸"
device = "Jordan2"
product = "Jordan2"
name = "Jordan2"
marketname = "HUAWEI 平板 M5 青春版 8 英寸"
fingerprint = ""

[templates."huawei_vrd_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 M6 8.4 英寸"
device = "Verdi"
product = "Verdi"
name = "Verdi"
marketname = "HUAWEI 平板 M6 8.4 英寸"
fingerprint = ""

[templates."huawei_vrd_w10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 M6 高能版 8.4 英寸"
device = "Verdi"
product = "Verdi"
name = "Verdi"
marketname = "HUAWEI 平板 M6 高能版 8.4 英寸"
fingerprint = ""

[templates."huawei_scm_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 M6 10.8 英寸"
device = "Schumann"
product = "Schumann"
name = "Schumann"
marketname = "HUAWEI 平板 M6 10.8 英寸"
fingerprint = ""

[templates."huawei_mrx_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 10.8 英寸"
device = "Marx"
product = "Marx"
name = "Marx"
marketname = "HUAWEI MatePad Pro 10.8 英寸"
fingerprint = ""

[templates."huawei_mrr_w29"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 10.8 英寸 2021"
device = "MarxR"
product = "MarxR"
name = "MarxR"
marketname = "HUAWEI MatePad Pro 10.8 英寸 2021"
fingerprint = ""

[templates."huawei_got_w29"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 11 英寸"
device = "Goethe"
product = "Goethe"
name = "Goethe"
marketname = "HUAWEI MatePad Pro 11 英寸"
fingerprint = ""

[templates."huawei_got_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 11 英寸 性能版"
device = "Goethe"
product = "Goethe"
name = "Goethe"
marketname = "HUAWEI MatePad Pro 11 英寸 性能版"
fingerprint = ""

[templates."huawei_xyao_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 11 英寸 2024"
device = "Xiaoyao"
product = "Xiaoyao"
name = "Xiaoyao"
marketname = "HUAWEI MatePad Pro 11 英寸 2024"
fingerprint = ""

[templates."huawei_wgr_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 12.6 英寸 2021"
device = "Wagner"
product = "Wagner"
name = "Wagner"
marketname = "HUAWEI MatePad Pro 12.6 英寸 2021"
fingerprint = ""

[templates."huawei_wgrr_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 12.6 英寸 2022"
device = "WagnerR"
product = "WagnerR"
name = "WagnerR"
marketname = "HUAWEI MatePad Pro 12.6 英寸 2022"
fingerprint = ""

[templates."huawei_pce_w30"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 13.2 英寸"
device = "Poincare"
product = "Poincare"
name = "Poincare"
marketname = "HUAWEI MatePad Pro 13.2 英寸"
fingerprint = ""

[templates."huawei_pce_al30"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 13.2 英寸 SIM 卡版"
device = "Poincare"
product = "Poincare"
name = "Poincare"
marketname = "HUAWEI MatePad Pro 13.2 英寸 SIM 卡版"
fingerprint = ""

[templates."huawei_pce_al40"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 13.2 英寸 典藏版 SIM 卡版"
device = "Poincare"
product = "Poincare"
name = "Poincare"
marketname = "HUAWEI MatePad Pro 13.2 英寸 典藏版 SIM 卡版"
fingerprint = ""

[templates."huawei_mro_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 12.2 英寸"
device = "Miro"
product = "Miro"
name = "Miro"
marketname = "HUAWEI MatePad Pro 12.2 英寸"
fingerprint = ""

[templates."huawei_mro_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 12.2 英寸 SIM 卡版"
device = "Miro"
product = "Miro"
name = "Miro"
marketname = "HUAWEI MatePad Pro 12.2 英寸 SIM 卡版"
fingerprint = ""

[templates."huawei_web_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 13.2 英寸 2025"
device = "Weber"
product = "Weber"
name = "Weber"
marketname = "HUAWEI MatePad Pro 13.2 英寸 2025"
fingerprint = ""

[templates."huawei_web_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 13.2 英寸 2025 典藏版 SIM 卡版"
device = "Weber"
product = "Weber"
name = "Weber"
marketname = "HUAWEI MatePad Pro 13.2 英寸 2025 典藏版 SIM 卡版"
fingerprint = ""

[templates."huawei_web_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 13.2 英寸 2025 SIM 卡版"
device = "Weber"
product = "Weber"
name = "Weber"
marketname = "HUAWEI MatePad Pro 13.2 英寸 2025 SIM 卡版"
fingerprint = ""

[templates."huawei_mrdi_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 12.2 英寸 2025"
device = "Morandi"
product = "Morandi"
name = "Morandi"
marketname = "HUAWEI MatePad Pro 12.2 英寸 2025"
fingerprint = ""

[templates."huawei_gem_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro Max 13.2 英寸"
device = "Gellmann"
product = "Gellmann"
name = "Gellmann"
marketname = "HUAWEI MatePad Pro Max 13.2 英寸"
fingerprint = ""

[templates."huawei_gem_w40"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro Max 13.2 英寸 悦享款"
device = "Gellmann"
product = "Gellmann"
name = "Gellmann"
marketname = "HUAWEI MatePad Pro Max 13.2 英寸 悦享款"
fingerprint = ""

[templates."huawei_dal_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 12 英寸"
device = "Dali"
product = "Dali"
name = "Dali"
marketname = "HUAWEI MatePad Pro 12 英寸"
fingerprint = ""

[templates."huawei_dal_w20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Pro 12 英寸 悦享款"
device = "Dali"
product = "Dali"
name = "Dali"
marketname = "HUAWEI MatePad Pro 12 英寸 悦享款"
fingerprint = ""

[templates."huawei_qxs_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Edge"
device = "Qianxuesen"
product = "Qianxuesen"
name = "Qianxuesen"
marketname = "HUAWEI MatePad Edge"
fingerprint = ""

[templates."huawei_qxs_w20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Edge 液冷版"
device = "Qianxuesen"
product = "Qianxuesen"
name = "Qianxuesen"
marketname = "HUAWEI MatePad Edge 液冷版"
fingerprint = ""

[templates."huawei_dby2_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Air 11.5 英寸"
device = "Debussy2"
product = "Debussy2"
name = "Debussy2"
marketname = "HUAWEI MatePad Air 11.5 英寸"
fingerprint = ""

[templates."huawei_bky_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Air 12 英寸"
device = "Banksy"
product = "Banksy"
name = "Banksy"
marketname = "HUAWEI MatePad Air 12 英寸"
fingerprint = ""

[templates."huawei_lrt_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Air 12 英寸 2025"
device = "Laurent"
product = "Laurent"
name = "Laurent"
marketname = "HUAWEI MatePad Air 12 英寸 2025"
fingerprint = ""

[templates."huawei_wki_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Air 12 英寸 2026 悦享款"
device = "WKI-W00"
product = "WKI-W00"
marketname = "HUAWEI MatePad Air 12 英寸 2026 悦享款"
fingerprint = ""

[templates."huawei_wki_w10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Air 12 英寸 2026"
device = "WKI-W10"
product = "WKI-W10"
marketname = "HUAWEI MatePad Air 12 英寸 2026"
fingerprint = ""

[templates."huawei_ast_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Air Z 12 英寸"
device = "AST-W00"
product = "AST-W00"
marketname = "HUAWEI MatePad Air Z 12 英寸"
fingerprint = ""

[templates."huawei_ast_w30"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Air Z 12 英寸 悦享款"
device = "AST-W30"
product = "AST-W30"
marketname = "HUAWEI MatePad Air Z 12 英寸 悦享款"
fingerprint = ""

[templates."huawei_bah3_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad 10.4 英寸"
device = "Bach3"
product = "Bach3"
name = "Bach3"
marketname = "HUAWEI MatePad 10.4 英寸"
fingerprint = ""

[templates."huawei_bah3_an10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad 5G 10.4 英寸"
device = "Bach3"
product = "Bach3"
name = "Bach3"
marketname = "HUAWEI MatePad 5G 10.4 英寸"
fingerprint = ""

[templates."huawei_scmr_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad 10.8 英寸"
device = "SchumannR"
product = "SchumannR"
name = "SchumannR"
marketname = "HUAWEI MatePad 10.8 英寸"
fingerprint = ""

[templates."huawei_bah4_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad 10.4 英寸 2022"
device = "Bach4"
product = "Bach4"
name = "Bach4"
marketname = "HUAWEI MatePad 10.4 英寸 2022"
fingerprint = ""

[templates."huawei_bah4_w19"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad 10.4 英寸 2022 悦动版"
device = "Bach4"
product = "Bach4"
name = "Bach4"
marketname = "HUAWEI MatePad 10.4 英寸 2022 悦动版"
fingerprint = ""

[templates."huawei_dby_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad 11 英寸"
device = "Debussy"
product = "Debussy"
name = "Debussy"
marketname = "HUAWEI MatePad 11 英寸"
fingerprint = ""

[templates."huawei_dbr_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad 11 英寸 2023"
device = "DebussyR"
product = "DebussyR"
name = "DebussyR"
marketname = "HUAWEI MatePad 11 英寸 2023"
fingerprint = ""

[templates."huawei_btk_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad 11.5 英寸 2023"
device = "Bartok"
product = "Bartok"
name = "Bartok"
marketname = "HUAWEI MatePad 11.5 英寸 2023"
fingerprint = ""

[templates."huawei_btkr_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad 11.5 英寸 2024"
device = "BartokR"
product = "BartokR"
name = "BartokR"
marketname = "HUAWEI MatePad 11.5 英寸 2024"
fingerprint = ""

[templates."huawei_tgr_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad 11.5 S"
device = "Tagore"
product = "Tagore"
name = "Tagore"
marketname = "HUAWEI MatePad 11.5 S"
fingerprint = ""

[templates."huawei_dmg_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad 11.5 S 灵动款"
device = "Domingo"
product = "Domingo"
name = "Domingo"
marketname = "HUAWEI MatePad 11.5 S 灵动款"
fingerprint = ""

[templates."huawei_slg_w10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad 11.5 S 2025"
device = "Salinger"
product = "Salinger"
name = "Salinger"
marketname = "HUAWEI MatePad 11.5 S 2025"
fingerprint = ""

[templates."huawei_slg_w50"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad 11.5 S 2025 灵动款"
device = "Salinger"
product = "Salinger"
name = "Salinger"
marketname = "HUAWEI MatePad 11.5 S 2025 灵动款"
fingerprint = ""

[templates."huawei_txz_w10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad 11.5 英寸 2026"
device = "Taoxingzhi"
product = "Taoxingzhi"
name = "Taoxingzhi"
marketname = "HUAWEI MatePad 11.5 英寸 2026"
fingerprint = ""

[templates."huawei_txz_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad 11.5 英寸 2026 SIM 卡版"
device = "Taoxingzhi"
product = "Taoxingzhi"
name = "Taoxingzhi"
marketname = "HUAWEI MatePad 11.5 英寸 2026 SIM 卡版"
fingerprint = ""

[templates."huawei_mlr_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Mini 悦读版 8.8 英寸"
device = "Mclaren"
product = "Mclaren"
name = "Mclaren"
marketname = "HUAWEI MatePad Mini 悦读版 8.8 英寸"
fingerprint = ""

[templates."huawei_mlr_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Mini 8.8 英寸"
device = "Mclaren"
product = "Mclaren"
name = "Mclaren"
marketname = "HUAWEI MatePad Mini 8.8 英寸"
fingerprint = ""

[templates."huawei_ags2_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享平板 10.1 英寸"
device = "Agassi2"
product = "Agassi2"
name = "Agassi2"
marketname = "HUAWEI 畅享平板 10.1 英寸"
fingerprint = ""

[templates."huawei_ags3_w00d"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 畅享平板 2 10.1 英寸"
device = "Agassi3"
product = "Agassi3"
name = "Agassi3"
marketname = "HUAWEI 畅享平板 2 10.1 英寸"
fingerprint = ""

[templates."huawei_ags3k_w20"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad SE 10.1 英寸"
device = "Agassi3K"
product = "Agassi3K"
name = "Agassi3K"
marketname = "HUAWEI MatePad SE 10.1 英寸"
fingerprint = ""

[templates."huawei_ags5_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad SE 10.4 英寸"
device = "Agassi5"
product = "Agassi5"
name = "Agassi5"
marketname = "HUAWEI MatePad SE 10.4 英寸"
fingerprint = ""

[templates."huawei_ags6_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad SE 11 英寸"
device = "Agassi6"
product = "Agassi6"
name = "Agassi6"
marketname = "HUAWEI MatePad SE 11 英寸"
fingerprint = ""

[templates."huawei_ags6_w10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad SE 活力版 11 英寸"
device = "Agassi6R"
product = "Agassi6R"
name = "Agassi6R"
marketname = "HUAWEI MatePad SE 活力版 11 英寸"
fingerprint = ""

[templates."huawei_hmw_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Paper 10.3 英寸"
device = "Hemingway"
product = "Hemingway"
name = "Hemingway"
marketname = "HUAWEI MatePad Paper 10.3 英寸"
fingerprint = ""

[templates."huawei_hmw_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI MatePad Paper 典藏版 10.3 英寸"
device = "Hemingway"
product = "Hemingway"
name = "Hemingway"
marketname = "HUAWEI MatePad Paper 典藏版 10.3 英寸"
fingerprint = ""

[templates."huawei_bzk_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 C3 8 英寸"
device = "Kobe"
product = "Kobe"
name = "Kobe"
marketname = "HUAWEI 平板 C3 8 英寸"
fingerprint = ""

[templates."huawei_bza_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 C3 9.6 英寸"
device = "Agassi"
product = "Agassi"
name = "Agassi"
marketname = "HUAWEI 平板 C3 9.6 英寸"
fingerprint = ""

[templates."huawei_bzd_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 C3 8 英寸 2020"
device = "BZD-W00"
product = "BZD-W00"
marketname = "HUAWEI 平板 C3 8 英寸 2020"
fingerprint = ""

[templates."huawei_bzc_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 C3 9.7 英寸 2020"
device = "BZC-W00"
product = "BZC-W00"
marketname = "HUAWEI 平板 C3 9.7 英寸 2020"
fingerprint = ""

[templates."huawei_bzh_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 C3 9.7 英寸 2022"
device = "BZH-W00"
product = "BZH-W00"
marketname = "HUAWEI 平板 C3 9.7 英寸 2022"
fingerprint = ""

[templates."huawei_bxe3_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 C3 10.4 英寸"
device = "BXE3-W00"
product = "BXE3-W00"
marketname = "HUAWEI 擎云 C3 10.4 英寸"
fingerprint = ""

[templates."huawei_mon_w19"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 C5 8 英寸"
device = "MON-W19"
product = "MON-W19"
marketname = "HUAWEI 平板 C5 8 英寸"
fingerprint = ""

[templates."huawei_bzt_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 C5 10.1 英寸"
device = "BZT-W09"
product = "BZT-W09"
marketname = "HUAWEI 平板 C5 10.1 英寸"
fingerprint = ""

[templates."huawei_bzw_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 C5 8 英寸 2020"
device = "BZW-AL00"
product = "BZW-AL00"
marketname = "HUAWEI 平板 C5 8 英寸 2020"
fingerprint = ""

[templates."huawei_bzt3_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 C5 10.4 英寸 2020"
device = "BZT3-W09"
product = "BZT3-W09"
marketname = "HUAWEI 平板 C5 10.4 英寸 2020"
fingerprint = ""

[templates."huawei_bzt3_w59"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 C5 10.4 英寸 2021"
device = "BZT3-W59"
product = "BZT3-W59"
marketname = "HUAWEI 平板 C5 10.4 英寸 2021"
fingerprint = ""

[templates."huawei_bzt4_w19"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 C5 10.4 英寸 2022"
device = "BZT4-W19"
product = "BZT4-W19"
marketname = "HUAWEI 平板 C5 10.4 英寸 2022"
fingerprint = ""

[templates."huawei_kob2kz_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 C5 8 英寸"
device = "Kobe2KZ"
product = "Kobe2KZ"
name = "Kobe2KZ"
marketname = "HUAWEI 擎云 C5 8 英寸"
fingerprint = ""

[templates."huawei_btkz_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 C5 11.5 英寸"
device = "BartokZ"
product = "BartokZ"
name = "BartokZ"
marketname = "HUAWEI 擎云 C5 11.5 英寸"
fingerprint = ""

[templates."huawei_byd5_al10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 C5 11.5 英寸 SIM 卡版"
device = "Taoxingzhi"
product = "Taoxingzhi"
name = "Taoxingzhi"
marketname = "HUAWEI 擎云 C5 11.5 英寸 SIM 卡版"
fingerprint = ""

[templates."huawei_bzi_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 平板 C5e 10.1 英寸 2022"
device = "BZI-W00"
product = "BZI-W00"
marketname = "HUAWEI 平板 C5e 10.1 英寸 2022"
fingerprint = ""

[templates."huawei_ags5z_w09"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 C5e 10.4 英寸"
device = "Agassi5Z"
product = "Agassi5Z"
name = "Agassi5Z"
marketname = "HUAWEI 擎云 C5e 10.4 英寸"
fingerprint = ""

[templates."huawei_bzf5_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 C5e 11 英寸"
device = "Agassi6"
product = "Agassi6"
name = "Agassi6"
marketname = "HUAWEI 擎云 C5e 11 英寸"
fingerprint = ""

[templates."huawei_blf5_w00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 C5x 11 英寸"
device = "Agassi6"
product = "Agassi6"
name = "Agassi6"
marketname = "HUAWEI 擎云 C5x 11 英寸"
fingerprint = ""

[templates."huawei_bve_w10"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 C5z 10.4 英寸"
device = "BVE-W10"
product = "BVE-W10"
marketname = "HUAWEI 擎云 C5z 10.4 英寸"
fingerprint = ""

[templates."huawei_dby2z_al00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 C7 11.5 英寸"
device = "Debussy2Z"
product = "Debussy2Z"
name = "Debussy2Z"
marketname = "HUAWEI 擎云 C7 11.5 英寸"
fingerprint = ""

[templates."huawei_ytsfz_5651tp"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 S520 i5"
device = "YutuFZ"
product = "YutuFZ"
name = "YutuFZ"
marketname = "HUAWEI 擎云 S520 i5"
fingerprint = ""

[templates."huawei_ytsfz_7611t"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 S520 i7"
device = "YutuFZ"
product = "YutuFZ"
name = "YutuFZ"
marketname = "HUAWEI 擎云 S520 i7"
fingerprint = ""

[templates."huawei_ytgz_5651sp"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 S520 Gen2 i5"
device = "YutuGZ"
product = "YutuGZ"
name = "YutuGZ"
marketname = "HUAWEI 擎云 S520 Gen2 i5"
fingerprint = ""

[templates."huawei_ytgz_7611s"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 S520 Gen2 i7"
device = "YutuGZ"
product = "YutuGZ"
name = "YutuGZ"
marketname = "HUAWEI 擎云 S520 Gen2 i7"
fingerprint = ""

[templates."huawei_ytfz_5851s"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 S540 i5"
device = "YutuFZ"
product = "YutuFZ"
name = "YutuFZ"
marketname = "HUAWEI 擎云 S540 i5"
fingerprint = ""

[templates."huawei_ytfz_7651s"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 S540 i7"
device = "YutuFZ"
product = "YutuFZ"
name = "YutuFZ"
marketname = "HUAWEI 擎云 S540 i7"
fingerprint = ""

[templates."huawei_ytsgz_5651tp"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 G540 Gen2 i5"
device = "YutuGZ"
product = "YutuGZ"
name = "YutuGZ"
marketname = "HUAWEI 擎云 G540 Gen2 i5"
fingerprint = ""

[templates."huawei_klvg_16z3_xxx"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 G740 i5"
device = "KelvinG"
product = "KelvinG"
name = "KelvinG"
marketname = "HUAWEI 擎云 G740 i5"
fingerprint = ""

[templates."huawei_klvg_16z1_xxx"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 G740 i7"
device = "KelvinG"
product = "KelvinG"
name = "KelvinG"
marketname = "HUAWEI 擎云 G740 i7"
fingerprint = ""

[templates."huawei_klvu_wdu0"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 L410"
device = "KelvinU"
product = "KelvinU"
name = "KelvinU"
marketname = "HUAWEI 擎云 L410"
fingerprint = ""

[templates."huawei_klvv_w5821"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 L420"
device = "KelvinV"
product = "KelvinV"
name = "KelvinV"
marketname = "HUAWEI 擎云 L420"
fingerprint = ""

[templates."huawei_had_w72_001"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 HM940"
device = "Harden"
product = "Harden"
name = "Harden"
marketname = "HUAWEI 擎云 HM940"
fingerprint = ""

[templates."huawei_leo_dlxxu"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI PORSCHE DESIGN HUAWEI Smartwatch"
device = "Leo"
product = "Leo"
name = "Leo"
marketname = "HUAWEI PORSCHE DESIGN HUAWEI Smartwatch"
fingerprint = ""

[templates."huawei_sya_b19b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 H3540"
device = "Seiya"
product = "Seiya"
name = "Seiya"
marketname = "HUAWEI 擎云 H3540"
fingerprint = ""

[templates."huawei_nki_b19b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 H3550"
device = "NKI-B19B"
product = "NKI-B19B"
marketname = "HUAWEI 擎云 H3550"
fingerprint = ""

[templates."huawei_pnx_b19b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 H5546"
device = "Phoinix"
product = "Phoinix"
name = "Phoinix"
marketname = "HUAWEI 擎云 H5546"
fingerprint = ""

[templates."huawei_vli_b19b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 H5556"
device = "Vili"
product = "Vili"
name = "Vili"
marketname = "HUAWEI 擎云 H5556"
fingerprint = ""

[templates."huawei_atm_b19b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 H5566"
device = "Atum"
product = "Atum"
name = "Atum"
marketname = "HUAWEI 擎云 H5566"
fingerprint = ""

[templates."huawei_vli_b29b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 H5756"
device = "Vilipro"
product = "Vilipro"
name = "Vilipro"
marketname = "HUAWEI 擎云 H5756"
fingerprint = ""

[templates."huawei_arc_al2b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 H7546"
device = "Archi"
product = "Archi"
name = "Archi"
marketname = "HUAWEI 擎云 H7546"
fingerprint = ""

[templates."huawei_rts_al2b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 H7556"
device = "RTS-AL2B"
product = "RTS-AL2B"
marketname = "HUAWEI 擎云 H7556"
fingerprint = ""

[templates."huawei_lca_b12"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 H9D20"
device = "Luca"
product = "Luca"
name = "Luca"
marketname = "HUAWEI 擎云 H9D20"
fingerprint = ""

[templates."huawei_ask_b29b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 HA580"
device = "ASK-B29B"
product = "ASK-B29B"
marketname = "HUAWEI 擎云 HA580"
fingerprint = ""

[templates."huawei_kim_b19b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 HA590"
device = "Kimi"
product = "Kimi"
name = "Kimi"
marketname = "HUAWEI 擎云 HA590"
fingerprint = ""

[templates."huawei_nor_b39b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 HA5A0"
device = "NOR-B39B"
product = "NOR-B39B"
marketname = "HUAWEI 擎云 HA5A0"
fingerprint = ""

[templates."huawei_cdy_b19b"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 擎云 HA5B0"
device = "CDY-B19B"
product = "CDY-B19B"
marketname = "HUAWEI 擎云 HA5B0"
fingerprint = ""

[templates."huawei_cmg0_per"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI X GENTLE MONSTER Eyewear"
device = "CMG0-PER"
product = "CMG0-PER"
marketname = "HUAWEI X GENTLE MONSTER Eyewear"
fingerprint = ""

[templates."huawei_fij_cg020"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI X GENTLE MONSTER Eyewear II"
device = "FIJ-CG020"
product = "FIJ-CG020"
marketname = "HUAWEI X GENTLE MONSTER Eyewear II"
fingerprint = ""

[templates."huawei_evi_cg010"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 智能眼镜"
device = "EVI-CG010"
product = "EVI-CG010"
marketname = "HUAWEI 智能眼镜"
fingerprint = ""

[templates."huawei_lft_g00"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI 智能眼镜 2"
device = "LFT-G00"
product = "LFT-G00"
marketname = "HUAWEI 智能眼镜 2"
fingerprint = ""

[templates."huawei_ali_cg01"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Vision Glass"
device = "ALI-CG01"
product = "ALI-CG01"
marketname = "HUAWEI Vision Glass"
fingerprint = ""

[templates."huawei_ail_g01"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI AI 眼镜"
device = "AIL-G01"
product = "AIL-G01"
marketname = "HUAWEI AI 眼镜"
fingerprint = ""

[templates."huawei_huawei_u9500"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend D1"
device = "HUAWEI U9500"
product = "HUAWEI U9500"
marketname = "HUAWEI Ascend D1"
fingerprint = ""

[templates."huawei_huawei_u9500e"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend D1 XL"
device = "HUAWEI U9500E"
product = "HUAWEI U9500E"
marketname = "HUAWEI Ascend D1 XL"
fingerprint = ""

[templates."huawei_huawei_u9510"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend D1 四核"
device = "HUAWEI U9510"
product = "HUAWEI U9510"
marketname = "HUAWEI Ascend D1 四核"
fingerprint = ""

[templates."huawei_huawei_u9510e"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend D1 四核 XL"
device = "HUAWEI U9510E"
product = "HUAWEI U9510E"
marketname = "HUAWEI Ascend D1 四核 XL"
fingerprint = ""

[templates."huawei_huawei_d2_5000"]
manufacturer = "HUAWEI"
brand = "HUAWEI"
model = "HUAWEI Ascend D2"
device = "HUAWEI D2-5000"
product = "HUAWEI D2-5000"
marketname = "HUAWEI Ascend D2"
fingerprint = ""

[templates."lenovo_lenovo_l78011"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo Z5"
device = "jd2018"
product = "jd2018"
name = "jd2018"
marketname = "Lenovo Z5"
fingerprint = ""

[templates."lenovo_lenovo_l78031"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo Z5 Pro"
device = "zap"
product = "zap"
name = "zap"
marketname = "Lenovo Z5 Pro"
fingerprint = ""

[templates."lenovo_lenovo_l78032"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo Z5 Pro GT"
device = "heart"
product = "heart"
name = "heart"
marketname = "Lenovo Z5 Pro GT"
fingerprint = ""

[templates."lenovo_lenovo_l78071"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo Z5s"
device = "jd2019"
product = "jd2019"
name = "jd2019"
marketname = "Lenovo Z5s"
fingerprint = ""

[templates."lenovo_lenovo_l78051"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo Z6 Pro"
device = "zippo"
product = "zippo"
name = "zippo"
marketname = "Lenovo Z6 Pro"
fingerprint = ""

[templates."lenovo_lenovo_l79041"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo Z6 Pro 5G"
device = "cream"
product = "cream"
name = "cream"
marketname = "Lenovo Z6 Pro 5G"
fingerprint = ""

[templates."lenovo_lenovo_l78121"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo Z6"
device = "jd20"
product = "jd20"
name = "jd20"
marketname = "Lenovo Z6"
fingerprint = ""

[templates."lenovo_lenovo_l38111"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo Z6 青春版"
device = "kunlun2"
product = "kunlun2"
name = "kunlun2"
marketname = "Lenovo Z6 青春版"
fingerprint = ""

[templates."lenovo_lenovo_k520"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo S5"
device = "seoul"
product = "seoul"
name = "seoul"
marketname = "Lenovo S5"
fingerprint = ""

[templates."lenovo_lenovo_l58041"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo S5 Pro"
device = "sprout"
product = "sprout"
name = "sprout"
marketname = "Lenovo S5 Pro"
fingerprint = ""

[templates."lenovo_lenovo_l58091"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo S5 Pro GT"
device = "sprout"
product = "sprout"
name = "sprout"
marketname = "Lenovo S5 Pro GT"
fingerprint = ""

[templates."lenovo_lenovo_k350t"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo K5"
device = "k350t"
product = "k350t"
name = "k350t"
marketname = "Lenovo K5"
fingerprint = ""

[templates."lenovo_lenovo_l38012"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo K5 Note"
device = "austin2018"
product = "austin2018"
name = "austin2018"
marketname = "Lenovo K5 Note"
fingerprint = ""

[templates."lenovo_lenovo_l38011"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo K5 Play"
device = "k5"
product = "k5"
name = "k5"
marketname = "Lenovo K5 Play"
fingerprint = ""

[templates."lenovo_lenovo_l38031"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo K5s"
device = "k5s"
product = "k5s"
name = "k5s"
marketname = "Lenovo K5s"
fingerprint = ""

[templates."lenovo_lenovo_l38041"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo K5 Pro"
device = "kunlun"
product = "kunlun"
name = "kunlun"
marketname = "Lenovo K5 Pro"
fingerprint = ""

[templates."lenovo_lenovo_l38082"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo K6 畅享版"
device = "l38082"
product = "l38082"
name = "l38082"
marketname = "Lenovo K6 畅享版"
fingerprint = ""

[templates."lenovo_lenovo_l18011"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo A5"
device = "l18011"
product = "l18011"
name = "l18011"
marketname = "Lenovo A5"
fingerprint = ""

[templates."lenovo_lenovo_k320t"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo K320t"
device = "lenovo_k320t"
product = "lenovo_k320t"
name = "lenovo_k320t"
marketname = "Lenovo K320t"
fingerprint = ""

[templates."lenovo_lenovo_l79031"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 拯救者电竞手机 Pro"
device = "moba"
product = "moba"
name = "moba"
marketname = "Lenovo 拯救者电竞手机 Pro"
fingerprint = ""

[templates."lenovo_lenovo_l70081"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 拯救者电竞手机 2 Pro"
device = "doom"
product = "doom"
name = "doom"
marketname = "Lenovo 拯救者电竞手机 2 Pro"
fingerprint = ""

[templates."lenovo_lenovo_l71091"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 拯救者 Y70"
device = "halo"
product = "halo"
name = "halo"
marketname = "Lenovo 拯救者 Y70"
fingerprint = ""

[templates."lenovo_lenovo_l71061"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 拯救者 Y90"
device = "diablo"
product = "diablo"
name = "diablo"
marketname = "Lenovo 拯救者 Y90"
fingerprint = ""

[templates."lenovo_xt2611_1"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 拯救者 Y70 新一代"
device = "avr"
product = "avr"
name = "avr"
marketname = "Lenovo 拯救者 Y70 新一代"
fingerprint = ""

[templates."lenovo_xt2081_4"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 乐檬 K12"
device = "guam"
product = "guam"
name = "guam"
marketname = "Lenovo 乐檬 K12"
fingerprint = ""

[templates."lenovo_xt2091_7"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 乐檬 K12 Pro"
device = "cebu"
product = "cebu"
name = "cebu"
marketname = "Lenovo 乐檬 K12 Pro"
fingerprint = ""

[templates."lenovo_z1221"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo ZUK Z1"
device = "Z1221"
product = "Z1221"
marketname = "Lenovo ZUK Z1"
fingerprint = ""

[templates."lenovo_z2131"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo ZUK Z2"
device = "Z2131"
product = "Z2131"
marketname = "Lenovo ZUK Z2"
fingerprint = ""

[templates."lenovo_z2121"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo ZUK Z2 Pro"
device = "Z2121"
product = "Z2121"
marketname = "Lenovo ZUK Z2 Pro"
fingerprint = ""

[templates."lenovo_z2151"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo ZUK Edge"
device = "Z2151"
product = "Z2151"
marketname = "Lenovo ZUK Edge"
fingerprint = ""

[templates."lenovo_lenovo_tb_8804f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新平板 8 英寸"
device = "Lenovo TB-8804F"
product = "Lenovo TB-8804F"
marketname = "Lenovo 小新平板 8 英寸"
fingerprint = ""

[templates."lenovo_lenovo_tb_x804f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新平板 10 英寸"
device = "Lenovo TB-X804F"
product = "Lenovo TB-X804F"
marketname = "Lenovo 小新平板 10 英寸"
fingerprint = ""

[templates."lenovo_lenovo_tb_j606f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad"
device = "m11"
product = "m11"
name = "m11"
marketname = "Lenovo 小新 Pad"
fingerprint = ""

[templates."lenovo_tb128fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad 2022"
device = "oak"
product = "oak"
name = "oak"
marketname = "Lenovo 小新 Pad 2022"
fingerprint = ""

[templates."lenovo_tb331fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad 2024"
device = "Balsa"
product = "Balsa"
name = "Balsa"
marketname = "Lenovo 小新 Pad 2024"
fingerprint = ""

[templates."lenovo_tb335fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新平板 11"
device = "sycamore"
product = "sycamore"
name = "sycamore"
marketname = "Lenovo 小新平板 11"
fingerprint = ""

[templates."lenovo_tb335zc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新平板 11 5G"
device = "sycamore"
product = "sycamore"
name = "sycamore"
marketname = "Lenovo 小新平板 11 5G"
fingerprint = ""

[templates."lenovo_tb365fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新平板 12.1"
device = "cava"
product = "cava"
name = "cava"
marketname = "Lenovo 小新平板 12.1"
fingerprint = ""

[templates."lenovo_tb356fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo AI 平板 小新 10.1"
device = "malibu"
product = "malibu"
name = "malibu"
marketname = "Lenovo AI 平板 小新 10.1"
fingerprint = ""

[templates."lenovo_lenovo_tb_j607f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad Plus"
device = "arnoz"
product = "arnoz"
name = "arnoz"
marketname = "Lenovo 小新 Pad Plus"
fingerprint = ""

[templates."lenovo_lenovo_tb_j607z"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad Plus 5G"
device = "arnoz"
product = "arnoz"
name = "arnoz"
marketname = "Lenovo 小新 Pad Plus 5G"
fingerprint = ""

[templates."lenovo_tb350fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad Plus 2023"
device = "tulip"
product = "tulip"
name = "tulip"
marketname = "Lenovo 小新 Pad Plus 2023"
fingerprint = ""

[templates."lenovo_tb372fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad Plus 12.7 舒视版"
device = "spruce"
product = "spruce"
name = "spruce"
marketname = "Lenovo 小新 Pad Plus 12.7 舒视版"
fingerprint = ""

[templates."lenovo_lenovo_tb_j706f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad Pro"
device = "pearl"
product = "pearl"
name = "pearl"
marketname = "Lenovo 小新 Pad Pro"
fingerprint = ""

[templates."lenovo_lenovo_tb_j716f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad Pro 2021"
device = "p11_pro_plus"
product = "p11_pro_plus"
name = "p11_pro_plus"
marketname = "Lenovo 小新 Pad Pro 2021"
fingerprint = ""

[templates."lenovo_lenovo_tb_q706f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad Pro 12.6"
device = "paladin"
product = "paladin"
name = "paladin"
marketname = "Lenovo 小新 Pad Pro 12.6"
fingerprint = ""

[templates."lenovo_tb138fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad Pro 2022 骁龙版"
device = "olivine"
product = "olivine"
name = "olivine"
marketname = "Lenovo 小新 Pad Pro 2022 骁龙版"
fingerprint = ""

[templates."lenovo_tb132fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad Pro 2022 迅鲲版"
device = "onyx"
product = "onyx"
name = "onyx"
marketname = "Lenovo 小新 Pad Pro 2022 迅鲲版"
fingerprint = ""

[templates."lenovo_tb371fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad Pro 12.7 骁龙版"
device = "spinel"
product = "spinel"
name = "spinel"
marketname = "Lenovo 小新 Pad Pro 12.7 骁龙版"
fingerprint = ""

[templates."lenovo_tb370fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad Pro 12.7 天玑版"
device = "spruce"
product = "spruce"
name = "spruce"
marketname = "Lenovo 小新 Pad Pro 12.7 天玑版"
fingerprint = ""

[templates."lenovo_tb375fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad Pro 12.7 2025"
device = "peridot"
product = "peridot"
name = "peridot"
marketname = "Lenovo 小新 Pad Pro 12.7 2025"
fingerprint = ""

[templates."lenovo_tb710fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新平板 Pro GT"
device = "topaz"
product = "topaz"
name = "topaz"
marketname = "Lenovo 小新平板 Pro GT"
fingerprint = ""

[templates."lenovo_tb376fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo AI 平板 小新 Pro 13"
device = "malbec"
product = "malbec"
name = "malbec"
marketname = "Lenovo AI 平板 小新 Pro 13"
fingerprint = ""

[templates."lenovo_tb378fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo AI 平板 小新 Pro GT 13"
device = "zhiyu"
product = "zhiyu"
name = "zhiyu"
marketname = "Lenovo AI 平板 小新 Pro GT 13"
fingerprint = ""

[templates."lenovo_tb351fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 小新 Pad Studio"
device = "calla"
product = "calla"
name = "calla"
marketname = "Lenovo 小新 Pad Studio"
fingerprint = ""

[templates."lenovo_lenovo_yt3_850f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo YOGA Tab 3 8”"
device = "Lenovo YT3-850F"
product = "Lenovo YT3-850F"
marketname = "Lenovo YOGA Tab 3 8”"
fingerprint = ""

[templates."lenovo_lenovo_yt3_x50f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo YOGA Tab 3 10”"
device = "Lenovo YT3-X50F"
product = "Lenovo YT3-X50F"
marketname = "Lenovo YOGA Tab 3 10”"
fingerprint = ""

[templates."lenovo_lenovo_yt_x703f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo YOGA Tab 3 Plus"
device = "Lenovo YT-X703F"
product = "Lenovo YT-X703F"
marketname = "Lenovo YOGA Tab 3 Plus"
fingerprint = ""

[templates."lenovo_lenovo_yt3_x90f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo YOGA Tab 3 PRO 10”"
device = "Lenovo YT3-X90F"
product = "Lenovo YT3-X90F"
marketname = "Lenovo YOGA Tab 3 PRO 10”"
fingerprint = ""

[templates."lenovo_lenovo_yt_k606f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo YOGA Pad Pro"
device = "bladex"
product = "bladex"
name = "bladex"
marketname = "Lenovo YOGA Pad Pro"
fingerprint = ""

[templates."lenovo_tb520fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo YOGA Pad Pro 12.7"
device = "lapis"
product = "lapis"
name = "lapis"
marketname = "Lenovo YOGA Pad Pro 12.7"
fingerprint = ""

[templates."lenovo_tb571fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo YOGA Pad Pro 14.5 AI 元启版"
device = "titans"
product = "titans"
name = "titans"
marketname = "Lenovo YOGA Pad Pro 14.5 AI 元启版"
fingerprint = ""

[templates."lenovo_sp101fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo YOGA Paper 墨水平板"
device = "SP101FU"
product = "SP101FU"
marketname = "Lenovo YOGA Paper 墨水平板"
fingerprint = ""

[templates."lenovo_lenovo_tb_9707f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 拯救者平板 Y700"
device = "p8"
product = "p8"
name = "p8"
marketname = "Lenovo 拯救者平板 Y700"
fingerprint = ""

[templates."lenovo_tb320fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 拯救者平板 Y700 2023"
device = "asphalt"
product = "asphalt"
name = "asphalt"
marketname = "Lenovo 拯救者平板 Y700 2023"
fingerprint = ""

[templates."lenovo_tb321fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 拯救者平板 Y700 2025"
device = "kirby"
product = "kirby"
name = "kirby"
marketname = "Lenovo 拯救者平板 Y700 2025"
fingerprint = ""

[templates."lenovo_tb322fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 拯救者平板 Y700 四代"
device = "elden"
product = "elden"
name = "elden"
marketname = "Lenovo 拯救者平板 Y700 四代"
fingerprint = ""

[templates."lenovo_tb323fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo AI 平板 拯救者 Y700 五代"
device = "baldur"
product = "baldur"
name = "baldur"
marketname = "Lenovo AI 平板 拯救者 Y700 五代"
fingerprint = ""

[templates."lenovo_tb324zc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo AI 平板 拯救者 Y700 无极"
device = "wuji"
product = "wuji"
name = "wuji"
marketname = "Lenovo AI 平板 拯救者 Y700 无极"
fingerprint = ""

[templates."lenovo_tb570fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 拯救者平板 Y900"
device = "inception"
product = "inception"
name = "inception"
marketname = "Lenovo 拯救者平板 Y900"
fingerprint = ""

[templates."lenovo_tb711fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo AI 平板 拯救者 Y900 11"
device = "beryl"
product = "beryl"
name = "beryl"
marketname = "Lenovo AI 平板 拯救者 Y900 11"
fingerprint = ""

[templates."lenovo_tb522fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo AI 平板 拯救者 Y900 13"
device = "mojito"
product = "mojito"
name = "mojito"
marketname = "Lenovo AI 平板 拯救者 Y900 13"
fingerprint = ""

[templates."lenovo_lenovo_tb_j616f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 天骄平板电脑"
device = "p11_plus"
product = "p11_plus"
name = "p11_plus"
marketname = "Lenovo 天骄平板电脑"
fingerprint = ""

[templates."lenovo_lenovo_tb_8504f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TAB4 8 英寸"
device = "Lenovo TB-8504F"
product = "Lenovo TB-8504F"
marketname = "Lenovo TAB4 8 英寸"
fingerprint = ""

[templates."lenovo_lenovo_tb_8604f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TAB4 8 英寸 REL"
device = "Lenovo TB-8604F"
product = "Lenovo TB-8604F"
marketname = "Lenovo TAB4 8 英寸 REL"
fingerprint = ""

[templates."lenovo_lenovo_tb_x304f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TAB4 10.1 英寸"
device = "Lenovo TB-X304F"
product = "Lenovo TB-X304F"
marketname = "Lenovo TAB4 10.1 英寸"
fingerprint = ""

[templates."lenovo_lenovo_tb_x504f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TAB4 10.1 英寸 REL"
device = "Lenovo TB-X504F"
product = "Lenovo TB-X504F"
marketname = "Lenovo TAB4 10.1 英寸 REL"
fingerprint = ""

[templates."lenovo_lenovo_tb_8704f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TAB4 Plus 8 英寸"
device = "Lenovo TB-8704F"
product = "Lenovo TB-8704F"
marketname = "Lenovo TAB4 Plus 8 英寸"
fingerprint = ""

[templates."lenovo_lenovo_tb_x704f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo TAB4 Plus 10.1 英寸"
device = "Lenovo TB-X704F"
product = "Lenovo TB-X704F"
marketname = "Lenovo TAB4 Plus 10.1 英寸"
fingerprint = ""

[templates."lenovo_lenovo_tb_8705f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo M8 8 英寸"
device = "aaron"
product = "aaron"
name = "aaron"
marketname = "Lenovo M8 8 英寸"
fingerprint = ""

[templates."lenovo_lenovo_tb_x306fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo M10 HD 10.1 英寸"
device = "amar"
product = "amar"
name = "amar"
marketname = "Lenovo M10 HD 10.1 英寸"
fingerprint = ""

[templates."lenovo_lenovo_tb_x605fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo M10 FHD-REL 10.1 英寸"
device = "achilles5"
product = "achilles5"
name = "achilles5"
marketname = "Lenovo M10 FHD-REL 10.1 英寸"
fingerprint = ""

[templates."lenovo_lenovo_tb_x606f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo M10 PLUS 10.3 英寸"
device = "achilles6"
product = "achilles6"
name = "achilles6"
marketname = "Lenovo M10 PLUS 10.3 英寸"
fingerprint = ""

[templates."lenovo_lenovo_tb_8506f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 启天 K8 8 英寸"
device = "Lenovo TB-8506F"
product = "Lenovo TB-8506F"
marketname = "Lenovo 启天 K8 8 英寸"
fingerprint = ""

[templates."lenovo_tb310fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 启天 K9 9 英寸"
device = "pine"
product = "pine"
name = "pine"
marketname = "Lenovo 启天 K9 9 英寸"
fingerprint = ""

[templates."lenovo_lenovo_tb_x6c6f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 启天 K10 10.3 英寸"
device = "asha"
product = "asha"
name = "asha"
marketname = "Lenovo 启天 K10 10.3 英寸"
fingerprint = ""

[templates."lenovo_lenovo_tb_x6c6nbf"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 启天 K10 10.3 英寸 无电池版本"
device = "asha"
product = "asha"
name = "asha"
marketname = "Lenovo 启天 K10 10.3 英寸 无电池版本"
fingerprint = ""

[templates."lenovo_lenovo_tb_x6e6f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 启天 K10c 10.3 英寸"
device = "Lenovo TB-X6E6F"
product = "Lenovo TB-X6E6F"
marketname = "Lenovo 启天 K10c 10.3 英寸"
fingerprint = ""

[templates."lenovo_lenovo_tb_x6e6fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 启天 E10c 10.3 英寸"
device = "Lenovo TB-X6E6FC"
product = "Lenovo TB-X6E6FC"
marketname = "Lenovo 启天 E10c 10.3 英寸"
fingerprint = ""

[templates."lenovo_tb223fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 启天 K10 Pro 10.61 英寸"
device = "maple"
product = "maple"
name = "maple"
marketname = "Lenovo 启天 K10 Pro 10.61 英寸"
fingerprint = ""

[templates."lenovo_lenovo_tb_j6c6f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 启天 K11 11 英寸"
device = "p11"
product = "p11"
name = "p11"
marketname = "Lenovo 启天 K11 11 英寸"
fingerprint = ""

[templates."lenovo_tb230fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 启天 K11 Gen2 11.5 英寸"
device = "tulip"
product = "tulip"
name = "tulip"
marketname = "Lenovo 启天 K11 Gen2 11.5 英寸"
fingerprint = ""

[templates."lenovo_tb240fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 启天 K12 12.7 英寸"
device = "spruce"
product = "spruce"
name = "spruce"
marketname = "Lenovo 启天 K12 12.7 英寸"
fingerprint = ""

[templates."lenovo_sp523fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 启天 SmartPaper 10.3 英寸"
device = "SP523FC"
product = "SP523FC"
marketname = "Lenovo 启天 SmartPaper 10.3 英寸"
fingerprint = ""

[templates."lenovo_tb305fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 昭阳 K9 8.7 英寸"
device = "clove"
product = "clove"
name = "clove"
marketname = "Lenovo 昭阳 K9 8.7 英寸"
fingerprint = ""

[templates."lenovo_tb330fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 昭阳 K10 10.95 英寸"
device = "barley"
product = "barley"
name = "barley"
marketname = "Lenovo 昭阳 K10 10.95 英寸"
fingerprint = ""

[templates."lenovo_tb311fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 昭阳 K10c 10.1 英寸"
device = "poplar"
product = "poplar"
name = "poplar"
marketname = "Lenovo 昭阳 K10c 10.1 英寸"
fingerprint = ""

[templates."lenovo_tb352fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 昭阳 K11 11.5 英寸"
device = "citrus"
product = "citrus"
name = "citrus"
marketname = "Lenovo 昭阳 K11 11.5 英寸"
fingerprint = ""

[templates."lenovo_tb336fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 昭阳 K11 11 英寸"
device = "sycamore"
product = "sycamore"
name = "sycamore"
marketname = "Lenovo 昭阳 K11 11 英寸"
fingerprint = ""

[templates."lenovo_tb337fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 昭阳 K11c 10.95 英寸"
device = "barley"
product = "barley"
name = "barley"
marketname = "Lenovo 昭阳 K11c 10.95 英寸"
fingerprint = ""

[templates."lenovo_tb373fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 昭阳 K12 12.7 英寸"
device = "peridot"
product = "peridot"
name = "peridot"
marketname = "Lenovo 昭阳 K12 12.7 英寸"
fingerprint = ""

[templates."lenovo_tb361fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 昭阳 K12c 12.1 英寸"
device = "cava"
product = "cava"
name = "cava"
marketname = "Lenovo 昭阳 K12c 12.1 英寸"
fingerprint = ""

[templates."lenovo_tb391fc"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 昭阳 K13 13 英寸"
device = "malbec"
product = "malbec"
name = "malbec"
marketname = "Lenovo 昭阳 K13 13 英寸"
fingerprint = ""

[templates."lenovo_tb_x802f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 昭阳 G11 10.95 英寸"
device = "barley"
product = "barley"
name = "barley"
marketname = "Lenovo 昭阳 G11 10.95 英寸"
fingerprint = ""

[templates."lenovo_tb_x903f"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 昭阳 G12 11.5 英寸"
device = "citrus"
product = "citrus"
name = "citrus"
marketname = "Lenovo 昭阳 G12 11.5 英寸"
fingerprint = ""

[templates."lenovo_tby11"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 昭阳 Y11 10.95 英寸"
device = "barley"
product = "barley"
name = "barley"
marketname = "Lenovo 昭阳 Y11 10.95 英寸"
fingerprint = ""

[templates."lenovo_lenovo_tb_j606n"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 平板电脑 K11 11 英寸"
device = "m11"
product = "m11"
name = "m11"
marketname = "Lenovo 平板电脑 K11 11 英寸"
fingerprint = ""

[templates."lenovo_qbh10"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 平板电脑 S11 10.95 英寸"
device = "barley"
product = "barley"
name = "barley"
marketname = "Lenovo 平板电脑 S11 10.95 英寸"
fingerprint = ""

[templates."lenovo_qbh11"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo 平板电脑 S11 Pro 11.5 英寸"
device = "citrus"
product = "citrus"
name = "citrus"
marketname = "Lenovo 平板电脑 S11 Pro 11.5 英寸"
fingerprint = ""

[templates."lenovo_tb610fu"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo ThinkBook Plus Hybrid 2024"
device = "gem"
product = "gem"
name = "gem"
marketname = "Lenovo ThinkBook Plus Hybrid 2024"
fingerprint = ""

[templates."lenovo_tb838"]
manufacturer = "LENOVO"
brand = "LENOVO"
model = "Lenovo ThinkTab T11S 11 英寸"
device = "sycamore"
product = "sycamore"
name = "sycamore"
marketname = "Lenovo ThinkTab T11S 11 英寸"
fingerprint = ""

[templates."meizu_m8"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M8"
device = "M8"
product = "M8"
marketname = "Meizu M8"
fingerprint = ""

[templates."meizu_m8se"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M8 SE"
device = "M8SE"
product = "M8SE"
marketname = "Meizu M8 SE"
fingerprint = ""

[templates."meizu_m9"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M9"
device = "M9"
product = "M9"
marketname = "Meizu M9"
fingerprint = ""

[templates."meizu_m030"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu MX 双核"
device = "M030"
product = "M030"
marketname = "Meizu MX 双核"
fingerprint = ""

[templates."meizu_m031"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu MX 双核新版"
device = "M031"
product = "M031"
marketname = "Meizu MX 双核新版"
fingerprint = ""

[templates."meizu_m032"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu MX 四核"
device = "m03"
product = "m03"
name = "m03"
marketname = "Meizu MX 四核"
fingerprint = ""

[templates."meizu_m040"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu MX2"
device = "m04"
product = "m04"
name = "m04"
marketname = "Meizu MX2"
fingerprint = ""

[templates."meizu_m351"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu MX3"
device = "m35"
product = "m35"
name = "m35"
marketname = "Meizu MX3"
fingerprint = ""

[templates."meizu_m460"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu MX4"
device = "m75"
product = "m75"
name = "m75"
marketname = "Meizu MX4"
fingerprint = ""

[templates."meizu_m460a"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu MX4 YunOS 版"
device = "m75"
product = "m75"
name = "m75"
marketname = "Meizu MX4 YunOS 版"
fingerprint = ""

[templates."meizu_m462"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu MX4 Pro"
device = "m76"
product = "m76"
name = "m76"
marketname = "Meizu MX4 Pro"
fingerprint = ""

[templates."meizu_m575"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu MX5"
device = "m85"
product = "m85"
name = "m85"
marketname = "Meizu MX5"
fingerprint = ""

[templates."meizu_m685q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu MX6"
device = "m95"
product = "m95"
name = "m95"
marketname = "Meizu MX6"
fingerprint = ""

[templates."meizu_m576"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu PRO 5"
device = "m86"
product = "m86"
name = "m86"
marketname = "Meizu PRO 5"
fingerprint = ""

[templates."meizu_m570q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu PRO 6"
device = "m80"
product = "m80"
name = "m80"
marketname = "Meizu PRO 6"
fingerprint = ""

[templates."meizu_m570q_s"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu PRO 6s"
device = "m80"
product = "m80"
name = "m80"
marketname = "Meizu PRO 6s"
fingerprint = ""

[templates."meizu_m686"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu PRO 6 Plus"
device = "m96"
product = "m96"
name = "m96"
marketname = "Meizu PRO 6 Plus"
fingerprint = ""

[templates."meizu_m792q_l"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu PRO 7"
device = "m1792L"
product = "m1792L"
name = "m1792L"
marketname = "Meizu PRO 7"
fingerprint = ""

[templates."meizu_m793q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu PRO 7 Plus"
device = "m1793"
product = "m1793"
name = "m1793"
marketname = "Meizu PRO 7 Plus"
fingerprint = ""

[templates."meizu_m881q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 15"
device = "m1881"
product = "m1881"
name = "m1881"
marketname = "Meizu 15"
fingerprint = ""

[templates."meizu_m891q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 15 Plus"
device = "m1891"
product = "m1891"
name = "m1891"
marketname = "Meizu 15 Plus"
fingerprint = ""

[templates."meizu_m871q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M15"
device = "m1871"
product = "m1871"
name = "m1871"
marketname = "Meizu M15"
fingerprint = ""

[templates."meizu_m871h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 15 Lite"
device = "m1871"
product = "m1871"
name = "m1871"
marketname = "Meizu 15 Lite"
fingerprint = ""

[templates."meizu_m882q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 16th"
device = "m1882"
product = "m1882"
name = "m1882"
marketname = "Meizu 16th"
fingerprint = ""

[templates."meizu_m892q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 16th Plus"
device = "m1892"
product = "m1892"
name = "m1892"
marketname = "Meizu 16th Plus"
fingerprint = ""

[templates."meizu_m872q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 16 X"
device = "m1872"
product = "m1872"
name = "m1872"
marketname = "Meizu 16 X"
fingerprint = ""

[templates."meizu_m872h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 16"
device = "m1872"
product = "m1872"
name = "m1872"
marketname = "Meizu 16"
fingerprint = ""

[templates."meizu_m971q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 16s"
device = "m1971"
product = "m1971"
name = "m1971"
marketname = "Meizu 16s"
fingerprint = ""

[templates."meizu_m926q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 16Xs"
device = "m1926"
product = "m1926"
name = "m1926"
marketname = "Meizu 16Xs"
fingerprint = ""

[templates."meizu_m973q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 16s Pro"
device = "m1973"
product = "m1973"
name = "m1973"
marketname = "Meizu 16s Pro"
fingerprint = ""

[templates."meizu_m928q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 16T"
device = "m1928"
product = "m1928"
name = "m1928"
marketname = "Meizu 16T"
fingerprint = ""

[templates."meizu_m081q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 17"
device = "m2081"
product = "m2081"
name = "m2081"
marketname = "Meizu 17"
fingerprint = ""

[templates."meizu_m091q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 17 Pro"
device = "m2091"
product = "m2091"
name = "m2091"
marketname = "Meizu 17 Pro"
fingerprint = ""

[templates."meizu_m181q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 18"
device = "m2181"
product = "m2181"
name = "m2181"
marketname = "Meizu 18"
fingerprint = ""

[templates."meizu_m191q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 18 Pro"
device = "m2191"
product = "m2191"
name = "m2191"
marketname = "Meizu 18 Pro"
fingerprint = ""

[templates."meizu_m172q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 18X"
device = "m2172"
product = "m2172"
name = "m2172"
marketname = "Meizu 18X"
fingerprint = ""

[templates."meizu_m182q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 18s"
device = "m2182"
product = "m2182"
name = "m2182"
marketname = "Meizu 18s"
fingerprint = ""

[templates."meizu_m381q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 20"
device = "m2381"
product = "m2381"
name = "m2381"
marketname = "Meizu 20"
fingerprint = ""

[templates."meizu_m391q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 20 PRO"
device = "m2391"
product = "m2391"
name = "m2391"
marketname = "Meizu 20 PRO"
fingerprint = ""

[templates."meizu_m392q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 20 INFINITY 无界版"
device = "m2392"
product = "m2392"
name = "m2392"
marketname = "Meizu 20 INFINITY 无界版"
fingerprint = ""

[templates."meizu_m461q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 21"
device = "m2461"
product = "m2461"
name = "m2461"
marketname = "Meizu 21"
fingerprint = ""

[templates."meizu_m481q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 21 PRO"
device = "m2481"
product = "m2481"
name = "m2481"
marketname = "Meizu 21 PRO"
fingerprint = ""

[templates."meizu_m481s"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 21 PRO Flyme 钛好用版"
device = "m2481s"
product = "m2481s"
name = "m2481s"
marketname = "Meizu 21 PRO Flyme 钛好用版"
fingerprint = ""

[templates."meizu_m468q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 21 Note"
device = "m2468l"
product = "m2468l"
name = "m2468l"
marketname = "Meizu 21 Note"
fingerprint = ""

[templates."meizu_m582q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 22"
device = "m2582"
product = "m2582"
name = "m2582"
marketname = "Meizu 22"
fingerprint = ""

[templates."meizu_m431q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu Lucky 08"
device = "m2431"
product = "m2431"
name = "m2431"
marketname = "Meizu Lucky 08"
fingerprint = ""

[templates."meizu_m852q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu X8"
device = "m1852"
product = "m1852"
name = "m1852"
marketname = "Meizu X8"
fingerprint = ""

[templates."meizu_m813q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu V8"
device = "m1813"
product = "m1813"
name = "m1813"
marketname = "Meizu V8"
fingerprint = ""

[templates."meizu_m816h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M8 Lite"
device = "m1816"
product = "m1816"
name = "m1816"
marketname = "Meizu M8 Lite"
fingerprint = ""

[templates."meizu_m822q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu Note8"
device = "m1822"
product = "m1822"
name = "m1822"
marketname = "Meizu Note8"
fingerprint = ""

[templates."meizu_m923q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu Note9"
device = "m1923"
product = "m1923"
name = "m1923"
marketname = "Meizu Note9"
fingerprint = ""

[templates."meizu_m521q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu Note 16"
device = "m2521"
product = "m2521"
name = "m2521"
marketname = "Meizu Note 16"
fingerprint = ""

[templates."meizu_m531q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu Note 16 Pro"
device = "m2531"
product = "m2531"
name = "m2531"
marketname = "Meizu Note 16 Pro"
fingerprint = ""

[templates."meizu_m411h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu Note 21"
device = "m2411"
product = "m2411"
name = "m2411"
marketname = "Meizu Note 21"
fingerprint = ""

[templates."meizu_m412h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu Note 21 Pro"
device = "m2412"
product = "m2412"
name = "m2412"
marketname = "Meizu Note 21 Pro"
fingerprint = ""

[templates."meizu_m513h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu Note 22"
device = "m2513"
product = "m2513"
name = "m2513"
marketname = "Meizu Note 22"
fingerprint = ""

[templates."meizu_m810h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M8c"
device = "m1810"
product = "m1810"
name = "m1810"
marketname = "Meizu M8c"
fingerprint = ""

[templates."meizu_m818h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu C9"
device = "m1818"
product = "m1818"
name = "m1818"
marketname = "Meizu C9"
fingerprint = ""

[templates."meizu_m819h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu C9 Pro"
device = "m1819"
product = "m1819"
name = "m1819"
marketname = "Meizu C9 Pro"
fingerprint = ""

[templates."meizu_m918h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M10"
device = "m1918"
product = "m1918"
name = "m1918"
marketname = "Meizu M10"
fingerprint = ""

[templates."meizu_m463m"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu note"
device = "m71"
product = "m71"
name = "m71"
marketname = "Meizu note"
fingerprint = ""

[templates."meizu_m463h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu m1 note"
device = "m71"
product = "m71"
name = "m71"
marketname = "Meizu m1 note"
fingerprint = ""

[templates."meizu_m571"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu note2"
device = "m81"
product = "m81"
name = "m81"
marketname = "Meizu note2"
fingerprint = ""

[templates."meizu_m571h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu m2 note"
device = "m81"
product = "m81"
name = "m81"
marketname = "Meizu m2 note"
fingerprint = ""

[templates."meizu_m681q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu Note3"
device = "m91"
product = "m91"
name = "m91"
marketname = "Meizu Note3"
fingerprint = ""

[templates."meizu_m681h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M3 note"
device = "m91"
product = "m91"
name = "m91"
marketname = "Meizu M3 note"
fingerprint = ""

[templates."meizu_m621q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu Note5"
device = "m1621"
product = "m1621"
name = "m1621"
marketname = "Meizu Note5"
fingerprint = ""

[templates."meizu_m621h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M5 Note"
device = "m1621"
product = "m1621"
name = "m1621"
marketname = "Meizu M5 Note"
fingerprint = ""

[templates."meizu_m721q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu Note6"
device = "m1721"
product = "m1721"
name = "m1721"
marketname = "Meizu Note6"
fingerprint = ""

[templates."meizu_m721h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M6 Note"
device = "m1721"
product = "m1721"
name = "m1721"
marketname = "Meizu M6 Note"
fingerprint = ""

[templates."meizu_a680q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu E"
device = "a02"
product = "a02"
name = "a02"
marketname = "Meizu E"
fingerprint = ""

[templates."meizu_a680h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M3E"
device = "a02"
product = "a02"
name = "a02"
marketname = "Meizu M3E"
fingerprint = ""

[templates."meizu_m741a"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu E2"
device = "m1741"
product = "m1741"
name = "m1741"
marketname = "Meizu E2"
fingerprint = ""

[templates."meizu_m851q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu E3"
device = "m1851"
product = "m1851"
name = "m1851"
marketname = "Meizu E3"
fingerprint = ""

[templates."meizu_m682q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu X"
device = "m92"
product = "m92"
name = "m92"
marketname = "Meizu X"
fingerprint = ""

[templates."meizu_m465m"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu"
device = "m79"
product = "m79"
name = "m79"
marketname = "Meizu"
fingerprint = ""

[templates."meizu_m465a"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu YunOS 版"
device = "m79"
product = "m79"
name = "m79"
marketname = "Meizu YunOS 版"
fingerprint = ""

[templates."meizu_m578"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 2"
device = "m88"
product = "m88"
name = "m88"
marketname = "Meizu 2"
fingerprint = ""

[templates."meizu_m578a"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 2 YunOS"
device = "m88"
product = "m88"
name = "m88"
marketname = "Meizu 2 YunOS"
fingerprint = ""

[templates."meizu_m578h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu m2"
device = "m88"
product = "m88"
name = "m88"
marketname = "Meizu m2"
fingerprint = ""

[templates."meizu_m688q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 3"
device = "m98"
product = "m98"
name = "m98"
marketname = "Meizu 3"
fingerprint = ""

[templates."meizu_y685q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 3s"
device = "y15"
product = "y15"
name = "y15"
marketname = "Meizu 3s"
fingerprint = ""

[templates."meizu_y685h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M3s"
device = "y15"
product = "y15"
name = "y15"
marketname = "Meizu M3s"
fingerprint = ""

[templates."meizu_m611a"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 5"
device = "m1611"
product = "m1611"
name = "m1611"
marketname = "Meizu 5"
fingerprint = ""

[templates."meizu_m611h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M5"
device = "m1611"
product = "m1611"
name = "m1611"
marketname = "Meizu M5"
fingerprint = ""

[templates."meizu_m612q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 5s"
device = "m1612"
product = "m1612"
name = "m1612"
marketname = "Meizu 5s"
fingerprint = ""

[templates."meizu_m612h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M5s"
device = "m1612"
product = "m1612"
name = "m1612"
marketname = "Meizu M5s"
fingerprint = ""

[templates."meizu_m711q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 6"
device = "m1711"
product = "m1711"
name = "m1711"
marketname = "Meizu 6"
fingerprint = ""

[templates."meizu_m711h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M6"
device = "m1711"
product = "m1711"
name = "m1711"
marketname = "Meizu M6"
fingerprint = ""

[templates."meizu_m712q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu S6"
device = "m1712"
product = "m1712"
name = "m1712"
marketname = "Meizu S6"
fingerprint = ""

[templates."meizu_m712h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M6s"
device = "m1712"
product = "m1712"
name = "m1712"
marketname = "Meizu M6s"
fingerprint = ""

[templates."meizu_m811q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 6T"
device = "m1811"
product = "m1811"
name = "m1811"
marketname = "Meizu 6T"
fingerprint = ""

[templates."meizu_m811h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M6T"
device = "m1811"
product = "m1811"
name = "m1811"
marketname = "Meizu M6T"
fingerprint = ""

[templates."meizu_m2112"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 10"
device = "m2112"
product = "m2112"
name = "m2112"
marketname = "Meizu 10"
fingerprint = ""

[templates."meizu_m2111"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu 10s"
device = "m2111"
product = "m2111"
name = "m2111"
marketname = "Meizu 10s"
fingerprint = ""

[templates."meizu_m416h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu Mblu 21"
device = "m2416"
product = "m2416"
name = "m2416"
marketname = "Meizu Mblu 21"
fingerprint = ""

[templates."meizu_m511h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu Mblu 22"
device = "m2511"
product = "m2511"
name = "m2511"
marketname = "Meizu Mblu 22"
fingerprint = ""

[templates."meizu_m512h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu Mblu 22 Pro"
device = "m2512"
product = "m2512"
name = "m2512"
marketname = "Meizu Mblu 22 Pro"
fingerprint = ""

[templates."meizu_s685q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu Max"
device = "s25"
product = "s25"
name = "s25"
marketname = "Meizu Max"
fingerprint = ""

[templates."meizu_s685h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M3 Max"
device = "s25"
product = "s25"
name = "s25"
marketname = "Meizu M3 Max"
fingerprint = ""

[templates."meizu_u680a"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu U10"
device = "u10"
product = "u10"
name = "u10"
marketname = "Meizu U10"
fingerprint = ""

[templates."meizu_u685q"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu U20"
device = "u15"
product = "u15"
name = "u15"
marketname = "Meizu U20"
fingerprint = ""

[templates."meizu_m57a"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu metal"
device = "ma01"
product = "ma01"
name = "ma01"
marketname = "Meizu metal"
fingerprint = ""

[templates."meizu_m710m"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu A5"
device = "m1710"
product = "m1710"
name = "m1710"
marketname = "Meizu A5"
fingerprint = ""

[templates."meizu_m710h"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu M5c"
device = "m1710"
product = "m1710"
name = "m1710"
marketname = "Meizu M5c"
fingerprint = ""

[templates."meizu_m481r"]
manufacturer = "meizu"
brand = "meizu"
model = "Meizu HongQi Wonder"
device = "m2481r"
product = "m2481r"
name = "m2481r"
marketname = "Meizu HongQi Wonder"
fingerprint = ""

[templates."motorola_xt1085"]
manufacturer = "motorola"
brand = "motorola"
model = "Moto X"
device = "victara"
product = "victara"
name = "victara"
marketname = "Moto X"
fingerprint = ""

[templates."motorola_xt1079"]
manufacturer = "motorola"
brand = "motorola"
model = "Moto G"
device = "thea_ds"
product = "thea_ds"
name = "thea_ds"
marketname = "Moto G"
fingerprint = ""

[templates."motorola_xt1115"]
manufacturer = "motorola"
brand = "motorola"
model = "Moto X Pro"
device = "shamu_t"
product = "shamu_t"
name = "shamu_t"
marketname = "Moto X Pro"
fingerprint = ""

[templates."motorola_xt1570"]
manufacturer = "motorola"
brand = "motorola"
model = "Moto X Style"
device = "clark_ds"
product = "clark_ds"
name = "clark_ds"
marketname = "Moto X Style"
fingerprint = ""

[templates."motorola_xt1561"]
manufacturer = "motorola"
brand = "motorola"
model = "Moto X Play"
device = "lux_uds"
product = "lux_uds"
name = "lux_uds"
marketname = "Moto X Play"
fingerprint = ""

[templates."motorola_xt1581"]
manufacturer = "motorola"
brand = "motorola"
model = "Moto X 极"
device = "kinzie_uds"
product = "kinzie_uds"
name = "kinzie_uds"
marketname = "Moto X 极"
fingerprint = ""

[templates."motorola_xt1635_03"]
manufacturer = "motorola"
brand = "motorola"
model = "Moto Z Play"
device = "addison"
product = "addison"
name = "addison"
marketname = "Moto Z Play"
fingerprint = ""

[templates."motorola_xt1662"]
manufacturer = "motorola"
brand = "motorola"
model = "Moto M"
device = "kungfu_m"
product = "kungfu_m"
name = "kungfu_m"
marketname = "Moto M"
fingerprint = ""

[templates."motorola_xt1650_05"]
manufacturer = "motorola"
brand = "motorola"
model = "Moto Z"
device = "griffin"
product = "griffin"
name = "griffin"
marketname = "Moto Z"
fingerprint = ""

[templates."motorola_xt1710_08"]
manufacturer = "motorola"
brand = "motorola"
model = "Moto Z2 Play"
device = "albus"
product = "albus"
name = "albus"
marketname = "Moto Z2 Play"
fingerprint = ""

[templates."motorola_xt1799_1"]
manufacturer = "motorola"
brand = "motorola"
model = "moto 青柚"
device = "montana"
product = "montana"
name = "montana"
marketname = "moto 青柚"
fingerprint = ""

[templates."motorola_xt1789_05"]
manufacturer = "motorola"
brand = "motorola"
model = "moto Z 2018"
device = "nash"
product = "nash"
name = "nash"
marketname = "moto Z 2018"
fingerprint = ""

[templates."motorola_xt1925_10"]
manufacturer = "motorola"
brand = "motorola"
model = "moto 青柚 1s"
device = "ali"
product = "ali"
name = "ali"
marketname = "moto 青柚 1s"
fingerprint = ""

[templates."motorola_xt1929_15"]
manufacturer = "motorola"
brand = "motorola"
model = "motorola Z3"
device = "messi"
product = "messi"
name = "messi"
marketname = "motorola Z3"
fingerprint = ""

[templates."motorola_xt1924_9"]
manufacturer = "motorola"
brand = "motorola"
model = "motorola e5 plus"
device = "ahannah"
product = "ahannah"
name = "ahannah"
marketname = "motorola e5 plus"
fingerprint = ""

[templates."motorola_xt1943_1"]
manufacturer = "motorola"
brand = "motorola"
model = "motorola p30"
device = "robusta"
product = "robusta"
name = "robusta"
marketname = "motorola p30"
fingerprint = ""

[templates."motorola_xt1942_1"]
manufacturer = "motorola"
brand = "motorola"
model = "motorola p30 note"
device = "chef"
product = "chef"
name = "chef"
marketname = "motorola p30 note"
fingerprint = ""

[templates."motorola_xt1941_2"]
manufacturer = "motorola"
brand = "motorola"
model = "motorola p30 play"
device = "deen"
product = "deen"
name = "deen"
marketname = "motorola p30 play"
fingerprint = ""

[templates."motorola_xt1965_6"]
manufacturer = "motorola"
brand = "motorola"
model = "motorola g7 plus"
device = "lake"
product = "lake"
name = "lake"
marketname = "motorola g7 plus"
fingerprint = ""

[templates."motorola_xt1970_5"]
manufacturer = "motorola"
brand = "motorola"
model = "motorola p50"
device = "kane"
product = "kane"
name = "kane"
marketname = "motorola p50"
fingerprint = ""

[templates."motorola_xt2071_4"]
manufacturer = "motorola"
brand = "motorola"
model = "motorola razr 5G"
device = "smith"
product = "smith"
name = "smith"
marketname = "motorola razr 5G"
fingerprint = ""

[templates."motorola_xt2125_4"]
manufacturer = "motorola"
brand = "motorola"
model = "motorola edge s"
device = "nio"
product = "nio"
name = "nio"
marketname = "motorola edge s"
fingerprint = ""

[templates."motorola_xt2143_1"]
manufacturer = "motorola"
brand = "motorola"
model = "motorola edge 轻奢版"
device = "berlin"
product = "berlin"
name = "berlin"
marketname = "motorola edge 轻奢版"
fingerprint = ""

[templates."motorola_xt2153_1"]
manufacturer = "motorola"
brand = "motorola"
model = "motorola edge s pro"
device = "pstar"
product = "pstar"
name = "pstar"
marketname = "motorola edge s pro"
fingerprint = ""

[templates."motorola_xt2137_2"]
manufacturer = "motorola"
brand = "motorola"
model = "motorola g50"
device = "ibiza"
product = "ibiza"
name = "ibiza"
marketname = "motorola g50"
fingerprint = ""

[templates."motorola_xt2171_3"]
manufacturer = "motorola"
brand = "motorola"
model = "moto g51"
device = "cypfq"
product = "cypfq"
name = "cypfq"
marketname = "moto g51"
fingerprint = ""

[templates."motorola_xt2169_2"]
manufacturer = "motorola"
brand = "motorola"
model = "moto g71"
device = "corfur"
product = "corfur"
name = "corfur"
marketname = "moto g71"
fingerprint = ""

[templates."motorola_xt2225_2"]
manufacturer = "motorola"
brand = "motorola"
model = "moto g71s"
device = "rhodep"
product = "rhodep"
name = "rhodep"
marketname = "moto g71s"
fingerprint = ""

[templates."motorola_xt2175_2"]
manufacturer = "motorola"
brand = "motorola"
model = "moto edge S30"
device = "xpeng"
product = "xpeng"
name = "xpeng"
marketname = "moto edge S30"
fingerprint = ""

[templates."motorola_xt2201_2"]
manufacturer = "motorola"
brand = "motorola"
model = "moto edge X30"
device = "hiphic"
product = "hiphic"
name = "hiphic"
marketname = "moto edge X30"
fingerprint = ""

[templates."motorola_xt2201_6"]
manufacturer = "motorola"
brand = "motorola"
model = "moto edge X30 屏下摄像版"
device = "hiphid"
product = "hiphid"
name = "hiphid"
marketname = "moto edge X30 屏下摄像版"
fingerprint = ""

[templates."motorola_xt2241_1"]
manufacturer = "motorola"
brand = "motorola"
model = "moto X30 Pro"
device = "eqs"
product = "eqs"
name = "eqs"
marketname = "moto X30 Pro"
fingerprint = ""

[templates."motorola_xt2243_2"]
manufacturer = "motorola"
brand = "motorola"
model = "moto S30 Pro"
device = "tundra"
product = "tundra"
name = "tundra"
marketname = "moto S30 Pro"
fingerprint = ""

[templates."motorola_xt2251_1"]
manufacturer = "motorola"
brand = "motorola"
model = "moto razr 2022"
device = "oneli"
product = "oneli"
name = "oneli"
marketname = "moto razr 2022"
fingerprint = ""

[templates."motorola_xt2301_5"]
manufacturer = "motorola"
brand = "motorola"
model = "moto X40"
device = "rtwo"
product = "rtwo"
name = "rtwo"
marketname = "moto X40"
fingerprint = ""

[templates."motorola_xt2335_3"]
manufacturer = "motorola"
brand = "motorola"
model = "moto g53"
device = "penang"
product = "penang"
name = "penang"
marketname = "moto g53"
fingerprint = ""

[templates."motorola_xt2323_3"]
manufacturer = "motorola"
brand = "motorola"
model = "moto razr 40"
device = "lynkco"
product = "lynkco"
name = "lynkco"
marketname = "moto razr 40"
fingerprint = ""

[templates."motorola_xt2321_2"]
manufacturer = "motorola"
brand = "motorola"
model = "moto razr 40 Ultra"
device = "zeekr"
product = "zeekr"
name = "zeekr"
marketname = "moto razr 40 Ultra"
fingerprint = ""

[templates."motorola_xt2343_3"]
manufacturer = "motorola"
brand = "motorola"
model = "moto g54"
device = "cancunf"
product = "cancunf"
name = "cancunf"
marketname = "moto g54"
fingerprint = ""

[templates."motorola_xt2363_4"]
manufacturer = "motorola"
brand = "motorola"
model = "moto g34"
device = "fogos"
product = "fogos"
name = "fogos"
marketname = "moto g34"
fingerprint = ""

[templates."motorola_xt2401_2"]
manufacturer = "motorola"
brand = "motorola"
model = "moto X50 Ultra"
device = "ctwo"
product = "ctwo"
name = "ctwo"
marketname = "moto X50 Ultra"
fingerprint = ""

[templates."motorola_xt2409_5"]
manufacturer = "motorola"
brand = "motorola"
model = "moto S50"
device = "vienna"
product = "vienna"
name = "vienna"
marketname = "moto S50"
fingerprint = ""

[templates."motorola_xt2427_4"]
manufacturer = "motorola"
brand = "motorola"
model = "moto S50 Neo"
device = "malmo"
product = "malmo"
name = "malmo"
marketname = "moto S50 Neo"
fingerprint = ""

[templates."motorola_xt2453_2"]
manufacturer = "motorola"
brand = "motorola"
model = "moto razr 50"
device = "aito"
product = "aito"
name = "aito"
marketname = "moto razr 50"
fingerprint = ""

[templates."motorola_xt2451_4"]
manufacturer = "motorola"
brand = "motorola"
model = "moto razr 50 Ultra"
device = "arcfox"
product = "arcfox"
name = "arcfox"
marketname = "moto razr 50 Ultra"
fingerprint = ""

[templates."motorola_xt2435_3"]
manufacturer = "motorola"
brand = "motorola"
model = "moto g55"
device = "taipei"
product = "taipei"
name = "taipei"
marketname = "moto g55"
fingerprint = ""

[templates."motorola_xt2437_4"]
manufacturer = "motorola"
brand = "motorola"
model = "moto g75"
device = "paros"
product = "paros"
name = "paros"
marketname = "moto g75"
fingerprint = ""

[templates."motorola_xt2505_4"]
manufacturer = "motorola"
brand = "motorola"
model = "moto edge 60"
device = "scout"
product = "scout"
name = "scout"
marketname = "moto edge 60"
fingerprint = ""

[templates."motorola_xt2503_3"]
manufacturer = "motorola"
brand = "motorola"
model = "moto edge 60s"
device = "scout"
product = "scout"
name = "scout"
marketname = "moto edge 60s"
fingerprint = ""

[templates."motorola_xt2507_5"]
manufacturer = "motorola"
brand = "motorola"
model = "moto edge 60 Pro"
device = "cybert"
product = "cybert"
name = "cybert"
marketname = "moto edge 60 Pro"
fingerprint = ""

[templates."motorola_xt2553_2"]
manufacturer = "motorola"
brand = "motorola"
model = "moto razr 60"
device = "aito"
product = "aito"
name = "aito"
marketname = "moto razr 60"
fingerprint = ""

[templates."motorola_xt2557_1"]
manufacturer = "motorola"
brand = "motorola"
model = "moto razr 60 Pro"
device = "arcfox"
product = "arcfox"
name = "arcfox"
marketname = "moto razr 60 Pro"
fingerprint = ""

[templates."motorola_xt2551_3"]
manufacturer = "motorola"
brand = "motorola"
model = "moto razr 60 Ultra"
device = "leap"
product = "leap"
name = "leap"
marketname = "moto razr 60 Ultra"
fingerprint = ""

[templates."motorola_xt2527_3"]
manufacturer = "motorola"
brand = "motorola"
model = "moto g100 Pro"
device = "nice"
product = "nice"
name = "nice"
marketname = "moto g100 Pro"
fingerprint = ""

[templates."motorola_xt2533_4"]
manufacturer = "motorola"
brand = "motorola"
model = "moto g100"
device = "portov"
product = "portov"
name = "portov"
marketname = "moto g100"
fingerprint = ""

[templates."motorola_xt2537_4"]
manufacturer = "motorola"
brand = "motorola"
model = "moto g100s"
device = "mumba"
product = "mumba"
name = "mumba"
marketname = "moto g100s"
fingerprint = ""

[templates."motorola_xt2601_1"]
manufacturer = "motorola"
brand = "motorola"
model = "moto X70 Air"
device = "roadstr"
product = "roadstr"
name = "roadstr"
marketname = "moto X70 Air"
fingerprint = ""

[templates."motorola_xt2603_1"]
manufacturer = "motorola"
brand = "motorola"
model = "moto X70 Air Pro"
device = "vantage"
product = "vantage"
name = "vantage"
marketname = "moto X70 Air Pro"
fingerprint = ""

[templates."motorola_xt2651_4"]
manufacturer = "motorola"
brand = "motorola"
model = "moto razr fold"
device = "blanc"
product = "blanc"
name = "blanc"
marketname = "moto razr fold"
fingerprint = ""

[templates."motorola_xt2655_4"]
manufacturer = "motorola"
brand = "motorola"
model = "moto razr 70 Ultra"
device = "lhotse"
product = "lhotse"
name = "lhotse"
marketname = "moto razr 70 Ultra"
fingerprint = ""

[templates."oneplus_one_a0001"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Phone"
device = "bacon"
product = "bacon"
name = "bacon"
marketname = "OnePlus Phone"
fingerprint = ""

[templates."oneplus_one_a2001"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Phone 2"
device = "oneplus2"
product = "oneplus2"
name = "oneplus2"
marketname = "OnePlus Phone 2"
fingerprint = ""

[templates."oneplus_one_e1000"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Phone X"
device = "onyx"
product = "onyx"
name = "onyx"
marketname = "OnePlus Phone X"
fingerprint = ""

[templates."oneplus_oneplus_a3000"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Phone 3"
device = "oneplus3"
product = "oneplus3"
name = "oneplus3"
marketname = "OnePlus Phone 3"
fingerprint = ""

[templates."oneplus_oneplus_a3010"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Phone 3T"
device = "oneplus3t"
product = "oneplus3t"
name = "oneplus3t"
marketname = "OnePlus Phone 3T"
fingerprint = ""

[templates."oneplus_oneplus_a5000"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 5"
device = "cheeseburger"
product = "cheeseburger"
name = "cheeseburger"
marketname = "OnePlus 5"
fingerprint = ""

[templates."oneplus_oneplus_a5010"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 5T"
device = "dumpling"
product = "dumpling"
name = "dumpling"
marketname = "OnePlus 5T"
fingerprint = ""

[templates."oneplus_oneplus_a6000"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 6"
device = "enchilada"
product = "enchilada"
name = "enchilada"
marketname = "OnePlus 6"
fingerprint = ""

[templates."oneplus_oneplus_a6010"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 6T"
device = "fajita"
product = "fajita"
name = "fajita"
marketname = "OnePlus 6T"
fingerprint = ""

[templates."oneplus_gm1900"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 7"
device = "guacamoleb"
product = "guacamoleb"
name = "guacamoleb"
marketname = "OnePlus 7"
fingerprint = ""

[templates."oneplus_gm1910"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 7 Pro"
device = "guacamole"
product = "guacamole"
name = "guacamole"
marketname = "OnePlus 7 Pro"
fingerprint = ""

[templates."oneplus_gm1917"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 7 Pro T-Mobile 版"
device = "guacamolet"
product = "guacamolet"
name = "guacamolet"
marketname = "OnePlus 7 Pro T-Mobile 版"
fingerprint = ""

[templates."oneplus_gm1920"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 7 Pro 5G"
device = "guacamoleg"
product = "guacamoleg"
name = "guacamoleg"
marketname = "OnePlus 7 Pro 5G"
fingerprint = ""

[templates."oneplus_gm1925"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 7 Pro 5G Sprint 版"
device = "guacamoles"
product = "guacamoles"
name = "guacamoles"
marketname = "OnePlus 7 Pro 5G Sprint 版"
fingerprint = ""

[templates."oneplus_hd1900"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 7T"
device = "hotdogb"
product = "hotdogb"
name = "hotdogb"
marketname = "OnePlus 7T"
fingerprint = ""

[templates."oneplus_hd1907"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 7T T-Mobile 版"
device = "hotdogt"
product = "hotdogt"
name = "hotdogt"
marketname = "OnePlus 7T T-Mobile 版"
fingerprint = ""

[templates."oneplus_hd1910"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 7T Pro"
device = "hotdog"
product = "hotdog"
name = "hotdog"
marketname = "OnePlus 7T Pro"
fingerprint = ""

[templates."oneplus_hd1925"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 7T Pro 5G T-Mobile 版"
device = "hotdogg"
product = "hotdogg"
name = "hotdogg"
marketname = "OnePlus 7T Pro 5G T-Mobile 版"
fingerprint = ""

[templates."oneplus_in2010"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 8"
device = "instantnoodle"
product = "instantnoodle"
name = "instantnoodle"
marketname = "OnePlus 8"
fingerprint = ""

[templates."oneplus_in2017"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 8 T-Mobile 版"
device = "instantnoodlet"
product = "instantnoodlet"
name = "instantnoodlet"
marketname = "OnePlus 8 T-Mobile 版"
fingerprint = ""

[templates."oneplus_in2019"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 8 Visible 版"
device = "instantnoodlevis"
product = "instantnoodlevis"
name = "instantnoodlevis"
marketname = "OnePlus 8 Visible 版"
fingerprint = ""

[templates."oneplus_in2020"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 8 Pro"
device = "instantnoodlep"
product = "instantnoodlep"
name = "instantnoodlep"
marketname = "OnePlus 8 Pro"
fingerprint = ""

[templates."oneplus_kb2000"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 8T"
device = "kebab"
product = "kebab"
name = "kebab"
marketname = "OnePlus 8T"
fingerprint = ""

[templates."oneplus_kb2007"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 8T+ T-Mobile 版"
device = "kebabt"
product = "kebabt"
name = "kebabt"
marketname = "OnePlus 8T+ T-Mobile 版"
fingerprint = ""

[templates."oneplus_le2100"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 9R"
device = "lemonades"
product = "lemonades"
name = "lemonades"
marketname = "OnePlus 9R"
fingerprint = ""

[templates."oneplus_le2110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 9"
device = "lemonade"
product = "lemonade"
name = "lemonade"
marketname = "OnePlus 9"
fingerprint = ""

[templates."oneplus_le2117"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 9 T-Mobile 版"
device = "lemonadet"
product = "lemonadet"
name = "lemonadet"
marketname = "OnePlus 9 T-Mobile 版"
fingerprint = ""

[templates."oneplus_le2119"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 9 Verizon 版"
device = "lemonadev"
product = "lemonadev"
name = "lemonadev"
marketname = "OnePlus 9 Verizon 版"
fingerprint = ""

[templates."oneplus_le2120"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 9 Pro"
device = "lemonadep"
product = "lemonadep"
name = "lemonadep"
marketname = "OnePlus 9 Pro"
fingerprint = ""

[templates."oneplus_le2127"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 9 Pro T-Mobile 版"
device = "lemonadept"
product = "lemonadept"
name = "lemonadept"
marketname = "OnePlus 9 Pro T-Mobile 版"
fingerprint = ""

[templates."oneplus_mt2110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 9RT"
device = "martini"
product = "martini"
name = "martini"
marketname = "OnePlus 9RT"
fingerprint = ""

[templates."oneplus_ne2210"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 10 Pro"
device = "negroni"
product = "negroni"
name = "negroni"
marketname = "OnePlus 10 Pro"
fingerprint = ""

[templates."oneplus_ne2217"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 10 Pro T-Mobile 版"
device = "negroni"
product = "negroni"
name = "negroni"
marketname = "OnePlus 10 Pro T-Mobile 版"
fingerprint = ""

[templates."oneplus_pgkm10"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace"
device = "pickle"
product = "pickle"
name = "pickle"
marketname = "OnePlus Ace"
fingerprint = ""

[templates."oneplus_cph2423"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 10R"
device = "pickle"
product = "pickle"
name = "pickle"
marketname = "OnePlus 10R"
fingerprint = ""

[templates."oneplus_cph2411"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 10R 长寿版"
device = "pickle"
product = "pickle"
name = "pickle"
marketname = "OnePlus 10R 长寿版"
fingerprint = ""

[templates."oneplus_pgz110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 竞速版"
device = "qqcandy"
product = "qqcandy"
name = "qqcandy"
marketname = "OnePlus Ace 竞速版"
fingerprint = ""

[templates."oneplus_pgp110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace Pro"
device = "ovaltine"
product = "ovaltine"
name = "ovaltine"
marketname = "OnePlus Ace Pro"
fingerprint = ""

[templates."oneplus_cph2413"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 10T"
device = "ovaltine"
product = "ovaltine"
name = "ovaltine"
marketname = "OnePlus 10T"
fingerprint = ""

[templates."oneplus_cph2419"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 10T T-Mobile 版"
device = "ovaltine"
product = "ovaltine"
name = "ovaltine"
marketname = "OnePlus 10T T-Mobile 版"
fingerprint = ""

[templates."oneplus_phb110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 11"
device = "salami"
product = "salami"
name = "salami"
marketname = "OnePlus 11"
fingerprint = ""

[templates."oneplus_phk110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 2"
device = "udon"
product = "udon"
name = "udon"
marketname = "OnePlus Ace 2"
fingerprint = ""

[templates."oneplus_cph2487"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 11R"
device = "udon"
product = "udon"
name = "udon"
marketname = "OnePlus 11R"
fingerprint = ""

[templates."oneplus_php110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 2V"
device = "vitamin"
product = "vitamin"
name = "vitamin"
marketname = "OnePlus Ace 2V"
fingerprint = ""

[templates."oneplus_cph2491"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord 3"
device = "vitamin"
product = "vitamin"
name = "vitamin"
marketname = "OnePlus Nord 3"
fingerprint = ""

[templates."oneplus_pja110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 2 Pro"
device = "xigua"
product = "xigua"
name = "xigua"
marketname = "OnePlus Ace 2 Pro"
fingerprint = ""

[templates."oneplus_pjd110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 12"
device = "waffle"
product = "waffle"
name = "waffle"
marketname = "OnePlus 12"
fingerprint = ""

[templates."oneplus_pje110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 3"
device = "aston"
product = "aston"
name = "aston"
marketname = "OnePlus Ace 3"
fingerprint = ""

[templates."oneplus_cph2585"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 12R"
device = "aston"
product = "aston"
name = "aston"
marketname = "OnePlus 12R"
fingerprint = ""

[templates."oneplus_pjf110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 3V"
device = "audi"
product = "audi"
name = "audi"
marketname = "OnePlus Ace 3V"
fingerprint = ""

[templates."oneplus_pjx110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 3 Pro"
device = "corvette"
product = "corvette"
name = "corvette"
marketname = "OnePlus Ace 3 Pro"
fingerprint = ""

[templates."oneplus_pjz110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 13"
device = "dodge"
product = "dodge"
name = "dodge"
marketname = "OnePlus 13"
fingerprint = ""

[templates."oneplus_pkg110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 5"
device = "giulia"
product = "giulia"
name = "giulia"
marketname = "OnePlus Ace 5"
fingerprint = ""

[templates."oneplus_cph2645"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 13R"
device = "giulia"
product = "giulia"
name = "giulia"
marketname = "OnePlus 13R"
fingerprint = ""

[templates."oneplus_pkr110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 5 Pro"
device = "hummer"
product = "hummer"
name = "hummer"
marketname = "OnePlus Ace 5 Pro"
fingerprint = ""

[templates."oneplus_pkx110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 13T"
device = "pagani"
product = "pagani"
name = "pagani"
marketname = "OnePlus 13T"
fingerprint = ""

[templates."oneplus_cph2723"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 13s"
device = "pagani"
product = "pagani"
name = "pagani"
marketname = "OnePlus 13s"
fingerprint = ""

[templates."oneplus_plc110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 5 至尊版"
device = "emira"
product = "emira"
name = "emira"
marketname = "OnePlus Ace 5 至尊版"
fingerprint = ""

[templates."oneplus_plf110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 5 竞速版"
device = "subaru"
product = "subaru"
name = "subaru"
marketname = "OnePlus Ace 5 竞速版"
fingerprint = ""

[templates."oneplus_plk110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 15"
device = "infiniti"
product = "infiniti"
name = "infiniti"
marketname = "OnePlus 15"
fingerprint = ""

[templates."oneplus_plq110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 6"
device = "ktm"
product = "ktm"
name = "ktm"
marketname = "OnePlus Ace 6"
fingerprint = ""

[templates."oneplus_plr110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 6T"
device = "macan"
product = "macan"
name = "macan"
marketname = "OnePlus Ace 6T"
fingerprint = ""

[templates."oneplus_cph2767"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 15R"
device = "macan"
product = "macan"
name = "macan"
marketname = "OnePlus 15R"
fingerprint = ""

[templates."oneplus_plz110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 15T"
device = "fairlady"
product = "fairlady"
name = "fairlady"
marketname = "OnePlus 15T"
fingerprint = ""

[templates."oneplus_pmb110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 6 至尊版"
device = "roadster"
product = "roadster"
name = "roadster"
marketname = "OnePlus Ace 6 至尊版"
fingerprint = ""

[templates."oneplus_plu110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Turbo 6"
device = "volkswagen"
product = "volkswagen"
name = "volkswagen"
marketname = "OnePlus Turbo 6"
fingerprint = ""

[templates."oneplus_cph2793"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord 6"
device = "volkswagen"
product = "volkswagen"
name = "volkswagen"
marketname = "OnePlus Nord 6"
fingerprint = ""

[templates."oneplus_ply110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Turbo 6V"
device = "prado"
product = "prado"
name = "prado"
marketname = "OnePlus Turbo 6V"
fingerprint = ""

[templates."oneplus_cph2805"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord CE 6"
device = "prado"
product = "prado"
name = "prado"
marketname = "OnePlus Nord CE 6"
fingerprint = ""

[templates."oneplus_pys110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Turbo 6X"
device = "kof"
product = "kof"
name = "kof"
marketname = "OnePlus Turbo 6X"
fingerprint = ""

[templates."oneplus_pyr110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Turbo 6X Pro"
device = "lol"
product = "lol"
name = "lol"
marketname = "OnePlus Turbo 6X Pro"
fingerprint = ""

[templates."oneplus_pyb110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 16"
device = "pokemon"
product = "pokemon"
name = "pokemon"
marketname = "OnePlus 16"
fingerprint = ""

[templates."oneplus_pyf110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 7"
device = "mario"
product = "mario"
name = "mario"
marketname = "OnePlus Ace 7"
fingerprint = ""

[templates."oneplus_pms110"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Ace 7 Pro"
device = "redalert"
product = "redalert"
name = "redalert"
marketname = "OnePlus Ace 7 Pro"
fingerprint = ""

[templates."oneplus_ac2001"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord"
device = "avicii"
product = "avicii"
name = "avicii"
marketname = "OnePlus Nord"
fingerprint = ""

[templates."oneplus_dn2101"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord 2"
device = "denniz"
product = "denniz"
name = "denniz"
marketname = "OnePlus Nord 2"
fingerprint = ""

[templates."oneplus_cph2399"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord 2T"
device = "karen"
product = "karen"
name = "karen"
marketname = "OnePlus Nord 2T"
fingerprint = ""

[templates."oneplus_cph2661"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord 4"
device = "avalon"
product = "avalon"
name = "avalon"
marketname = "OnePlus Nord 4"
fingerprint = ""

[templates."oneplus_cph2707"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord 5"
device = "lexus"
product = "lexus"
name = "lexus"
marketname = "OnePlus Nord 5"
fingerprint = ""

[templates."oneplus_eb2101"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord CE"
device = "ebba"
product = "ebba"
name = "ebba"
marketname = "OnePlus Nord CE"
fingerprint = ""

[templates."oneplus_iv2201"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord CE 2"
device = "ivan"
product = "ivan"
name = "ivan"
marketname = "OnePlus Nord CE 2"
fingerprint = ""

[templates."oneplus_cph2381"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord CE 2 Lite"
device = "oscar"
product = "oscar"
name = "oscar"
marketname = "OnePlus Nord CE 2 Lite"
fingerprint = ""

[templates."oneplus_cph2569"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord CE 3"
device = "ziti"
product = "ziti"
name = "ziti"
marketname = "OnePlus Nord CE 3"
fingerprint = ""

[templates."oneplus_cph2465"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord CE 3 Lite"
device = "larry"
product = "larry"
name = "larry"
marketname = "OnePlus Nord CE 3 Lite"
fingerprint = ""

[templates."oneplus_cph2513"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord N30"
device = "larry"
product = "larry"
name = "larry"
marketname = "OnePlus Nord N30"
fingerprint = ""

[templates."oneplus_cph2515"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord N30 T-Mobile 版"
device = "larry"
product = "larry"
name = "larry"
marketname = "OnePlus Nord N30 T-Mobile 版"
fingerprint = ""

[templates."oneplus_cph2613"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord CE 4"
device = "benz"
product = "benz"
name = "benz"
marketname = "OnePlus Nord CE 4"
fingerprint = ""

[templates."oneplus_cph2619"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord CE 4 Lite"
device = "camry"
product = "camry"
name = "camry"
marketname = "OnePlus Nord CE 4 Lite"
fingerprint = ""

[templates."oneplus_cph2717"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord CE 5"
device = "honda"
product = "honda"
name = "honda"
marketname = "OnePlus Nord CE 5"
fingerprint = ""

[templates."oneplus_cph2943"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord CE 6 Lite"
device = "suzuki-o"
product = "suzuki-o"
name = "suzuki-o"
marketname = "OnePlus Nord CE 6 Lite"
fingerprint = ""

[templates."oneplus_cph2955"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus N6"
device = "mumbai-o"
product = "mumbai-o"
name = "mumbai-o"
marketname = "OnePlus N6"
fingerprint = ""

[templates."oneplus_cph2971"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus N6x"
device = "mumbai-c5"
product = "mumbai-c5"
name = "mumbai-c5"
marketname = "OnePlus N6x"
fingerprint = ""

[templates."oneplus_cph2993"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus N6 Lite"
device = "CPH2993"
product = "CPH2993"
marketname = "OnePlus N6 Lite"
fingerprint = ""

[templates."oneplus_be2025"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord N10 Metro 版"
device = "billie8"
product = "billie8"
name = "billie8"
marketname = "OnePlus Nord N10 Metro 版"
fingerprint = ""

[templates."oneplus_be2026"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord N10"
device = "billie8"
product = "billie8"
name = "billie8"
marketname = "OnePlus Nord N10"
fingerprint = ""

[templates."oneplus_be2028"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord N10 T-Mobile 版"
device = "billie8t"
product = "billie8t"
name = "billie8t"
marketname = "OnePlus Nord N10 T-Mobile 版"
fingerprint = ""

[templates."oneplus_be2011"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord N100"
device = "bengal"
product = "bengal"
name = "bengal"
marketname = "OnePlus Nord N100"
fingerprint = ""

[templates."oneplus_be2012"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord N100 T-Mobile 版"
device = "bengal"
product = "bengal"
name = "bengal"
marketname = "OnePlus Nord N100 T-Mobile 版"
fingerprint = ""

[templates."oneplus_be2015"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord N100 Metro 版"
device = "bengal"
product = "bengal"
name = "bengal"
marketname = "OnePlus Nord N100 Metro 版"
fingerprint = ""

[templates."oneplus_gn2200"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord N20 北美运营商版"
device = "gunnar"
product = "gunnar"
name = "gunnar"
marketname = "OnePlus Nord N20 北美运营商版"
fingerprint = ""

[templates."oneplus_cph2459"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord N20 北美无锁版"
device = "gunnar"
product = "gunnar"
name = "gunnar"
marketname = "OnePlus Nord N20 北美无锁版"
fingerprint = ""

[templates."oneplus_cph2469"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord N20 SE"
device = "zhaoyun-o"
product = "zhaoyun-o"
name = "zhaoyun-o"
marketname = "OnePlus Nord N20 SE"
fingerprint = ""

[templates."oneplus_cph2605"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord N30 SE"
device = "fanli-o"
product = "fanli-o"
name = "fanli-o"
marketname = "OnePlus Nord N30 SE"
fingerprint = ""

[templates."oneplus_de2117"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord N200"
device = "dre9"
product = "dre9"
name = "dre9"
marketname = "OnePlus Nord N200"
fingerprint = ""

[templates."oneplus_de2118"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord N200 T-Mobile 版"
device = "dre8t"
product = "dre8t"
name = "dre8t"
marketname = "OnePlus Nord N200 T-Mobile 版"
fingerprint = ""

[templates."oneplus_cph2389"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Nord N300"
device = "hilda"
product = "hilda"
name = "hilda"
marketname = "OnePlus Nord N300"
fingerprint = ""

[templates."oneplus_cph2551"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus Open"
device = "hedwig"
product = "hedwig"
name = "hedwig"
marketname = "OnePlus Open"
fingerprint = ""

[templates."oneplus_opd2203"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 平板"
device = "aries-o"
product = "aries-o"
name = "aries-o"
marketname = "OnePlus 平板"
fingerprint = ""

[templates."oneplus_opd2304"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 平板 Go"
device = "bluey-o"
product = "bluey-o"
name = "bluey-o"
marketname = "OnePlus 平板 Go"
fingerprint = ""

[templates."oneplus_opd2404"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 平板 Pro"
device = "rainbow"
product = "rainbow"
name = "rainbow"
marketname = "OnePlus 平板 Pro"
fingerprint = ""

[templates."oneplus_opd2403"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 平板 2"
device = "rainbow"
product = "rainbow"
name = "rainbow"
marketname = "OnePlus 平板 2"
fingerprint = ""

[templates."oneplus_opd2413"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 平板 2 Pro"
device = "erhai-o"
product = "erhai-o"
name = "erhai-o"
marketname = "OnePlus 平板 2 Pro"
fingerprint = ""

[templates."oneplus_opd2415"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 平板 3"
device = "erhai-o"
product = "erhai-o"
name = "erhai-o"
marketname = "OnePlus 平板 3"
fingerprint = ""

[templates."oneplus_opd2480"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 平板 Lite"
device = "fiji-o"
product = "fiji-o"
name = "fiji-o"
marketname = "OnePlus 平板 Lite"
fingerprint = ""

[templates."oneplus_opd2504"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 平板 Go 2"
device = "greenland-o"
product = "greenland-o"
name = "greenland-o"
marketname = "OnePlus 平板 Go 2"
fingerprint = ""

[templates."oneplus_opd2505"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 平板 Go 2 5G"
device = "greenland-o"
product = "greenland-o"
name = "greenland-o"
marketname = "OnePlus 平板 Go 2 5G"
fingerprint = ""

[templates."oneplus_opd2513"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 平板 3 Pro"
device = "iceland-o"
product = "iceland-o"
name = "iceland-o"
marketname = "OnePlus 平板 3 Pro"
fingerprint = ""

[templates."oneplus_opd2514"]
manufacturer = "OnePlus"
brand = "OnePlus"
model = "OnePlus 平板 4"
device = "iceland-o"
product = "iceland-o"
name = "iceland-o"
marketname = "OnePlus 平板 4"
fingerprint = ""

[templates."oppo_pafm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X"
device = "PAFM00"
product = "PAFM00"
marketname = "OPPO Find X"
fingerprint = ""

[templates."oppo_pahm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X 超级闪充版/兰博基尼版"
device = "PAHM00"
product = "PAHM00"
marketname = "OPPO Find X 超级闪充版/兰博基尼版"
fingerprint = ""

[templates."oppo_paft10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X 超级闪充版"
device = "PAFT10"
product = "PAFT10"
marketname = "OPPO Find X 超级闪充版"
fingerprint = ""

[templates."oppo_pdem10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X2"
device = "PDEM10"
product = "PDEM10"
marketname = "OPPO Find X2"
fingerprint = ""

[templates."oppo_pdem30"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X2 Pro"
device = "PDEM30"
product = "PDEM30"
marketname = "OPPO Find X2 Pro"
fingerprint = ""

[templates."oppo_pedm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X3"
device = "horee"
product = "horee"
name = "horee"
marketname = "OPPO Find X3"
fingerprint = ""

[templates."oppo_peem00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X3 Pro"
device = "fluorite"
product = "fluorite"
name = "fluorite"
marketname = "OPPO Find X3 Pro"
fingerprint = ""

[templates."oppo_pffm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X5"
device = "luwu"
product = "luwu"
name = "luwu"
marketname = "OPPO Find X5"
fingerprint = ""

[templates."oppo_pfem10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X5 Pro"
device = "baize"
product = "baize"
name = "baize"
marketname = "OPPO Find X5 Pro"
fingerprint = ""

[templates."oppo_pffm20"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X5 Pro 天玑版"
device = "diting"
product = "diting"
name = "diting"
marketname = "OPPO Find X5 Pro 天玑版"
fingerprint = ""

[templates."oppo_pgfm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X6"
device = "luna"
product = "luna"
name = "luna"
marketname = "OPPO Find X6"
fingerprint = ""

[templates."oppo_pgem10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X6 Pro"
device = "wukong"
product = "wukong"
name = "wukong"
marketname = "OPPO Find X6 Pro"
fingerprint = ""

[templates."oppo_phz110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X7"
device = "nvwa-v"
product = "nvwa-v"
name = "nvwa-v"
marketname = "OPPO Find X7"
fingerprint = ""

[templates."oppo_phy110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X7 Ultra"
device = "pangu"
product = "pangu"
name = "pangu"
marketname = "OPPO Find X7 Ultra"
fingerprint = ""

[templates."oppo_phy120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X7 Ultra 卫星通信版"
device = "pangu"
product = "pangu"
name = "pangu"
marketname = "OPPO Find X7 Ultra 卫星通信版"
fingerprint = ""

[templates."oppo_pkb110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X8"
device = "yala"
product = "yala"
name = "yala"
marketname = "OPPO Find X8"
fingerprint = ""

[templates."oppo_pkc110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X8 Pro"
device = "konka"
product = "konka"
name = "konka"
marketname = "OPPO Find X8 Pro"
fingerprint = ""

[templates."oppo_pkc130"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X8 Pro 卫星通信版"
device = "konka"
product = "konka"
name = "konka"
marketname = "OPPO Find X8 Pro 卫星通信版"
fingerprint = ""

[templates."oppo_pkt110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X8s"
device = "koktokay"
product = "koktokay"
name = "koktokay"
marketname = "OPPO Find X8s"
fingerprint = ""

[templates."oppo_plb110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X8s+"
device = "slmh"
product = "slmh"
name = "slmh"
marketname = "OPPO Find X8s+"
fingerprint = ""

[templates."oppo_pkj110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X8 Ultra"
device = "zhufeng"
product = "zhufeng"
name = "zhufeng"
marketname = "OPPO Find X8 Ultra"
fingerprint = ""

[templates."oppo_pku110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X8 Ultra 卫星通信版"
device = "zhufeng"
product = "zhufeng"
name = "zhufeng"
marketname = "OPPO Find X8 Ultra 卫星通信版"
fingerprint = ""

[templates."oppo_plj110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X9"
device = "zhujiang"
product = "zhujiang"
name = "zhujiang"
marketname = "OPPO Find X9"
fingerprint = ""

[templates."oppo_plg110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X9 Pro"
device = "changjiang"
product = "changjiang"
name = "changjiang"
marketname = "OPPO Find X9 Pro"
fingerprint = ""

[templates."oppo_plg120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X9 Pro 卫星通信版"
device = "changjiang"
product = "changjiang"
name = "changjiang"
marketname = "OPPO Find X9 Pro 卫星通信版"
fingerprint = ""

[templates."oppo_pme110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X9s Pro"
device = "venus"
product = "venus"
name = "venus"
marketname = "OPPO Find X9s Pro"
fingerprint = ""

[templates."oppo_pma110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X9 Ultra"
device = "lighthouse"
product = "lighthouse"
name = "lighthouse"
marketname = "OPPO Find X9 Ultra"
fingerprint = ""

[templates."oppo_pma120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X9 Ultra 卫星通信版"
device = "lighthouse"
product = "lighthouse"
name = "lighthouse"
marketname = "OPPO Find X9 Ultra 卫星通信版"
fingerprint = ""

[templates."oppo_pmw110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X10"
device = "uranus"
product = "uranus"
name = "uranus"
marketname = "OPPO Find X10"
fingerprint = ""

[templates."oppo_pna110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X10 E"
device = "neptune"
product = "neptune"
name = "neptune"
marketname = "OPPO Find X10 E"
fingerprint = ""

[templates."oppo_pmx110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find X10 Pro Max"
device = "mars"
product = "mars"
name = "mars"
marketname = "OPPO Find X10 Pro Max"
fingerprint = ""

[templates."oppo_peum00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find N"
device = "peacock"
product = "peacock"
name = "peacock"
marketname = "OPPO Find N"
fingerprint = ""

[templates."oppo_pgu110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find N2"
device = "whiteswan"
product = "whiteswan"
name = "whiteswan"
marketname = "OPPO Find N2"
fingerprint = ""

[templates."oppo_pgt110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find N2 Flip"
device = "dragonfly"
product = "dragonfly"
name = "dragonfly"
marketname = "OPPO Find N2 Flip"
fingerprint = ""

[templates."oppo_phn110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find N3"
device = "xueying"
product = "xueying"
name = "xueying"
marketname = "OPPO Find N3"
fingerprint = ""

[templates."oppo_pht110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find N3 Flip"
device = "flamingo"
product = "flamingo"
name = "flamingo"
marketname = "OPPO Find N3 Flip"
fingerprint = ""

[templates."oppo_pkh110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find N5"
device = "petrel"
product = "petrel"
name = "petrel"
marketname = "OPPO Find N5"
fingerprint = ""

[templates."oppo_pkh120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find N5 卫星通信版"
device = "petrel"
product = "petrel"
name = "petrel"
marketname = "OPPO Find N5 卫星通信版"
fingerprint = ""

[templates."oppo_plp110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find N6"
device = "swangoose"
product = "swangoose"
name = "swangoose"
marketname = "OPPO Find N6"
fingerprint = ""

[templates."oppo_plp120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Find N6 卫星通信版"
device = "swangoose"
product = "swangoose"
name = "swangoose"
marketname = "OPPO Find N6 卫星通信版"
fingerprint = ""

[templates."oppo_pcam00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno"
device = "PCAM00"
product = "PCAM00"
marketname = "OPPO Reno"
fingerprint = ""

[templates."oppo_pccm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno 10 倍变焦版"
device = "PCCM00"
product = "PCCM00"
marketname = "OPPO Reno 10 倍变焦版"
fingerprint = ""

[templates."oppo_pcdm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno Z"
device = "PCDM10"
product = "PCDM10"
marketname = "OPPO Reno Z"
fingerprint = ""

[templates."oppo_pckm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno2"
device = "PCKM00"
product = "PCKM00"
marketname = "OPPO Reno2"
fingerprint = ""

[templates."oppo_pckm80"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno2 Z"
device = "PCKM80"
product = "PCKM80"
marketname = "OPPO Reno2 Z"
fingerprint = ""

[templates."oppo_pdcm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno3"
device = "PDCM00"
product = "PDCM00"
marketname = "OPPO Reno3"
fingerprint = ""

[templates."oppo_pcrm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno3 Pro"
device = "PCRM00"
product = "PCRM00"
marketname = "OPPO Reno3 Pro"
fingerprint = ""

[templates."oppo_pclm50"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno3 元气版"
device = "PCLM50"
product = "PCLM50"
marketname = "OPPO Reno3 元气版"
fingerprint = ""

[templates."oppo_pdpm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno4"
device = "PDPM00"
product = "PDPM00"
marketname = "OPPO Reno4"
fingerprint = ""

[templates."oppo_pdnm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno4 Pro"
device = "PDNM00"
product = "PDNM00"
marketname = "OPPO Reno4 Pro"
fingerprint = ""

[templates."oppo_peam00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno4 SE"
device = "PEAM00"
product = "PEAM00"
marketname = "OPPO Reno4 SE"
fingerprint = ""

[templates."oppo_pegm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno5"
device = "kunlun"
product = "kunlun"
name = "kunlun"
marketname = "OPPO Reno5"
fingerprint = ""

[templates."oppo_pegm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno5 K"
device = "wudang"
product = "wudang"
name = "wudang"
marketname = "OPPO Reno5 K"
fingerprint = ""

[templates."oppo_pdsm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno5 Pro"
device = "chaka"
product = "chaka"
name = "chaka"
marketname = "OPPO Reno5 Pro"
fingerprint = ""

[templates."oppo_pdrm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno5 Pro+"
device = "hima"
product = "hima"
name = "hima"
marketname = "OPPO Reno5 Pro+"
fingerprint = ""

[templates."oppo_peqm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno6"
device = "garen"
product = "garen"
name = "garen"
marketname = "OPPO Reno6"
fingerprint = ""

[templates."oppo_pepm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno6 Pro"
device = "yasuo"
product = "yasuo"
name = "yasuo"
marketname = "OPPO Reno6 Pro"
fingerprint = ""

[templates."oppo_penm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno6 Pro+"
device = "jin"
product = "jin"
name = "jin"
marketname = "OPPO Reno6 Pro+"
fingerprint = ""

[templates."oppo_pfjm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno7"
device = "libai"
product = "libai"
name = "libai"
marketname = "OPPO Reno7"
fingerprint = ""

[templates."oppo_pfdm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno7 Pro"
device = "mozi"
product = "mozi"
name = "mozi"
marketname = "OPPO Reno7 Pro"
fingerprint = ""

[templates."oppo_pfcm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno7 SE"
device = "dufu"
product = "dufu"
name = "dufu"
marketname = "OPPO Reno7 SE"
fingerprint = ""

[templates."oppo_pgbm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno8"
device = "ali"
product = "ali"
name = "ali"
marketname = "OPPO Reno8"
fingerprint = ""

[templates."oppo_pgam10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno8 Pro"
device = "wuyi"
product = "wuyi"
name = "wuyi"
marketname = "OPPO Reno8 Pro"
fingerprint = ""

[templates."oppo_pfzm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno8 Pro+"
device = "taibai"
product = "taibai"
name = "taibai"
marketname = "OPPO Reno8 Pro+"
fingerprint = ""

[templates."oppo_phm110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno9"
device = "lantian"
product = "lantian"
name = "lantian"
marketname = "OPPO Reno9"
fingerprint = ""

[templates."oppo_pgx110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno9 Pro"
device = "linhai"
product = "linhai"
name = "linhai"
marketname = "OPPO Reno9 Pro"
fingerprint = ""

[templates."oppo_pgw110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno9 Pro+"
device = "lvzhou"
product = "lvzhou"
name = "lvzhou"
marketname = "OPPO Reno9 Pro+"
fingerprint = ""

[templates."oppo_phw110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno10"
device = "taylor"
product = "taylor"
name = "taylor"
marketname = "OPPO Reno10"
fingerprint = ""

[templates."oppo_phv110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno10 Pro"
device = "viven"
product = "viven"
name = "viven"
marketname = "OPPO Reno10 Pro"
fingerprint = ""

[templates."oppo_phu110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno10 Pro+"
device = "monroe"
product = "monroe"
name = "monroe"
marketname = "OPPO Reno10 Pro+"
fingerprint = ""

[templates."oppo_pjh110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno11"
device = "huahai"
product = "huahai"
name = "huahai"
marketname = "OPPO Reno11"
fingerprint = ""

[templates."oppo_pjj110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno11 Pro"
device = "daoxiang"
product = "daoxiang"
name = "daoxiang"
marketname = "OPPO Reno11 Pro"
fingerprint = ""

[templates."oppo_pjv110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno12"
device = "omega"
product = "omega"
name = "omega"
marketname = "OPPO Reno12"
fingerprint = ""

[templates."oppo_pjw110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno12 Pro"
device = "omega"
product = "omega"
name = "omega"
marketname = "OPPO Reno12 Pro"
fingerprint = ""

[templates."oppo_pkm110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno13"
device = "milkyway"
product = "milkyway"
name = "milkyway"
marketname = "OPPO Reno13"
fingerprint = ""

[templates."oppo_pkk110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno13 Pro"
device = "milkyway"
product = "milkyway"
name = "milkyway"
marketname = "OPPO Reno13 Pro"
fingerprint = ""

[templates."oppo_pla110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno14"
device = "zhuque"
product = "zhuque"
name = "zhuque"
marketname = "OPPO Reno14"
fingerprint = ""

[templates."oppo_pkz110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno14 Pro"
device = "zhuque"
product = "zhuque"
name = "zhuque"
marketname = "OPPO Reno14 Pro"
fingerprint = ""

[templates."oppo_plw110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno15"
device = "whoopass-c2"
product = "whoopass-c2"
name = "whoopass-c2"
marketname = "OPPO Reno15"
fingerprint = ""

[templates."oppo_plv110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno15 Pro"
device = "whoopass-c1"
product = "whoopass-c1"
name = "whoopass-c1"
marketname = "OPPO Reno15 Pro"
fingerprint = ""

[templates."oppo_pmd110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno15c"
device = "whoopass-c3"
product = "whoopass-c3"
name = "whoopass-c3"
marketname = "OPPO Reno15c"
fingerprint = ""

[templates."oppo_pmm110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno16"
device = "lychee-c2"
product = "lychee-c2"
name = "lychee-c2"
marketname = "OPPO Reno16"
fingerprint = ""

[templates."oppo_pmk110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno16 Pro"
device = "lychee-c1"
product = "lychee-c1"
name = "lychee-c1"
marketname = "OPPO Reno16 Pro"
fingerprint = ""

[templates."oppo_pyk110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno17"
device = "PYK110"
product = "PYK110"
marketname = "OPPO Reno17"
fingerprint = ""

[templates."oppo_pnd110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno17 Pro"
device = "PND110"
product = "PND110"
marketname = "OPPO Reno17 Pro"
fingerprint = ""

[templates."oppo_pclm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Reno Ace"
device = "PCLM10"
product = "PCLM10"
marketname = "OPPO Reno Ace"
fingerprint = ""

[templates."oppo_pdhm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Ace2"
device = "PDHM00"
product = "PDHM00"
marketname = "OPPO Ace2"
fingerprint = ""

[templates."oppo_pacm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO R15"
device = "PACM00"
product = "PACM00"
marketname = "OPPO R15"
fingerprint = ""

[templates."oppo_paam00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO R15 梦镜版"
device = "PAAM00"
product = "PAAM00"
marketname = "OPPO R15 梦镜版"
fingerprint = ""

[templates."oppo_pbcm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO R15x"
device = "PBCM10"
product = "PBCM10"
marketname = "OPPO R15x"
fingerprint = ""

[templates."oppo_pbem00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO R17"
device = "PBEM00"
product = "PBEM00"
marketname = "OPPO R17"
fingerprint = ""

[templates."oppo_pbdm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO R17 Pro"
device = "PBDM00"
product = "PBDM00"
marketname = "OPPO R17 Pro"
fingerprint = ""

[templates."oppo_padm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A3"
device = "PADM00"
product = "PADM00"
marketname = "OPPO A3"
fingerprint = ""

[templates."oppo_pbam00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A5"
device = "PBAM00"
product = "PBAM00"
marketname = "OPPO A5"
fingerprint = ""

[templates."oppo_pbfm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A7"
device = "PBFM00"
product = "PBFM00"
marketname = "OPPO A7"
fingerprint = ""

[templates."oppo_pbbm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A7x"
device = "PBBM00"
product = "PBBM00"
marketname = "OPPO A7x"
fingerprint = ""

[templates."oppo_pcdm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A7n"
device = "PCDM00"
product = "PCDM00"
marketname = "OPPO A7n"
fingerprint = ""

[templates."oppo_pdbm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A8"
device = "PDBM00"
product = "PDBM00"
marketname = "OPPO A8"
fingerprint = ""

[templates."oppo_pcam10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A9"
device = "PCAM10"
product = "PCAM10"
marketname = "OPPO A9"
fingerprint = ""

[templates."oppo_pcem00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A9x"
device = "PCEM00"
product = "PCEM00"
marketname = "OPPO A9x"
fingerprint = ""

[templates."oppo_pchm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A11"
device = "PCHM10"
product = "PCHM10"
marketname = "OPPO A11"
fingerprint = ""

[templates."oppo_pchm30"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A11x"
device = "PCHM30"
product = "PCHM30"
marketname = "OPPO A11x"
fingerprint = ""

[templates."oppo_pchm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A11n"
device = "PCHM00"
product = "PCHM00"
marketname = "OPPO A11n"
fingerprint = ""

[templates."oppo_pdvm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A11s"
device = "PDVM00"
product = "PDVM00"
marketname = "OPPO A11s"
fingerprint = ""

[templates."oppo_pefm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A35"
device = "PEFM00"
product = "PEFM00"
marketname = "OPPO A35"
fingerprint = ""

[templates."oppo_pesm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A36"
device = "PESM10"
product = "PESM10"
marketname = "OPPO A36"
fingerprint = ""

[templates."oppo_pdam10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A52"
device = "PDAM10"
product = "PDAM10"
marketname = "OPPO A52"
fingerprint = ""

[templates."oppo_pecm20"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A53"
device = "PECM20"
product = "PECM20"
marketname = "OPPO A53"
fingerprint = ""

[templates."oppo_pemm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A55"
device = "PEMM00"
product = "PEMM00"
marketname = "OPPO A55"
fingerprint = ""

[templates."oppo_pfvm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A56"
device = "PFVM10"
product = "PFVM10"
marketname = "OPPO A56"
fingerprint = ""

[templates."oppo_pftm20"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A56s"
device = "PFTM20"
product = "PFTM20"
marketname = "OPPO A56s"
fingerprint = ""

[templates."oppo_phj110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A58"
device = "lijing"
product = "lijing"
name = "lijing"
marketname = "OPPO A58"
fingerprint = ""

[templates."oppo_pdym20"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A72"
device = "PDYM20"
product = "PDYM20"
marketname = "OPPO A72"
fingerprint = ""

[templates."oppo_pdym10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A72n"
device = "PDYM10"
product = "PDYM10"
marketname = "OPPO A72n"
fingerprint = ""

[templates."oppo_pcpm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A91"
device = "PCPM00"
product = "PCPM00"
marketname = "OPPO A91"
fingerprint = ""

[templates."oppo_pdkm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A92s"
device = "PDKM00"
product = "PDKM00"
marketname = "OPPO A92s"
fingerprint = ""

[templates."oppo_pehm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A93"
device = "PEHM00"
product = "PEHM00"
marketname = "OPPO A93"
fingerprint = ""

[templates."oppo_pfgm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A93s"
device = "odin-a"
product = "odin-a"
name = "odin-a"
marketname = "OPPO A93s"
fingerprint = ""

[templates."oppo_pelm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A95"
device = "PELM00"
product = "PELM00"
marketname = "OPPO A95"
fingerprint = ""

[templates."oppo_pfum10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A96"
device = "mulan"
product = "mulan"
name = "mulan"
marketname = "OPPO A96"
fingerprint = ""

[templates."oppo_pftm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A97"
device = "alice"
product = "alice"
name = "alice"
marketname = "OPPO A97"
fingerprint = ""

[templates."oppo_phs110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A1 5G"
device = "colombo"
product = "colombo"
name = "colombo"
marketname = "OPPO A1 5G"
fingerprint = ""

[templates."oppo_phq110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A1 Pro"
device = "hepburn"
product = "hepburn"
name = "hepburn"
marketname = "OPPO A1 Pro"
fingerprint = ""

[templates."oppo_pjb110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A1s"
device = "fanli"
product = "fanli"
name = "fanli"
marketname = "OPPO A1s"
fingerprint = ""

[templates."oppo_pju110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A1i"
device = "lijing-a"
product = "lijing-a"
name = "lijing-a"
marketname = "OPPO A1i"
fingerprint = ""

[templates."oppo_pjs110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A2x"
device = "lijing-a"
product = "lijing-a"
name = "lijing-a"
marketname = "OPPO A2x"
fingerprint = ""

[templates."oppo_pjg110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A2 Pro"
device = "givenchy"
product = "givenchy"
name = "givenchy"
marketname = "OPPO A2 Pro"
fingerprint = ""

[templates."oppo_pka110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A3 5G"
device = "avatar-m"
product = "avatar-m"
name = "avatar-m"
marketname = "OPPO A3 5G"
fingerprint = ""

[templates."oppo_pkd110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A3 活力版"
device = "avatar-l5"
product = "avatar-l5"
name = "avatar-l5"
marketname = "OPPO A3 活力版"
fingerprint = ""

[templates."oppo_pkd120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A3m"
device = "PKD120"
product = "PKD120"
marketname = "OPPO A3m"
fingerprint = ""

[templates."oppo_pkd130"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A3x"
device = "avatar-l5"
product = "avatar-l5"
name = "avatar-l5"
marketname = "OPPO A3x"
fingerprint = ""

[templates."oppo_pkl110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A3i"
device = "avatar-b5"
product = "avatar-b5"
name = "avatar-b5"
marketname = "OPPO A3i"
fingerprint = ""

[templates."oppo_pjy110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A3 Pro"
device = "avatar-h"
product = "avatar-h"
name = "avatar-h"
marketname = "OPPO A3 Pro"
fingerprint = ""

[templates."oppo_pkq110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A5 5G"
device = "alpha-m"
product = "alpha-m"
name = "alpha-m"
marketname = "OPPO A5 5G"
fingerprint = ""

[templates."oppo_pkv110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A5 活力版"
device = "alpha-l5"
product = "alpha-l5"
name = "alpha-l5"
marketname = "OPPO A5 活力版"
fingerprint = ""

[templates."oppo_pkw110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A5x"
device = "alpha-b5"
product = "alpha-b5"
name = "alpha-b5"
marketname = "OPPO A5x"
fingerprint = ""

[templates."oppo_pkp110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A5 Pro"
device = "alpha"
product = "alpha"
name = "alpha"
marketname = "OPPO A5 Pro"
fingerprint = ""

[templates."oppo_pls120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A6"
device = "baikal-l5"
product = "baikal-l5"
name = "baikal-l5"
marketname = "OPPO A6"
fingerprint = ""

[templates."oppo_pll110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A6 GT"
device = "baikal-h"
product = "baikal-h"
name = "baikal-h"
marketname = "OPPO A6 GT"
fingerprint = ""

[templates."oppo_pln110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A6 Pro"
device = "baikal-m"
product = "baikal-m"
name = "baikal-m"
marketname = "OPPO A6 Pro"
fingerprint = ""

[templates."oppo_pkw120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A6i"
device = "alpha-b5"
product = "alpha-b5"
name = "alpha-b5"
marketname = "OPPO A6i"
fingerprint = ""

[templates."oppo_plt120"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A6s"
device = "baikal-b5"
product = "baikal-b5"
name = "baikal-b5"
marketname = "OPPO A6s"
fingerprint = ""

[templates."oppo_pmt110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A6s Pro"
device = "cruiser-l5"
product = "cruiser-l5"
name = "cruiser-l5"
marketname = "OPPO A6s Pro"
fingerprint = ""

[templates."oppo_plt130"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A6v"
device = "baikal-b5"
product = "baikal-b5"
name = "baikal-b5"
marketname = "OPPO A6v"
fingerprint = ""

[templates."oppo_plt140"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A6x"
device = "baikal-b5"
product = "baikal-b5"
name = "baikal-b5"
marketname = "OPPO A6x"
fingerprint = ""

[templates."oppo_pmc110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A6c"
device = "baikal-b4"
product = "baikal-b4"
name = "baikal-b4"
marketname = "OPPO A6c"
fingerprint = ""

[templates."oppo_plt150"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A7i"
device = "baikal-b5"
product = "baikal-b5"
name = "baikal-b5"
marketname = "OPPO A7i"
fingerprint = ""

[templates."oppo_pye110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A7 Pro"
device = "doraemon-b5"
product = "doraemon-b5"
name = "doraemon-b5"
marketname = "OPPO A7 Pro"
fingerprint = ""

[templates."oppo_pyc110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO A7 Pro Max"
device = "doraemon-m"
product = "doraemon-m"
name = "doraemon-m"
marketname = "OPPO A7 Pro Max"
fingerprint = ""

[templates."oppo_pbcm30"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K1"
device = "PBCM30"
product = "PBCM30"
marketname = "OPPO K1"
fingerprint = ""

[templates."oppo_pcgm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K3"
device = "PCGM00"
product = "PCGM00"
marketname = "OPPO K3"
fingerprint = ""

[templates."oppo_pcnm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K5"
device = "PCNM00"
product = "PCNM00"
marketname = "OPPO K5"
fingerprint = ""

[templates."oppo_perm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K7x"
device = "PERM00"
product = "PERM00"
marketname = "OPPO K7x"
fingerprint = ""

[templates."oppo_pexm00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K9"
device = "ciri"
product = "ciri"
name = "ciri"
marketname = "OPPO K9"
fingerprint = ""

[templates."oppo_perm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K9s"
device = "walle"
product = "walle"
name = "walle"
marketname = "OPPO K9s"
fingerprint = ""

[templates."oppo_peym00"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K9 Pro"
device = "tiga"
product = "tiga"
name = "tiga"
marketname = "OPPO K9 Pro"
fingerprint = ""

[templates."oppo_pgcm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K9x"
device = "apollo-o"
product = "apollo-o"
name = "apollo-o"
marketname = "OPPO K9x"
fingerprint = ""

[templates."oppo_pgjm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K10"
device = "qqcandy"
product = "qqcandy"
name = "qqcandy"
marketname = "OPPO K10"
fingerprint = ""

[templates."oppo_pgim10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K10 Pro"
device = "eva"
product = "eva"
name = "eva"
marketname = "OPPO K10 Pro"
fingerprint = ""

[templates."oppo_pggm10"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K10x"
device = "oscar-y"
product = "oscar-y"
name = "oscar-y"
marketname = "OPPO K10x"
fingerprint = ""

[templates."oppo_pjc110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K11"
device = "ziti"
product = "ziti"
name = "ziti"
marketname = "OPPO K11"
fingerprint = ""

[templates."oppo_phf110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K11x"
device = "larry"
product = "larry"
name = "larry"
marketname = "OPPO K11x"
fingerprint = ""

[templates."oppo_pjr110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K12"
device = "benz"
product = "benz"
name = "benz"
marketname = "OPPO K12"
fingerprint = ""

[templates."oppo_pks110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K12 Plus"
device = "jeep"
product = "jeep"
name = "jeep"
marketname = "OPPO K12 Plus"
fingerprint = ""

[templates."oppo_pjt110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K12x"
device = "camry"
product = "camry"
name = "camry"
marketname = "OPPO K12x"
fingerprint = ""

[templates."oppo_pld110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K12s"
device = "knight-l"
product = "knight-l"
name = "knight-l"
marketname = "OPPO K12s"
fingerprint = ""

[templates."oppo_plm110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K13 Turbo"
device = "knight"
product = "knight"
name = "knight"
marketname = "OPPO K13 Turbo"
fingerprint = ""

[templates."oppo_ple110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K13 Turbo Pro"
device = "knight-h"
product = "knight-h"
name = "knight-h"
marketname = "OPPO K13 Turbo Pro"
fingerprint = ""

[templates."oppo_pyd110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K15"
device = "jinx-m"
product = "jinx-m"
name = "jinx-m"
marketname = "OPPO K15"
fingerprint = ""

[templates."oppo_pmh110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K15 Pro"
device = "lux-m"
product = "lux-m"
name = "lux-m"
marketname = "OPPO K15 Pro"
fingerprint = ""

[templates."oppo_pmg110"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K15 Pro+"
device = "lux-h"
product = "lux-h"
name = "lux-h"
marketname = "OPPO K15 Pro+"
fingerprint = ""

[templates."oppo_pye130"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO K15s"
device = "doraemon-b5"
product = "doraemon-b5"
name = "doraemon-b5"
marketname = "OPPO K15s"
fingerprint = ""

[templates."oppo_opd2101"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Pad"
device = "oslo"
product = "oslo"
name = "oslo"
marketname = "OPPO Pad"
fingerprint = ""

[templates."oppo_opd2102"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Pad Air"
device = "reeves"
product = "reeves"
name = "reeves"
marketname = "OPPO Pad Air"
fingerprint = ""

[templates."oppo_opd2201"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Pad 2"
device = "aries"
product = "aries"
name = "aries"
marketname = "OPPO Pad 2"
fingerprint = ""

[templates."oppo_opd2301"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Pad Air2"
device = "bluey"
product = "bluey"
name = "bluey"
marketname = "OPPO Pad Air2"
fingerprint = ""

[templates."oppo_opd2405"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Pad 3"
device = "dunhuang"
product = "dunhuang"
name = "dunhuang"
marketname = "OPPO Pad 3"
fingerprint = ""

[templates."oppo_opd2401"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Pad 3 Pro"
device = "caihong"
product = "caihong"
name = "caihong"
marketname = "OPPO Pad 3 Pro"
fingerprint = ""

[templates."oppo_opd2409"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Pad 4 Pro"
device = "erhai"
product = "erhai"
name = "erhai"
marketname = "OPPO Pad 4 Pro"
fingerprint = ""

[templates."oppo_opd2417"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Pad SE"
device = "fiji"
product = "fiji"
name = "fiji"
marketname = "OPPO Pad SE"
fingerprint = ""

[templates."oppo_opd2506"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Pad 5"
device = "himalayan"
product = "himalayan"
name = "himalayan"
marketname = "OPPO Pad 5"
fingerprint = ""

[templates."oppo_opd2501"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Pad Air5"
device = "greenland"
product = "greenland"
name = "greenland"
marketname = "OPPO Pad Air5"
fingerprint = ""

[templates."oppo_opd2511"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Pad 5 Pro"
device = "iceland"
product = "iceland"
name = "iceland"
marketname = "OPPO Pad 5 Pro"
fingerprint = ""

[templates."oppo_opd2515"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Pad Mini"
device = "ivy"
product = "ivy"
name = "ivy"
marketname = "OPPO Pad Mini"
fingerprint = ""

[templates."oppo_opd2601"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Pad 6"
device = "jinggangshan"
product = "jinggangshan"
name = "jinggangshan"
marketname = "OPPO Pad 6"
fingerprint = ""

[templates."oppo_opd2613"]
manufacturer = "OPPO"
brand = "OPPO"
model = "OPPO Pad Air6"
device = "OPD2613"
product = "OPD2613"
marketname = "OPPO Pad Air6"
fingerprint = ""

[templates."realme_rmx1901"]
manufacturer = "realme"
brand = "realme"
model = "realme X"
device = "RMX1901"
product = "RMX1901"
marketname = "realme X"
fingerprint = ""

[templates."realme_rmx1851"]
manufacturer = "realme"
brand = "realme"
model = "realme X 青春版"
device = "RMX1851"
product = "RMX1851"
marketname = "realme X 青春版"
fingerprint = ""

[templates."realme_rmx1991"]
manufacturer = "realme"
brand = "realme"
model = "realme X2"
device = "RMX1991"
product = "RMX1991"
marketname = "realme X2"
fingerprint = ""

[templates."realme_rmx1931"]
manufacturer = "realme"
brand = "realme"
model = "realme X2 Pro"
device = "samurai"
product = "samurai"
name = "samurai"
marketname = "realme X2 Pro"
fingerprint = ""

[templates."realme_rmx2051"]
manufacturer = "realme"
brand = "realme"
model = "realme X50 5G"
device = "RMX2051"
product = "RMX2051"
marketname = "realme X50 5G"
fingerprint = ""

[templates."realme_rmx2071"]
manufacturer = "realme"
brand = "realme"
model = "realme X50 Pro 5G"
device = "bladerunner"
product = "bladerunner"
name = "bladerunner"
marketname = "realme X50 Pro 5G"
fingerprint = ""

[templates."realme_rmx2072"]
manufacturer = "realme"
brand = "realme"
model = "realme X50 Pro 玩家版"
device = "bladerunner_48m"
product = "bladerunner_48m"
name = "bladerunner_48m"
marketname = "realme X50 Pro 玩家版"
fingerprint = ""

[templates."realme_rmx2141"]
manufacturer = "realme"
brand = "realme"
model = "realme X50m 5G"
device = "RMX2141"
product = "RMX2141"
marketname = "realme X50m 5G"
fingerprint = ""

[templates."realme_rmx2052"]
manufacturer = "realme"
brand = "realme"
model = "realme X50t 5G"
device = "RMX2052"
product = "RMX2052"
marketname = "realme X50t 5G"
fingerprint = ""

[templates."realme_rmx2176"]
manufacturer = "realme"
brand = "realme"
model = "realme X7 5G"
device = "RMX2176"
product = "RMX2176"
marketname = "realme X7 5G"
fingerprint = ""

[templates."realme_rmx2121"]
manufacturer = "realme"
brand = "realme"
model = "realme X7 Pro 5G"
device = "RMX2121"
product = "RMX2121"
marketname = "realme X7 Pro 5G"
fingerprint = ""

[templates."realme_rmx3115"]
manufacturer = "realme"
brand = "realme"
model = "realme X7 Pro 至尊版 5G"
device = "RMX3115"
product = "RMX3115"
marketname = "realme X7 Pro 至尊版 5G"
fingerprint = ""

[templates."realme_rmx2202"]
manufacturer = "realme"
brand = "realme"
model = "realme GT 5G"
device = "cupid"
product = "cupid"
name = "cupid"
marketname = "realme GT 5G"
fingerprint = ""

[templates."realme_rmx3361"]
manufacturer = "realme"
brand = "realme"
model = "realme GT 大师版"
device = "lunaa"
product = "lunaa"
name = "lunaa"
marketname = "realme GT 大师版"
fingerprint = ""

[templates."realme_rmx3366"]
manufacturer = "realme"
brand = "realme"
model = "realme GT 大师探索版"
device = "rivena"
product = "rivena"
name = "rivena"
marketname = "realme GT 大师探索版"
fingerprint = ""

[templates."realme_rmx3310"]
manufacturer = "realme"
brand = "realme"
model = "realme GT2"
device = "porsche"
product = "porsche"
name = "porsche"
marketname = "realme GT2"
fingerprint = ""

[templates."realme_rmx3300"]
manufacturer = "realme"
brand = "realme"
model = "realme GT2 Pro"
device = "ferrari"
product = "ferrari"
name = "ferrari"
marketname = "realme GT2 Pro"
fingerprint = ""

[templates."realme_rmx3551"]
manufacturer = "realme"
brand = "realme"
model = "realme GT2 大师探索版"
device = "jennie"
product = "jennie"
name = "jennie"
marketname = "realme GT2 大师探索版"
fingerprint = ""

[templates."realme_rmx3820"]
manufacturer = "realme"
brand = "realme"
model = "realme GT5"
device = "jennie"
product = "jennie"
name = "jennie"
marketname = "realme GT5"
fingerprint = ""

[templates."realme_rmx3823"]
manufacturer = "realme"
brand = "realme"
model = "realme GT5 240W"
device = "zonda-b"
product = "zonda-b"
name = "zonda-b"
marketname = "realme GT5 240W"
fingerprint = ""

[templates."realme_rmx3888"]
manufacturer = "realme"
brand = "realme"
model = "realme GT5 Pro"
device = "enzo"
product = "enzo"
name = "enzo"
marketname = "realme GT5 Pro"
fingerprint = ""

[templates."realme_rmx3800"]
manufacturer = "realme"
brand = "realme"
model = "realme GT6"
device = "divo"
product = "divo"
name = "divo"
marketname = "realme GT6"
fingerprint = ""

[templates."realme_rmx6688"]
manufacturer = "realme"
brand = "realme"
model = "realme GT7"
device = "targa"
product = "targa"
name = "targa"
marketname = "realme GT7"
fingerprint = ""

[templates."realme_rmx5010"]
manufacturer = "realme"
brand = "realme"
model = "realme GT7 Pro"
device = "pista"
product = "pista"
name = "pista"
marketname = "realme GT7 Pro"
fingerprint = ""

[templates."realme_rmx5090"]
manufacturer = "realme"
brand = "realme"
model = "realme GT7 Pro 竞速版"
device = "piloti"
product = "piloti"
name = "piloti"
marketname = "realme GT7 Pro 竞速版"
fingerprint = ""

[templates."realme_rmx6699"]
manufacturer = "realme"
brand = "realme"
model = "realme GT8"
device = "amg"
product = "amg"
name = "amg"
marketname = "realme GT8"
fingerprint = ""

[templates."realme_rmx5200"]
manufacturer = "realme"
brand = "realme"
model = "realme GT8 Pro"
device = "lafa"
product = "lafa"
name = "lafa"
marketname = "realme GT8 Pro"
fingerprint = ""

[templates."realme_rmx3031"]
manufacturer = "realme"
brand = "realme"
model = "realme GT Neo 5G"
device = "RMX3031"
product = "RMX3031"
marketname = "realme GT Neo 5G"
fingerprint = ""

[templates."realme_rmx3350"]
manufacturer = "realme"
brand = "realme"
model = "realme GT Neo 闪速版"
device = "RMX3350"
product = "RMX3350"
marketname = "realme GT Neo 闪速版"
fingerprint = ""

[templates."realme_rmx3370"]
manufacturer = "realme"
brand = "realme"
model = "realme GT Neo2"
device = "bitra"
product = "bitra"
name = "bitra"
marketname = "realme GT Neo2"
fingerprint = ""

[templates."realme_rmx3357"]
manufacturer = "realme"
brand = "realme"
model = "realme GT Neo2T"
device = "RMX3357"
product = "RMX3357"
marketname = "realme GT Neo2T"
fingerprint = ""

[templates."realme_rmx3560"]
manufacturer = "realme"
brand = "realme"
model = "realme GT Neo3"
device = "lisa-a"
product = "lisa-a"
name = "lisa-a"
marketname = "realme GT Neo3"
fingerprint = ""

[templates."realme_rmx3562"]
manufacturer = "realme"
brand = "realme"
model = "realme GT Neo3 150W"
device = "lisa-b"
product = "lisa-b"
name = "lisa-b"
marketname = "realme GT Neo3 150W"
fingerprint = ""

[templates."realme_rmx3706"]
manufacturer = "realme"
brand = "realme"
model = "realme GT Neo5"
device = "senna-b"
product = "senna-b"
name = "senna-b"
marketname = "realme GT Neo5"
fingerprint = ""

[templates."realme_rmx3708"]
manufacturer = "realme"
brand = "realme"
model = "realme GT Neo5 240W"
device = "senna-c"
product = "senna-c"
name = "senna-c"
marketname = "realme GT Neo5 240W"
fingerprint = ""

[templates."realme_rmx3700"]
manufacturer = "realme"
brand = "realme"
model = "realme GT Neo5 SE"
device = "senna-a"
product = "senna-a"
name = "senna-a"
marketname = "realme GT Neo5 SE"
fingerprint = ""

[templates."realme_rmx3852"]
manufacturer = "realme"
brand = "realme"
model = "realme GT Neo6"
device = "bale-b"
product = "bale-b"
name = "bale-b"
marketname = "realme GT Neo6"
fingerprint = ""

[templates."realme_rmx3850"]
manufacturer = "realme"
brand = "realme"
model = "realme GT Neo6 SE"
device = "bale-a"
product = "bale-a"
name = "bale-a"
marketname = "realme GT Neo6 SE"
fingerprint = ""

[templates."realme_rmx5060"]
manufacturer = "realme"
brand = "realme"
model = "realme Neo7"
device = "cayman-a"
product = "cayman-a"
name = "cayman-a"
marketname = "realme Neo7"
fingerprint = ""

[templates."realme_rmx5062"]
manufacturer = "realme"
brand = "realme"
model = "realme Neo7 Turbo"
device = "cayman-c"
product = "cayman-c"
name = "cayman-c"
marketname = "realme Neo7 Turbo"
fingerprint = ""

[templates."realme_rmx5080"]
manufacturer = "realme"
brand = "realme"
model = "realme Neo7 SE"
device = "brz-a"
product = "brz-a"
name = "brz-a"
marketname = "realme Neo7 SE"
fingerprint = ""

[templates."realme_rmx5071"]
manufacturer = "realme"
brand = "realme"
model = "realme Neo7x"
device = "dongfeng"
product = "dongfeng"
name = "dongfeng"
marketname = "realme Neo7x"
fingerprint = ""

[templates."realme_rmx8899"]
manufacturer = "realme"
brand = "realme"
model = "realme Neo8"
device = "u9"
product = "u9"
name = "u9"
marketname = "realme Neo8"
fingerprint = ""

[templates."realme_rmx1971"]
manufacturer = "realme"
brand = "realme"
model = "realme Q"
device = "RMX1971"
product = "RMX1971"
marketname = "realme Q"
fingerprint = ""

[templates."realme_rmx2117"]
manufacturer = "realme"
brand = "realme"
model = "realme Q2 5G"
device = "RMX2117"
product = "RMX2117"
marketname = "realme Q2 5G"
fingerprint = ""

[templates."realme_rmx2173"]
manufacturer = "realme"
brand = "realme"
model = "realme Q2 Pro 5G"
device = "RMX2173"
product = "RMX2173"
marketname = "realme Q2 Pro 5G"
fingerprint = ""

[templates."realme_rmx2200"]
manufacturer = "realme"
brand = "realme"
model = "realme Q2i 5G"
device = "RMX2200"
product = "RMX2200"
marketname = "realme Q2i 5G"
fingerprint = ""

[templates."realme_rmx3161"]
manufacturer = "realme"
brand = "realme"
model = "realme Q3 5G"
device = "zeus"
product = "zeus"
name = "zeus"
marketname = "realme Q3 5G"
fingerprint = ""

[templates."realme_rmx2205"]
manufacturer = "realme"
brand = "realme"
model = "realme Q3 Pro 5G"
device = "RMX2205"
product = "RMX2205"
marketname = "realme Q3 Pro 5G"
fingerprint = ""

[templates."realme_rmx3142"]
manufacturer = "realme"
brand = "realme"
model = "realme Q3 Pro 狂欢版"
device = "luna"
product = "luna"
name = "luna"
marketname = "realme Q3 Pro 狂欢版"
fingerprint = ""

[templates."realme_rmx3042"]
manufacturer = "realme"
brand = "realme"
model = "realme Q3i 5G"
device = "RMX3042"
product = "RMX3042"
marketname = "realme Q3i 5G"
fingerprint = ""

[templates."realme_rmx3461"]
manufacturer = "realme"
brand = "realme"
model = "realme Q3s"
device = "ice"
product = "ice"
name = "ice"
marketname = "realme Q3s"
fingerprint = ""

[templates."realme_rmx3462"]
manufacturer = "realme"
brand = "realme"
model = "realme Q3t"
device = "ice"
product = "ice"
name = "ice"
marketname = "realme Q3t"
fingerprint = ""

[templates."realme_rmx3478"]
manufacturer = "realme"
brand = "realme"
model = "realme Q5"
device = "oscar"
product = "oscar"
name = "oscar"
marketname = "realme Q5"
fingerprint = ""

[templates."realme_rmx3372"]
manufacturer = "realme"
brand = "realme"
model = "realme Q5 Pro"
device = "spartan"
product = "spartan"
name = "spartan"
marketname = "realme Q5 Pro"
fingerprint = ""

[templates."realme_rmx3574"]
manufacturer = "realme"
brand = "realme"
model = "realme Q5i"
device = "alice"
product = "alice"
name = "alice"
marketname = "realme Q5i"
fingerprint = ""

[templates."realme_rmx3616"]
manufacturer = "realme"
brand = "realme"
model = "realme Q5x"
device = "blade"
product = "blade"
name = "blade"
marketname = "realme Q5x"
fingerprint = ""

[templates."realme_rmx3615"]
manufacturer = "realme"
brand = "realme"
model = "realme 10"
device = "blade"
product = "blade"
name = "blade"
marketname = "realme 10"
fingerprint = ""

[templates."realme_rmx3617"]
manufacturer = "realme"
brand = "realme"
model = "realme 10s"
device = "blade"
product = "blade"
name = "blade"
marketname = "realme 10s"
fingerprint = ""

[templates."realme_rmx3663"]
manufacturer = "realme"
brand = "realme"
model = "realme 10 Pro"
device = "luigi"
product = "luigi"
name = "luigi"
marketname = "realme 10 Pro"
fingerprint = ""

[templates."realme_rmx3687"]
manufacturer = "realme"
brand = "realme"
model = "realme 10 Pro+"
device = "roma"
product = "roma"
name = "roma"
marketname = "realme 10 Pro+"
fingerprint = ""

[templates."realme_rmx3751"]
manufacturer = "realme"
brand = "realme"
model = "realme 11"
device = "hawaii"
product = "hawaii"
name = "hawaii"
marketname = "realme 11"
fingerprint = ""

[templates."realme_rmx3770"]
manufacturer = "realme"
brand = "realme"
model = "realme 11 Pro"
device = "chengdu-b"
product = "chengdu-b"
name = "chengdu-b"
marketname = "realme 11 Pro"
fingerprint = ""

[templates."realme_rmx3740"]
manufacturer = "realme"
brand = "realme"
model = "realme 11 Pro+"
device = "chengdu"
product = "chengdu"
name = "chengdu"
marketname = "realme 11 Pro+"
fingerprint = ""

[templates."realme_rmx3992"]
manufacturer = "realme"
brand = "realme"
model = "realme 12"
device = "RMX3992"
product = "RMX3992"
marketname = "realme 12"
fingerprint = ""

[templates."realme_rmx3993"]
manufacturer = "realme"
brand = "realme"
model = "realme 12x"
device = "RMX3993"
product = "RMX3993"
marketname = "realme 12x"
fingerprint = ""

[templates."realme_rmx3843"]
manufacturer = "realme"
brand = "realme"
model = "realme 12 Pro"
device = "coffee-a"
product = "coffee-a"
name = "coffee-a"
marketname = "realme 12 Pro"
fingerprint = ""

[templates."realme_rmx3841"]
manufacturer = "realme"
brand = "realme"
model = "realme 12 Pro+"
device = "coffee"
product = "coffee"
name = "coffee"
marketname = "realme 12 Pro+"
fingerprint = ""

[templates."realme_rmx3952"]
manufacturer = "realme"
brand = "realme"
model = "realme 13"
device = "barley-x"
product = "barley-x"
name = "barley-x"
marketname = "realme 13"
fingerprint = ""

[templates."realme_rmx5002"]
manufacturer = "realme"
brand = "realme"
model = "realme 13 Pro"
device = "casio"
product = "casio"
name = "casio"
marketname = "realme 13 Pro"
fingerprint = ""

[templates."realme_rmx3989"]
manufacturer = "realme"
brand = "realme"
model = "realme 13 Pro 至尊版"
device = "amber-t"
product = "amber-t"
name = "amber-t"
marketname = "realme 13 Pro 至尊版"
fingerprint = ""

[templates."realme_rmx3920"]
manufacturer = "realme"
brand = "realme"
model = "realme 13 Pro+"
device = "amber"
product = "amber"
name = "amber"
marketname = "realme 13 Pro+"
fingerprint = ""

[templates."realme_rmx5075"]
manufacturer = "realme"
brand = "realme"
model = "realme 14"
device = "dongfeng"
product = "dongfeng"
name = "dongfeng"
marketname = "realme 14"
fingerprint = ""

[templates."realme_rmx5055"]
manufacturer = "realme"
brand = "realme"
model = "realme 14 Pro"
device = "casio-x"
product = "casio-x"
name = "casio-x"
marketname = "realme 14 Pro"
fingerprint = ""

[templates."realme_rmx5050"]
manufacturer = "realme"
brand = "realme"
model = "realme 14 Pro+"
device = "piaget"
product = "piaget"
name = "piaget"
marketname = "realme 14 Pro+"
fingerprint = ""

[templates."realme_rmx5105"]
manufacturer = "realme"
brand = "realme"
model = "realme 15"
device = "casio-y"
product = "casio-y"
name = "casio-y"
marketname = "realme 15"
fingerprint = ""

[templates."realme_rmx5100"]
manufacturer = "realme"
brand = "realme"
model = "realme 15 Pro"
device = "neutron"
product = "neutron"
name = "neutron"
marketname = "realme 15 Pro"
fingerprint = ""

[templates."realme_rmx5112"]
manufacturer = "realme"
brand = "realme"
model = "realme 15T"
device = "chopard-a"
product = "chopard-a"
name = "chopard-a"
marketname = "realme 15T"
fingerprint = ""

[templates."realme_rmx2201"]
manufacturer = "realme"
brand = "realme"
model = "realme V3 5G"
device = "RMX2201"
product = "RMX2201"
marketname = "realme V3 5G"
fingerprint = ""

[templates."realme_rmx2111"]
manufacturer = "realme"
brand = "realme"
model = "realme V5 5G"
device = "RMX2111"
product = "RMX2111"
marketname = "realme V5 5G"
fingerprint = ""

[templates."realme_rmx3121"]
manufacturer = "realme"
brand = "realme"
model = "realme V11 5G"
device = "RMX3121"
product = "RMX3121"
marketname = "realme V11 5G"
fingerprint = ""

[templates."realme_rmx3125"]
manufacturer = "realme"
brand = "realme"
model = "realme V11s 5G"
device = "RMX3125"
product = "RMX3125"
marketname = "realme V11s 5G"
fingerprint = ""

[templates."realme_rmx3041"]
manufacturer = "realme"
brand = "realme"
model = "realme V13 5G"
device = "RMX3041"
product = "RMX3041"
marketname = "realme V13 5G"
fingerprint = ""

[templates."realme_rmx3092"]
manufacturer = "realme"
brand = "realme"
model = "realme V15 5G"
device = "RMX3092"
product = "RMX3092"
marketname = "realme V15 5G"
fingerprint = ""

[templates."realme_rmx3610"]
manufacturer = "realme"
brand = "realme"
model = "realme V20"
device = "blade"
product = "blade"
name = "blade"
marketname = "realme V20"
fingerprint = ""

[templates."realme_rmx3571"]
manufacturer = "realme"
brand = "realme"
model = "realme V23"
device = "alice"
product = "alice"
name = "alice"
marketname = "realme V23"
fingerprint = ""

[templates."realme_rmx3576"]
manufacturer = "realme"
brand = "realme"
model = "realme V23i"
device = "alice"
product = "alice"
name = "alice"
marketname = "realme V23i"
fingerprint = ""

[templates."realme_rmx3475"]
manufacturer = "realme"
brand = "realme"
model = "realme V25"
device = "oscar"
product = "oscar"
name = "oscar"
marketname = "realme V25"
fingerprint = ""

[templates."realme_rmx3619"]
manufacturer = "realme"
brand = "realme"
model = "realme V30"
device = "blade"
product = "blade"
name = "blade"
marketname = "realme V30"
fingerprint = ""

[templates."realme_rmx3618"]
manufacturer = "realme"
brand = "realme"
model = "realme V30t"
device = "blade"
product = "blade"
name = "blade"
marketname = "realme V30t"
fingerprint = ""

[templates."realme_rmx3783"]
manufacturer = "realme"
brand = "realme"
model = "realme V50"
device = "chongqing"
product = "chongqing"
name = "chongqing"
marketname = "realme V50"
fingerprint = ""

[templates."realme_rmx3781"]
manufacturer = "realme"
brand = "realme"
model = "realme V50s"
device = "chongqing"
product = "chongqing"
name = "chongqing"
marketname = "realme V50s"
fingerprint = ""

[templates."realme_rmx3995"]
manufacturer = "realme"
brand = "realme"
model = "realme V60"
device = "barley-d"
product = "barley-d"
name = "barley-d"
marketname = "realme V60"
fingerprint = ""

[templates."realme_rmx3996"]
manufacturer = "realme"
brand = "realme"
model = "realme V60s"
device = "barley-d"
product = "barley-d"
name = "barley-d"
marketname = "realme V60s"
fingerprint = ""

[templates."realme_rmx3953"]
manufacturer = "realme"
brand = "realme"
model = "realme V60 Pro"
device = "rado"
product = "rado"
name = "rado"
marketname = "realme V60 Pro"
fingerprint = ""

[templates."realme_rmx3946"]
manufacturer = "realme"
brand = "realme"
model = "realme V70"
device = "rado"
product = "rado"
name = "rado"
marketname = "realme V70"
fingerprint = ""

[templates."realme_rmx3948"]
manufacturer = "realme"
brand = "realme"
model = "realme V70s"
device = "rado"
product = "rado"
name = "rado"
marketname = "realme V70s"
fingerprint = ""

[templates."realme_rmp2108"]
manufacturer = "realme"
brand = "realme"
model = "realme 平板 X"
device = "tyr"
product = "tyr"
name = "tyr"
marketname = "realme 平板 X"
fingerprint = ""

[templates."samsung_gt_i9000"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S"
device = "GT-I9000"
product = "GT-I9000"
marketname = "Samsung Galaxy S"
fingerprint = ""

[templates."samsung_gt_i9100"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S2"
device = "GT-I9100"
product = "GT-I9100"
marketname = "Samsung Galaxy S2"
fingerprint = ""

[templates."samsung_sch_i919"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S Duos"
device = "SCH-I919"
product = "SCH-I919"
marketname = "Samsung Galaxy S Duos"
fingerprint = ""

[templates."samsung_gt_i9300"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S3"
device = "m0"
product = "m0"
name = "m0"
marketname = "Samsung Galaxy S3"
fingerprint = ""

[templates."samsung_sch_i939d"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S3 电信双卡"
device = "m0ctcduos"
product = "m0ctcduos"
name = "m0ctcduos"
marketname = "Samsung Galaxy S3 电信双卡"
fingerprint = ""

[templates."samsung_gt_i9300i"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S3 Neo+"
device = "s3ve3g"
product = "s3ve3g"
name = "s3ve3g"
marketname = "Samsung Galaxy S3 Neo+"
fingerprint = ""

[templates."samsung_gt_i8190n"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S3 Mini"
device = "golden"
product = "golden"
name = "golden"
marketname = "Samsung Galaxy S3 Mini"
fingerprint = ""

[templates."samsung_gt_i9500"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S4"
device = "ja3g"
product = "ja3g"
name = "ja3g"
marketname = "Samsung Galaxy S4"
fingerprint = ""

[templates."samsung_sm_c101"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S4 zoom"
device = "mproject3g"
product = "mproject3g"
name = "mproject3g"
marketname = "Samsung Galaxy S4 zoom"
fingerprint = ""

[templates."samsung_sm_g9009d"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S5"
device = "k3g"
product = "k3g"
name = "k3g"
marketname = "Samsung Galaxy S5"
fingerprint = ""

[templates."samsung_sm_g9006v"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S5 联通 4G 单卡版"
device = "klte"
product = "klte"
name = "klte"
marketname = "Samsung Galaxy S5 联通 4G 单卡版"
fingerprint = ""

[templates."samsung_sm_g9008v"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S5 移动 4G 单卡版"
device = "klte"
product = "klte"
name = "klte"
marketname = "Samsung Galaxy S5 移动 4G 单卡版"
fingerprint = ""

[templates."samsung_sm_g9200"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S6"
device = "zerofltechn"
product = "zerofltechn"
name = "zerofltechn"
marketname = "Samsung Galaxy S6"
fingerprint = ""

[templates."samsung_sm_g9250"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S6 edge"
device = "zeroltechn"
product = "zeroltechn"
name = "zeroltechn"
marketname = "Samsung Galaxy S6 edge"
fingerprint = ""

[templates."samsung_sm_g9280"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S6 edge+"
device = "zenltechn"
product = "zenltechn"
name = "zenltechn"
marketname = "Samsung Galaxy S6 edge+"
fingerprint = ""

[templates."samsung_sm_g9300"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S7"
device = "heroqltechn"
product = "heroqltechn"
name = "heroqltechn"
marketname = "Samsung Galaxy S7"
fingerprint = ""

[templates."samsung_sm_g9350"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S7 edge"
device = "hero2qltechn"
product = "hero2qltechn"
name = "hero2qltechn"
marketname = "Samsung Galaxy S7 edge"
fingerprint = ""

[templates."samsung_sm_g9500"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S8"
device = "dreamqltechn"
product = "dreamqltechn"
name = "dreamqltechn"
marketname = "Samsung Galaxy S8"
fingerprint = ""

[templates."samsung_sm_g9508"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S8 4G+"
device = "dreamqltecmcc"
product = "dreamqltecmcc"
name = "dreamqltecmcc"
marketname = "Samsung Galaxy S8 4G+"
fingerprint = ""

[templates."samsung_sm_g9550"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S8+"
device = "dream2qltechn"
product = "dream2qltechn"
name = "dream2qltechn"
marketname = "Samsung Galaxy S8+"
fingerprint = ""

[templates."samsung_sm_g9600_ds"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S9"
device = "starqltechn"
product = "starqltechn"
name = "starqltechn"
marketname = "Samsung Galaxy S9"
fingerprint = ""

[templates."samsung_sm_g9608_ds"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S9 4G+"
device = "starqltecmcc"
product = "starqltecmcc"
name = "starqltecmcc"
marketname = "Samsung Galaxy S9 4G+"
fingerprint = ""

[templates."samsung_sm_g9650_ds"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S9+"
device = "star2qltechn"
product = "star2qltechn"
name = "star2qltechn"
marketname = "Samsung Galaxy S9+"
fingerprint = ""

[templates."samsung_sm_g8750"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S 轻奢版"
device = "dreamliteqltechn"
product = "dreamliteqltechn"
name = "dreamliteqltechn"
marketname = "Samsung Galaxy S 轻奢版"
fingerprint = ""

[templates."samsung_sm_g9700"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S10e"
device = "beyond0q"
product = "beyond0q"
name = "beyond0q"
marketname = "Samsung Galaxy S10e"
fingerprint = ""

[templates."samsung_sm_g9708"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S10e 4G+"
device = "beyond0q"
product = "beyond0q"
name = "beyond0q"
marketname = "Samsung Galaxy S10e 4G+"
fingerprint = ""

[templates."samsung_sm_g9730"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S10"
device = "beyond1q"
product = "beyond1q"
name = "beyond1q"
marketname = "Samsung Galaxy S10"
fingerprint = ""

[templates."samsung_sm_g9738"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S10 4G+"
device = "beyond1q"
product = "beyond1q"
name = "beyond1q"
marketname = "Samsung Galaxy S10 4G+"
fingerprint = ""

[templates."samsung_sm_g9750"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S10+"
device = "beyond2q"
product = "beyond2q"
name = "beyond2q"
marketname = "Samsung Galaxy S10+"
fingerprint = ""

[templates."samsung_sm_g9758"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S10+ 4G+"
device = "beyond2q"
product = "beyond2q"
name = "beyond2q"
marketname = "Samsung Galaxy S10+ 4G+"
fingerprint = ""

[templates."samsung_sm_g9810"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S20 5G"
device = "x1q"
product = "x1q"
name = "x1q"
marketname = "Samsung Galaxy S20 5G"
fingerprint = ""

[templates."samsung_sm_g9860"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S20+ 5G"
device = "y2q"
product = "y2q"
name = "y2q"
marketname = "Samsung Galaxy S20+ 5G"
fingerprint = ""

[templates."samsung_sm_g9880"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S20 Ultra 5G"
device = "z3q"
product = "z3q"
name = "z3q"
marketname = "Samsung Galaxy S20 Ultra 5G"
fingerprint = ""

[templates."samsung_sm_g7810"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S20 FE 5G"
device = "r8q"
product = "r8q"
name = "r8q"
marketname = "Samsung Galaxy S20 FE 5G"
fingerprint = ""

[templates."samsung_sm_g9910"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S21 5G"
device = "o1q"
product = "o1q"
name = "o1q"
marketname = "Samsung Galaxy S21 5G"
fingerprint = ""

[templates."samsung_sm_g9960"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S21+ 5G"
device = "t2q"
product = "t2q"
name = "t2q"
marketname = "Samsung Galaxy S21+ 5G"
fingerprint = ""

[templates."samsung_sm_g9980"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S21 Ultra 5G"
device = "p3q"
product = "p3q"
name = "p3q"
marketname = "Samsung Galaxy S21 Ultra 5G"
fingerprint = ""

[templates."samsung_sm_g9900"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S21 FE 5G"
device = "r9q"
product = "r9q"
name = "r9q"
marketname = "Samsung Galaxy S21 FE 5G"
fingerprint = ""

[templates."samsung_sm_s9010"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S22"
device = "r0q"
product = "r0q"
name = "r0q"
marketname = "Samsung Galaxy S22"
fingerprint = ""

[templates."samsung_sm_s9060"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S22+"
device = "g0q"
product = "g0q"
name = "g0q"
marketname = "Samsung Galaxy S22+"
fingerprint = ""

[templates."samsung_sm_s9080"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S22 Ultra"
device = "b0q"
product = "b0q"
name = "b0q"
marketname = "Samsung Galaxy S22 Ultra"
fingerprint = ""

[templates."samsung_sm_s9110"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S23"
device = "dm1q"
product = "dm1q"
name = "dm1q"
marketname = "Samsung Galaxy S23"
fingerprint = ""

[templates."samsung_sm_s9160"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S23+"
device = "dm2q"
product = "dm2q"
name = "dm2q"
marketname = "Samsung Galaxy S23+"
fingerprint = ""

[templates."samsung_sm_s9180"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S23 Ultra"
device = "dm3q"
product = "dm3q"
name = "dm3q"
marketname = "Samsung Galaxy S23 Ultra"
fingerprint = ""

[templates."samsung_sm_s7110"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S23 FE"
device = "r11q"
product = "r11q"
name = "r11q"
marketname = "Samsung Galaxy S23 FE"
fingerprint = ""

[templates."samsung_sm_s9210"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S24"
device = "e1q"
product = "e1q"
name = "e1q"
marketname = "Samsung Galaxy S24"
fingerprint = ""

[templates."samsung_sm_s9260"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S24+"
device = "e2q"
product = "e2q"
name = "e2q"
marketname = "Samsung Galaxy S24+"
fingerprint = ""

[templates."samsung_sm_s9280"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S24 Ultra"
device = "e3q"
product = "e3q"
name = "e3q"
marketname = "Samsung Galaxy S24 Ultra"
fingerprint = ""

[templates."samsung_sm_s9310"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S25"
device = "pa1q"
product = "pa1q"
name = "pa1q"
marketname = "Samsung Galaxy S25"
fingerprint = ""

[templates."samsung_sm_s9360"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S25+"
device = "pa2q"
product = "pa2q"
name = "pa2q"
marketname = "Samsung Galaxy S25+"
fingerprint = ""

[templates."samsung_sm_s9370"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S25 Edge"
device = "psq"
product = "psq"
name = "psq"
marketname = "Samsung Galaxy S25 Edge"
fingerprint = ""

[templates."samsung_sm_s9380"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S25 Ultra"
device = "pa3q"
product = "pa3q"
name = "pa3q"
marketname = "Samsung Galaxy S25 Ultra"
fingerprint = ""

[templates."samsung_sm_s9420"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S26"
device = "m1q"
product = "m1q"
name = "m1q"
marketname = "Samsung Galaxy S26"
fingerprint = ""

[templates."samsung_sm_s9470"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S26+"
device = "m2q"
product = "m2q"
name = "m2q"
marketname = "Samsung Galaxy S26+"
fingerprint = ""

[templates."samsung_sm_s9480"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy S26 Ultra"
device = "m3q"
product = "m3q"
name = "m3q"
marketname = "Samsung Galaxy S26 Ultra"
fingerprint = ""

[templates."samsung_gt_i9220"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note"
device = "GT-I9220"
product = "GT-I9220"
marketname = "Samsung Galaxy Note"
fingerprint = ""

[templates."samsung_gt_n7100"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note2"
device = "t03gchn"
product = "t03gchn"
name = "t03gchn"
marketname = "Samsung Galaxy Note2"
fingerprint = ""

[templates."samsung_sm_n9002"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note3"
device = "hlte"
product = "hlte"
name = "hlte"
marketname = "Samsung Galaxy Note3"
fingerprint = ""

[templates."samsung_sm_n9008s"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note3 4G"
device = "hlte"
product = "hlte"
name = "hlte"
marketname = "Samsung Galaxy Note3 4G"
fingerprint = ""

[templates."samsung_sm_n7506v"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note3 Lite"
device = "hllte"
product = "hllte"
name = "hllte"
marketname = "Samsung Galaxy Note3 Lite"
fingerprint = ""

[templates."samsung_sm_n9100"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note4"
device = "trltechn"
product = "trltechn"
name = "trltechn"
marketname = "Samsung Galaxy Note4"
fingerprint = ""

[templates."samsung_sm_n9150"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note Edge"
device = "tbltechn"
product = "tbltechn"
name = "tbltechn"
marketname = "Samsung Galaxy Note Edge"
fingerprint = ""

[templates."samsung_sm_n9200"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note5"
device = "nobleltechn"
product = "nobleltechn"
name = "nobleltechn"
marketname = "Samsung Galaxy Note5"
fingerprint = ""

[templates."samsung_sm_n9300"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note7"
device = "graceqltechn"
product = "graceqltechn"
name = "graceqltechn"
marketname = "Samsung Galaxy Note7"
fingerprint = ""

[templates."samsung_sm_n9500"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note8"
device = "greatqltechn"
product = "greatqltechn"
name = "greatqltechn"
marketname = "Samsung Galaxy Note8"
fingerprint = ""

[templates."samsung_sm_n9508"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note8 4G+"
device = "greatqltecmcc"
product = "greatqltecmcc"
name = "greatqltecmcc"
marketname = "Samsung Galaxy Note8 4G+"
fingerprint = ""

[templates."samsung_sm_n9600"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note9"
device = "crownqltechn"
product = "crownqltechn"
name = "crownqltechn"
marketname = "Samsung Galaxy Note9"
fingerprint = ""

[templates."samsung_sm_n9608"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note9 4G+"
device = "crownqltecmcc"
product = "crownqltecmcc"
name = "crownqltecmcc"
marketname = "Samsung Galaxy Note9 4G+"
fingerprint = ""

[templates."samsung_sm_n9700"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note10"
device = "d1q"
product = "d1q"
name = "d1q"
marketname = "Samsung Galaxy Note10"
fingerprint = ""

[templates."samsung_sm_n9760"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note10+ 5G"
device = "d2xq"
product = "d2xq"
name = "d2xq"
marketname = "Samsung Galaxy Note10+ 5G"
fingerprint = ""

[templates."samsung_sm_n9810"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note20 5G"
device = "c1q"
product = "c1q"
name = "c1q"
marketname = "Samsung Galaxy Note20 5G"
fingerprint = ""

[templates."samsung_sm_n9860"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Note20 Ultra 5G"
device = "c2q"
product = "c2q"
name = "c2q"
marketname = "Samsung Galaxy Note20 Ultra 5G"
fingerprint = ""

[templates."samsung_sm_f9000"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Fold"
device = "winner"
product = "winner"
name = "winner"
marketname = "Samsung Galaxy Fold"
fingerprint = ""

[templates."samsung_sm_f9160"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Fold2 5G"
device = "f2q"
product = "f2q"
name = "f2q"
marketname = "Samsung Galaxy Z Fold2 5G"
fingerprint = ""

[templates."samsung_sm_f9260"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Fold3 5G"
device = "q2q"
product = "q2q"
name = "q2q"
marketname = "Samsung Galaxy Z Fold3 5G"
fingerprint = ""

[templates."samsung_sm_f9360"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Fold4"
device = "q4q"
product = "q4q"
name = "q4q"
marketname = "Samsung Galaxy Z Fold4"
fingerprint = ""

[templates."samsung_sm_f9460"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Fold5"
device = "q5q"
product = "q5q"
name = "q5q"
marketname = "Samsung Galaxy Z Fold5"
fingerprint = ""

[templates."samsung_sm_f9560"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Fold6"
device = "q6q"
product = "q6q"
name = "q6q"
marketname = "Samsung Galaxy Z Fold6"
fingerprint = ""

[templates."samsung_sm_f9660"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Fold7"
device = "q7q"
product = "q7q"
name = "q7q"
marketname = "Samsung Galaxy Z Fold7"
fingerprint = ""

[templates."samsung_sm_f9680"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z TriFold"
device = "q7mq"
product = "q7mq"
name = "q7mq"
marketname = "Samsung Galaxy Z TriFold"
fingerprint = ""

[templates."samsung_sm_f9710"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Fold8"
device = "h8q"
product = "h8q"
name = "h8q"
marketname = "Samsung Galaxy Z Fold8"
fingerprint = ""

[templates."samsung_sm_f9760"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Fold8 Ultra"
device = "q8q"
product = "q8q"
name = "q8q"
marketname = "Samsung Galaxy Z Fold8 Ultra"
fingerprint = ""

[templates."samsung_sm_f7000"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Flip"
device = "bloomq"
product = "bloomq"
name = "bloomq"
marketname = "Samsung Galaxy Z Flip"
fingerprint = ""

[templates."samsung_sm_f7070"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Flip 5G"
device = "bloomxq"
product = "bloomxq"
name = "bloomxq"
marketname = "Samsung Galaxy Z Flip 5G"
fingerprint = ""

[templates."samsung_sm_f7110"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Flip3 5G"
device = "b2q"
product = "b2q"
name = "b2q"
marketname = "Samsung Galaxy Z Flip3 5G"
fingerprint = ""

[templates."samsung_sm_f7210"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Flip4"
device = "b4q"
product = "b4q"
name = "b4q"
marketname = "Samsung Galaxy Z Flip4"
fingerprint = ""

[templates."samsung_sm_f7310"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Flip5"
device = "b5q"
product = "b5q"
name = "b5q"
marketname = "Samsung Galaxy Z Flip5"
fingerprint = ""

[templates."samsung_sm_f7410"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Flip6"
device = "b6q"
product = "b6q"
name = "b6q"
marketname = "Samsung Galaxy Z Flip6"
fingerprint = ""

[templates."samsung_sm_f7660"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Flip7"
device = "b7s"
product = "b7s"
name = "b7s"
marketname = "Samsung Galaxy Z Flip7"
fingerprint = ""

[templates."samsung_sm_f7610"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Flip7 FE"
device = "b7r"
product = "b7r"
name = "b7r"
marketname = "Samsung Galaxy Z Flip7 FE"
fingerprint = ""

[templates."samsung_sm_f7760"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Z Flip8"
device = "b8q"
product = "b8q"
name = "b8q"
marketname = "Samsung Galaxy Z Flip8"
fingerprint = ""

[templates."samsung_sm_a3000"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A3"
device = "a3ltechn"
product = "a3ltechn"
name = "a3ltechn"
marketname = "Samsung Galaxy A3"
fingerprint = ""

[templates."samsung_sm_a5000"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A5"
device = "a5ltechn"
product = "a5ltechn"
name = "a5ltechn"
marketname = "Samsung Galaxy A5"
fingerprint = ""

[templates."samsung_sm_a7000"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A7"
device = "a7ltechn"
product = "a7ltechn"
name = "a7ltechn"
marketname = "Samsung Galaxy A7"
fingerprint = ""

[templates."samsung_sm_a8000"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A8"
device = "a8ltechn"
product = "a8ltechn"
name = "a8ltechn"
marketname = "Samsung Galaxy A8"
fingerprint = ""

[templates."samsung_sm_a5108"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A5 移动定制疾速版"
device = "a5xeltecmcc"
product = "a5xeltecmcc"
name = "a5xeltecmcc"
marketname = "Samsung Galaxy A5 移动定制疾速版"
fingerprint = ""

[templates."samsung_sm_a7108"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A7 移动定制疾速版"
device = "a7xeltecmcc"
product = "a7xeltecmcc"
name = "a7xeltecmcc"
marketname = "Samsung Galaxy A7 移动定制疾速版"
fingerprint = ""

[templates."samsung_sm_a9000"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A9"
device = "a9xltechn"
product = "a9xltechn"
name = "a9xltechn"
marketname = "Samsung Galaxy A9"
fingerprint = ""

[templates."samsung_sm_g8850"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A9 Star"
device = "astarqltechn"
product = "astarqltechn"
name = "astarqltechn"
marketname = "Samsung Galaxy A9 Star"
fingerprint = ""

[templates."samsung_sm_g8858"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A9 Star 4G+"
device = "astarqltecmcc"
product = "astarqltecmcc"
name = "astarqltecmcc"
marketname = "Samsung Galaxy A9 Star 4G+"
fingerprint = ""

[templates."samsung_sm_a6050"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A9 Star Lite"
device = "a6pltechn"
product = "a6pltechn"
name = "a6pltechn"
marketname = "Samsung Galaxy A9 Star Lite"
fingerprint = ""

[templates."samsung_sm_a6058"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A9 Star Lite 4G+"
device = "a6pltecmcc"
product = "a6pltecmcc"
name = "a6pltecmcc"
marketname = "Samsung Galaxy A9 Star Lite 4G+"
fingerprint = ""

[templates."samsung_sm_g6200"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A6s"
device = "phoenix"
product = "phoenix"
name = "phoenix"
marketname = "Samsung Galaxy A6s"
fingerprint = ""

[templates."samsung_sm_g8870"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A8s"
device = "a8sqltechn"
product = "a8sqltechn"
name = "a8sqltechn"
marketname = "Samsung Galaxy A8s"
fingerprint = ""

[templates."samsung_sm_a9200"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A9s"
device = "a9y18qltechn"
product = "a9y18qltechn"
name = "a9y18qltechn"
marketname = "Samsung Galaxy A9s"
fingerprint = ""

[templates."samsung_sm_a2070"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A20s"
device = "a20s"
product = "a20s"
name = "a20s"
marketname = "Samsung Galaxy A20s"
fingerprint = ""

[templates."samsung_sm_a3050"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A40s"
device = "a30c"
product = "a30c"
name = "a30c"
marketname = "Samsung Galaxy A40s"
fingerprint = ""

[templates."samsung_sm_a3058"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A40s 4G+"
device = "a30c"
product = "a30c"
name = "a30c"
marketname = "Samsung Galaxy A40s 4G+"
fingerprint = ""

[templates."samsung_sm_a5070"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A50s"
device = "a50s"
product = "a50s"
name = "a50s"
marketname = "Samsung Galaxy A50s"
fingerprint = ""

[templates."samsung_sm_a6060"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A60"
device = "a60q"
product = "a60q"
name = "a60q"
marketname = "Samsung Galaxy A60"
fingerprint = ""

[templates."samsung_sm_a7050"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A70"
device = "a70q"
product = "a70q"
name = "a70q"
marketname = "Samsung Galaxy A70"
fingerprint = ""

[templates."samsung_sm_a7070"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A70s"
device = "a70s"
product = "a70s"
name = "a70s"
marketname = "Samsung Galaxy A70s"
fingerprint = ""

[templates."samsung_sm_a8050"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A80"
device = "r1q"
product = "r1q"
name = "r1q"
marketname = "Samsung Galaxy A80"
fingerprint = ""

[templates."samsung_sm_a9080"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A90 5G"
device = "r3q"
product = "r3q"
name = "r3q"
marketname = "Samsung Galaxy A90 5G"
fingerprint = ""

[templates."samsung_sm_a5160"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A51 5G"
device = "a51x"
product = "a51x"
name = "a51x"
marketname = "Samsung Galaxy A51 5G"
fingerprint = ""

[templates."samsung_sm_a7160"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A71 5G"
device = "a71x"
product = "a71x"
name = "a71x"
marketname = "Samsung Galaxy A71 5G"
fingerprint = ""

[templates."samsung_sm_a5260"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A52 5G"
device = "a52xq"
product = "a52xq"
name = "a52xq"
marketname = "Samsung Galaxy A52 5G"
fingerprint = ""

[templates."samsung_sm_a5360"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A53 5G"
device = "a53x"
product = "a53x"
name = "a53x"
marketname = "Samsung Galaxy A53 5G"
fingerprint = ""

[templates."samsung_sm_a5460"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A54 5G"
device = "a54x"
product = "a54x"
name = "a54x"
marketname = "Samsung Galaxy A54 5G"
fingerprint = ""

[templates."samsung_sm_a5560"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A55 5G"
device = "a55x"
product = "a55x"
name = "a55x"
marketname = "Samsung Galaxy A55 5G"
fingerprint = ""

[templates."samsung_sm_a5660"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A56 5G"
device = "a56x"
product = "a56x"
name = "a56x"
marketname = "Samsung Galaxy A56 5G"
fingerprint = ""

[templates."samsung_sm_a5760"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy A57 5G"
device = "a57x"
product = "a57x"
name = "a57x"
marketname = "Samsung Galaxy A57 5G"
fingerprint = ""

[templates."samsung_sm_e5260"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy F52 5G"
device = "f52x"
product = "f52x"
name = "f52x"
marketname = "Samsung Galaxy F52 5G"
fingerprint = ""

[templates."samsung_sm_m3070"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy M30s"
device = "m30s"
product = "m30s"
name = "m30s"
marketname = "Samsung Galaxy M30s"
fingerprint = ""

[templates."samsung_sm_c5000"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy C5"
device = "c5ltechn"
product = "c5ltechn"
name = "c5ltechn"
marketname = "Samsung Galaxy C5"
fingerprint = ""

[templates."samsung_sm_c5010"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy C5 Pro"
device = "c5proltechn"
product = "c5proltechn"
name = "c5proltechn"
marketname = "Samsung Galaxy C5 Pro"
fingerprint = ""

[templates."samsung_sm_c5018"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy C5 Pro 4G+"
device = "c5proltechn"
product = "c5proltechn"
name = "c5proltechn"
marketname = "Samsung Galaxy C5 Pro 4G+"
fingerprint = ""

[templates."samsung_sm_c7000"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy C7"
device = "c7ltechn"
product = "c7ltechn"
name = "c7ltechn"
marketname = "Samsung Galaxy C7"
fingerprint = ""

[templates."samsung_sm_c7010"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy C7 Pro"
device = "c7proltechn"
product = "c7proltechn"
name = "c7proltechn"
marketname = "Samsung Galaxy C7 Pro"
fingerprint = ""

[templates."samsung_sm_c7018"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy C7 Pro 4G+"
device = "c7proltechn"
product = "c7proltechn"
name = "c7proltechn"
marketname = "Samsung Galaxy C7 Pro 4G+"
fingerprint = ""

[templates."samsung_sm_c7100"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy C8"
device = "jadeltechn"
product = "jadeltechn"
name = "jadeltechn"
marketname = "Samsung Galaxy C8"
fingerprint = ""

[templates."samsung_sm_c7108"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy C8 4G+"
device = "jadeltecmcc"
product = "jadeltecmcc"
name = "jadeltecmcc"
marketname = "Samsung Galaxy C8 4G+"
fingerprint = ""

[templates."samsung_sm_c9000"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy C9 Pro"
device = "c9ltechn"
product = "c9ltechn"
name = "c9ltechn"
marketname = "Samsung Galaxy C9 Pro"
fingerprint = ""

[templates."samsung_sm_c9008"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy C9 Pro 4G+"
device = "c9ltechn"
product = "c9ltechn"
name = "c9ltechn"
marketname = "Samsung Galaxy C9 Pro 4G+"
fingerprint = ""

[templates."samsung_sm_c5560"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy C55 5G"
device = "m55xq"
product = "m55xq"
name = "m55xq"
marketname = "Samsung Galaxy C55 5G"
fingerprint = ""

[templates."samsung_sm_j3109"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy J3"
device = "j3ltectc"
product = "j3ltectc"
name = "j3ltectc"
marketname = "Samsung Galaxy J3"
fingerprint = ""

[templates."samsung_sm_j5008"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy J5"
device = "j5ltechn"
product = "j5ltechn"
name = "j5ltechn"
marketname = "Samsung Galaxy J5"
fingerprint = ""

[templates."samsung_sm_j7008"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy J7"
device = "j7ltechn"
product = "j7ltechn"
name = "j7ltechn"
marketname = "Samsung Galaxy J7"
fingerprint = ""

[templates."samsung_sm_j3110"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy J3 Pro"
device = "j3xproltechn"
product = "j3xproltechn"
name = "j3xproltechn"
marketname = "Samsung Galaxy J3 Pro"
fingerprint = ""

[templates."samsung_sm_j3119s"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy J3 Pro 增强版"
device = "j3xpro6mltechn"
product = "j3xpro6mltechn"
name = "j3xpro6mltechn"
marketname = "Samsung Galaxy J3 Pro 增强版"
fingerprint = ""

[templates."samsung_sm_j3308"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy J3 4G+"
device = "j3y17qltecmcc"
product = "j3y17qltecmcc"
name = "j3y17qltecmcc"
marketname = "Samsung Galaxy J3 4G+"
fingerprint = ""

[templates."samsung_sm_g5500"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy On5"
device = "o5ltechn"
product = "o5ltechn"
name = "o5ltechn"
marketname = "Samsung Galaxy On5"
fingerprint = ""

[templates."samsung_sm_g6000"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy On7"
device = "o7ltechn"
product = "o7ltechn"
name = "o7ltechn"
marketname = "Samsung Galaxy On7"
fingerprint = ""

[templates."samsung_sm_g5510"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy On5 青春版"
device = "on5xlltechn"
product = "on5xlltechn"
name = "on5xlltechn"
marketname = "Samsung Galaxy On5 青春版"
fingerprint = ""

[templates."samsung_sm_g5520"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy On5 时尚版"
device = "on5xfltechn"
product = "on5xfltechn"
name = "on5xfltechn"
marketname = "Samsung Galaxy On5 时尚版"
fingerprint = ""

[templates."samsung_sch_w699"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W699"
device = "SCH-W699"
product = "SCH-W699"
marketname = "Samsung W699"
fingerprint = ""

[templates."samsung_sch_w799"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W799"
device = "SCH-W799"
product = "SCH-W799"
marketname = "Samsung W799"
fingerprint = ""

[templates."samsung_sch_w899"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W899"
device = "SCH-W899"
product = "SCH-W899"
marketname = "Samsung W899"
fingerprint = ""

[templates."samsung_sch_w999"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W999"
device = "SCH-W999"
product = "SCH-W999"
marketname = "Samsung W999"
fingerprint = ""

[templates."samsung_sch_w2013"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W2013"
device = "m0grandectc"
product = "m0grandectc"
name = "m0grandectc"
marketname = "Samsung W2013"
fingerprint = ""

[templates."samsung_sm_w2014"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W2014"
device = "montblanc3gctc"
product = "montblanc3gctc"
name = "montblanc3gctc"
marketname = "Samsung W2014"
fingerprint = ""

[templates."samsung_sm_w2015"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W2015"
device = "pateklte"
product = "pateklte"
name = "pateklte"
marketname = "Samsung W2015"
fingerprint = ""

[templates."samsung_sm_w2016"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W2016"
device = "royceltectc"
product = "royceltectc"
name = "royceltectc"
marketname = "Samsung W2016"
fingerprint = ""

[templates."samsung_sm_w2017"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W2017"
device = "veyronltectc"
product = "veyronltectc"
name = "veyronltectc"
marketname = "Samsung W2017"
fingerprint = ""

[templates."samsung_sm_w2018"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W2018"
device = "kellyltechn"
product = "kellyltechn"
name = "kellyltechn"
marketname = "Samsung W2018"
fingerprint = ""

[templates."samsung_sm_w2019"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W2019"
device = "lykanlte"
product = "lykanlte"
name = "lykanlte"
marketname = "Samsung W2019"
fingerprint = ""

[templates."samsung_sm_w2020"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W20 5G"
device = "zodiac"
product = "zodiac"
name = "zodiac"
marketname = "Samsung W20 5G"
fingerprint = ""

[templates."samsung_sm_w2021"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W21 5G"
device = "victory"
product = "victory"
name = "victory"
marketname = "Samsung W21 5G"
fingerprint = ""

[templates."samsung_sm_w2022"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W22 5G"
device = "v2q"
product = "v2q"
name = "v2q"
marketname = "Samsung W22 5G"
fingerprint = ""

[templates."samsung_sm_w9023"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W23"
device = "v4q"
product = "v4q"
name = "v4q"
marketname = "Samsung W23"
fingerprint = ""

[templates."samsung_sm_w7023"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W23 Flip"
device = "e4q"
product = "e4q"
name = "e4q"
marketname = "Samsung W23 Flip"
fingerprint = ""

[templates."samsung_sm_w9024"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W24"
device = "v5q"
product = "v5q"
name = "v5q"
marketname = "Samsung W24"
fingerprint = ""

[templates."samsung_sm_w7024"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W24 Flip"
device = "e5q"
product = "e5q"
name = "e5q"
marketname = "Samsung W24 Flip"
fingerprint = ""

[templates."samsung_sm_w9025"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W25"
device = "q6aq"
product = "q6aq"
name = "q6aq"
marketname = "Samsung W25"
fingerprint = ""

[templates."samsung_sm_w7025"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W25 Flip"
device = "b6q"
product = "b6q"
name = "b6q"
marketname = "Samsung W25 Flip"
fingerprint = ""

[templates."samsung_sm_w9026"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W26"
device = "q7q"
product = "q7q"
name = "q7q"
marketname = "Samsung W26"
fingerprint = ""

[templates."samsung_sm_w9027"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung W27"
device = "q8q"
product = "q8q"
name = "q8q"
marketname = "Samsung W27"
fingerprint = ""

[templates."samsung_sm_g1600"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Folder"
device = "eliteltechn"
product = "eliteltechn"
name = "eliteltechn"
marketname = "Samsung Galaxy Folder"
fingerprint = ""

[templates."samsung_sm_g1650"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Folder 2"
device = "elitexltechn"
product = "elitexltechn"
name = "elitexltechn"
marketname = "Samsung Galaxy Folder 2"
fingerprint = ""

[templates."samsung_sm_g8508s"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Alpha"
device = "sltechn"
product = "sltechn"
name = "sltechn"
marketname = "Samsung Galaxy Alpha"
fingerprint = ""

[templates."samsung_sm_e7000"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy E7"
device = "e7ltechn"
product = "e7ltechn"
name = "e7ltechn"
marketname = "Samsung Galaxy E7"
fingerprint = ""

[templates."samsung_sm_t700"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S 8.4 WLAN"
device = "klimtwifi"
product = "klimtwifi"
name = "klimtwifi"
marketname = "Samsung Galaxy Tab S 8.4 WLAN"
fingerprint = ""

[templates."samsung_sm_t705c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S 8.4"
device = "klimtlte"
product = "klimtlte"
name = "klimtlte"
marketname = "Samsung Galaxy Tab S 8.4"
fingerprint = ""

[templates."samsung_sm_t800"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S 10.5 WLAN"
device = "chagallwifi"
product = "chagallwifi"
name = "chagallwifi"
marketname = "Samsung Galaxy Tab S 10.5 WLAN"
fingerprint = ""

[templates."samsung_sm_t805c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S 10.5"
device = "chagalllte"
product = "chagalllte"
name = "chagalllte"
marketname = "Samsung Galaxy Tab S 10.5"
fingerprint = ""

[templates."samsung_sm_t710"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S2 8.0 WLAN"
device = "gts28wifichn"
product = "gts28wifichn"
name = "gts28wifichn"
marketname = "Samsung Galaxy Tab S2 8.0 WLAN"
fingerprint = ""

[templates."samsung_sm_t715c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S2 8.0"
device = "gts28ltechn"
product = "gts28ltechn"
name = "gts28ltechn"
marketname = "Samsung Galaxy Tab S2 8.0"
fingerprint = ""

[templates."samsung_sm_t810"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S2 9.7 WLAN"
device = "gts210wifichn"
product = "gts210wifichn"
name = "gts210wifichn"
marketname = "Samsung Galaxy Tab S2 9.7 WLAN"
fingerprint = ""

[templates."samsung_sm_t815c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S2 9.7"
device = "gts210ltechn"
product = "gts210ltechn"
name = "gts210ltechn"
marketname = "Samsung Galaxy Tab S2 9.7"
fingerprint = ""

[templates."samsung_sm_t820"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S3 WLAN"
device = "gts3lwifichn"
product = "gts3lwifichn"
name = "gts3lwifichn"
marketname = "Samsung Galaxy Tab S3 WLAN"
fingerprint = ""

[templates."samsung_sm_t825c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S3"
device = "gts3lltechn"
product = "gts3lltechn"
name = "gts3lltechn"
marketname = "Samsung Galaxy Tab S3"
fingerprint = ""

[templates."samsung_sm_t830"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S4 WLAN"
device = "gts4lwifichn"
product = "gts4lwifichn"
name = "gts4lwifichn"
marketname = "Samsung Galaxy Tab S4 WLAN"
fingerprint = ""

[templates."samsung_sm_t835c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S4"
device = "gts4lltechn"
product = "gts4lltechn"
name = "gts4lltechn"
marketname = "Samsung Galaxy Tab S4"
fingerprint = ""

[templates."samsung_sm_t720"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S5e WLAN"
device = "gts4lvwifichn"
product = "gts4lvwifichn"
name = "gts4lvwifichn"
marketname = "Samsung Galaxy Tab S5e WLAN"
fingerprint = ""

[templates."samsung_sm_t725c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S5e"
device = "gts4lv"
product = "gts4lv"
name = "gts4lv"
marketname = "Samsung Galaxy Tab S5e"
fingerprint = ""

[templates."samsung_sm_t860"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S6 WLAN"
device = "gts6lwifi"
product = "gts6lwifi"
name = "gts6lwifi"
marketname = "Samsung Galaxy Tab S6 WLAN"
fingerprint = ""

[templates."samsung_sm_p610"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S6 Lite WLAN"
device = "gta4xlwifi"
product = "gta4xlwifi"
name = "gta4xlwifi"
marketname = "Samsung Galaxy Tab S6 Lite WLAN"
fingerprint = ""

[templates."samsung_sm_p615c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S6 Lite"
device = "gta4xl"
product = "gta4xl"
name = "gta4xl"
marketname = "Samsung Galaxy Tab S6 Lite"
fingerprint = ""

[templates."samsung_sm_t870"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S7 WLAN"
device = "gts7lwifi"
product = "gts7lwifi"
name = "gts7lwifi"
marketname = "Samsung Galaxy Tab S7 WLAN"
fingerprint = ""

[templates."samsung_sm_t970"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S7+ WLAN"
device = "gts7xlwifi"
product = "gts7xlwifi"
name = "gts7xlwifi"
marketname = "Samsung Galaxy Tab S7+ WLAN"
fingerprint = ""

[templates."samsung_sm_t730"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S7 FE WLAN"
device = "gts7xllitewifi"
product = "gts7xllitewifi"
name = "gts7xllitewifi"
marketname = "Samsung Galaxy Tab S7 FE WLAN"
fingerprint = ""

[templates."samsung_sm_t735c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S7 FE"
device = "gts7xllite"
product = "gts7xllite"
name = "gts7xllite"
marketname = "Samsung Galaxy Tab S7 FE"
fingerprint = ""

[templates."samsung_sm_x700"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S8 WLAN"
device = "gts8wifi"
product = "gts8wifi"
name = "gts8wifi"
marketname = "Samsung Galaxy Tab S8 WLAN"
fingerprint = ""

[templates."samsung_sm_x706c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S8 5G"
device = "gts8"
product = "gts8"
name = "gts8"
marketname = "Samsung Galaxy Tab S8 5G"
fingerprint = ""

[templates."samsung_sm_x800"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S8+ WLAN"
device = "gts8pwifi"
product = "gts8pwifi"
name = "gts8pwifi"
marketname = "Samsung Galaxy Tab S8+ WLAN"
fingerprint = ""

[templates."samsung_sm_x806c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S8+ 5G"
device = "gts8p"
product = "gts8p"
name = "gts8p"
marketname = "Samsung Galaxy Tab S8+ 5G"
fingerprint = ""

[templates."samsung_sm_x900"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S8 Ultra WLAN"
device = "gts8uwifi"
product = "gts8uwifi"
name = "gts8uwifi"
marketname = "Samsung Galaxy Tab S8 Ultra WLAN"
fingerprint = ""

[templates."samsung_sm_x906c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S8 Ultra 5G"
device = "gts8u"
product = "gts8u"
name = "gts8u"
marketname = "Samsung Galaxy Tab S8 Ultra 5G"
fingerprint = ""

[templates."samsung_sm_x710"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S9 WLAN"
device = "gts9wifi"
product = "gts9wifi"
name = "gts9wifi"
marketname = "Samsung Galaxy Tab S9 WLAN"
fingerprint = ""

[templates."samsung_sm_x810"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S9+ WLAN"
device = "gts9pwifi"
product = "gts9pwifi"
name = "gts9pwifi"
marketname = "Samsung Galaxy Tab S9+ WLAN"
fingerprint = ""

[templates."samsung_sm_x910"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S9 Ultra WLAN"
device = "gts9uwifi"
product = "gts9uwifi"
name = "gts9uwifi"
marketname = "Samsung Galaxy Tab S9 Ultra WLAN"
fingerprint = ""

[templates."samsung_sm_x916c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S9 Ultra 5G"
device = "gts9u"
product = "gts9u"
name = "gts9u"
marketname = "Samsung Galaxy Tab S9 Ultra 5G"
fingerprint = ""

[templates."samsung_sm_x510"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S9 FE WLAN"
device = "gts9fewifi"
product = "gts9fewifi"
name = "gts9fewifi"
marketname = "Samsung Galaxy Tab S9 FE WLAN"
fingerprint = ""

[templates."samsung_sm_x516c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S9 FE 5G"
device = "gts9fe"
product = "gts9fe"
name = "gts9fe"
marketname = "Samsung Galaxy Tab S9 FE 5G"
fingerprint = ""

[templates."samsung_sm_x610"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S9 FE+ WLAN"
device = "gts9fepwifi"
product = "gts9fepwifi"
name = "gts9fepwifi"
marketname = "Samsung Galaxy Tab S9 FE+ WLAN"
fingerprint = ""

[templates."samsung_sm_x616c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S9 FE+ 5G"
device = "gts9fep"
product = "gts9fep"
name = "gts9fep"
marketname = "Samsung Galaxy Tab S9 FE+ 5G"
fingerprint = ""

[templates."samsung_sm_x820"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S10+ WLAN"
device = "gts10pwifi"
product = "gts10pwifi"
name = "gts10pwifi"
marketname = "Samsung Galaxy Tab S10+ WLAN"
fingerprint = ""

[templates."samsung_sm_x920"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S10 Ultra WLAN"
device = "gts10uwifi"
product = "gts10uwifi"
name = "gts10uwifi"
marketname = "Samsung Galaxy Tab S10 Ultra WLAN"
fingerprint = ""

[templates."samsung_sm_x926c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S10 Ultra 5G"
device = "gts10u"
product = "gts10u"
name = "gts10u"
marketname = "Samsung Galaxy Tab S10 Ultra 5G"
fingerprint = ""

[templates."samsung_sm_x520"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S10 FE WLAN"
device = "gts10fewifi"
product = "gts10fewifi"
name = "gts10fewifi"
marketname = "Samsung Galaxy Tab S10 FE WLAN"
fingerprint = ""

[templates."samsung_sm_x526c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S10 FE 5G"
device = "gts10fe"
product = "gts10fe"
name = "gts10fe"
marketname = "Samsung Galaxy Tab S10 FE 5G"
fingerprint = ""

[templates."samsung_sm_x620"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S10 FE+ WLAN"
device = "gts10fepwifi"
product = "gts10fepwifi"
name = "gts10fepwifi"
marketname = "Samsung Galaxy Tab S10 FE+ WLAN"
fingerprint = ""

[templates."samsung_sm_x626c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S10 FE+ 5G"
device = "gts10fep"
product = "gts10fep"
name = "gts10fep"
marketname = "Samsung Galaxy Tab S10 FE+ 5G"
fingerprint = ""

[templates."samsung_sm_x400"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S10 Lite WLAN"
device = "gts10litewifi"
product = "gts10litewifi"
name = "gts10litewifi"
marketname = "Samsung Galaxy Tab S10 Lite WLAN"
fingerprint = ""

[templates."samsung_sm_x730"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S11 WLAN"
device = "gts11wifi"
product = "gts11wifi"
name = "gts11wifi"
marketname = "Samsung Galaxy Tab S11 WLAN"
fingerprint = ""

[templates."samsung_sm_x736c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S11 5G"
device = "gts11"
product = "gts11"
name = "gts11"
marketname = "Samsung Galaxy Tab S11 5G"
fingerprint = ""

[templates."samsung_sm_x930"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S11 Ultra WLAN"
device = "gts11uwifi"
product = "gts11uwifi"
name = "gts11uwifi"
marketname = "Samsung Galaxy Tab S11 Ultra WLAN"
fingerprint = ""

[templates."samsung_sm_x936c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S11 Ultra 5G"
device = "gts11u"
product = "gts11u"
name = "gts11u"
marketname = "Samsung Galaxy Tab S11 Ultra 5G"
fingerprint = ""

[templates."samsung_sm_x840"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S12+ WLAN"
device = "gts12pwifi"
product = "gts12pwifi"
name = "gts12pwifi"
marketname = "Samsung Galaxy Tab S12+ WLAN"
fingerprint = ""

[templates."samsung_sm_x940"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab S12 Ultra WLAN"
device = "gts12uwifi"
product = "gts12uwifi"
name = "gts12uwifi"
marketname = "Samsung Galaxy Tab S12 Ultra WLAN"
fingerprint = ""

[templates."samsung_sm_t350"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A 8.0 WLAN"
device = "gt58wifichn"
product = "gt58wifichn"
name = "gt58wifichn"
marketname = "Samsung Galaxy Tab A 8.0 WLAN"
fingerprint = ""

[templates."samsung_sm_t355c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A 8.0"
device = "gt58ltechn"
product = "gt58ltechn"
name = "gt58ltechn"
marketname = "Samsung Galaxy Tab A 8.0"
fingerprint = ""

[templates."samsung_sm_t550"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A 9.7 WLAN"
device = "gt510wifichn"
product = "gt510wifichn"
name = "gt510wifichn"
marketname = "Samsung Galaxy Tab A 9.7 WLAN"
fingerprint = ""

[templates."samsung_sm_t555c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A 9.7"
device = "gt510ltechn"
product = "gt510ltechn"
name = "gt510ltechn"
marketname = "Samsung Galaxy Tab A 9.7"
fingerprint = ""

[templates."samsung_sm_t580"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A 10.1 WLAN"
device = "gtaxlwifichn"
product = "gtaxlwifichn"
name = "gtaxlwifichn"
marketname = "Samsung Galaxy Tab A 10.1 WLAN"
fingerprint = ""

[templates."samsung_sm_t585c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A 10.1"
device = "gtaxlltechn"
product = "gtaxlltechn"
name = "gtaxlltechn"
marketname = "Samsung Galaxy Tab A 10.1"
fingerprint = ""

[templates."samsung_sm_p583"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A with S Pen 10.1 WLAN"
device = "gtanotexlwifichn"
product = "gtanotexlwifichn"
name = "gtanotexlwifichn"
marketname = "Samsung Galaxy Tab A with S Pen 10.1 WLAN"
fingerprint = ""

[templates."samsung_sm_p588c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A with S Pen 10.1"
device = "S"
product = "S"
name = "S"
marketname = "Samsung Galaxy Tab A with S Pen 10.1"
fingerprint = ""

[templates."samsung_sm_t590"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A 10.5 WLAN"
device = "gta2xlwifichn"
product = "gta2xlwifichn"
name = "gta2xlwifichn"
marketname = "Samsung Galaxy Tab A 10.5 WLAN"
fingerprint = ""

[templates."samsung_sm_t595c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A 10.5"
device = "gta2xlltechn"
product = "gta2xlltechn"
name = "gta2xlltechn"
marketname = "Samsung Galaxy Tab A 10.5"
fingerprint = ""

[templates."samsung_sm_t500"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A7 10.4 WLAN"
device = "gta4lwifi"
product = "gta4lwifi"
name = "gta4lwifi"
marketname = "Samsung Galaxy Tab A7 10.4 WLAN"
fingerprint = ""

[templates."samsung_sm_t505c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A7 10.4"
device = "gta4l"
product = "gta4l"
name = "gta4l"
marketname = "Samsung Galaxy Tab A7 10.4"
fingerprint = ""

[templates."samsung_sm_t220"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A7 Lite 8.7 WLAN"
device = "gta7litewifi"
product = "gta7litewifi"
name = "gta7litewifi"
marketname = "Samsung Galaxy Tab A7 Lite 8.7 WLAN"
fingerprint = ""

[templates."samsung_sm_t225c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A7 Lite 8.7"
device = "gta7lite"
product = "gta7lite"
name = "gta7lite"
marketname = "Samsung Galaxy Tab A7 Lite 8.7"
fingerprint = ""

[templates."samsung_sm_x200"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A8 WLAN"
device = "gta8wifi"
product = "gta8wifi"
name = "gta8wifi"
marketname = "Samsung Galaxy Tab A8 WLAN"
fingerprint = ""

[templates."samsung_sm_x205c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A8"
device = "gta8"
product = "gta8"
name = "gta8"
marketname = "Samsung Galaxy Tab A8"
fingerprint = ""

[templates."samsung_sm_x210"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A9+ WLAN"
device = "gta9pwifi"
product = "gta9pwifi"
name = "gta9pwifi"
marketname = "Samsung Galaxy Tab A9+ WLAN"
fingerprint = ""

[templates."samsung_sm_x216c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A9+ 5G"
device = "gta9p"
product = "gta9p"
name = "gta9p"
marketname = "Samsung Galaxy Tab A9+ 5G"
fingerprint = ""

[templates."samsung_sm_x230"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A11+ WLAN"
device = "gta11pwifi"
product = "gta11pwifi"
name = "gta11pwifi"
marketname = "Samsung Galaxy Tab A11+ WLAN"
fingerprint = ""

[templates."samsung_sm_x236c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab A11+ 5H"
device = "gta11p"
product = "gta11p"
name = "gta11p"
marketname = "Samsung Galaxy Tab A11+ 5H"
fingerprint = ""

[templates."samsung_sm_t230"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab4 7.0 WLAN"
device = "degaswifi"
product = "degaswifi"
name = "degaswifi"
marketname = "Samsung Galaxy Tab4 7.0 WLAN"
fingerprint = ""

[templates."samsung_sm_t231"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab4 7.0 3G"
device = "degas3g"
product = "degas3g"
name = "degas3g"
marketname = "Samsung Galaxy Tab4 7.0 3G"
fingerprint = ""

[templates."samsung_sm_t239c"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab4 7.0 VE"
device = "degasveltechn"
product = "degasveltechn"
name = "degasveltechn"
marketname = "Samsung Galaxy Tab4 7.0 VE"
fingerprint = ""

[templates."samsung_sm_t330"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab4 8.0 WLAN"
device = "milletwifi"
product = "milletwifi"
name = "milletwifi"
marketname = "Samsung Galaxy Tab4 8.0 WLAN"
fingerprint = ""

[templates."samsung_sm_t331"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab4 8.0 3G"
device = "millet3g"
product = "millet3g"
name = "millet3g"
marketname = "Samsung Galaxy Tab4 8.0 3G"
fingerprint = ""

[templates."samsung_sm_t530"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab4 10.1 WLAN"
device = "matissewifi"
product = "matissewifi"
name = "matissewifi"
marketname = "Samsung Galaxy Tab4 10.1 WLAN"
fingerprint = ""

[templates."samsung_sm_t531"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab4 10.1 3G"
device = "matisse3g"
product = "matisse3g"
name = "matisse3g"
marketname = "Samsung Galaxy Tab4 10.1 3G"
fingerprint = ""

[templates."samsung_sm_t320"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab PRO 8.4 WLAN"
device = "mondrianwifi"
product = "mondrianwifi"
name = "mondrianwifi"
marketname = "Samsung Galaxy Tab PRO 8.4 WLAN"
fingerprint = ""

[templates."samsung_sm_t321"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab PRO 8.4 3G"
device = "mondrian3g"
product = "mondrian3g"
name = "mondrian3g"
marketname = "Samsung Galaxy Tab PRO 8.4 3G"
fingerprint = ""

[templates."samsung_sm_t520"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy Tab PRO 10.1 WLAN"
device = "picassowifi"
product = "picassowifi"
name = "picassowifi"
marketname = "Samsung Galaxy Tab PRO 10.1 WLAN"
fingerprint = ""

[templates."samsung_sm_w700"]
manufacturer = "samsung"
brand = "samsung"
model = "Samsung Galaxy TabPro S WLAN"
device = "SM-W700"
product = "SM-W700"
marketname = "Samsung Galaxy TabPro S WLAN"
fingerprint = ""

[templates."vivo_v1821a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo NEX 双屏版"
device = "PD1821"
product = "PD1821"
name = "PD1821"
marketname = "vivo NEX 双屏版"
fingerprint = ""

[templates."vivo_v1923a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo NEX 3"
device = "PD1923"
product = "PD1923"
name = "PD1923"
marketname = "vivo NEX 3"
fingerprint = ""

[templates."vivo_v1924a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo NEX 3 5G"
device = "PD1924"
product = "PD1924"
name = "PD1924"
marketname = "vivo NEX 3 5G"
fingerprint = ""

[templates."vivo_v1950a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo NEX 3S 5G"
device = "PD1950"
product = "PD1950"
name = "PD1950"
marketname = "vivo NEX 3S 5G"
fingerprint = ""

[templates."vivo_v1814a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X21s"
device = "PD1814"
product = "PD1814"
name = "PD1814"
marketname = "vivo X21s"
fingerprint = ""

[templates."vivo_v1809a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X23"
device = "PD1809"
product = "PD1809"
name = "PD1809"
marketname = "vivo X23"
fingerprint = ""

[templates."vivo_v1816a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X23 幻彩版"
device = "PD1816"
product = "PD1816"
name = "PD1816"
marketname = "vivo X23 幻彩版"
fingerprint = ""

[templates."vivo_v1829a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X27 8GB+256GB"
device = "PD1829"
product = "PD1829"
name = "PD1829"
marketname = "vivo X27 8GB+256GB"
fingerprint = ""

[templates."vivo_v1838a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X27 8GB+128GB"
device = "PD1838"
product = "PD1838"
name = "PD1838"
marketname = "vivo X27 8GB+128GB"
fingerprint = ""

[templates."vivo_v1836a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X27 Pro"
device = "PD1836"
product = "PD1836"
name = "PD1836"
marketname = "vivo X27 Pro"
fingerprint = ""

[templates."vivo_v1938ca"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X30 5G"
device = "PD1938C"
product = "PD1938C"
name = "PD1938C"
marketname = "vivo X30 5G"
fingerprint = ""

[templates."vivo_v1938a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X30 Pro 5G"
device = "PD1938"
product = "PD1938"
name = "PD1938"
marketname = "vivo X30 Pro 5G"
fingerprint = ""

[templates."vivo_v2001a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X50"
device = "PD2001"
product = "PD2001"
name = "PD2001"
marketname = "vivo X50"
fingerprint = ""

[templates."vivo_v2005a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X50 Pro"
device = "PD2005"
product = "PD2005"
name = "PD2005"
marketname = "vivo X50 Pro"
fingerprint = ""

[templates."vivo_v2011a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X50 Pro+"
device = "PD2011"
product = "PD2011"
name = "PD2011"
marketname = "vivo X50 Pro+"
fingerprint = ""

[templates."vivo_v2046a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X60"
device = "PD2046"
product = "PD2046"
name = "PD2046"
marketname = "vivo X60"
fingerprint = ""

[templates."vivo_v2059a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X60 曲屏版"
device = "PD2059"
product = "PD2059"
name = "PD2059"
marketname = "vivo X60 曲屏版"
fingerprint = ""

[templates."vivo_v2085a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X60t"
device = "PD2085"
product = "PD2085"
name = "PD2085"
marketname = "vivo X60t"
fingerprint = ""

[templates."vivo_v2047a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X60 Pro"
device = "PD2047"
product = "PD2047"
name = "PD2047"
marketname = "vivo X60 Pro"
fingerprint = ""

[templates."vivo_v2120a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X60t Pro"
device = "PD2120"
product = "PD2120"
name = "PD2120"
marketname = "vivo X60t Pro"
fingerprint = ""

[templates."vivo_v2056a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X60 Pro+"
device = "PD2056"
product = "PD2056"
name = "PD2056"
marketname = "vivo X60 Pro+"
fingerprint = ""

[templates."vivo_v2133a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X70"
device = "PD2133"
product = "PD2133"
name = "PD2133"
marketname = "vivo X70"
fingerprint = ""

[templates."vivo_v2132a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X70t"
device = "PD2132"
product = "PD2132"
name = "PD2132"
marketname = "vivo X70t"
fingerprint = ""

[templates."vivo_v2134a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X70 Pro"
device = "PD2134"
product = "PD2134"
name = "PD2134"
marketname = "vivo X70 Pro"
fingerprint = ""

[templates."vivo_v2145a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X70 Pro+"
device = "PD2145"
product = "PD2145"
name = "PD2145"
marketname = "vivo X70 Pro+"
fingerprint = ""

[templates."vivo_v2178a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X Fold"
device = "PD2178"
product = "PD2178"
name = "PD2178"
marketname = "vivo X Fold"
fingerprint = ""

[templates."vivo_v2170a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X Note"
device = "PD2170"
product = "PD2170"
name = "PD2170"
marketname = "vivo X Note"
fingerprint = ""

[templates."vivo_v2183a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X80"
device = "PD2183"
product = "PD2183"
name = "PD2183"
marketname = "vivo X80"
fingerprint = ""

[templates."vivo_v2185a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X80 Pro"
device = "PD2185"
product = "PD2185"
name = "PD2185"
marketname = "vivo X80 Pro"
fingerprint = ""

[templates."vivo_v2186a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X80 Pro 天玑 9000 版"
device = "PD2186"
product = "PD2186"
name = "PD2186"
marketname = "vivo X80 Pro 天玑 9000 版"
fingerprint = ""

[templates."vivo_v2229a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X Fold+"
device = "PD2229"
product = "PD2229"
name = "PD2229"
marketname = "vivo X Fold+"
fingerprint = ""

[templates."vivo_v2241a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X90"
device = "PD2241"
product = "PD2241"
name = "PD2241"
marketname = "vivo X90"
fingerprint = ""

[templates."vivo_v2241ha"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X90s"
device = "PD2241"
product = "PD2241"
name = "PD2241"
marketname = "vivo X90s"
fingerprint = ""

[templates."vivo_v2242a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X90 Pro"
device = "PD2242"
product = "PD2242"
name = "PD2242"
marketname = "vivo X90 Pro"
fingerprint = ""

[templates."vivo_v2227a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X90 Pro+"
device = "PD2227"
product = "PD2227"
name = "PD2227"
marketname = "vivo X90 Pro+"
fingerprint = ""

[templates."vivo_v2266a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X Fold2"
device = "PD2266"
product = "PD2266"
name = "PD2266"
marketname = "vivo X Fold2"
fingerprint = ""

[templates."vivo_v2256a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X Flip"
device = "PD2256"
product = "PD2256"
name = "PD2256"
marketname = "vivo X Flip"
fingerprint = ""

[templates."vivo_v2309a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X100"
device = "PD2309"
product = "PD2309"
name = "PD2309"
marketname = "vivo X100"
fingerprint = ""

[templates."vivo_v2324a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X100 Pro"
device = "PD2324"
product = "PD2324"
name = "PD2324"
marketname = "vivo X100 Pro"
fingerprint = ""

[templates."vivo_v2303a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X Fold3"
device = "PD2303"
product = "PD2303"
name = "PD2303"
marketname = "vivo X Fold3"
fingerprint = ""

[templates."vivo_v2337a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X Fold3 Pro"
device = "PD2337"
product = "PD2337"
name = "PD2337"
marketname = "vivo X Fold3 Pro"
fingerprint = ""

[templates."vivo_v2359a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X100s"
device = "PD2359"
product = "PD2359"
name = "PD2359"
marketname = "vivo X100s"
fingerprint = ""

[templates."vivo_v2324ha"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X100s Pro"
device = "PD2324"
product = "PD2324"
name = "PD2324"
marketname = "vivo X100s Pro"
fingerprint = ""

[templates."vivo_v2366ga"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X100 Ultra"
device = "PD2366"
product = "PD2366"
name = "PD2366"
marketname = "vivo X100 Ultra"
fingerprint = ""

[templates."vivo_v2366ha"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X100 Ultra 卫星通信版"
device = "PD2366"
product = "PD2366"
name = "PD2366"
marketname = "vivo X100 Ultra 卫星通信版"
fingerprint = ""

[templates."vivo_v2415a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X200"
device = "PD2415"
product = "PD2415"
name = "PD2415"
marketname = "vivo X200"
fingerprint = ""

[templates."vivo_v2405a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X200 Pro"
device = "PD2405"
product = "PD2405"
name = "PD2405"
marketname = "vivo X200 Pro"
fingerprint = ""

[templates."vivo_v2405da"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X200 Pro 卫星通信版"
device = "PD2405"
product = "PD2405"
name = "PD2405"
marketname = "vivo X200 Pro 卫星通信版"
fingerprint = ""

[templates."vivo_v2419a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X200 Pro mini"
device = "PD2419"
product = "PD2419"
name = "PD2419"
marketname = "vivo X200 Pro mini"
fingerprint = ""

[templates."vivo_v2458a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X200s"
device = "PD2458"
product = "PD2458"
name = "PD2458"
marketname = "vivo X200s"
fingerprint = ""

[templates."vivo_v2454a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X200 Ultra"
device = "PD2454"
product = "PD2454"
name = "PD2454"
marketname = "vivo X200 Ultra"
fingerprint = ""

[templates."vivo_v2454da"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X200 Ultra 卫星通信版"
device = "PD2454"
product = "PD2454"
name = "PD2454"
marketname = "vivo X200 Ultra 卫星通信版"
fingerprint = ""

[templates."vivo_v2436a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X Fold5"
device = "PD2436"
product = "PD2436"
name = "PD2436"
marketname = "vivo X Fold5"
fingerprint = ""

[templates."vivo_v2509a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X300"
device = "PD2509"
product = "PD2509"
name = "PD2509"
marketname = "vivo X300"
fingerprint = ""

[templates."vivo_v2502a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X300 Pro"
device = "PD2502"
product = "PD2502"
name = "PD2502"
marketname = "vivo X300 Pro"
fingerprint = ""

[templates."vivo_v2502da"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X300 Pro 卫星通信版"
device = "PD2502"
product = "PD2502"
name = "PD2502"
marketname = "vivo X300 Pro 卫星通信版"
fingerprint = ""

[templates."vivo_v2548a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X300s"
device = "PD2548"
product = "PD2548"
name = "PD2548"
marketname = "vivo X300s"
fingerprint = ""

[templates."vivo_v2547a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X300 Ultra"
device = "PD2547"
product = "PD2547"
name = "PD2547"
marketname = "vivo X300 Ultra"
fingerprint = ""

[templates."vivo_v2547da"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X300 Ultra 卫星通信版"
device = "PD2547"
product = "PD2547"
name = "PD2547"
marketname = "vivo X300 Ultra 卫星通信版"
fingerprint = ""

[templates."vivo_v2612a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X300 E"
device = "PD2612"
product = "PD2612"
name = "PD2612"
marketname = "vivo X300 E"
fingerprint = ""

[templates."vivo_v2545a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X Fold6"
device = "PD2545"
product = "PD2545"
name = "PD2545"
marketname = "vivo X Fold6"
fingerprint = ""

[templates."vivo_v2609a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X500"
device = "PD2609"
product = "PD2609"
name = "PD2609"
marketname = "vivo X500"
fingerprint = ""

[templates."vivo_v2608a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X500 Pro"
device = "PD2608"
product = "PD2608"
name = "PD2608"
marketname = "vivo X500 Pro"
fingerprint = ""

[templates."vivo_v2608da"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X500 Pro eSIM 版"
device = "PD2608"
product = "PD2608"
name = "PD2608"
marketname = "vivo X500 Pro eSIM 版"
fingerprint = ""

[templates."vivo_v2602a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X500 Pro Max"
device = "PD2602"
product = "PD2602"
name = "PD2602"
marketname = "vivo X500 Pro Max"
fingerprint = ""

[templates."vivo_v2602da"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo X500 Pro Max 卫星通信版"
device = "PD2602"
product = "PD2602"
name = "PD2602"
marketname = "vivo X500 Pro Max 卫星通信版"
fingerprint = ""

[templates."vivo_v1831a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S1"
device = "PD1831"
product = "PD1831"
name = "PD1831"
marketname = "vivo S1"
fingerprint = ""

[templates."vivo_v1832a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S1 Pro"
device = "PD1832"
product = "PD1832"
name = "PD1832"
marketname = "vivo S1 Pro"
fingerprint = ""

[templates."vivo_v1932a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S5"
device = "PD1932"
product = "PD1932"
name = "PD1932"
marketname = "vivo S5"
fingerprint = ""

[templates."vivo_v1962a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S6"
device = "PD1962"
product = "PD1962"
name = "PD1962"
marketname = "vivo S6"
fingerprint = ""

[templates."vivo_v2020a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S7"
device = "PD2020"
product = "PD2020"
name = "PD2020"
marketname = "vivo S7"
fingerprint = ""

[templates."vivo_v2080a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S7t"
device = "PD2080"
product = "PD2080"
name = "PD2080"
marketname = "vivo S7t"
fingerprint = ""

[templates."vivo_v2031a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S7e"
device = "PD2031"
product = "PD2031"
name = "PD2031"
marketname = "vivo S7e"
fingerprint = ""

[templates."vivo_v2031ea"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S7e 活力版"
device = "PD2031EA"
product = "PD2031EA"
name = "PD2031EA"
marketname = "vivo S7e 活力版"
fingerprint = ""

[templates."vivo_v2072a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S9"
device = "PD2072"
product = "PD2072"
name = "PD2072"
marketname = "vivo S9"
fingerprint = ""

[templates."vivo_v2048a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S9e"
device = "PD2048"
product = "PD2048"
name = "PD2048"
marketname = "vivo S9e"
fingerprint = ""

[templates."vivo_v2121a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S10"
device = "PD2121"
product = "PD2121"
name = "PD2121"
marketname = "vivo S10"
fingerprint = ""

[templates."vivo_v2130a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S10e"
device = "PD2130"
product = "PD2130"
name = "PD2130"
marketname = "vivo S10e"
fingerprint = ""

[templates."vivo_v2162a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S12"
device = "PD2162"
product = "PD2162"
name = "PD2162"
marketname = "vivo S12"
fingerprint = ""

[templates."vivo_v2163a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S12 Pro"
device = "PD2163"
product = "PD2163"
name = "PD2163"
marketname = "vivo S12 Pro"
fingerprint = ""

[templates."vivo_v2203a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S15"
device = "PD2203"
product = "PD2203"
name = "PD2203"
marketname = "vivo S15"
fingerprint = ""

[templates."vivo_v2207a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S15 Pro"
device = "PD2207"
product = "PD2207"
name = "PD2207"
marketname = "vivo S15 Pro"
fingerprint = ""

[templates."vivo_v2190a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S15e"
device = "PD2190"
product = "PD2190"
name = "PD2190"
marketname = "vivo S15e"
fingerprint = ""

[templates."vivo_v2244a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S16"
device = "PD2244"
product = "PD2244"
name = "PD2244"
marketname = "vivo S16"
fingerprint = ""

[templates."vivo_v2245a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S16 Pro"
device = "PD2245"
product = "PD2245"
name = "PD2245"
marketname = "vivo S16 Pro"
fingerprint = ""

[templates."vivo_v2239a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S16e"
device = "PD2239"
product = "PD2239"
name = "PD2239"
marketname = "vivo S16e"
fingerprint = ""

[templates."vivo_v2283a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S17"
device = "PD2283"
product = "PD2283"
name = "PD2283"
marketname = "vivo S17"
fingerprint = ""

[templates."vivo_v2282a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S17t"
device = "PD2282"
product = "PD2282"
name = "PD2282"
marketname = "vivo S17t"
fingerprint = ""

[templates."vivo_v2284a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S17 Pro"
device = "PD2284"
product = "PD2284"
name = "PD2284"
marketname = "vivo S17 Pro"
fingerprint = ""

[templates."vivo_v2285a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S17e"
device = "PD2285"
product = "PD2285"
name = "PD2285"
marketname = "vivo S17e"
fingerprint = ""

[templates."vivo_v2323a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S18"
device = "PD2323"
product = "PD2323"
name = "PD2323"
marketname = "vivo S18"
fingerprint = ""

[templates."vivo_v2344a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S18 Pro"
device = "PD2344"
product = "PD2344"
name = "PD2344"
marketname = "vivo S18 Pro"
fingerprint = ""

[templates."vivo_v2334a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S18e"
device = "PD2334"
product = "PD2334"
name = "PD2334"
marketname = "vivo S18e"
fingerprint = ""

[templates."vivo_v2364a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S19"
device = "PD2364"
product = "PD2364"
name = "PD2364"
marketname = "vivo S19"
fingerprint = ""

[templates."vivo_v2362a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S19 Pro"
device = "PD2362"
product = "PD2362"
name = "PD2362"
marketname = "vivo S19 Pro"
fingerprint = ""

[templates."vivo_v2429a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S20"
device = "PD2429"
product = "PD2429"
name = "PD2429"
marketname = "vivo S20"
fingerprint = ""

[templates."vivo_v2430a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S20 Pro"
device = "PD2430"
product = "PD2430"
name = "PD2430"
marketname = "vivo S20 Pro"
fingerprint = ""

[templates."vivo_v2464a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S30"
device = "PD2464"
product = "PD2464"
name = "PD2464"
marketname = "vivo S30"
fingerprint = ""

[templates."vivo_v2465a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S30 Pro mini"
device = "PD2465"
product = "PD2465"
name = "PD2465"
marketname = "vivo S30 Pro mini"
fingerprint = ""

[templates."vivo_v2528a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S50"
device = "PD2528"
product = "PD2528"
name = "PD2528"
marketname = "vivo S50"
fingerprint = ""

[templates."vivo_v2527a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S50 Pro mini"
device = "PD2527"
product = "PD2527"
name = "PD2527"
marketname = "vivo S50 Pro mini"
fingerprint = ""

[templates."vivo_v2571a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S60"
device = "PD2571"
product = "PD2571"
name = "PD2571"
marketname = "vivo S60"
fingerprint = ""

[templates."vivo_v2572a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S60 元气版"
device = "PD2572"
product = "PD2572"
name = "PD2572"
marketname = "vivo S60 元气版"
fingerprint = ""

[templates."vivo_v2620a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo S60t"
device = "PD2620"
product = "PD2620"
name = "PD2620"
marketname = "vivo S60t"
fingerprint = ""

[templates."vivo_v1901a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y3"
device = "PD1901"
product = "PD1901"
name = "PD1901"
marketname = "vivo Y3"
fingerprint = ""

[templates."vivo_v1934a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y5s"
device = "PD1934"
product = "PD1934"
name = "PD1934"
marketname = "vivo Y5s"
fingerprint = ""

[templates."vivo_v1913a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y7s"
device = "PD1913"
product = "PD1913"
name = "PD1913"
marketname = "vivo Y7s"
fingerprint = ""

[templates."vivo_v1945a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y9s"
device = "PD1945"
product = "PD1945"
name = "PD1945"
marketname = "vivo Y9s"
fingerprint = ""

[templates."vivo_v2140a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y10"
device = "PD2140"
product = "PD2140"
name = "PD2140"
marketname = "vivo Y10"
fingerprint = ""

[templates."vivo_v2236a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y11"
device = "PD2236"
product = "PD2236"
name = "PD2236"
marketname = "vivo Y11"
fingerprint = ""

[templates."vivo_v2317a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y12"
device = "PD2317"
product = "PD2317"
name = "PD2317"
marketname = "vivo Y12"
fingerprint = ""

[templates."vivo_v2034a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y30"
device = "PD2034"
product = "PD2034"
name = "PD2034"
marketname = "vivo Y30"
fingerprint = ""

[templates."vivo_v2099a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y30 2021"
device = "PD2099"
product = "PD2099"
name = "PD2099"
marketname = "vivo Y30 2021"
fingerprint = ""

[templates."vivo_v2066a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y30 活力版"
device = "PD2066"
product = "PD2066"
name = "PD2066"
marketname = "vivo Y30 活力版"
fingerprint = ""

[templates."vivo_v2066ba"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y30g"
device = "PD2066B"
product = "PD2066B"
name = "PD2066B"
marketname = "vivo Y30g"
fingerprint = ""

[templates."vivo_v2054a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y31s 5G"
device = "t1"
product = "t1"
name = "t1"
marketname = "vivo Y31s 5G"
fingerprint = ""

[templates."vivo_v2068a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y31s 标准版 5G"
device = "t1"
product = "t1"
name = "t1"
marketname = "vivo Y31s 标准版 5G"
fingerprint = ""

[templates."vivo_v2158a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y32"
device = "PD2158"
product = "PD2158"
name = "PD2158"
marketname = "vivo Y32"
fingerprint = ""

[templates."vivo_v2166a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y33s 5G"
device = "PD2166"
product = "PD2166"
name = "PD2166"
marketname = "vivo Y33s 5G"
fingerprint = ""

[templates."vivo_v2230a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y35 5G"
device = "PD2230"
product = "PD2230"
name = "PD2230"
marketname = "vivo Y35 5G"
fingerprint = ""

[templates."vivo_v2279a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y35+ 5G"
device = "PD2279"
product = "PD2279"
name = "PD2279"
marketname = "vivo Y35+ 5G"
fingerprint = ""

[templates."vivo_v2318a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y36 5G"
device = "PD2318"
product = "PD2318"
name = "PD2318"
marketname = "vivo Y36 5G"
fingerprint = ""

[templates."vivo_v2327a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y36t"
device = "PD2327"
product = "PD2327"
name = "PD2327"
marketname = "vivo Y36t"
fingerprint = ""

[templates."vivo_v2357a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y36c 5G"
device = "PD2357"
product = "PD2357"
name = "PD2357"
marketname = "vivo Y36c 5G"
fingerprint = ""

[templates."vivo_v2357ea"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y37m 5G"
device = "PD2357"
product = "PD2357"
name = "PD2357"
marketname = "vivo Y37m 5G"
fingerprint = ""

[templates."vivo_v2354a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y37 Pro 5G"
device = "PD2354"
product = "PD2354"
name = "PD2354"
marketname = "vivo Y37 Pro 5G"
fingerprint = ""

[templates."vivo_v2442a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y37c"
device = "PD2442"
product = "PD2442"
name = "PD2442"
marketname = "vivo Y37c"
fingerprint = ""

[templates."vivo_v1965a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y50"
device = "PD1965"
product = "PD1965"
name = "PD1965"
marketname = "vivo Y50"
fingerprint = ""

[templates."vivo_v2023ea"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y50t"
device = "PD2023"
product = "PD2023"
name = "PD2023"
marketname = "vivo Y50t"
fingerprint = ""

[templates."vivo_v2443a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y37t 5G"
device = "PD2443"
product = "PD2443"
name = "PD2443"
marketname = "vivo Y37t 5G"
fingerprint = ""

[templates."vivo_v2443ba"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y50m 5G"
device = "PD2443"
product = "PD2443"
name = "PD2443"
marketname = "vivo Y50m 5G"
fingerprint = ""

[templates."vivo_v2002a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y51s 5G"
device = "PD2019"
product = "PD2019"
name = "PD2019"
marketname = "vivo Y51s 5G"
fingerprint = ""

[templates."vivo_v2057a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y52s 5G"
device = "PD2057"
product = "PD2057"
name = "PD2057"
marketname = "vivo Y52s 5G"
fingerprint = ""

[templates."vivo_v2111a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y53s 5G"
device = "PD2111"
product = "PD2111"
name = "PD2111"
marketname = "vivo Y53s 5G"
fingerprint = ""

[templates."vivo_v2045a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y54s 5G"
device = "PD2045"
product = "PD2045"
name = "PD2045"
marketname = "vivo Y54s 5G"
fingerprint = ""

[templates."vivo_v2164a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y55s 5G"
device = "PD2164"
product = "PD2164"
name = "PD2164"
marketname = "vivo Y55s 5G"
fingerprint = ""

[templates."vivo_v2541a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y6c"
device = "PD2541"
product = "PD2541"
name = "PD2541"
marketname = "vivo Y6c"
fingerprint = ""

[templates."vivo_v2559a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y60"
device = "PD2559"
product = "PD2559"
name = "PD2559"
marketname = "vivo Y60"
fingerprint = ""

[templates."vivo_v2559ba"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y60m"
device = "PD2559"
product = "PD2559"
name = "PD2559"
marketname = "vivo Y60m"
fingerprint = ""

[templates."vivo_v2532ba"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y6m"
device = "PD2532"
product = "PD2532"
name = "PD2532"
marketname = "vivo Y6m"
fingerprint = ""

[templates."vivo_v2542a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y60i"
device = "PD2542"
product = "PD2542"
name = "PD2542"
marketname = "vivo Y60i"
fingerprint = ""

[templates."vivo_v1731ca"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y71s"
device = "PD1731C"
product = "PD1731C"
name = "PD1731C"
marketname = "vivo Y71s"
fingerprint = ""

[templates."vivo_v2102a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y71t 5G"
device = "PD2102"
product = "PD2102"
name = "PD2102"
marketname = "vivo Y71t 5G"
fingerprint = ""

[templates."vivo_v2164pa"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y73t 5G"
device = "PD2164U"
product = "PD2164U"
name = "PD2164U"
marketname = "vivo Y73t 5G"
fingerprint = ""

[templates."vivo_v2009a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y74s 5G"
device = "PD2009"
product = "PD2009"
name = "PD2009"
marketname = "vivo Y74s 5G"
fingerprint = ""

[templates."vivo_v2069ba"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y75s 5G"
device = "PD2069"
product = "PD2069"
name = "PD2069"
marketname = "vivo Y75s 5G"
fingerprint = ""

[templates."vivo_v2156a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y76s 5G"
device = "PD2156"
product = "PD2156"
name = "PD2156"
marketname = "vivo Y76s 5G"
fingerprint = ""

[templates."vivo_v2219a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y77 5G"
device = "PD2219"
product = "PD2219"
name = "PD2219"
marketname = "vivo Y77 5G"
fingerprint = ""

[templates."vivo_v2166ba"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y77e 5G"
device = "t1"
product = "t1"
name = "t1"
marketname = "vivo Y77e 5G"
fingerprint = ""

[templates."vivo_v2278a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y77t 5G"
device = "PD2278"
product = "PD2278"
name = "PD2278"
marketname = "vivo Y77t 5G"
fingerprint = ""

[templates."vivo_v2271a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y78+ 5G"
device = "t1"
product = "t1"
name = "t1"
marketname = "vivo Y78+ 5G"
fingerprint = ""

[templates."vivo_v2312ba"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y78t 5G"
device = "PD2312"
product = "PD2312"
name = "PD2312"
marketname = "vivo Y78t 5G"
fingerprint = ""

[templates."vivo_v1732a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y81"
device = "PD1732"
product = "PD1732"
name = "PD1732"
marketname = "vivo Y81"
fingerprint = ""

[templates."vivo_v1730ea"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y89"
device = "PD1730E"
product = "PD1730E"
name = "PD1730E"
marketname = "vivo Y89"
fingerprint = ""

[templates."vivo_v1818ca"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y91"
device = "PD1818C"
product = "PD1818C"
name = "PD1818C"
marketname = "vivo Y91"
fingerprint = ""

[templates."vivo_v1818a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y93"
device = "PD1818"
product = "PD1818"
name = "PD1818"
marketname = "vivo Y93"
fingerprint = ""

[templates."vivo_v1813a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y97"
device = "PD1813"
product = "PD1813"
name = "PD1813"
marketname = "vivo Y97"
fingerprint = ""

[templates."vivo_v2313a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y100 5G"
device = "PD2313"
product = "PD2313"
name = "PD2313"
marketname = "vivo Y100 5G"
fingerprint = ""

[templates."vivo_v2314da"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y100t 5G"
device = "PD2314"
product = "PD2314"
name = "PD2314"
marketname = "vivo Y100t 5G"
fingerprint = ""

[templates."vivo_v2343a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y200 5G"
device = "PD2343"
product = "PD2343"
name = "PD2343"
marketname = "vivo Y200 5G"
fingerprint = ""

[templates."vivo_v2361ga"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y200 GT 5G"
device = "PD2361"
product = "PD2361"
name = "PD2361"
marketname = "vivo Y200 GT 5G"
fingerprint = ""

[templates."vivo_v2353da"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y200t 5G"
device = "PD2353"
product = "PD2353"
name = "PD2353"
marketname = "vivo Y200t 5G"
fingerprint = ""

[templates."vivo_v2435a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y300 5G"
device = "PD2435"
product = "PD2435"
name = "PD2435"
marketname = "vivo Y300 5G"
fingerprint = ""

[templates."vivo_v2444a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y300i 5G"
device = "PD2444"
product = "PD2444"
name = "PD2444"
marketname = "vivo Y300i 5G"
fingerprint = ""

[templates."vivo_v2410a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y300 Pro"
device = "PD2410"
product = "PD2410"
name = "PD2410"
marketname = "vivo Y300 Pro"
fingerprint = ""

[templates."vivo_v2456a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y300 Pro+"
device = "PD2456"
product = "PD2456"
name = "PD2456"
marketname = "vivo Y300 Pro+"
fingerprint = ""

[templates."vivo_v2445ea"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y300t"
device = "PD2445D"
product = "PD2445D"
name = "PD2445D"
marketname = "vivo Y300t"
fingerprint = ""

[templates."vivo_v2452ga"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y300 GT"
device = "PD2452"
product = "PD2452"
name = "PD2452"
marketname = "vivo Y300 GT"
fingerprint = ""

[templates."vivo_v2506a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y500"
device = "PD2506"
product = "PD2506"
name = "PD2506"
marketname = "vivo Y500"
fingerprint = ""

[templates."vivo_v2516a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y500 Pro"
device = "PD2516"
product = "PD2516"
name = "PD2516"
marketname = "vivo Y500 Pro"
fingerprint = ""

[templates."vivo_v2531a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y500i"
device = "PD2531"
product = "PD2531"
name = "PD2531"
marketname = "vivo Y500i"
fingerprint = ""

[templates."vivo_v2617a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y500k"
device = "PD2617"
product = "PD2617"
name = "PD2617"
marketname = "vivo Y500k"
fingerprint = ""

[templates."vivo_v2607a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y600"
device = "PD2607"
product = "PD2607"
name = "PD2607"
marketname = "vivo Y600"
fingerprint = ""

[templates."vivo_v2561a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y600 Pro"
device = "PD2561"
product = "PD2561"
name = "PD2561"
marketname = "vivo Y600 Pro"
fingerprint = ""

[templates."vivo_v2553a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Y600 Turbo"
device = "PD2553"
product = "PD2553"
name = "PD2553"
marketname = "vivo Y600 Turbo"
fingerprint = ""

[templates."vivo_v2115a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo T1"
device = "PD2115"
product = "PD2115"
name = "PD2115"
marketname = "vivo T1"
fingerprint = ""

[templates."vivo_v2199ga"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo T2"
device = "PD2199"
product = "PD2199"
name = "PD2199"
marketname = "vivo T2"
fingerprint = ""

[templates."vivo_v2188a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo T2x"
device = "PD2188"
product = "PD2188"
name = "PD2188"
marketname = "vivo T2x"
fingerprint = ""

[templates."vivo_v1801a0"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Z1"
device = "PD1730C"
product = "PD1730C"
name = "PD1730C"
marketname = "vivo Z1"
fingerprint = ""

[templates."vivo_v1730da"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Z1i"
device = "PD1730D"
product = "PD1730D"
name = "PD1730D"
marketname = "vivo Z1i"
fingerprint = ""

[templates."vivo_v1813ba"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Z3"
device = "PD1813B"
product = "PD1813B"
name = "PD1813B"
marketname = "vivo Z3"
fingerprint = ""

[templates."vivo_v1730ga"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Z3x"
device = "PD1730G"
product = "PD1730G"
name = "PD1730G"
marketname = "vivo Z3x"
fingerprint = ""

[templates."vivo_v1921a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Z5"
device = "PD1921"
product = "PD1921"
name = "PD1921"
marketname = "vivo Z5"
fingerprint = ""

[templates."vivo_v1911a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Z5x"
device = "PD1911"
product = "PD1911"
name = "PD1911"
marketname = "vivo Z5x"
fingerprint = ""

[templates."vivo_v1990a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Z5x 712 版"
device = "PD1990"
product = "PD1990"
name = "PD1990"
marketname = "vivo Z5x 712 版"
fingerprint = ""

[templates."vivo_v1941a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Z5i"
device = "PD1941"
product = "PD1941"
name = "PD1941"
marketname = "vivo Z5i"
fingerprint = ""

[templates."vivo_v1963a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Z6 5G"
device = "PD1963"
product = "PD1963"
name = "PD1963"
marketname = "vivo Z6 5G"
fingerprint = ""

[templates."vivo_v1928a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo U3x"
device = "PD1928"
product = "PD1928"
name = "PD1928"
marketname = "vivo U3x"
fingerprint = ""

[templates."vivo_v1962ba"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo G1"
device = "PD1962B"
product = "PD1962B"
name = "PD1962B"
marketname = "vivo G1"
fingerprint = ""

[templates."vivo_v1824ba"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO"
device = "PD1824"
product = "PD1824"
name = "PD1824"
marketname = "vivo iQOO"
fingerprint = ""

[templates."vivo_v1922a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Pro"
device = "PD1922"
product = "PD1922"
name = "PD1922"
marketname = "vivo iQOO Pro"
fingerprint = ""

[templates."vivo_v1916a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Pro 5G"
device = "PD1916"
product = "PD1916"
name = "PD1916"
marketname = "vivo iQOO Pro 5G"
fingerprint = ""

[templates."vivo_v1955a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 3"
device = "PD1955"
product = "PD1955"
name = "PD1955"
marketname = "vivo iQOO 3"
fingerprint = ""

[templates."vivo_v2024a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 5"
device = "PD2024"
product = "PD2024"
name = "PD2024"
marketname = "vivo iQOO 5"
fingerprint = ""

[templates."vivo_v2025a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 5 Pro"
device = "PD2025"
product = "PD2025"
name = "PD2025"
marketname = "vivo iQOO 5 Pro"
fingerprint = ""

[templates."vivo_v2049a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 7"
device = "PD2049"
product = "PD2049"
name = "PD2049"
marketname = "vivo iQOO 7"
fingerprint = ""

[templates."vivo_v2136a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 8"
device = "PD2136"
product = "PD2136"
name = "PD2136"
marketname = "vivo iQOO 8"
fingerprint = ""

[templates."vivo_v2141a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 8 Pro"
device = "PD2141"
product = "PD2141"
name = "PD2141"
marketname = "vivo iQOO 8 Pro"
fingerprint = ""

[templates."vivo_v2171a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 9"
device = "PD2171"
product = "PD2171"
name = "PD2171"
marketname = "vivo iQOO 9"
fingerprint = ""

[templates."vivo_v2172a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 9 Pro"
device = "PD2172"
product = "PD2172"
name = "PD2172"
marketname = "vivo iQOO 9 Pro"
fingerprint = ""

[templates."vivo_v2217a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 10"
device = "PD2217"
product = "PD2217"
name = "PD2217"
marketname = "vivo iQOO 10"
fingerprint = ""

[templates."vivo_v2218a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 10 Pro"
device = "PD2218"
product = "PD2218"
name = "PD2218"
marketname = "vivo iQOO 10 Pro"
fingerprint = ""

[templates."vivo_v2243a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 11"
device = "PD2243"
product = "PD2243"
name = "PD2243"
marketname = "vivo iQOO 11"
fingerprint = ""

[templates."vivo_v2254a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 11 Pro"
device = "PD2254"
product = "PD2254"
name = "PD2254"
marketname = "vivo iQOO 11 Pro"
fingerprint = ""

[templates."vivo_v2304a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 11S"
device = "PD2304"
product = "PD2304"
name = "PD2304"
marketname = "vivo iQOO 11S"
fingerprint = ""

[templates."vivo_v2307a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 12"
device = "PD2307"
product = "PD2307"
name = "PD2307"
marketname = "vivo iQOO 12"
fingerprint = ""

[templates."vivo_v2329a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 12 Pro"
device = "PD2329"
product = "PD2329"
name = "PD2329"
marketname = "vivo iQOO 12 Pro"
fingerprint = ""

[templates."vivo_v2408a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 13"
device = "PD2408"
product = "PD2408"
name = "PD2408"
marketname = "vivo iQOO 13"
fingerprint = ""

[templates."vivo_v2505a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 15"
device = "PD2505"
product = "PD2505"
name = "PD2505"
marketname = "vivo iQOO 15"
fingerprint = ""

[templates."vivo_v2546a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 15 Ultra"
device = "PD2546"
product = "PD2546"
name = "PD2546"
marketname = "vivo iQOO 15 Ultra"
fingerprint = ""

[templates."vivo_v2564a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 15T"
device = "PD2564"
product = "PD2564"
name = "PD2564"
marketname = "vivo iQOO 15T"
fingerprint = ""

[templates."vivo_v2606a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO 16"
device = "PD2606"
product = "PD2606"
name = "PD2606"
marketname = "vivo iQOO 16"
fingerprint = ""

[templates."vivo_v1914a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo"
device = "PD1914"
product = "PD1914"
name = "PD1914"
marketname = "vivo iQOO Neo"
fingerprint = ""

[templates."vivo_v1936a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo 855 版"
device = "PD1936"
product = "PD1936"
name = "PD1936"
marketname = "vivo iQOO Neo 855 版"
fingerprint = ""

[templates."vivo_v1936al"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo 855 竞速版"
device = "PD1936"
product = "PD1936"
name = "PD1936"
marketname = "vivo iQOO Neo 855 竞速版"
fingerprint = ""

[templates."vivo_v1981a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo3"
device = "PD1981"
product = "PD1981"
name = "PD1981"
marketname = "vivo iQOO Neo3"
fingerprint = ""

[templates."vivo_v2055a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo5"
device = "PD2055"
product = "PD2055"
name = "PD2055"
marketname = "vivo iQOO Neo5"
fingerprint = ""

[templates."vivo_v2118a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo5 活力版"
device = "PD2118"
product = "PD2118"
name = "PD2118"
marketname = "vivo iQOO Neo5 活力版"
fingerprint = ""

[templates."vivo_v2154a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo5S"
device = "PD2154"
product = "PD2154"
name = "PD2154"
marketname = "vivo iQOO Neo5S"
fingerprint = ""

[templates."vivo_v2157a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo5 SE"
device = "PD2157"
product = "PD2157"
name = "PD2157"
marketname = "vivo iQOO Neo5 SE"
fingerprint = ""

[templates."vivo_v2196a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo6"
device = "PD2196"
product = "PD2196"
name = "PD2196"
marketname = "vivo iQOO Neo6"
fingerprint = ""

[templates."vivo_v2199a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo6 SE"
device = "PD2199"
product = "PD2199"
name = "PD2199"
marketname = "vivo iQOO Neo6 SE"
fingerprint = ""

[templates."vivo_v2231a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo7"
device = "PD2231"
product = "PD2231"
name = "PD2231"
marketname = "vivo iQOO Neo7"
fingerprint = ""

[templates."vivo_v2232a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo7 竞速版"
device = "PD2232"
product = "PD2232"
name = "PD2232"
marketname = "vivo iQOO Neo7 竞速版"
fingerprint = ""

[templates."vivo_v2238a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo7 SE"
device = "PD2238"
product = "PD2238"
name = "PD2238"
marketname = "vivo iQOO Neo7 SE"
fingerprint = ""

[templates."vivo_v2301a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo8"
device = "PD2301"
product = "PD2301"
name = "PD2301"
marketname = "vivo iQOO Neo8"
fingerprint = ""

[templates."vivo_v2302a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo8 Pro"
device = "PD2302"
product = "PD2302"
name = "PD2302"
marketname = "vivo iQOO Neo8 Pro"
fingerprint = ""

[templates."vivo_v2338a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo9"
device = "PD2338"
product = "PD2338"
name = "PD2338"
marketname = "vivo iQOO Neo9"
fingerprint = ""

[templates."vivo_v2339a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo9 Pro"
device = "PD2339"
product = "PD2339"
name = "PD2339"
marketname = "vivo iQOO Neo9 Pro"
fingerprint = ""

[templates."vivo_v2339fa"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo9S Pro"
device = "PD2339"
product = "PD2339"
name = "PD2339"
marketname = "vivo iQOO Neo9S Pro"
fingerprint = ""

[templates."vivo_v2403a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo9S Pro+"
device = "PD2403"
product = "PD2403"
name = "PD2403"
marketname = "vivo iQOO Neo9S Pro+"
fingerprint = ""

[templates."vivo_v2425a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo10"
device = "PD2425"
product = "PD2425"
name = "PD2425"
marketname = "vivo iQOO Neo10"
fingerprint = ""

[templates."vivo_v2426a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo10 Pro"
device = "PD2426"
product = "PD2426"
name = "PD2426"
marketname = "vivo iQOO Neo10 Pro"
fingerprint = ""

[templates."vivo_v2463a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo10 Pro+"
device = "PD2463"
product = "PD2463"
name = "PD2463"
marketname = "vivo iQOO Neo10 Pro+"
fingerprint = ""

[templates."vivo_v2520a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo11"
device = "PD2520"
product = "PD2520"
name = "PD2520"
marketname = "vivo iQOO Neo11"
fingerprint = ""

[templates."vivo_v2573a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo11 至尊版"
device = "PD2573"
product = "PD2573"
name = "PD2573"
marketname = "vivo iQOO Neo11 至尊版"
fingerprint = ""

[templates."vivo_v2618a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Neo12"
device = "PD2618"
product = "PD2618"
name = "PD2618"
marketname = "vivo iQOO Neo12"
fingerprint = ""

[templates."vivo_v1986a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z1"
device = "PD1986"
product = "PD1986"
name = "PD1986"
marketname = "vivo iQOO Z1"
fingerprint = ""

[templates."vivo_v2012a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z1x"
device = "PD2012"
product = "PD2012"
name = "PD2012"
marketname = "vivo iQOO Z1x"
fingerprint = ""

[templates."vivo_v2073a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z3"
device = "PD2073"
product = "PD2073"
name = "PD2073"
marketname = "vivo iQOO Z3"
fingerprint = ""

[templates."vivo_v2148a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z5"
device = "PD2148"
product = "PD2148"
name = "PD2148"
marketname = "vivo iQOO Z5"
fingerprint = ""

[templates."vivo_v2131a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z5x"
device = "PD2131"
product = "PD2131"
name = "PD2131"
marketname = "vivo iQOO Z5x"
fingerprint = ""

[templates."vivo_v2220a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z6"
device = "PD2220"
product = "PD2220"
name = "PD2220"
marketname = "vivo iQOO Z6"
fingerprint = ""

[templates."vivo_v2164ka"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z6x"
device = "PD2164U"
product = "PD2164U"
name = "PD2164U"
marketname = "vivo iQOO Z6x"
fingerprint = ""

[templates."vivo_v2270a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z7"
device = "PD2270"
product = "PD2270"
name = "PD2270"
marketname = "vivo iQOO Z7"
fingerprint = ""

[templates."vivo_v2272a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z7x"
device = "PD2272"
product = "PD2272"
name = "PD2272"
marketname = "vivo iQOO Z7x"
fingerprint = ""

[templates."vivo_v2230ea"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z7i"
device = "PD2230"
product = "PD2230"
name = "PD2230"
marketname = "vivo iQOO Z7i"
fingerprint = ""

[templates."vivo_v2314a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z8"
device = "PD2314"
product = "PD2314"
name = "PD2314"
marketname = "vivo iQOO Z8"
fingerprint = ""

[templates."vivo_v2312a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z8x"
device = "PD2312"
product = "PD2312"
name = "PD2312"
marketname = "vivo iQOO Z8x"
fingerprint = ""

[templates."vivo_v2361a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z9"
device = "PD2361"
product = "PD2361"
name = "PD2361"
marketname = "vivo iQOO Z9"
fingerprint = ""

[templates."vivo_v2352a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z9 Turbo"
device = "PD2352"
product = "PD2352"
name = "PD2352"
marketname = "vivo iQOO Z9 Turbo"
fingerprint = ""

[templates."vivo_v2352ga"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z9 Turbo 长续航版"
device = "PD2352G"
product = "PD2352G"
name = "PD2352G"
marketname = "vivo iQOO Z9 Turbo 长续航版"
fingerprint = ""

[templates."vivo_v2417a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z9 Turbo+"
device = "PD2417"
product = "PD2417"
name = "PD2417"
marketname = "vivo iQOO Z9 Turbo+"
fingerprint = ""

[templates."vivo_v2353a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z9x"
device = "PD2353"
product = "PD2353"
name = "PD2353"
marketname = "vivo iQOO Z9x"
fingerprint = ""

[templates."vivo_v2452a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z10 Turbo"
device = "PD2452"
product = "PD2452"
name = "PD2452"
marketname = "vivo iQOO Z10 Turbo"
fingerprint = ""

[templates."vivo_v2453a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z10 Turbo Pro"
device = "PD2453"
product = "PD2453"
name = "PD2453"
marketname = "vivo iQOO Z10 Turbo Pro"
fingerprint = ""

[templates."vivo_v2507a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z10 Turbo+"
device = "PD2507"
product = "PD2507"
name = "PD2507"
marketname = "vivo iQOO Z10 Turbo+"
fingerprint = ""

[templates."vivo_v2445a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z10x"
device = "PD2445"
product = "PD2445"
name = "PD2445"
marketname = "vivo iQOO Z10x"
fingerprint = ""

[templates."vivo_v2536a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z11 Turbo"
device = "PD2536"
product = "PD2536"
name = "PD2536"
marketname = "vivo iQOO Z11 Turbo"
fingerprint = ""

[templates."vivo_v2551a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z11"
device = "PD2551"
product = "PD2551"
name = "PD2551"
marketname = "vivo iQOO Z11"
fingerprint = ""

[templates."vivo_v2532a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z11x"
device = "PD2532"
product = "PD2532"
name = "PD2532"
marketname = "vivo iQOO Z11x"
fingerprint = ""

[templates."vivo_v2559ua"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z11i"
device = "PD2559"
product = "PD2559"
name = "PD2559"
marketname = "vivo iQOO Z11i"
fingerprint = ""

[templates."vivo_v2603a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Z11S"
device = "PD2603"
product = "PD2603"
name = "PD2603"
marketname = "vivo iQOO Z11S"
fingerprint = ""

[templates."vivo_v2023a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO U1"
device = "PD2023"
product = "PD2023"
name = "PD2023"
marketname = "vivo iQOO U1"
fingerprint = ""

[templates."vivo_v2065a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO U1x"
device = "PD2065"
product = "PD2065"
name = "PD2065"
marketname = "vivo iQOO U1x"
fingerprint = ""

[templates."vivo_v2061a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO U3 5G"
device = "PD2061"
product = "PD2061"
name = "PD2061"
marketname = "vivo iQOO U3 5G"
fingerprint = ""

[templates."vivo_v2106a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO U3x 5G"
device = "PD2106"
product = "PD2106"
name = "PD2106"
marketname = "vivo iQOO U3x 5G"
fingerprint = ""

[templates."vivo_v2143a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO U3x"
device = "PD2143"
product = "PD2143"
name = "PD2143"
marketname = "vivo iQOO U3x"
fingerprint = ""

[templates."vivo_v2165a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO U5 5G"
device = "PD2165"
product = "PD2165"
name = "PD2165"
marketname = "vivo iQOO U5 5G"
fingerprint = ""

[templates."vivo_v2180ga"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO U5x"
device = "PD2180G"
product = "PD2180G"
name = "PD2180G"
marketname = "vivo iQOO U5x"
fingerprint = ""

[templates."vivo_v2197a"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO U5e 5G"
device = "PD2197"
product = "PD2197"
name = "PD2197"
marketname = "vivo iQOO U5e 5G"
fingerprint = ""

[templates."vivo_pa2170"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Pad"
device = "DPD2106"
product = "DPD2106"
name = "DPD2106"
marketname = "vivo Pad"
fingerprint = ""

[templates."vivo_pa2373"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Pad2"
device = "DPD2221"
product = "DPD2221"
name = "DPD2221"
marketname = "vivo Pad2"
fingerprint = ""

[templates."vivo_pa2353"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Pad Air"
device = "DPD2305"
product = "DPD2305"
name = "DPD2305"
marketname = "vivo Pad Air"
fingerprint = ""

[templates."vivo_pa2455"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Pad3"
device = "DPD2345"
product = "DPD2345"
name = "DPD2345"
marketname = "vivo Pad3"
fingerprint = ""

[templates."vivo_pa2473"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Pad3 Pro"
device = "DPD2329"
product = "DPD2329"
name = "DPD2329"
marketname = "vivo Pad3 Pro"
fingerprint = ""

[templates."vivo_pa2553"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Pad5"
device = "DPD2437"
product = "DPD2437"
name = "DPD2437"
marketname = "vivo Pad5"
fingerprint = ""

[templates."vivo_pa2573"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Pad5 Pro"
device = "DPD2429"
product = "DPD2429"
name = "DPD2429"
marketname = "vivo Pad5 Pro"
fingerprint = ""

[templates."vivo_pa2535"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Pad5e"
device = "DPD2345"
product = "DPD2345"
name = "DPD2345"
marketname = "vivo Pad5e"
fingerprint = ""

[templates."vivo_pa2511"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Pad SE"
device = "DPD2424"
product = "DPD2424"
name = "DPD2424"
marketname = "vivo Pad SE"
fingerprint = ""

[templates."vivo_pa2671"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo Pad6 Pro"
device = "DPD2540"
product = "DPD2540"
name = "DPD2540"
marketname = "vivo Pad6 Pro"
fingerprint = ""

[templates."vivo_ipa2375"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Pad"
device = "DPD2307"
product = "DPD2307"
name = "DPD2307"
marketname = "vivo iQOO Pad"
fingerprint = ""

[templates."vivo_ipa2451"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Pad Air"
device = "DPD2305"
product = "DPD2305"
name = "DPD2305"
marketname = "vivo iQOO Pad Air"
fingerprint = ""

[templates."vivo_ipa2453"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Pad2"
device = "DPD2345"
product = "DPD2345"
name = "DPD2345"
marketname = "vivo iQOO Pad2"
fingerprint = ""

[templates."vivo_ipa2475"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Pad2 Pro"
device = "DPD2329"
product = "DPD2329"
name = "DPD2329"
marketname = "vivo iQOO Pad2 Pro"
fingerprint = ""

[templates."vivo_ipa2556"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Pad5"
device = "DPD2437"
product = "DPD2437"
name = "DPD2437"
marketname = "vivo iQOO Pad5"
fingerprint = ""

[templates."vivo_ipa2575"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Pad5 Pro"
device = "DPD2438"
product = "DPD2438"
name = "DPD2438"
marketname = "vivo iQOO Pad5 Pro"
fingerprint = ""

[templates."vivo_ipa2537"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Pad5e"
device = "DPD2345"
product = "DPD2345"
name = "DPD2345"
marketname = "vivo iQOO Pad5e"
fingerprint = ""

[templates."vivo_ipa2673"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Pad6 Pro"
device = "DPD2540"
product = "DPD2540"
name = "DPD2540"
marketname = "vivo iQOO Pad6 Pro"
fingerprint = ""

[templates."vivo_ipa2691"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Pad Ultra"
device = "DPD2605"
product = "DPD2605"
name = "DPD2605"
marketname = "vivo iQOO Pad Ultra"
fingerprint = ""

[templates."vivo_ipa2693"]
manufacturer = "vivo"
brand = "vivo"
model = "vivo iQOO Pad Pro 8.8"
device = "DPD2653"
product = "DPD2653"
name = "DPD2653"
marketname = "vivo iQOO Pad Pro 8.8"
fingerprint = ""

[templates."google_g_2pw4100"]
manufacturer = "Google"
brand = "google"
model = "Pixel"
device = "sailfish"
product = "sailfish"
name = "sailfish"
marketname = "Pixel"
fingerprint = ""

[templates."google_g_2pw2100"]
manufacturer = "Google"
brand = "google"
model = "Pixel XL"
device = "marlin"
product = "marlin"
name = "marlin"
marketname = "Pixel XL"
fingerprint = ""

[templates."google_g011a"]
manufacturer = "Google"
brand = "google"
model = "Pixel 2"
device = "walleye"
product = "walleye"
name = "walleye"
marketname = "Pixel 2"
fingerprint = ""

[templates."google_g011c"]
manufacturer = "Google"
brand = "google"
model = "Pixel 2 XL"
device = "taimen"
product = "taimen"
name = "taimen"
marketname = "Pixel 2 XL"
fingerprint = ""

[templates."google_g013a"]
manufacturer = "Google"
brand = "google"
model = "Pixel 3"
device = "blueline"
product = "blueline"
name = "blueline"
marketname = "Pixel 3"
fingerprint = ""

[templates."google_g013c"]
manufacturer = "Google"
brand = "google"
model = "Pixel 3 XL"
device = "crosshatch"
product = "crosshatch"
name = "crosshatch"
marketname = "Pixel 3 XL"
fingerprint = ""

[templates."google_g020e"]
manufacturer = "Google"
brand = "google"
model = "Pixel 3a"
device = "sargo"
product = "sargo"
name = "sargo"
marketname = "Pixel 3a"
fingerprint = ""

[templates."google_g020a"]
manufacturer = "Google"
brand = "google"
model = "Pixel 3a XL"
device = "bonito"
product = "bonito"
name = "bonito"
marketname = "Pixel 3a XL"
fingerprint = ""

[templates."google_g020i"]
manufacturer = "Google"
brand = "google"
model = "Pixel 4"
device = "flame"
product = "flame"
name = "flame"
marketname = "Pixel 4"
fingerprint = ""

[templates."google_g020j"]
manufacturer = "Google"
brand = "google"
model = "Pixel 4 XL"
device = "coral"
product = "coral"
name = "coral"
marketname = "Pixel 4 XL"
fingerprint = ""

[templates."google_g025j"]
manufacturer = "Google"
brand = "google"
model = "Pixel 4a"
device = "sunfish"
product = "sunfish"
name = "sunfish"
marketname = "Pixel 4a"
fingerprint = ""

[templates."google_g025e"]
manufacturer = "Google"
brand = "google"
model = "Pixel 4a 5G"
device = "bramble"
product = "bramble"
name = "bramble"
marketname = "Pixel 4a 5G"
fingerprint = ""

[templates."google_gd1yq"]
manufacturer = "Google"
brand = "google"
model = "Pixel 5"
device = "redfin"
product = "redfin"
name = "redfin"
marketname = "Pixel 5"
fingerprint = ""

[templates."google_g1f8f"]
manufacturer = "Google"
brand = "google"
model = "Pixel 5a 5G"
device = "barbet"
product = "barbet"
name = "barbet"
marketname = "Pixel 5a 5G"
fingerprint = ""

[templates."google_g9s9b"]
manufacturer = "Google"
brand = "google"
model = "Pixel 6"
device = "oriole"
product = "oriole"
name = "oriole"
marketname = "Pixel 6"
fingerprint = ""

[templates."google_g8vou"]
manufacturer = "Google"
brand = "google"
model = "Pixel 6 Pro"
device = "raven"
product = "raven"
name = "raven"
marketname = "Pixel 6 Pro"
fingerprint = ""

[templates."google_gb62z"]
manufacturer = "Google"
brand = "google"
model = "Pixel 6a"
device = "bluejay"
product = "bluejay"
name = "bluejay"
marketname = "Pixel 6a"
fingerprint = ""

[templates."google_gqml3"]
manufacturer = "Google"
brand = "google"
model = "Pixel 7"
device = "panther"
product = "panther"
name = "panther"
marketname = "Pixel 7"
fingerprint = ""

[templates."google_ge2ae"]
manufacturer = "Google"
brand = "google"
model = "Pixel 7 Pro"
device = "cheetah"
product = "cheetah"
name = "cheetah"
marketname = "Pixel 7 Pro"
fingerprint = ""

[templates."google_g0dzq"]
manufacturer = "Google"
brand = "google"
model = "Pixel 7a"
device = "lynx"
product = "lynx"
name = "lynx"
marketname = "Pixel 7a"
fingerprint = ""

[templates."google_gkws6"]
manufacturer = "Google"
brand = "google"
model = "Pixel 8"
device = "shiba"
product = "shiba"
name = "shiba"
marketname = "Pixel 8"
fingerprint = ""

[templates."google_g1mnw"]
manufacturer = "Google"
brand = "google"
model = "Pixel 8 Pro"
device = "husky"
product = "husky"
name = "husky"
marketname = "Pixel 8 Pro"
fingerprint = ""

[templates."google_g8hnn"]
manufacturer = "Google"
brand = "google"
model = "Pixel 8a"
device = "akita"
product = "akita"
name = "akita"
marketname = "Pixel 8a"
fingerprint = ""

[templates."google_g9fpl"]
manufacturer = "Google"
brand = "google"
model = "Pixel Fold"
device = "felix"
product = "felix"
name = "felix"
marketname = "Pixel Fold"
fingerprint = ""

[templates."google_g2ybb"]
manufacturer = "Google"
brand = "google"
model = "Pixel 9"
device = "tokay"
product = "tokay"
name = "tokay"
marketname = "Pixel 9"
fingerprint = ""

[templates."google_gr83y"]
manufacturer = "Google"
brand = "google"
model = "Pixel 9 Pro"
device = "caiman"
product = "caiman"
name = "caiman"
marketname = "Pixel 9 Pro"
fingerprint = ""

[templates."google_ggx8b"]
manufacturer = "Google"
brand = "google"
model = "Pixel 9 Pro XL"
device = "komodo"
product = "komodo"
name = "komodo"
marketname = "Pixel 9 Pro XL"
fingerprint = ""

[templates."google_ggh2x"]
manufacturer = "Google"
brand = "google"
model = "Pixel 9 Pro Fold"
device = "comet"
product = "comet"
name = "comet"
marketname = "Pixel 9 Pro Fold"
fingerprint = ""

[templates."google_gxq96"]
manufacturer = "Google"
brand = "google"
model = "Pixel 9a"
device = "tegu"
product = "tegu"
name = "tegu"
marketname = "Pixel 9a"
fingerprint = ""

[templates."google_glbw0"]
manufacturer = "Google"
brand = "google"
model = "Pixel 10"
device = "frankel"
product = "frankel"
name = "frankel"
marketname = "Pixel 10"
fingerprint = ""

[templates."google_g4qur"]
manufacturer = "Google"
brand = "google"
model = "Pixel 10 Pro"
device = "blazer"
product = "blazer"
name = "blazer"
marketname = "Pixel 10 Pro"
fingerprint = ""

[templates."google_gul82"]
manufacturer = "Google"
brand = "google"
model = "Pixel 10 Pro XL"
device = "mustang"
product = "mustang"
name = "mustang"
marketname = "Pixel 10 Pro XL"
fingerprint = ""

[templates."google_gu0np"]
manufacturer = "Google"
brand = "google"
model = "Pixel 10 Pro Fold"
device = "rango"
product = "rango"
name = "rango"
marketname = "Pixel 10 Pro Fold"
fingerprint = ""

[templates."google_ge1gq"]
manufacturer = "Google"
brand = "google"
model = "Pixel 10a"
device = "stallion"
product = "stallion"
name = "stallion"
marketname = "Pixel 10a"
fingerprint = ""

[templates."google_gpqq7"]
manufacturer = "Google"
brand = "google"
model = "Pixel 11"
device = "cubs"
product = "cubs"
name = "cubs"
marketname = "Pixel 11"
fingerprint = ""

[templates."google_g7swn"]
manufacturer = "Google"
brand = "google"
model = "Pixel 11 Pro"
device = "grizzly"
product = "grizzly"
name = "grizzly"
marketname = "Pixel 11 Pro"
fingerprint = ""

[templates."google_gbc0h"]
manufacturer = "Google"
brand = "google"
model = "Pixel 11 Pro XL"
device = "kodiak"
product = "kodiak"
name = "kodiak"
marketname = "Pixel 11 Pro XL"
fingerprint = ""

[templates."google_gzdq6"]
manufacturer = "Google"
brand = "google"
model = "Pixel 11 Pro Fold"
device = "yogi"
product = "yogi"
name = "yogi"
marketname = "Pixel 11 Pro Fold"
fingerprint = ""

[templates."google_c1502w"]
manufacturer = "Google"
brand = "google"
model = "Pixel C"
device = "dragon"
product = "dragon"
name = "dragon"
marketname = "Pixel C"
fingerprint = ""

[templates."google_gtu8p"]
manufacturer = "Google"
brand = "google"
model = "Pixel Tablet"
device = "tangorpro"
product = "tangorpro"
name = "tangorpro"
marketname = "Pixel Tablet"
fingerprint = ""

[templates."apple_a1324"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 3G"
device = "A1324"
product = "A1324"
marketname = "iPhone 3G"
fingerprint = ""

[templates."apple_a1303"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 3GS"
device = "A1303"
product = "A1303"
marketname = "iPhone 3GS"
fingerprint = ""

[templates."apple_a1332"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 4"
device = "A1332"
product = "A1332"
marketname = "iPhone 4"
fingerprint = ""

[templates."apple_a1431"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 4S"
device = "A1431"
product = "A1431"
marketname = "iPhone 4S"
fingerprint = ""

[templates."apple_a1429"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 5"
device = "A1429"
product = "A1429"
marketname = "iPhone 5"
fingerprint = ""

[templates."apple_a1533"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 5s"
device = "A1533"
product = "A1533"
marketname = "iPhone 5s"
fingerprint = ""

[templates."apple_a1532"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 5c"
device = "A1532"
product = "A1532"
marketname = "iPhone 5c"
fingerprint = ""

[templates."apple_a1586"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 6"
device = "A1586"
product = "A1586"
marketname = "iPhone 6"
fingerprint = ""

[templates."apple_a1524"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 6 Plus"
device = "A1524"
product = "A1524"
marketname = "iPhone 6 Plus"
fingerprint = ""

[templates."apple_a1700"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 6s"
device = "A1700"
product = "A1700"
marketname = "iPhone 6s"
fingerprint = ""

[templates."apple_a1699"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 6s Plus"
device = "A1699"
product = "A1699"
marketname = "iPhone 6s Plus"
fingerprint = ""

[templates."apple_a1723"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone SE"
device = "A1723"
product = "A1723"
marketname = "iPhone SE"
fingerprint = ""

[templates."apple_a1660"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 7"
device = "A1660"
product = "A1660"
marketname = "iPhone 7"
fingerprint = ""

[templates."apple_a1661"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 7 Plus"
device = "A1661"
product = "A1661"
marketname = "iPhone 7 Plus"
fingerprint = ""

[templates."apple_a1863"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 8"
device = "A1863"
product = "A1863"
marketname = "iPhone 8"
fingerprint = ""

[templates."apple_a1864"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 8 Plus"
device = "A1864"
product = "A1864"
marketname = "iPhone 8 Plus"
fingerprint = ""

[templates."apple_a1865"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone X"
device = "A1865"
product = "A1865"
marketname = "iPhone X"
fingerprint = ""

[templates."apple_a2100"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone XS"
device = "A2100"
product = "A2100"
marketname = "iPhone XS"
fingerprint = ""

[templates."apple_a2104"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone XS Max"
device = "A2104"
product = "A2104"
marketname = "iPhone XS Max"
fingerprint = ""

[templates."apple_a2108"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone XR"
device = "A2108"
product = "A2108"
marketname = "iPhone XR"
fingerprint = ""

[templates."apple_a2223"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 11"
device = "A2223"
product = "A2223"
marketname = "iPhone 11"
fingerprint = ""

[templates."apple_a2217"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 11 Pro"
device = "A2217"
product = "A2217"
marketname = "iPhone 11 Pro"
fingerprint = ""

[templates."apple_a2220"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 11 Pro Max"
device = "A2220"
product = "A2220"
marketname = "iPhone 11 Pro Max"
fingerprint = ""

[templates."apple_a2400"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 12 mini"
device = "A2400"
product = "A2400"
marketname = "iPhone 12 mini"
fingerprint = ""

[templates."apple_a2404"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 12"
device = "A2404"
product = "A2404"
marketname = "iPhone 12"
fingerprint = ""

[templates."apple_a2408"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 12 Pro"
device = "A2408"
product = "A2408"
marketname = "iPhone 12 Pro"
fingerprint = ""

[templates."apple_a2412"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 12 Pro Max"
device = "A2412"
product = "A2412"
marketname = "iPhone 12 Pro Max"
fingerprint = ""

[templates."apple_a2629"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 13 mini"
device = "A2629"
product = "A2629"
marketname = "iPhone 13 mini"
fingerprint = ""

[templates."apple_a2634"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 13"
device = "A2634"
product = "A2634"
marketname = "iPhone 13"
fingerprint = ""

[templates."apple_a2639"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 13 Pro"
device = "A2639"
product = "A2639"
marketname = "iPhone 13 Pro"
fingerprint = ""

[templates."apple_a2644"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 13 Pro Max"
device = "A2644"
product = "A2644"
marketname = "iPhone 13 Pro Max"
fingerprint = ""

[templates."apple_a2884"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 14"
device = "A2884"
product = "A2884"
marketname = "iPhone 14"
fingerprint = ""

[templates."apple_a2888"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 14 Plus"
device = "A2888"
product = "A2888"
marketname = "iPhone 14 Plus"
fingerprint = ""

[templates."apple_a2892"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 14 Pro"
device = "A2892"
product = "A2892"
marketname = "iPhone 14 Pro"
fingerprint = ""

[templates."apple_a2896"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 14 Pro Max"
device = "A2896"
product = "A2896"
marketname = "iPhone 14 Pro Max"
fingerprint = ""

[templates."apple_a3092"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 15"
device = "A3092"
product = "A3092"
marketname = "iPhone 15"
fingerprint = ""

[templates."apple_a3096"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 15 Plus"
device = "A3096"
product = "A3096"
marketname = "iPhone 15 Plus"
fingerprint = ""

[templates."apple_a3104"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 15 Pro"
device = "A3104"
product = "A3104"
marketname = "iPhone 15 Pro"
fingerprint = ""

[templates."apple_a3108"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 15 Pro Max"
device = "A3108"
product = "A3108"
marketname = "iPhone 15 Pro Max"
fingerprint = ""

[templates."apple_a3288"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 16"
device = "A3288"
product = "A3288"
marketname = "iPhone 16"
fingerprint = ""

[templates."apple_a3291"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 16 Plus"
device = "A3291"
product = "A3291"
marketname = "iPhone 16 Plus"
fingerprint = ""

[templates."apple_a3294"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 16 Pro"
device = "A3294"
product = "A3294"
marketname = "iPhone 16 Pro"
fingerprint = ""

[templates."apple_a3297"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 16 Pro Max"
device = "A3297"
product = "A3297"
marketname = "iPhone 16 Pro Max"
fingerprint = ""

[templates."apple_a3410"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 16e"
device = "A3410"
product = "A3410"
marketname = "iPhone 16e"
fingerprint = ""

[templates."apple_a3521"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 17"
device = "A3521"
product = "A3521"
marketname = "iPhone 17"
fingerprint = ""

[templates."apple_a3518"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone Air"
device = "A3518"
product = "A3518"
marketname = "iPhone Air"
fingerprint = ""

[templates."apple_a3524"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 17 Pro"
device = "A3524"
product = "A3524"
marketname = "iPhone 17 Pro"
fingerprint = ""

[templates."apple_a3527"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 17 Pro Max"
device = "A3527"
product = "A3527"
marketname = "iPhone 17 Pro Max"
fingerprint = ""

[templates."apple_a3635"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 17e"
device = "A3635"
product = "A3635"
marketname = "iPhone 17e"
fingerprint = ""

[templates."apple_a3715"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 18 Pro"
device = "A3715"
product = "A3715"
marketname = "iPhone 18 Pro"
fingerprint = ""

[templates."apple_a3718"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone 18 Pro Max"
device = "A3718"
product = "A3718"
marketname = "iPhone 18 Pro Max"
fingerprint = ""

[templates."apple_a3721"]
manufacturer = "Apple"
brand = "Apple"
model = "iPhone Duo"
device = "A3721"
product = "A3721"
marketname = "iPhone Duo"
fingerprint = ""

[templates."apple_a1219"]
manufacturer = "Apple"
brand = "Apple"
model = "iPad"
device = "A1219"
product = "A1219"
marketname = "iPad"
fingerprint = ""

[templates."apple_a1395"]
manufacturer = "Apple"
brand = "Apple"
model = "iPad 2"
device = "A1395"
product = "A1395"
marketname = "iPad 2"
fingerprint = ""

[templates."apple_a1474"]
manufacturer = "Apple"
brand = "Apple"
model = "iPad Air"
device = "A1474"
product = "A1474"
marketname = "iPad Air"
fingerprint = ""

[templates."apple_a1566"]
manufacturer = "Apple"
brand = "Apple"
model = "iPad Air 2"
device = "A1566"
product = "A1566"
marketname = "iPad Air 2"
fingerprint = ""

[templates."apple_a1584"]
manufacturer = "Apple"
brand = "Apple"
model = "iPad Pro"
device = "A1584"
product = "A1584"
marketname = "iPad Pro"
fingerprint = ""

[templates."apple_a1432"]
manufacturer = "Apple"
brand = "Apple"
model = "iPad mini"
device = "A1432"
product = "A1432"
marketname = "iPad mini"
fingerprint = ""

[templates."apple_a1489"]
manufacturer = "Apple"
brand = "Apple"
model = "iPad mini 2"
device = "A1489"
product = "A1489"
marketname = "iPad mini 2"
fingerprint = ""

[templates."apple_a1599"]
manufacturer = "Apple"
brand = "Apple"
model = "iPad mini 3"
device = "A1599"
product = "A1599"
marketname = "iPad mini 3"
fingerprint = ""

[templates."apple_a1538"]
manufacturer = "Apple"
brand = "Apple"
model = "iPad mini 4"
device = "A1538"
product = "A1538"
marketname = "iPad mini 4"
fingerprint = ""

[templates."apple_a1603"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple Pencil"
device = "A1603"
product = "A1603"
marketname = "Apple Pencil"
fingerprint = ""

[templates."apple_a2538"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple Pencil Pro"
device = "A2538"
product = "A2538"
marketname = "Apple Pencil Pro"
fingerprint = ""

[templates."apple_a2117"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple Vision Pro"
device = "A2117"
product = "A2117"
marketname = "Apple Vision Pro"
fingerprint = ""

[templates."apple_a1213"]
manufacturer = "Apple"
brand = "Apple"
model = "iPod touch"
device = "A1213"
product = "A1213"
marketname = "iPod touch"
fingerprint = ""

[templates."apple_a2337"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple MacBook Air"
device = "M1"
product = "M1"
name = "M1"
marketname = "Apple MacBook Air"
fingerprint = ""

[templates."apple_a3404"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple MacBook Neo"
device = "A18"
product = "A18"
name = "A18"
marketname = "Apple MacBook Neo"
fingerprint = ""

[templates."apple_a2338"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple MacBook Pro"
device = "M2"
product = "M2"
name = "M2"
marketname = "Apple MacBook Pro"
fingerprint = ""

[templates."apple_a2438"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple iMac"
device = "M1"
product = "M1"
name = "M1"
marketname = "Apple iMac"
fingerprint = ""

[templates."apple_a2348"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple Mac mini"
device = "M1"
product = "M1"
name = "M1"
marketname = "Apple Mac mini"
fingerprint = ""

[templates."apple_a2615"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple Mac Studio"
device = "M1"
product = "M1"
name = "M1"
marketname = "Apple Mac Studio"
fingerprint = ""

[templates."apple_a2786"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple Mac Pro"
device = "A2786"
product = "A2786"
marketname = "Apple Mac Pro"
fingerprint = ""

[templates."apple_a1999"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple Pro Display XDR"
device = "A1999"
product = "A1999"
marketname = "Apple Pro Display XDR"
fingerprint = ""

[templates."apple_a2525"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple Studio Display"
device = "A2525"
product = "A2525"
marketname = "Apple Studio Display"
fingerprint = ""

[templates."apple_a3348"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple Studio Display XDR"
device = "A3348"
product = "A3348"
marketname = "Apple Studio Display XDR"
fingerprint = ""

[templates."apple_a1523"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple AirPods"
device = "A1523"
product = "A1523"
marketname = "Apple AirPods"
fingerprint = ""

[templates."apple_a3053"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple AirPods 4"
device = "A3053"
product = "A3053"
marketname = "Apple AirPods 4"
fingerprint = ""

[templates."apple_a3531"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple AirPods 5"
device = "A3531"
product = "A3531"
marketname = "Apple AirPods 5"
fingerprint = ""

[templates."apple_a2083"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple AirPods Pro"
device = "A2083"
product = "A2083"
marketname = "Apple AirPods Pro"
fingerprint = ""

[templates."apple_a2699"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple AirPods Pro 2"
device = "A2699"
product = "A2699"
marketname = "Apple AirPods Pro 2"
fingerprint = ""

[templates."apple_a3064"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple AirPods Pro 3"
device = "A3064"
product = "A3064"
marketname = "Apple AirPods Pro 3"
fingerprint = ""

[templates."apple_a2096"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple AirPods Max"
device = "A2096"
product = "A2096"
marketname = "Apple AirPods Max"
fingerprint = ""

[templates."apple_a3454"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple AirPods Max 2"
device = "A3454"
product = "A3454"
marketname = "Apple AirPods Max 2"
fingerprint = ""

[templates."apple_a2187"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple AirTag"
device = "A2187"
product = "A2187"
marketname = "Apple AirTag"
fingerprint = ""

[templates."apple_a1639"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple HomePod"
device = "A1639"
product = "A1639"
marketname = "Apple HomePod"
fingerprint = ""

[templates."apple_a2374"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple HomePod mini"
device = "A2374"
product = "A2374"
marketname = "Apple HomePod mini"
fingerprint = ""

[templates."apple_a3374"]
manufacturer = "Apple"
brand = "Apple"
model = "Apple HomePod mini 2"
device = "A3374"
product = "A3374"
marketname = "Apple HomePod mini 2"
fingerprint = ""

[templates."nubia_nx501"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z5"
device = "NX501"
product = "NX501"
marketname = "nubia Z5"
fingerprint = ""

[templates."nubia_nx401"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z5 mini"
device = "NX401"
product = "NX401"
marketname = "nubia Z5 mini"
fingerprint = ""

[templates."nubia_nx503a"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z5S"
device = "NX503A"
product = "NX503A"
marketname = "nubia Z5S"
fingerprint = ""

[templates."nubia_nx403a"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z5S mini"
device = "NX403A"
product = "NX403A"
marketname = "nubia Z5S mini"
fingerprint = ""

[templates."nubia_nx506j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z7"
device = "NX506J"
product = "NX506J"
marketname = "nubia Z7"
fingerprint = ""

[templates."nubia_nx507j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z7 mini"
device = "NX507J"
product = "NX507J"
marketname = "nubia Z7 mini"
fingerprint = ""

[templates."nubia_nx505j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z7 Max"
device = "NX505J"
product = "NX505J"
marketname = "nubia Z7 Max"
fingerprint = ""

[templates."nubia_nx508j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z9"
device = "NX508J"
product = "NX508J"
marketname = "nubia Z9"
fingerprint = ""

[templates."nubia_nx511j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z9 mini"
device = "NX511J"
product = "NX511J"
marketname = "nubia Z9 mini"
fingerprint = ""

[templates."nubia_nx510j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z9 Max"
device = "NX510J"
product = "NX510J"
marketname = "nubia Z9 Max"
fingerprint = ""

[templates."nubia_nx512j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z9 Max 极速版"
device = "NX512J"
product = "NX512J"
marketname = "nubia Z9 Max 极速版"
fingerprint = ""

[templates."nubia_nx518j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z9 Max 精英版"
device = "NX518J"
product = "NX518J"
marketname = "nubia Z9 Max 精英版"
fingerprint = ""

[templates."nubia_nx531j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z11"
device = "NX531J"
product = "NX531J"
marketname = "nubia Z11"
fingerprint = ""

[templates."nubia_nx529j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z11 mini"
device = "NX529J"
product = "NX529J"
marketname = "nubia Z11 mini"
fingerprint = ""

[templates."nubia_nx523j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z11 Max"
device = "NX523J"
product = "NX523J"
marketname = "nubia Z11 Max"
fingerprint = ""

[templates."nubia_nx535j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z11 Max 经典版"
device = "NX535J"
product = "NX535J"
marketname = "nubia Z11 Max 经典版"
fingerprint = ""

[templates."nubia_nx549j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z11 miniS"
device = "NX549J"
product = "NX549J"
marketname = "nubia Z11 miniS"
fingerprint = ""

[templates."nubia_nx563j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z17"
device = "NX563J"
product = "NX563J"
marketname = "nubia Z17"
fingerprint = ""

[templates."nubia_nx591j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z17 畅享版"
device = "NX591J"
product = "NX591J"
marketname = "nubia Z17 畅享版"
fingerprint = ""

[templates."nubia_nx569j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z17 mini"
device = "NX569J"
product = "NX569J"
marketname = "nubia Z17 mini"
fingerprint = ""

[templates."nubia_nx595j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z17S"
device = "NX595J"
product = "NX595J"
marketname = "nubia Z17S"
fingerprint = ""

[templates."nubia_nx589j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z17 miniS"
device = "NX589J"
product = "NX589J"
marketname = "nubia Z17 miniS"
fingerprint = ""

[templates."nubia_nx606j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z18"
device = "NX606J"
product = "NX606J"
marketname = "nubia Z18"
fingerprint = ""

[templates."nubia_nx611j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z18 mini"
device = "NX611J"
product = "NX611J"
marketname = "nubia Z18 mini"
fingerprint = ""

[templates."nubia_nx627j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z20"
device = "NX627J"
product = "NX627J"
marketname = "nubia Z20"
fingerprint = ""

[templates."nubia_nx667j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z30 Pro"
device = "NX667J"
product = "NX667J"
marketname = "nubia Z30 Pro"
fingerprint = ""

[templates."nubia_nx701j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z40 Pro"
device = "NX701J"
product = "NX701J"
marketname = "nubia Z40 Pro"
fingerprint = ""

[templates."nubia_nx702j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z40S Pro"
device = "NX702J"
product = "NX702J"
marketname = "nubia Z40S Pro"
fingerprint = ""

[templates."nubia_nx711j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z50"
device = "NX711J"
product = "NX711J"
marketname = "nubia Z50"
fingerprint = ""

[templates."nubia_nx712j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z50 Ultra"
device = "NX712J"
product = "NX712J"
marketname = "nubia Z50 Ultra"
fingerprint = ""

[templates."nubia_nx713j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z50S Pro"
device = "NX713J"
product = "NX713J"
marketname = "nubia Z50S Pro"
fingerprint = ""

[templates."nubia_nx715j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z50 SE"
device = "NX715J"
product = "NX715J"
marketname = "nubia Z50 SE"
fingerprint = ""

[templates."nubia_nx721j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z60 Ultra"
device = "NX721J"
product = "NX721J"
marketname = "nubia Z60 Ultra"
fingerprint = ""

[templates."nubia_nx725j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z60S Pro"
device = "NX725J"
product = "NX725J"
marketname = "nubia Z60S Pro"
fingerprint = ""

[templates."nubia_nx733j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z70 Ultra"
device = "NX733J"
product = "NX733J"
marketname = "nubia Z70 Ultra"
fingerprint = ""

[templates."nubia_nx736j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z70 Ultra 星空典藏版"
device = "NX736J"
product = "NX736J"
marketname = "nubia Z70 Ultra 星空典藏版"
fingerprint = ""

[templates."nubia_nx737j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z70S Ultra 摄影师版"
device = "NX737J"
product = "NX737J"
marketname = "nubia Z70S Ultra 摄影师版"
fingerprint = ""

[templates."nubia_nx741j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Z80 Ultra"
device = "NX741J"
product = "NX741J"
marketname = "nubia Z80 Ultra"
fingerprint = ""

[templates."nubia_nx601j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia X6"
device = "NX601J"
product = "NX601J"
marketname = "nubia X6"
fingerprint = ""

[templates."nubia_nx616j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia X"
device = "NX616J"
product = "NX616J"
marketname = "nubia X"
fingerprint = ""

[templates."nubia_nx612j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia V18"
device = "NX612J"
product = "NX612J"
marketname = "nubia V18"
fingerprint = ""

[templates."nubia_nx651j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Play"
device = "NX651J"
product = "NX651J"
marketname = "nubia Play"
fingerprint = ""

[templates."nubia_nx724j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Flip 5G"
device = "NX724J"
product = "NX724J"
marketname = "nubia Flip 5G"
fingerprint = ""

[templates."nubia_nx732j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Flip 2"
device = "NX732J"
product = "NX732J"
marketname = "nubia Flip 2"
fingerprint = ""

[templates."nubia_a404zt"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Flip 2 SoftBank"
device = "A404ZT"
product = "A404ZT"
marketname = "nubia Flip 2 SoftBank"
fingerprint = ""

[templates."nubia_z8900ca"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Flip 2 eSIM"
device = "Z8900CA"
product = "Z8900CA"
marketname = "nubia Flip 2 eSIM"
fingerprint = ""

[templates."nubia_nx302j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia 小牛"
device = "NX302J"
product = "NX302J"
marketname = "nubia 小牛"
fingerprint = ""

[templates."nubia_nx513j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia My 布拉格"
device = "NX513J"
product = "NX513J"
marketname = "nubia My 布拉格"
fingerprint = ""

[templates."nubia_nx551j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia M2"
device = "NX551J"
product = "NX551J"
marketname = "nubia M2"
fingerprint = ""

[templates."nubia_nx573j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia M2 青春版"
device = "NX573J"
product = "NX573J"
marketname = "nubia M2 青春版"
fingerprint = ""

[templates."nubia_nx907j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia M2 畅玩版"
device = "NX907J"
product = "NX907J"
marketname = "nubia M2 畅玩版"
fingerprint = ""

[templates."nubia_p0110"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia M153 豆包手机助手技术预览版"
device = "P0110"
product = "P0110"
marketname = "nubia M153 豆包手机助手技术预览版"
fingerprint = ""

[templates."nubia_nx888j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia NaviX Ultra"
device = "NX888J"
product = "NX888J"
marketname = "nubia NaviX Ultra"
fingerprint = ""

[templates."nubia_nx541j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia N1"
device = "NX541J"
product = "NX541J"
marketname = "nubia N1"
fingerprint = ""

[templates."nubia_nx575j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia N2"
device = "NX575J"
product = "NX575J"
marketname = "nubia N2"
fingerprint = ""

[templates."nubia_nx608j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia N3"
device = "NX608J"
product = "NX608J"
marketname = "nubia N3"
fingerprint = ""

[templates."nubia_nx301j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia N5"
device = "NX301J"
product = "NX301J"
marketname = "nubia N5"
fingerprint = ""

[templates."nubia_lpd_20w"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Pad 3D"
device = "LPD-20W"
product = "LPD-20W"
marketname = "nubia Pad 3D"
fingerprint = ""

[templates."nubia_np02j"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Pad 3D II"
device = "NP02J"
product = "NP02J"
marketname = "nubia Pad 3D II"
fingerprint = ""

[templates."nubia_nt01"]
manufacturer = "nubia"
brand = "nubia"
model = "nubia Pad Pro"
device = "NT01"
product = "NT01"
marketname = "nubia Pad Pro"
fingerprint = ""

[templates."nubia_nx609j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic"
device = "REDMAGIC"
product = "NX609J"
name = "REDMAGIC"
marketname = "RedMagic"
fingerprint = ""

[templates."nubia_nx619j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic Mars"
device = "REDMAGIC MARS"
product = "NX619J"
name = "REDMAGIC MARS"
marketname = "RedMagic Mars"
fingerprint = ""

[templates."nubia_nx629j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 3"
device = "REDMAGIC 3"
product = "NX629J"
name = "REDMAGIC 3"
marketname = "RedMagic 3"
fingerprint = ""

[templates."nubia_nx659j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 5G"
device = "REDMAGIC 5G"
product = "NX659J"
name = "REDMAGIC 5G"
marketname = "RedMagic 5G"
fingerprint = ""

[templates."nubia_nx669j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 6"
device = "REDMAGIC 6"
product = "NX669J"
name = "REDMAGIC 6"
marketname = "RedMagic 6"
fingerprint = ""

[templates."nubia_nx669j_p"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 6 Pro"
device = "REDMAGIC 6 PRO"
product = "NX669J-P"
name = "REDMAGIC 6 PRO"
marketname = "RedMagic 6 Pro"
fingerprint = ""

[templates."nubia_nx666j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 6R"
device = "REDMAGIC 6R"
product = "NX666J"
name = "REDMAGIC 6R"
marketname = "RedMagic 6R"
fingerprint = ""

[templates."nubia_nx669j_s"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 6S Pro"
device = "REDMAGIC 6S PRO"
product = "NX669J-S"
name = "REDMAGIC 6S PRO"
marketname = "RedMagic 6S Pro"
fingerprint = ""

[templates."nubia_nx679j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 7"
device = "REDMAGIC 7"
product = "NX679J"
name = "REDMAGIC 7"
marketname = "RedMagic 7"
fingerprint = ""

[templates."nubia_nx709j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 7 Pro"
device = "REDMAGIC 7 PRO"
product = "NX709J"
name = "REDMAGIC 7 PRO"
marketname = "RedMagic 7 Pro"
fingerprint = ""

[templates."nubia_nx679s"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 7S"
device = "REDMAGIC 7S"
product = "NX679S"
name = "REDMAGIC 7S"
marketname = "RedMagic 7S"
fingerprint = ""

[templates."nubia_nx709s"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 7S Pro"
device = "REDMAGIC 7S PRO"
product = "NX709S"
name = "REDMAGIC 7S PRO"
marketname = "RedMagic 7S Pro"
fingerprint = ""

[templates."nubia_nx729j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 8 Pro+"
device = "REDMAGIC 8 PRO+"
product = "NX729J"
name = "REDMAGIC 8 PRO+"
marketname = "RedMagic 8 Pro+"
fingerprint = ""

[templates."nubia_nx729s"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 8S Pro+"
device = "REDMAGIC 8S PRO+"
product = "NX729S"
name = "REDMAGIC 8S PRO+"
marketname = "RedMagic 8S Pro+"
fingerprint = ""

[templates."nubia_nx769j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 9 Pro+"
device = "REDMAGIC 9 PRO+"
product = "NX769J"
name = "REDMAGIC 9 PRO+"
marketname = "RedMagic 9 Pro+"
fingerprint = ""

[templates."nubia_nx789j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 10 Pro+"
device = "REDMAGIC 10 PRO+"
product = "NX789J"
name = "REDMAGIC 10 PRO+"
marketname = "RedMagic 10 Pro+"
fingerprint = ""

[templates."nubia_nx779j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 10 Air"
device = "REDMAGIC 10 AIR"
product = "NX779J"
name = "REDMAGIC 10 AIR"
marketname = "RedMagic 10 Air"
fingerprint = ""

[templates."nubia_nx809j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 11 Pro+"
device = "REDMAGIC 11 PRO+"
product = "NX809J"
name = "REDMAGIC 11 PRO+"
marketname = "RedMagic 11 Pro+"
fingerprint = ""

[templates."nubia_nx799j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 11 Air"
device = "REDMAGIC 11 AIR"
product = "NX799J"
name = "REDMAGIC 11 AIR"
marketname = "RedMagic 11 Air"
fingerprint = ""

[templates."nubia_nx819j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic 12 Pro+"
device = "REDMAGIC 12 PRO+"
product = "NX819J"
name = "REDMAGIC 12 PRO+"
marketname = "RedMagic 12 Pro+"
fingerprint = ""

[templates."nubia_np01j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic Pad 5G"
device = "REDMAGIC PAD 5G"
product = "NP01J"
name = "REDMAGIC PAD 5G"
marketname = "RedMagic Pad 5G"
fingerprint = ""

[templates."nubia_np03j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic Pad Pro"
device = "REDMAGIC PAD PRO"
product = "NP03J"
name = "REDMAGIC PAD PRO"
marketname = "RedMagic Pad Pro"
fingerprint = ""

[templates."nubia_np05j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic Pad 3 Pro"
device = "REDMAGIC PAD 3 PRO"
product = "NP05J"
name = "REDMAGIC PAD 3 PRO"
marketname = "RedMagic Pad 3 Pro"
fingerprint = ""

[templates."nubia_np06j"]
manufacturer = "Nubia"
brand = "REDMAGIC"
model = "RedMagic Pad 5 Pro"
device = "REDMAGIC PAD 5 PRO"
product = "NP06J"
name = "REDMAGIC PAD 5 PRO"
marketname = "RedMagic Pad 5 Pro"
fingerprint = ""

[templates."zte_zte_a2017"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 7"
device = "ZTE A2017"
product = "ZTE A2017"
marketname = "ZTE 天机 7"
fingerprint = ""

[templates."zte_zte_a2018"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 7S"
device = "ZTE A2018"
product = "ZTE A2018"
marketname = "ZTE 天机 7S"
fingerprint = ""

[templates."zte_zte_c2017"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 7 MAX"
device = "ZTE C2017"
product = "ZTE C2017"
marketname = "ZTE 天机 7 MAX"
fingerprint = ""

[templates."zte_z999"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 Axon M"
device = "Z999"
product = "Z999"
marketname = "ZTE 天机 Axon M"
fingerprint = ""

[templates."zte_zte_a2019_pro"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 Axon 9 Pro"
device = "ZTE A2019 Pro"
product = "ZTE A2019 Pro"
marketname = "ZTE 天机 Axon 9 Pro"
fingerprint = ""

[templates."zte_zte_a2020_pro"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 Axon 10 Pro 4G"
device = "ZTE A2020 Pro"
product = "ZTE A2020 Pro"
marketname = "ZTE 天机 Axon 10 Pro 4G"
fingerprint = ""

[templates."zte_zte_a2020n2_pro"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 Axon 10 Pro 5G"
device = "ZTE A2020N2 Pro"
product = "ZTE A2020N2 Pro"
marketname = "ZTE 天机 Axon 10 Pro 5G"
fingerprint = ""

[templates."zte_zte_a2020_sp"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 Axon 10s Pro 5G"
device = "ZTE A2020 SP"
product = "ZTE A2020 SP"
marketname = "ZTE 天机 Axon 10s Pro 5G"
fingerprint = ""

[templates."zte_zte_9000n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 Axon 11 SE 5G"
device = "ZTE 9000N"
product = "ZTE 9000N"
marketname = "ZTE 天机 Axon 11 SE 5G"
fingerprint = ""

[templates."zte_zte_a2021"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 Axon 11 5G"
device = "ZTE A2021"
product = "ZTE A2021"
marketname = "ZTE 天机 Axon 11 5G"
fingerprint = ""

[templates."zte_zte_a2021h"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 Axon 11 5G 行业版"
device = "ZTE A2021H"
product = "ZTE A2021H"
marketname = "ZTE 天机 Axon 11 5G 行业版"
fingerprint = ""

[templates."zte_zte_a2121"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 Axon 20 5G"
device = "ZTE A2121"
product = "ZTE A2121"
marketname = "ZTE 天机 Axon 20 5G"
fingerprint = ""

[templates."zte_zte_a2322"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Axon 30 5G"
device = "ZTE A2322"
product = "ZTE A2322"
marketname = "ZTE Axon 30 5G"
fingerprint = ""

[templates."zte_zte_a2022"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Axon 30 Pro 5G"
device = "ZTE A2022"
product = "ZTE A2022"
marketname = "ZTE Axon 30 Pro 5G"
fingerprint = ""

[templates."zte_zte_a2022p"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Axon 30 Ultra 5G"
device = "ZTE A2022P"
product = "ZTE A2022P"
marketname = "ZTE Axon 30 Ultra 5G"
fingerprint = ""

[templates."zte_zte_a2122h"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 A31 5G"
device = "ZTE A2122H"
product = "ZTE A2122H"
marketname = "ZTE 天机 A31 5G"
fingerprint = ""

[templates."zte_zte_a2022h"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 A31 Pro 5G"
device = "ZTE A2022H"
product = "ZTE A2022H"
marketname = "ZTE 天机 A31 Pro 5G"
fingerprint = ""

[templates."zte_zte_a2023"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Axon 40 Pro"
device = "ZTE A2023"
product = "ZTE A2023"
marketname = "ZTE Axon 40 Pro"
fingerprint = ""

[templates."zte_zte_a2023p"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Axon 40 Ultra"
device = "ZTE A2023P"
product = "ZTE A2023P"
marketname = "ZTE Axon 40 Ultra"
fingerprint = ""

[templates."zte_zte_a2024h"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Axon 50"
device = "ZTE A2024H"
product = "ZTE A2024H"
marketname = "ZTE Axon 50"
fingerprint = ""

[templates."zte_zte_a2025hl"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Axon 60 Ultra"
device = "ZTE A2025HL"
product = "ZTE A2025HL"
marketname = "ZTE Axon 60 Ultra"
fingerprint = ""

[templates."zte_zte_a2025h"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Axon 60 Ultra 天通版"
device = "ZTE A2025H"
product = "ZTE A2025H"
marketname = "ZTE Axon 60 Ultra 天通版"
fingerprint = ""

[templates."zte_zte_a2023bh"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 A41"
device = "ZTE A2023BH"
product = "ZTE A2023BH"
marketname = "ZTE 天机 A41"
fingerprint = ""

[templates."zte_zte_a2023h"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 天机 A41 Ultra"
device = "ZTE A2023H"
product = "ZTE A2023H"
marketname = "ZTE 天机 A41 Ultra"
fingerprint = ""

[templates."zte_zte_9030n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE S30 5G"
device = "ZTE 9030N"
product = "ZTE 9030N"
marketname = "ZTE S30 5G"
fingerprint = ""

[templates."zte_zte_8030n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE S30 SE 5G"
device = "ZTE 8030N"
product = "ZTE 8030N"
marketname = "ZTE S30 SE 5G"
fingerprint = ""

[templates."zte_zte_bv0730"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Blade A2 Plus"
device = "ZTE BV0730"
product = "ZTE BV0730"
marketname = "ZTE Blade A2 Plus"
fingerprint = ""

[templates."zte_zte_v0721"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Blade A2S"
device = "ZTE V0721"
product = "ZTE V0721"
marketname = "ZTE Blade A2S"
fingerprint = ""

[templates."zte_zte_a0616"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Blade A3"
device = "ZTE A0616"
product = "ZTE A0616"
marketname = "ZTE Blade A3"
fingerprint = ""

[templates."zte_zte_a0722"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Blade A4"
device = "ZTE A0722"
product = "ZTE A0722"
marketname = "ZTE Blade A4"
fingerprint = ""

[templates."zte_zte_a7000"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Blade A7"
device = "ZTE A7000"
product = "ZTE A7000"
marketname = "ZTE Blade A7"
fingerprint = ""

[templates."zte_zte_a7010"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Blade A7S"
device = "ZTE A7010"
product = "ZTE A7010"
marketname = "ZTE Blade A7S"
fingerprint = ""

[templates."zte_zte_bv0800"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Blade V8"
device = "ZTE BV0800"
product = "ZTE BV0800"
marketname = "ZTE Blade V8"
fingerprint = ""

[templates."zte_zte_bv0850"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Blade V8 mini"
device = "ZTE BV0850"
product = "ZTE BV0850"
marketname = "ZTE Blade V8 mini"
fingerprint = ""

[templates."zte_zte_v0900"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Blade V9"
device = "ZTE V0900"
product = "ZTE V0900"
marketname = "ZTE Blade V9"
fingerprint = ""

[templates."zte_zte_v1000"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Blade V10"
device = "ZTE V1000"
product = "ZTE V1000"
marketname = "ZTE Blade V10"
fingerprint = ""

[templates."zte_zte_v1050"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Blade 20 Smart"
device = "ZTE V1050"
product = "ZTE V1050"
marketname = "ZTE Blade 20 Smart"
fingerprint = ""

[templates."zte_zte_8012n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Blade 20 5G"
device = "ZTE 8012N"
product = "ZTE 8012N"
marketname = "ZTE Blade 20 5G"
fingerprint = ""

[templates."zte_zte_8010"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Blade V2020 Smart"
device = "ZTE 8010"
product = "ZTE 8010"
marketname = "ZTE Blade V2020 Smart"
fingerprint = ""

[templates."zte_zte_8031"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE ZTE V2022"
device = "ZTE 8031"
product = "ZTE 8031"
marketname = "ZTE ZTE V2022"
fingerprint = ""

[templates."zte_zte_bv0701"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 小鲜 4"
device = "ZTE BV0701"
product = "ZTE BV0701"
marketname = "ZTE 小鲜 4"
fingerprint = ""

[templates."zte_zte_v0840"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 小鲜 5"
device = "ZTE V0840"
product = "ZTE V0840"
marketname = "ZTE 小鲜 5"
fingerprint = ""

[templates."zte_zte_v0920"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 小鲜 5S"
device = "ZTE V0920"
product = "ZTE V0920"
marketname = "ZTE 小鲜 5S"
fingerprint = ""

[templates."zte_zte_a0620"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 远航 5 plus"
device = "ZTE A0620"
product = "ZTE A0620"
marketname = "ZTE 远航 5 plus"
fingerprint = ""

[templates."zte_zte_7530n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 远航 10"
device = "ZTE 7530N"
product = "ZTE 7530N"
marketname = "ZTE 远航 10"
fingerprint = ""

[templates."zte_zte_9040n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 远航 20 Pro"
device = "ZTE 9040N"
product = "ZTE 9040N"
marketname = "ZTE 远航 20 Pro"
fingerprint = ""

[templates."zte_zte_7532n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 远航 30"
device = "ZTE 7532N"
product = "ZTE 7532N"
marketname = "ZTE 远航 30"
fingerprint = ""

[templates."zte_zte_7531n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 远航 30S"
device = "ZTE 7531N"
product = "ZTE 7531N"
marketname = "ZTE 远航 30S"
fingerprint = ""

[templates."zte_zte_7534n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 远航 30 畅行版"
device = "ZTE 7534N"
product = "ZTE 7534N"
marketname = "ZTE 远航 30 畅行版"
fingerprint = ""

[templates."zte_zte_8040n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 远航 30 Pro"
device = "ZTE 8040N"
product = "ZTE 8040N"
marketname = "ZTE 远航 30 Pro"
fingerprint = ""

[templates."zte_zte_9041n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 远航 30 Pro+"
device = "ZTE 9041N"
product = "ZTE 9041N"
marketname = "ZTE 远航 30 Pro+"
fingerprint = ""

[templates."zte_zte_1010l"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 畅行 30"
device = "ZTE 1010L"
product = "ZTE 1010L"
marketname = "ZTE 畅行 30"
fingerprint = ""

[templates."zte_zte_7542n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 远航 40"
device = "ZTE 7542N"
product = "ZTE 7542N"
marketname = "ZTE 远航 40"
fingerprint = ""

[templates."zte_zte_9042n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 远航 40 Pro+"
device = "ZTE 9042N"
product = "ZTE 9042N"
marketname = "ZTE 远航 40 Pro+"
fingerprint = ""

[templates."zte_zte_7541n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 远航 41"
device = "ZTE 7541N"
product = "ZTE 7541N"
marketname = "ZTE 远航 41"
fingerprint = ""

[templates."zte_zte_7546n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 远航 41S"
device = "ZTE 7546N"
product = "ZTE 7546N"
marketname = "ZTE 远航 41S"
fingerprint = ""

[templates."zte_zte_1021l"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 畅行 40 SE"
device = "ZTE 1021L"
product = "ZTE 1021L"
marketname = "ZTE 畅行 40 SE"
fingerprint = ""

[templates."zte_zte_7543n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 小鲜 50"
device = "ZTE 7543N"
product = "ZTE 7543N"
marketname = "ZTE 小鲜 50"
fingerprint = ""

[templates."zte_zte_7551n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 小鲜 60"
device = "ZTE 7551N"
product = "ZTE 7551N"
marketname = "ZTE 小鲜 60"
fingerprint = ""

[templates."zte_zte_7552n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 畅行 60"
device = "ZTE 7552N"
product = "ZTE 7552N"
marketname = "ZTE 畅行 60"
fingerprint = ""

[templates."zte_zte_7553n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 畅行 60 Plus"
device = "ZTE 7553N"
product = "ZTE 7553N"
marketname = "ZTE 畅行 60 Plus"
fingerprint = ""

[templates."zte_zte_7661n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 畅行 60 Ultra"
device = "ZTE 7661N"
product = "ZTE 7661N"
marketname = "ZTE 畅行 60 Ultra"
fingerprint = ""

[templates."zte_zte_7561n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 远航 60 Plus"
device = "ZTE 7561N"
product = "ZTE 7561N"
marketname = "ZTE 远航 60 Plus"
fingerprint = ""

[templates."zte_zte_7533n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 远航 3D"
device = "ZTE 7533N"
product = "ZTE 7533N"
marketname = "ZTE 远航 3D"
fingerprint = ""

[templates."zte_zte_7671n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 畅行 70 Plus"
device = "ZTE 7671N"
product = "ZTE 7671N"
marketname = "ZTE 畅行 70 Plus"
fingerprint = ""

[templates."zte_zte_7672n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 小鲜 70 Plus"
device = "ZTE 7672N"
product = "ZTE 7672N"
marketname = "ZTE 小鲜 70 Plus"
fingerprint = ""

[templates."zte_zte_9043n"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE V70 Pro"
device = "ZTE 9043N"
product = "ZTE 9043N"
marketname = "ZTE V70 Pro"
fingerprint = ""

[templates."zte_zte_pa01"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE Axon Pad"
device = "ZTE PA01"
product = "ZTE PA01"
marketname = "ZTE Axon Pad"
fingerprint = ""

[templates."zte_w200ds"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 云电脑 逍遥系列"
device = "W200DS"
product = "W200DS"
marketname = "ZTE 云电脑 逍遥系列"
fingerprint = ""

[templates."zte_w200ds_pro"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 云电脑 逍遥系列 Pro"
device = "W200DS Pro"
product = "W200DS Pro"
marketname = "ZTE 云电脑 逍遥系列 Pro"
fingerprint = ""

[templates."zte_w210ds"]
manufacturer = "ZTE"
brand = "ZTE"
model = "ZTE 云电脑 逍遥 20"
device = "W210DS"
product = "W210DS"
marketname = "ZTE 云电脑 逍遥 20"
fingerprint = ""

[templates."sony_e2104"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia E4"
device = "Jasmine"
product = "Jasmine"
name = "Jasmine"
marketname = "Xperia E4"
fingerprint = ""

[templates."sony_e2115"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia E4 dual"
device = "Jasmine"
product = "Jasmine"
name = "Jasmine"
marketname = "Xperia E4 dual"
fingerprint = ""

[templates."sony_e2114"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia E4 dual Brazil"
device = "Jasmine"
product = "Jasmine"
name = "Jasmine"
marketname = "Xperia E4 dual Brazil"
fingerprint = ""

[templates."sony_e2303"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia M4 Aqua"
device = "Tulip"
product = "Tulip"
name = "Tulip"
marketname = "Xperia M4 Aqua"
fingerprint = ""

[templates."sony_e2312"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia M4 Aqua dual"
device = "Tulip"
product = "Tulip"
name = "Tulip"
marketname = "Xperia M4 Aqua dual"
fingerprint = ""

[templates."sony_e5603"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia M5"
device = "Holly"
product = "Holly"
name = "Holly"
marketname = "Xperia M5"
fingerprint = ""

[templates."sony_e5633"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia M5 dual"
device = "Holly"
product = "Holly"
name = "Holly"
marketname = "Xperia M5 dual"
fingerprint = ""

[templates."sony_e5643"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia M5 dual Brazil"
device = "Holly"
product = "Holly"
name = "Holly"
marketname = "Xperia M5 dual Brazil"
fingerprint = ""

[templates."sony_e5303"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia C4"
device = "Cosmos"
product = "Cosmos"
name = "Cosmos"
marketname = "Xperia C4"
fingerprint = ""

[templates."sony_e5333"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia C4 dual"
device = "Cosmos"
product = "Cosmos"
name = "Cosmos"
marketname = "Xperia C4 dual"
fingerprint = ""

[templates."sony_e5343"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia C4 dual Brazil"
device = "Cosmos"
product = "Cosmos"
name = "Cosmos"
marketname = "Xperia C4 dual Brazil"
fingerprint = ""

[templates."sony_e5606"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia C5 Ultra"
device = "Lavender"
product = "Lavender"
name = "Lavender"
marketname = "Xperia C5 Ultra"
fingerprint = ""

[templates."sony_e5533"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia C5 Ultra dual"
device = "Lavender"
product = "Lavender"
name = "Lavender"
marketname = "Xperia C5 Ultra dual"
fingerprint = ""

[templates."sony_e6553"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Z3+"
device = "Ivy"
product = "Ivy"
name = "Ivy"
marketname = "Xperia Z3+"
fingerprint = ""

[templates."sony_e6533"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Z3+ dual"
device = "Ivy"
product = "Ivy"
name = "Ivy"
marketname = "Xperia Z3+ dual"
fingerprint = ""

[templates."sony_402so"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Z4 Japan"
device = "Ivy"
product = "Ivy"
name = "Ivy"
marketname = "Xperia Z4 Japan"
fingerprint = ""

[templates."sony_e6603"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Z5"
device = "Sumire"
product = "Sumire"
name = "Sumire"
marketname = "Xperia Z5"
fingerprint = ""

[templates."sony_e6633"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Z5 dual"
device = "Sumire"
product = "Sumire"
name = "Sumire"
marketname = "Xperia Z5 dual"
fingerprint = ""

[templates."sony_501so"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Z5 Japan"
device = "Sumire"
product = "Sumire"
name = "Sumire"
marketname = "Xperia Z5 Japan"
fingerprint = ""

[templates."sony_e5803"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Z5 Compact"
device = "Suzuran"
product = "Suzuran"
name = "Suzuran"
marketname = "Xperia Z5 Compact"
fingerprint = ""

[templates."sony_so_02h"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Z5 Compact Japan"
device = "Suzuran"
product = "Suzuran"
name = "Suzuran"
marketname = "Xperia Z5 Compact Japan"
fingerprint = ""

[templates."sony_e6853"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Z5 Premium"
device = "Satsuki"
product = "Satsuki"
name = "Satsuki"
marketname = "Xperia Z5 Premium"
fingerprint = ""

[templates."sony_e6833"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Z5 Premium dual"
device = "Satsuki"
product = "Satsuki"
name = "Satsuki"
marketname = "Xperia Z5 Premium dual"
fingerprint = ""

[templates."sony_so_03h"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Z5 Premium Japan"
device = "Satsuki"
product = "Satsuki"
name = "Satsuki"
marketname = "Xperia Z5 Premium Japan"
fingerprint = ""

[templates."sony_f3311"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia E5"
device = "Bassoon"
product = "Bassoon"
name = "Bassoon"
marketname = "Xperia E5"
fingerprint = ""

[templates."sony_f3111"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XA"
device = "Tuba"
product = "Tuba"
name = "Tuba"
marketname = "Xperia XA"
fingerprint = ""

[templates."sony_f3211"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XA Ultra"
device = "Tuba"
product = "Tuba"
name = "Tuba"
marketname = "Xperia XA Ultra"
fingerprint = ""

[templates."sony_f5121"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia X"
device = "Suzu"
product = "Suzu"
name = "Suzu"
marketname = "Xperia X"
fingerprint = ""

[templates."sony_f5321"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia X Compact"
device = "Kugo"
product = "Kugo"
name = "Kugo"
marketname = "Xperia X Compact"
fingerprint = ""

[templates."sony_so_02j"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia X Compact Japan"
device = "Kugo"
product = "Kugo"
name = "Kugo"
marketname = "Xperia X Compact Japan"
fingerprint = ""

[templates."sony_f8131"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia X Performance"
device = "Dora"
product = "Dora"
name = "Dora"
marketname = "Xperia X Performance"
fingerprint = ""

[templates."sony_502so"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia X Performance Japan"
device = "Dora"
product = "Dora"
name = "Dora"
marketname = "Xperia X Performance Japan"
fingerprint = ""

[templates."sony_f8331"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ"
device = "Kagura"
product = "Kagura"
name = "Kagura"
marketname = "Xperia XZ"
fingerprint = ""

[templates."sony_601so"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ Japan"
device = "Kagura"
product = "Kagura"
name = "Kagura"
marketname = "Xperia XZ Japan"
fingerprint = ""

[templates."sony_g3311"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia L1"
device = "Pine"
product = "Pine"
name = "Pine"
marketname = "Xperia L1"
fingerprint = ""

[templates."sony_g3121"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XA1"
device = "Hinoki"
product = "Hinoki"
name = "Hinoki"
marketname = "Xperia XA1"
fingerprint = ""

[templates."sony_g3221"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XA1 Ultra"
device = "Redwood"
product = "Redwood"
name = "Redwood"
marketname = "Xperia XA1 Ultra"
fingerprint = ""

[templates."sony_g3421"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XA1 Plus"
device = "Teak"
product = "Teak"
name = "Teak"
marketname = "Xperia XA1 Plus"
fingerprint = ""

[templates."sony_g8231"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZs"
device = "Keyaki"
product = "Keyaki"
name = "Keyaki"
marketname = "Xperia XZs"
fingerprint = ""

[templates."sony_602so"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZs Japan"
device = "Keyaki"
product = "Keyaki"
name = "Keyaki"
marketname = "Xperia XZs Japan"
fingerprint = ""

[templates."sony_g8141"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ Premium"
device = "Maple"
product = "Maple"
name = "Maple"
marketname = "Xperia XZ Premium"
fingerprint = ""

[templates."sony_g8188"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ Premium Japan"
device = "Maple"
product = "Maple"
name = "Maple"
marketname = "Xperia XZ Premium Japan"
fingerprint = ""

[templates."sony_g8341"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ1"
device = "Poplar"
product = "Poplar"
name = "Poplar"
marketname = "Xperia XZ1"
fingerprint = ""

[templates."sony_g8343"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ1 Canada"
device = "Poplar"
product = "Poplar"
name = "Poplar"
marketname = "Xperia XZ1 Canada"
fingerprint = ""

[templates."sony_701so"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ1 Japan"
device = "Poplar"
product = "Poplar"
name = "Poplar"
marketname = "Xperia XZ1 Japan"
fingerprint = ""

[templates."sony_g8441"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ1 Compact"
device = "Lilac"
product = "Lilac"
name = "Lilac"
marketname = "Xperia XZ1 Compact"
fingerprint = ""

[templates."sony_so_02k"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ1 Compact Japan"
device = "Lilac"
product = "Lilac"
name = "Lilac"
marketname = "Xperia XZ1 Compact Japan"
fingerprint = ""

[templates."sony_h3311"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia L2"
device = "Ranger"
product = "Ranger"
name = "Ranger"
marketname = "Xperia L2"
fingerprint = ""

[templates."sony_h3113"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XA2"
device = "Pioneer"
product = "Pioneer"
name = "Pioneer"
marketname = "Xperia XA2"
fingerprint = ""

[templates."sony_h3213"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XA2 Ultra"
device = "Discovery"
product = "Discovery"
name = "Discovery"
marketname = "Xperia XA2 Ultra"
fingerprint = ""

[templates."sony_h3413"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XA2 Plus"
device = "Voyager"
product = "Voyager"
name = "Voyager"
marketname = "Xperia XA2 Plus"
fingerprint = ""

[templates."sony_h8216"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ2"
device = "Akari"
product = "Akari"
name = "Akari"
marketname = "Xperia XZ2"
fingerprint = ""

[templates."sony_h8276"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ2 Canada"
device = "Akari"
product = "Akari"
name = "Akari"
marketname = "Xperia XZ2 Canada"
fingerprint = ""

[templates."sony_702so"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ2 Japan"
device = "Akari"
product = "Akari"
name = "Akari"
marketname = "Xperia XZ2 Japan"
fingerprint = ""

[templates."sony_h8314"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ2 Compact"
device = "Apollo"
product = "Apollo"
name = "Apollo"
marketname = "Xperia XZ2 Compact"
fingerprint = ""

[templates."sony_so_05k"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ2 Compact Japan"
device = "Apollo"
product = "Apollo"
name = "Apollo"
marketname = "Xperia XZ2 Compact Japan"
fingerprint = ""

[templates."sony_h8116"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ2 Premium"
device = "Aurora"
product = "Aurora"
name = "Aurora"
marketname = "Xperia XZ2 Premium"
fingerprint = ""

[templates."sony_so_04k"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ2 Premium Japan"
device = "Aurora"
product = "Aurora"
name = "Aurora"
marketname = "Xperia XZ2 Premium Japan"
fingerprint = ""

[templates."sony_h8416"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ3"
device = "Akatsuki"
product = "Akatsuki"
name = "Akatsuki"
marketname = "Xperia XZ3"
fingerprint = ""

[templates."sony_801so"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia XZ3 Japan"
device = "Akatsuki"
product = "Akatsuki"
name = "Akatsuki"
marketname = "Xperia XZ3 Japan"
fingerprint = ""

[templates."sony_i3312"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia L3"
device = "Dragon"
product = "Dragon"
name = "Dragon"
marketname = "Xperia L3"
fingerprint = ""

[templates."sony_j8110"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1"
device = "Griffin"
product = "Griffin"
name = "Griffin"
marketname = "Xperia 1"
fingerprint = ""

[templates."sony_j8170"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 US"
device = "Griffin"
product = "Griffin"
name = "Griffin"
marketname = "Xperia 1 US"
fingerprint = ""

[templates."sony_j9180"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 Professional Editon China"
device = "Griffin"
product = "Griffin"
name = "Griffin"
marketname = "Xperia 1 Professional Editon China"
fingerprint = ""

[templates."sony_j9150"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 Japan"
device = "Griffin"
product = "Griffin"
name = "Griffin"
marketname = "Xperia 1 Japan"
fingerprint = ""

[templates."sony_j8210"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5"
device = "Bahamut"
product = "Bahamut"
name = "Bahamut"
marketname = "Xperia 5"
fingerprint = ""

[templates."sony_j8270"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 US"
device = "Bahamut"
product = "Bahamut"
name = "Bahamut"
marketname = "Xperia 5 US"
fingerprint = ""

[templates."sony_j9260"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 Japan"
device = "Bahamut"
product = "Bahamut"
name = "Bahamut"
marketname = "Xperia 5 Japan"
fingerprint = ""

[templates."sony_j3273"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 8 Lite Japan"
device = "Himiko"
product = "Himiko"
name = "Himiko"
marketname = "Xperia 8 Lite Japan"
fingerprint = ""

[templates."sony_902so"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 8 Japan"
device = "Himiko"
product = "Himiko"
name = "Himiko"
marketname = "Xperia 8 Japan"
fingerprint = ""

[templates."sony_i3113"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10"
device = "Kirin"
product = "Kirin"
name = "Kirin"
marketname = "Xperia 10"
fingerprint = ""

[templates."sony_i3213"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 Plus"
device = "Mermaid"
product = "Mermaid"
name = "Mermaid"
marketname = "Xperia 10 Plus"
fingerprint = ""

[templates."sony_j3173"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Ace Japan"
device = "Houou"
product = "Houou"
name = "Houou"
marketname = "Xperia Ace Japan"
fingerprint = ""

[templates."sony_xq_aq52"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia PRO Global"
device = "PDX-204"
product = "PDX-204"
name = "PDX-204"
marketname = "Xperia PRO Global"
fingerprint = ""

[templates."sony_xq_aq62"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia PRO US"
device = "PDX-204"
product = "PDX-204"
name = "PDX-204"
marketname = "Xperia PRO US"
fingerprint = ""

[templates."sony_xq_at42"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 II Japan"
device = "PDX-203"
product = "PDX-203"
name = "PDX-203"
marketname = "Xperia 1 II Japan"
fingerprint = ""

[templates."sony_xq_at51"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 II Global"
device = "PDX-203"
product = "PDX-203"
name = "PDX-203"
marketname = "Xperia 1 II Global"
fingerprint = ""

[templates."sony_xq_at72"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 II China"
device = "PDX-203"
product = "PDX-203"
name = "PDX-203"
marketname = "Xperia 1 II China"
fingerprint = ""

[templates."sony_xq_as42"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 II Japan"
device = "PDX-206"
product = "PDX-206"
name = "PDX-206"
marketname = "Xperia 5 II Japan"
fingerprint = ""

[templates."sony_xq_as52"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 II Global"
device = "PDX-206"
product = "PDX-206"
name = "PDX-206"
marketname = "Xperia 5 II Global"
fingerprint = ""

[templates."sony_xq_as62"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 II US"
device = "PDX-206"
product = "PDX-206"
name = "PDX-206"
marketname = "Xperia 5 II US"
fingerprint = ""

[templates."sony_xq_as72"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 II China"
device = "PDX-206"
product = "PDX-206"
name = "PDX-206"
marketname = "Xperia 5 II China"
fingerprint = ""

[templates."sony_xq_au42"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 II Japan"
device = "PDX-201"
product = "PDX-201"
name = "PDX-201"
marketname = "Xperia 10 II Japan"
fingerprint = ""

[templates."sony_xq_au51"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 II Global"
device = "PDX-201"
product = "PDX-201"
name = "PDX-201"
marketname = "Xperia 10 II Global"
fingerprint = ""

[templates."sony_xq_ad51"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia L4"
device = "PDX-202"
product = "PDX-202"
name = "PDX-202"
marketname = "Xperia L4"
fingerprint = ""

[templates."sony_xq_bc42"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 III Japan"
device = "PDX-215"
product = "PDX-215"
name = "PDX-215"
marketname = "Xperia 1 III Japan"
fingerprint = ""

[templates."sony_xq_bc52"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 III Global"
device = "PDX-215"
product = "PDX-215"
name = "PDX-215"
marketname = "Xperia 1 III Global"
fingerprint = ""

[templates."sony_xq_bc62"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 III US"
device = "PDX-215"
product = "PDX-215"
name = "PDX-215"
marketname = "Xperia 1 III US"
fingerprint = ""

[templates."sony_xq_bc72"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 III Asia Pacific"
device = "PDX-215"
product = "PDX-215"
name = "PDX-215"
marketname = "Xperia 1 III Asia Pacific"
fingerprint = ""

[templates."sony_xq_bq42"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 III Japan"
device = "PDX-214"
product = "PDX-214"
name = "PDX-214"
marketname = "Xperia 5 III Japan"
fingerprint = ""

[templates."sony_xq_bq52"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 III Global"
device = "PDX-214"
product = "PDX-214"
name = "PDX-214"
marketname = "Xperia 5 III Global"
fingerprint = ""

[templates."sony_xq_bq62"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 III US"
device = "PDX-214"
product = "PDX-214"
name = "PDX-214"
marketname = "Xperia 5 III US"
fingerprint = ""

[templates."sony_xq_bq72"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 III Asia Pacific"
device = "PDX-214"
product = "PDX-214"
name = "PDX-214"
marketname = "Xperia 5 III Asia Pacific"
fingerprint = ""

[templates."sony_xq_bt44"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 III Japan"
device = "PDX-213"
product = "PDX-213"
name = "PDX-213"
marketname = "Xperia 10 III Japan"
fingerprint = ""

[templates."sony_xq_bt52"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 III Global"
device = "PDX-213"
product = "PDX-213"
name = "PDX-213"
marketname = "Xperia 10 III Global"
fingerprint = ""

[templates."sony_xq_be42"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia PRO-I Japan"
device = "PDX-217"
product = "PDX-217"
name = "PDX-217"
marketname = "Xperia PRO-I Japan"
fingerprint = ""

[templates."sony_xq_be52"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia PRO-I Global"
device = "PDX-217"
product = "PDX-217"
name = "PDX-217"
marketname = "Xperia PRO-I Global"
fingerprint = ""

[templates."sony_xq_be62"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia PRO-I US"
device = "PDX-217"
product = "PDX-217"
name = "PDX-217"
marketname = "Xperia PRO-I US"
fingerprint = ""

[templates."sony_xq_be72"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia PRO-I Asia Pacific"
device = "PDX-217"
product = "PDX-217"
name = "PDX-217"
marketname = "Xperia PRO-I Asia Pacific"
fingerprint = ""

[templates."sony_so_41b"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Ace II Japan"
device = "PDX-212"
product = "PDX-212"
name = "PDX-212"
marketname = "Xperia Ace II Japan"
fingerprint = ""

[templates."sony_xq_ct44"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 IV Japan"
device = "PDX-223"
product = "PDX-223"
name = "PDX-223"
marketname = "Xperia 1 IV Japan"
fingerprint = ""

[templates."sony_xq_ct54"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 IV Global"
device = "PDX-223"
product = "PDX-223"
name = "PDX-223"
marketname = "Xperia 1 IV Global"
fingerprint = ""

[templates."sony_xq_ct62"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 IV US"
device = "PDX-223"
product = "PDX-223"
name = "PDX-223"
marketname = "Xperia 1 IV US"
fingerprint = ""

[templates."sony_xq_ct72"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 IV Asia Pacific"
device = "PDX-223"
product = "PDX-223"
name = "PDX-223"
marketname = "Xperia 1 IV Asia Pacific"
fingerprint = ""

[templates."sony_xq_cq44"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 IV Japan"
device = "PDX-224"
product = "PDX-224"
name = "PDX-224"
marketname = "Xperia 5 IV Japan"
fingerprint = ""

[templates."sony_xq_cq54"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 IV Global"
device = "PDX-224"
product = "PDX-224"
name = "PDX-224"
marketname = "Xperia 5 IV Global"
fingerprint = ""

[templates."sony_xq_cq62"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 IV US"
device = "PDX-224"
product = "PDX-224"
name = "PDX-224"
marketname = "Xperia 5 IV US"
fingerprint = ""

[templates."sony_xq_cq72"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 IV Asia Pacific"
device = "PDX-224"
product = "PDX-224"
name = "PDX-224"
marketname = "Xperia 5 IV Asia Pacific"
fingerprint = ""

[templates."sony_xq_cc44"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 IV Japan"
device = "PDX-225"
product = "PDX-225"
name = "PDX-225"
marketname = "Xperia 10 IV Japan"
fingerprint = ""

[templates."sony_xq_cc54"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 IV Global"
device = "PDX-225"
product = "PDX-225"
name = "PDX-225"
marketname = "Xperia 10 IV Global"
fingerprint = ""

[templates."sony_xq_cc72"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 IV Asia Pacific"
device = "PDX-225"
product = "PDX-225"
name = "PDX-225"
marketname = "Xperia 10 IV Asia Pacific"
fingerprint = ""

[templates."sony_a203so"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Ace III Japan"
device = "PDX-226"
product = "PDX-226"
name = "PDX-226"
marketname = "Xperia Ace III Japan"
fingerprint = ""

[templates."sony_xq_dq44"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 V Japan"
device = "PDX-234"
product = "PDX-234"
name = "PDX-234"
marketname = "Xperia 1 V Japan"
fingerprint = ""

[templates."sony_xq_dq54"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 V Global"
device = "PDX-234"
product = "PDX-234"
name = "PDX-234"
marketname = "Xperia 1 V Global"
fingerprint = ""

[templates."sony_xq_dq62"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 V US"
device = "PDX-234"
product = "PDX-234"
name = "PDX-234"
marketname = "Xperia 1 V US"
fingerprint = ""

[templates."sony_xq_dq72"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 V Asia Pacific"
device = "PDX-234"
product = "PDX-234"
name = "PDX-234"
marketname = "Xperia 1 V Asia Pacific"
fingerprint = ""

[templates."sony_xq_de44"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 V Japan"
device = "PDX-237"
product = "PDX-237"
name = "PDX-237"
marketname = "Xperia 5 V Japan"
fingerprint = ""

[templates."sony_xq_de54"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 V Global"
device = "PDX-237"
product = "PDX-237"
name = "PDX-237"
marketname = "Xperia 5 V Global"
fingerprint = ""

[templates."sony_xq_de72"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 5 V Asia Pacific"
device = "PDX-237"
product = "PDX-237"
name = "PDX-237"
marketname = "Xperia 5 V Asia Pacific"
fingerprint = ""

[templates."sony_xq_dc44"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 V Japan"
device = "PDX-235"
product = "PDX-235"
name = "PDX-235"
marketname = "Xperia 10 V Japan"
fingerprint = ""

[templates."sony_xq_dc54"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 V Global"
device = "PDX-235"
product = "PDX-235"
name = "PDX-235"
marketname = "Xperia 10 V Global"
fingerprint = ""

[templates."sony_xq_dc72"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 V Asia Pacific"
device = "PDX-235"
product = "PDX-235"
name = "PDX-235"
marketname = "Xperia 10 V Asia Pacific"
fingerprint = ""

[templates."sony_xq_ec44"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 VI Japan"
device = "PDX-245"
product = "PDX-245"
name = "PDX-245"
marketname = "Xperia 1 VI Japan"
fingerprint = ""

[templates."sony_xq_ec54"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 VI Global"
device = "PDX-245"
product = "PDX-245"
name = "PDX-245"
marketname = "Xperia 1 VI Global"
fingerprint = ""

[templates."sony_xq_ec72"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 VI Asia Pacific"
device = "PDX-245"
product = "PDX-245"
name = "PDX-245"
marketname = "Xperia 1 VI Asia Pacific"
fingerprint = ""

[templates."sony_xq_es44"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 VI Japan"
device = "PDX-246"
product = "PDX-246"
name = "PDX-246"
marketname = "Xperia 10 VI Japan"
fingerprint = ""

[templates."sony_xq_es54"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 VI Global"
device = "PDX-246"
product = "PDX-246"
name = "PDX-246"
marketname = "Xperia 10 VI Global"
fingerprint = ""

[templates."sony_xq_es72"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 VI Asia Pacific"
device = "PDX-246"
product = "PDX-246"
name = "PDX-246"
marketname = "Xperia 10 VI Asia Pacific"
fingerprint = ""

[templates."sony_xq_fs44"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 VII Japan"
device = "PDX-256"
product = "PDX-256"
name = "PDX-256"
marketname = "Xperia 1 VII Japan"
fingerprint = ""

[templates."sony_xq_fs54"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 VII Global"
device = "PDX-256"
product = "PDX-256"
name = "PDX-256"
marketname = "Xperia 1 VII Global"
fingerprint = ""

[templates."sony_xq_fs72"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 VII Asia Pacific"
device = "PDX-256"
product = "PDX-256"
name = "PDX-256"
marketname = "Xperia 1 VII Asia Pacific"
fingerprint = ""

[templates."sony_xq_fe44"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 VII Japan"
device = "PDX-257"
product = "PDX-257"
name = "PDX-257"
marketname = "Xperia 10 VII Japan"
fingerprint = ""

[templates."sony_xq_fe54"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 VII Global"
device = "PDX-257"
product = "PDX-257"
name = "PDX-257"
marketname = "Xperia 10 VII Global"
fingerprint = ""

[templates."sony_xq_fe72"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 VII Asia Pacific"
device = "PDX-257"
product = "PDX-257"
name = "PDX-257"
marketname = "Xperia 10 VII Asia Pacific"
fingerprint = ""

[templates."sony_xq_ge44"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 VIII Japan"
device = "PDX-267"
product = "PDX-267"
name = "PDX-267"
marketname = "Xperia 1 VIII Japan"
fingerprint = ""

[templates."sony_xq_ge54"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 VIII Global"
device = "PDX-267"
product = "PDX-267"
name = "PDX-267"
marketname = "Xperia 1 VIII Global"
fingerprint = ""

[templates."sony_xq_ge74"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 1 VIII Asia Pacific"
device = "PDX-267"
product = "PDX-267"
name = "PDX-267"
marketname = "Xperia 1 VIII Asia Pacific"
fingerprint = ""

[templates."sony_xq_gh44"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 VIII Japan"
device = "PDX-268"
product = "PDX-268"
name = "PDX-268"
marketname = "Xperia 10 VIII Japan"
fingerprint = ""

[templates."sony_xq_gh54"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 VIII Global"
device = "PDX-268"
product = "PDX-268"
name = "PDX-268"
marketname = "Xperia 10 VIII Global"
fingerprint = ""

[templates."sony_xq_gh74"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia 10 VIII Asia Pacific"
device = "PDX-268"
product = "PDX-268"
name = "PDX-268"
marketname = "Xperia 10 VIII Asia Pacific"
fingerprint = ""

[templates."sony_sgp712"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Z4 Tablet"
device = "Karin"
product = "Karin"
name = "Karin"
marketname = "Xperia Z4 Tablet"
fingerprint = ""

[templates."sony_so_05g"]
manufacturer = "Sony"
brand = "Sony"
model = "Xperia Z4 Tablet LTE Japan"
device = "Karin"
product = "Karin"
name = "Karin"
marketname = "Xperia Z4 Tablet LTE Japan"
fingerprint = ""

[templates."nothing_a063"]
manufacturer = "Nothing"
brand = "Nothing"
model = "Nothing Phone"
device = "Spacewar"
product = "Spacewar"
name = "Spacewar"
marketname = "Nothing Phone"
fingerprint = ""

[templates."nothing_a065"]
manufacturer = "Nothing"
brand = "Nothing"
model = "Nothing Phone Global"
device = "Pong"
product = "Pong"
name = "Pong"
marketname = "Nothing Phone Global"
fingerprint = ""

[templates."nothing_ain065"]
manufacturer = "Nothing"
brand = "Nothing"
model = "Nothing Phone India"
device = "Pong"
product = "Pong"
name = "Pong"
marketname = "Nothing Phone India"
fingerprint = ""

[templates."nothing_a142p"]
manufacturer = "Nothing"
brand = "Nothing"
model = "Nothing Phone Plus"
device = "PacmanPro"
product = "PacmanPro"
name = "PacmanPro"
marketname = "Nothing Phone Plus"
fingerprint = ""

[templates."nothing_a059p"]
manufacturer = "Nothing"
brand = "Nothing"
model = "Nothing Phone Pro"
device = "Asteroids"
product = "Asteroids"
name = "Asteroids"
marketname = "Nothing Phone Pro"
fingerprint = ""

[templates."nothing_a001t"]
manufacturer = "Nothing"
brand = "Nothing"
model = "Nothing Phone Lite"
device = "Galaxian"
product = "Galaxian"
name = "Galaxian"
marketname = "Nothing Phone Lite"
fingerprint = ""

[templates."nothing_a015"]
manufacturer = "Nothing"
brand = "Nothing"
model = "Nothing CMF Phone 1"
device = "Tetris"
product = "Tetris"
name = "Tetris"
marketname = "Nothing CMF Phone 1"
fingerprint = ""

[templates."nothing_a001"]
manufacturer = "Nothing"
brand = "Nothing"
model = "Nothing CMF Phone 2 Pro"
device = "Galaga"
product = "Galaga"
name = "Galaga"
marketname = "Nothing CMF Phone 2 Pro"
fingerprint = ""

[templates."blackshark_skr_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "BlackShark 游戏版"
device = "shark"
product = "shark"
name = "shark"
marketname = "BlackShark 游戏版"
fingerprint = ""

[templates."blackshark_awm_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "BlackShark 游戏版 Helo"
device = "bullhead"
product = "bullhead"
name = "bullhead"
marketname = "BlackShark 游戏版 Helo"
fingerprint = ""

[templates."blackshark_skw_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "BlackShark 游戏版 2"
device = "skywalker"
product = "skywalker"
name = "skywalker"
marketname = "BlackShark 游戏版 2"
fingerprint = ""

[templates."blackshark_dlt_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "BlackShark 游戏版 2 Pro"
device = "darklighter"
product = "darklighter"
name = "darklighter"
marketname = "BlackShark 游戏版 2 Pro"
fingerprint = ""

[templates."blackshark_shark_kle_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "BlackShark 腾讯黑鲨游戏手机 3"
device = "klein"
product = "klein"
name = "klein"
marketname = "BlackShark 腾讯黑鲨游戏手机 3"
fingerprint = ""

[templates."blackshark_shark_kle_h0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "BlackShark 游戏版 3"
device = "klein"
product = "klein"
name = "klein"
marketname = "BlackShark 游戏版 3"
fingerprint = ""

[templates."blackshark_shark_mbu_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "BlackShark 腾讯黑鲨游戏手机 3 Pro"
device = "mobius"
product = "mobius"
name = "mobius"
marketname = "BlackShark 腾讯黑鲨游戏手机 3 Pro"
fingerprint = ""

[templates."blackshark_shark_mbu_h0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "BlackShark 游戏版 3 Pro"
device = "mobius"
product = "mobius"
name = "mobius"
marketname = "BlackShark 游戏版 3 Pro"
fingerprint = ""

[templates."blackshark_shark_prs_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "BlackShark 4"
device = "penrose"
product = "penrose"
name = "penrose"
marketname = "BlackShark 4"
fingerprint = ""

[templates."blackshark_shark_ksr_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "BlackShark 4 Pro"
device = "kaiser"
product = "kaiser"
name = "kaiser"
marketname = "BlackShark 4 Pro"
fingerprint = ""

[templates."blackshark_shark_par_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "BlackShark 5"
device = "patriot"
product = "patriot"
name = "patriot"
marketname = "BlackShark 5"
fingerprint = ""

[templates."blackshark_shark_ktus_a0"]
manufacturer = "BlackShark"
brand = "BlackShark"
model = "BlackShark 5 Pro"
device = "katyusha"
product = "katyusha"
name = "katyusha"
marketname = "BlackShark 5 Pro"
fingerprint = ""

[templates."asus_asus_z01qd"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ROG 游戏版"
device = "ZS600KL"
product = "ZS600KL"
name = "ZS600KL"
marketname = "ROG 游戏版"
fingerprint = ""

[templates."asus_asus_i001da"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ROG 游戏版 2"
device = "ZS660KL"
product = "ZS660KL"
name = "ZS660KL"
marketname = "ROG 游戏版 2"
fingerprint = ""

[templates."asus_asus_i003dd"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ROG 游戏版 3"
device = "ZS661KS"
product = "ZS661KS"
name = "ZS661KS"
marketname = "ROG 游戏版 3"
fingerprint = ""

[templates."asus_asus_i005da"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS 腾讯 ROG 游戏版 5"
device = "ZS676KS"
product = "ZS676KS"
name = "ZS676KS"
marketname = "ASUS 腾讯 ROG 游戏版 5"
fingerprint = ""

[templates."asus_asus_i005db"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS 腾讯 ROG 游戏版 5 Pro"
device = "ZS676KS"
product = "ZS676KS"
name = "ZS676KS"
marketname = "ASUS 腾讯 ROG 游戏版 5 Pro"
fingerprint = ""

[templates."asus_asus_ai2201_a"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS 腾讯 ROG 游戏版 6"
device = "AI2201"
product = "AI2201"
name = "AI2201"
marketname = "ASUS 腾讯 ROG 游戏版 6"
fingerprint = ""

[templates."asus_asus_ai2201_b"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS 腾讯 ROG 游戏版 6 Pro"
device = "AI2201"
product = "AI2201"
name = "AI2201"
marketname = "ASUS 腾讯 ROG 游戏版 6 Pro"
fingerprint = ""

[templates."asus_asus_ai2203_a"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS 腾讯 ROG 游戏版 6 天玑版"
device = "AI2203"
product = "AI2203"
name = "AI2203"
marketname = "ASUS 腾讯 ROG 游戏版 6 天玑版"
fingerprint = ""

[templates."asus_asus_ai2203_b"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS 腾讯 ROG 游戏版 6 天玑至尊版"
device = "AI2203"
product = "AI2203"
name = "AI2203"
marketname = "ASUS 腾讯 ROG 游戏版 6 天玑至尊版"
fingerprint = ""

[templates."asus_asus_ai2205_a"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS 腾讯 ROG 游戏版 7"
device = "AI2205"
product = "AI2205"
name = "AI2205"
marketname = "ASUS 腾讯 ROG 游戏版 7"
fingerprint = ""

[templates."asus_asus_ai2205_b"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS 腾讯 ROG 游戏版 7 Pro"
device = "AI2205"
product = "AI2205"
name = "AI2205"
marketname = "ASUS 腾讯 ROG 游戏版 7 Pro"
fingerprint = ""

[templates."asus_asus_ai2401_a"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ROG 游戏版 8"
device = "AI2401"
product = "AI2401"
name = "AI2401"
marketname = "ROG 游戏版 8"
fingerprint = ""

[templates."asus_asusai2501a"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ROG 游戏版 9"
device = "AI2501"
product = "AI2501"
name = "AI2501"
marketname = "ROG 游戏版 9"
fingerprint = ""

[templates."asus_asus_i007d"]
manufacturer = "ASUS"
brand = "ASUS"
model = "ASUS Smartphone for Snapdragon Insiders"
device = "ASUS_I007D"
product = "ASUS_I007D"
marketname = "ASUS Smartphone for Snapdragon Insiders"
fingerprint = ""

[templates."nokia_ta_1000"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia 6"
device = "plate"
product = "plate"
name = "plate"
marketname = "Nokia 6"
fingerprint = ""

[templates."nokia_ta_1041"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia 7"
device = "charm"
product = "charm"
name = "charm"
marketname = "Nokia 7"
fingerprint = ""

[templates."nokia_ta_1062"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia 7 Plus"
device = "onyx"
product = "onyx"
name = "onyx"
marketname = "Nokia 7 Plus"
fingerprint = ""

[templates."nokia_ta_1042"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia 8 Sirocco"
device = "avenger"
product = "avenger"
name = "avenger"
marketname = "Nokia 8 Sirocco"
fingerprint = ""

[templates."nokia_ta_1094"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia 9 PureView"
device = "beholder"
product = "beholder"
name = "beholder"
marketname = "Nokia 9 PureView"
fingerprint = ""

[templates."nokia_ta_1109"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia X5"
device = "panda"
product = "panda"
name = "panda"
marketname = "Nokia X5"
fingerprint = ""

[templates."nokia_ta_1099"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia X6"
device = "dragon"
product = "dragon"
name = "dragon"
marketname = "Nokia X6"
fingerprint = ""

[templates."nokia_ta_1131"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia X7"
device = "phoenix"
product = "phoenix"
name = "phoenix"
marketname = "Nokia X7"
fingerprint = ""

[templates."nokia_ta_1172"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia X71"
device = "taisun"
product = "taisun"
name = "taisun"
marketname = "Nokia X71"
fingerprint = ""

[templates."nokia_ta_1117"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia 3.1 Plus"
device = "rooster"
product = "rooster"
name = "rooster"
marketname = "Nokia 3.1 Plus"
fingerprint = ""

[templates."nokia_ta_1335"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia C1 Plus"
device = "yondu"
product = "yondu"
name = "yondu"
marketname = "Nokia C1 Plus"
fingerprint = ""

[templates."nokia_ta_1258"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia C3"
device = "gamoraplus"
product = "gamoraplus"
name = "gamoraplus"
marketname = "Nokia C3"
fingerprint = ""

[templates."nokia_ta_1388"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia C20 Plus"
device = "sirius"
product = "sirius"
name = "sirius"
marketname = "Nokia C20 Plus"
fingerprint = ""

[templates."nokia_ta_1361"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia G50"
device = "punisher"
product = "punisher"
name = "punisher"
marketname = "Nokia G50"
fingerprint = ""

[templates."nokia_ta_1392"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia T20"
device = "riddler"
product = "riddler"
name = "riddler"
marketname = "Nokia T20"
fingerprint = ""

[templates."nokia_ta_1511"]
manufacturer = "Nokia"
brand = "Nokia"
model = "Nokia C31"
device = "vision"
product = "vision"
name = "vision"
marketname = "Nokia C31"
fingerprint = ""

[templates."smartisan_sm701"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan T1"
device = "sfo"
product = "sfo"
name = "sfo"
marketname = "Smartisan T1"
fingerprint = ""

[templates."smartisan_sm801"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan T2"
device = "icesky"
product = "icesky"
name = "icesky"
marketname = "Smartisan T2"
fingerprint = ""

[templates."smartisan_sm901"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan M1"
device = "surabaya"
product = "surabaya"
name = "surabaya"
marketname = "Smartisan M1"
fingerprint = ""

[templates."smartisan_sm919"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan M1L"
device = "colombo"
product = "colombo"
name = "colombo"
marketname = "Smartisan M1L"
fingerprint = ""

[templates."smartisan_yq601"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan 手机"
device = "nut"
product = "nut"
name = "nut"
marketname = "Smartisan 手机"
fingerprint = ""

[templates."smartisan_yq603"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan 手机 文艺青年版"
device = "nut"
product = "nut"
name = "nut"
marketname = "Smartisan 手机 文艺青年版"
fingerprint = ""

[templates."smartisan_od103"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan Pro"
device = "odin"
product = "odin"
name = "odin"
marketname = "Smartisan Pro"
fingerprint = ""

[templates."smartisan_os105"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan Pro 2"
device = "osborn"
product = "osborn"
name = "osborn"
marketname = "Smartisan Pro 2"
fingerprint = ""

[templates."smartisan_os103"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan Pro 2 特别版"
device = "oxford"
product = "oxford"
name = "oxford"
marketname = "Smartisan Pro 2 特别版"
fingerprint = ""

[templates."smartisan_oc105"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan 3"
device = "oscar"
product = "oscar"
name = "oscar"
marketname = "Smartisan 3"
fingerprint = ""

[templates."smartisan_de106"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan R1"
device = "trident"
product = "trident"
name = "trident"
marketname = "Smartisan R1"
fingerprint = ""

[templates."smartisan_oe106"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan Pro 2S"
device = "ocean"
product = "ocean"
name = "ocean"
marketname = "Smartisan Pro 2S"
fingerprint = ""

[templates."smartisan_dt1901a"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan Pro 3"
device = "delta"
product = "delta"
name = "delta"
marketname = "Smartisan Pro 3"
fingerprint = ""

[templates."smartisan_dt2002c"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan R2"
device = "darwin"
product = "darwin"
name = "darwin"
marketname = "Smartisan R2"
fingerprint = ""

[templates."smartisan_dt2003a"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan TNT go 有线版"
device = "DT2003A"
product = "DT2003A"
marketname = "Smartisan TNT go 有线版"
fingerprint = ""

[templates."smartisan_dt2003c"]
manufacturer = "Smartisan"
brand = "Smartisan"
model = "Smartisan TNT go 无线版"
device = "DT2003C"
product = "DT2003C"
marketname = "Smartisan TNT go 无线版"
fingerprint = ""

[templates."letv_letv_x600"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 1 通用版"
device = "Letv X600"
product = "Letv X600"
marketname = "LeTV 乐 1 通用版"
fingerprint = ""

[templates."letv_letv_x608"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 1"
device = "Letv X608"
product = "Letv X608"
marketname = "LeTV 乐 1"
fingerprint = ""

[templates."letv_letv_x500"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 1s 通用版"
device = "Letv X500"
product = "Letv X500"
marketname = "LeTV 乐 1s 通用版"
fingerprint = ""

[templates."letv_letv_x501"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 1s 太子妃版"
device = "Letv X501"
product = "Letv X501"
marketname = "LeTV 乐 1s 太子妃版"
fingerprint = ""

[templates."letv_letv_x508"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 1s"
device = "Letv X508"
product = "Letv X508"
marketname = "LeTV 乐 1s"
fingerprint = ""

[templates."letv_letv_x502"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 1s 未知版本"
device = "Letv X502"
product = "Letv X502"
marketname = "LeTV 乐 1s 未知版本"
fingerprint = ""

[templates."letv_letv_x800"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 1 Pro 通用版"
device = "Letv X800"
product = "Letv X800"
marketname = "LeTV 乐 1 Pro 通用版"
fingerprint = ""

[templates."letv_letv_x900"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 Max 通用版"
device = "Letv X900"
product = "Letv X900"
marketname = "LeTV 乐 Max 通用版"
fingerprint = ""

[templates."letv_letv_x906"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 Max"
device = "Letv X906"
product = "Letv X906"
marketname = "LeTV 乐 Max"
fingerprint = ""

[templates."letv_le_x620"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 2"
device = "MTK"
product = "MTK"
name = "MTK"
marketname = "LeTV 乐 2"
fingerprint = ""

[templates."letv_le_x625"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 2 Pro"
device = "Le X625"
product = "Le X625"
marketname = "LeTV 乐 2 Pro"
fingerprint = ""

[templates."letv_le_x520"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV Le X525: 乐 2"
device = "Le X520"
product = "Le X520"
marketname = "LeTV Le X525: 乐 2"
fingerprint = ""

[templates."letv_le_x529"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 2 未知版本"
device = "Le X529"
product = "Le X529"
marketname = "LeTV 乐 2 未知版本"
fingerprint = ""

[templates."letv_le_x820"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 Max 2"
device = "Le X820"
product = "Le X820"
marketname = "LeTV 乐 Max 2"
fingerprint = ""

[templates."letv_letv_x910"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 Max Pro"
device = "Letv X910"
product = "Letv X910"
marketname = "LeTV 乐 Max Pro"
fingerprint = ""

[templates."letv_lex622"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 S3"
device = "LEX622"
product = "LEX622"
marketname = "LeTV 乐 S3"
fingerprint = ""

[templates."letv_lex623"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 S3 未知版本"
device = "LEX623"
product = "LEX623"
marketname = "LeTV 乐 S3 未知版本"
fingerprint = ""

[templates."letv_lex720"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 Pro 3"
device = "LEX720"
product = "LEX720"
marketname = "LeTV 乐 Pro 3"
fingerprint = ""

[templates."letv_lex722"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 Pro 3 精英版"
device = "LEX722"
product = "LEX722"
marketname = "LeTV 乐 Pro 3 精英版"
fingerprint = ""

[templates."letv_lex726"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 Pro 3 未知版本"
device = "LEX726"
product = "LEX726"
marketname = "LeTV 乐 Pro 3 未知版本"
fingerprint = ""

[templates."letv_lex651"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 Pro 3 双摄 AI 版"
device = "LEX651"
product = "LEX651"
marketname = "LeTV 乐 Pro 3 双摄 AI 版"
fingerprint = ""

[templates."letv_lex650"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 Pro 3 双摄 AI 版 生态版"
device = "LEX650"
product = "LEX650"
marketname = "LeTV 乐 Pro 3 双摄 AI 版 生态版"
fingerprint = ""

[templates."letv_lex652"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 乐 Pro 3 双摄 AI 版 未知版本"
device = "LEX652"
product = "LEX652"
marketname = "LeTV 乐 Pro 3 双摄 AI 版 未知版本"
fingerprint = ""

[templates."letv_lex850"]
manufacturer = "Letv"
brand = "Letv"
model = "LeTV 未知机型"
device = "LEX850"
product = "LEX850"
marketname = "LeTV 未知机型"
fingerprint = ""

[templates."letv_l5"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv S1 5G"
device = "L5"
product = "L5"
marketname = "Letv S1 5G"
fingerprint = ""

[templates."letv_letv_l6"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv Y1 Pro"
device = "Letv L6"
product = "Letv L6"
marketname = "Letv Y1 Pro"
fingerprint = ""

[templates."letv_letv_l6b"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv Y1 Pro+"
device = "Letv L6B"
product = "Letv L6B"
marketname = "Letv Y1 Pro+"
fingerprint = ""

[templates."letv_letv_l7"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv Y2 Pro"
device = "Letv L7"
product = "Letv L7"
marketname = "Letv Y2 Pro"
fingerprint = ""

[templates."letv_letv_l8"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv S1 Pro 5G"
device = "Letv L8"
product = "Letv L8"
marketname = "Letv S1 Pro 5G"
fingerprint = ""

[templates."letv_letv_l9"]
manufacturer = "Letv"
brand = "Letv"
model = "Letv S3 Pro"
device = "Letv L9"
product = "Letv L9"
marketname = "Letv S3 Pro"
fingerprint = ""

[templates."coolpad_8297"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大神 F1"
device = "8297"
product = "8297"
marketname = "Coolpad 大神 F1"
fingerprint = ""

[templates."coolpad_8297d"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大神 F1 青春版"
device = "8297D"
product = "8297D"
marketname = "Coolpad 大神 F1 青春版"
fingerprint = ""

[templates."coolpad_8297_w01"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大神 F1 Plus"
device = "8297-W01"
product = "8297-W01"
marketname = "Coolpad 大神 F1 Plus"
fingerprint = ""

[templates."coolpad_8297_t01"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大神 F1 Plus 移动 4G 版 & 酷派大神 F1 极速版"
device = "8297-T01"
product = "8297-T01"
marketname = "Coolpad 大神 F1 Plus 移动 4G 版 & 酷派大神 F1 极速版"
fingerprint = ""

[templates."coolpad_8675_hd"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大神 F2"
device = "8675-HD"
product = "8675-HD"
marketname = "Coolpad 大神 F2"
fingerprint = ""

[templates."coolpad_8675_f01"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大神 F2 全高清"
device = "8675-F01"
product = "8675-F01"
marketname = "Coolpad 大神 F2 全高清"
fingerprint = ""

[templates."coolpad_8690"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大神 X7 双网通版"
device = "8690"
product = "8690"
marketname = "Coolpad 大神 X7 双网通版"
fingerprint = ""

[templates."coolpad_8690_t00"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大神 X7"
device = "8690-T00"
product = "8690-T00"
marketname = "Coolpad 大神 X7"
fingerprint = ""

[templates."coolpad_8670"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大神 Note"
device = "8670"
product = "8670"
marketname = "Coolpad 大神 Note"
fingerprint = ""

[templates."coolpad_c105"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad COOL Changer S1"
device = "C105"
product = "C105"
marketname = "Coolpad COOL Changer S1"
fingerprint = ""

[templates."coolpad_c106"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad C106-7 C106-8 C106-9: 酷派 COOL 1 dual"
device = "C106"
product = "C106"
marketname = "Coolpad C106-7 C106-8 C106-9: 酷派 COOL 1 dual"
fingerprint = ""

[templates."coolpad_c107"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad COOL 1C"
device = "C107"
product = "C107"
marketname = "Coolpad COOL 1C"
fingerprint = ""

[templates."coolpad_pol_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad COOL M7"
device = "POL-A0"
product = "POL-A0"
marketname = "Coolpad COOL M7"
fingerprint = ""

[templates."coolpad_vcr_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 酷玩 6"
device = "VCR-A0"
product = "VCR-A0"
marketname = "Coolpad 酷玩 6"
fingerprint = ""

[templates."coolpad_gra_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 酷玩 6C"
device = "GRA-A0"
product = "GRA-A0"
marketname = "Coolpad 酷玩 6C"
fingerprint = ""

[templates."coolpad_1871_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad COOL 2"
device = "1871-A0"
product = "1871-A0"
marketname = "Coolpad COOL 2"
fingerprint = ""

[templates."coolpad_mts_t0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 锋尚 N2M"
device = "MTS-T0"
product = "MTS-T0"
marketname = "Coolpad 锋尚 N2M"
fingerprint = ""

[templates."coolpad_art_t0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 锋尚 N2D"
device = "ART-T0"
product = "ART-T0"
marketname = "Coolpad 锋尚 N2D"
fingerprint = ""

[templates."coolpad_1802_t0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 锋尚 K2"
device = "1802-T0"
product = "1802-T0"
marketname = "Coolpad 锋尚 K2"
fingerprint = ""

[templates."coolpad_1812_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 锋尚 K2 Max"
device = "1812-A0"
product = "1812-A0"
marketname = "Coolpad 锋尚 K2 Max"
fingerprint = ""

[templates."coolpad_1841_c0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 锋尚 N3"
device = "1841-C0"
product = "1841-C0"
marketname = "Coolpad 锋尚 N3"
fingerprint = ""

[templates."coolpad_1801_t0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 锋尚 N3M"
device = "1801-T0"
product = "1801-T0"
marketname = "Coolpad 锋尚 N3M"
fingerprint = ""

[templates."coolpad_1822_c0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 锋尚 N3C"
device = "1822-C0"
product = "1822-C0"
marketname = "Coolpad 锋尚 N3C"
fingerprint = ""

[templates."coolpad_1821_t0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 锋尚 N3D"
device = "1821-T0"
product = "1821-T0"
marketname = "Coolpad 锋尚 N3D"
fingerprint = ""

[templates."coolpad_1872_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 酷玩 7"
device = "1872-A0"
product = "1872-A0"
marketname = "Coolpad 酷玩 7"
fingerprint = ""

[templates."coolpad_1831_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 酷玩 7C"
device = "1831-A0"
product = "1831-A0"
marketname = "Coolpad 酷玩 7C"
fingerprint = ""

[templates."coolpad_1873_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 酷玩 8"
device = "1873-A0"
product = "1873-A0"
marketname = "Coolpad 酷玩 8"
fingerprint = ""

[templates."coolpad_1832_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 酷玩 8 Lite"
device = "1832-A0"
product = "1832-A0"
marketname = "Coolpad 酷玩 8 Lite"
fingerprint = ""

[templates."coolpad_orl_c0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad COOL 9"
device = "ORL-C0"
product = "ORL-C0"
marketname = "Coolpad COOL 9"
fingerprint = ""

[templates."coolpad_orl_t0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad COOL 9A"
device = "ORL-T0"
product = "ORL-T0"
marketname = "Coolpad COOL 9A"
fingerprint = ""

[templates."coolpad_sac_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 26"
device = "SAC-A0"
product = "SAC-A0"
marketname = "Coolpad 26"
fingerprint = ""

[templates."coolpad_cha_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 酷玩 10"
device = "CHA-A0"
product = "CHA-A0"
marketname = "Coolpad 酷玩 10"
fingerprint = ""

[templates."coolpad_sea_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad COOL 10"
device = "SEA-A0"
product = "SEA-A0"
marketname = "Coolpad COOL 10"
fingerprint = ""

[templates."coolpad_det_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad COOL 10C"
device = "DET-A0"
product = "DET-A0"
marketname = "Coolpad COOL 10C"
fingerprint = ""

[templates."coolpad_bos_a0"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad COOL 10 青春版"
device = "BOS-A0"
product = "BOS-A0"
marketname = "Coolpad COOL 10 青春版"
fingerprint = ""

[templates."coolpad_hou_5ga"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad X10 5G"
device = "HOU-5GA"
product = "HOU-5GA"
marketname = "Coolpad X10 5G"
fingerprint = ""

[templates."coolpad_pho_5gt"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 锋尚 A11 5G"
device = "PHO-5GT"
product = "PHO-5GT"
marketname = "Coolpad 锋尚 A11 5G"
fingerprint = ""

[templates."coolpad_cp03"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad COOL 20"
device = "CP03"
product = "CP03"
marketname = "Coolpad COOL 20"
fingerprint = ""

[templates."coolpad_cp05"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大观 40 Pro 5G"
device = "CP05"
product = "CP05"
marketname = "Coolpad 大观 40 Pro 5G"
fingerprint = ""

[templates."coolpad_cp07"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad COOL 20s 5G"
device = "CP07"
product = "CP07"
marketname = "Coolpad COOL 20s 5G"
fingerprint = ""

[templates."coolpad_cp13"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad COOL 30"
device = "CP13"
product = "CP13"
marketname = "Coolpad COOL 30"
fingerprint = ""

[templates."coolpad_cp15"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad COOL 30 Pro 5G"
device = "CP15"
product = "CP15"
marketname = "Coolpad COOL 30 Pro 5G"
fingerprint = ""

[templates."coolpad_cpdm1y"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad COOL 50"
device = "CPDM1Y"
product = "CPDM1Y"
marketname = "Coolpad COOL 50"
fingerprint = ""

[templates."coolpad_cp3nv2"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad COOL 60 5G"
device = "CP3NV2"
product = "CP3NV2"
marketname = "Coolpad COOL 60 5G"
fingerprint = ""

[templates."coolpad_cp16t"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大观 40s 5G"
device = "CP16t"
product = "CP16t"
marketname = "Coolpad 大观 40s 5G"
fingerprint = ""

[templates."coolpad_cp17"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大观 50s 5G"
device = "CP17"
product = "CP17"
marketname = "Coolpad 大观 50s 5G"
fingerprint = ""

[templates."coolpad_cp27"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大观 Y60 5G"
device = "CP27"
product = "CP27"
marketname = "Coolpad 大观 Y60 5G"
fingerprint = ""

[templates."coolpad_cp3at2"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大观 Y60 Lite 5G"
device = "CP3AT2"
product = "CP3AT2"
marketname = "Coolpad 大观 Y60 Lite 5G"
fingerprint = ""

[templates."coolpad_cp3ct1"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大观 Y60s 5G"
device = "CP3CT1"
product = "CP3CT1"
marketname = "Coolpad 大观 Y60s 5G"
fingerprint = ""

[templates."coolpad_cp3at5"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大观 C60 5G"
device = "CP3AT5"
product = "CP3AT5"
marketname = "Coolpad 大观 C60 5G"
fingerprint = ""

[templates."coolpad_cp3nv1"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 大观 3 5G"
device = "CP3NV1"
product = "CP3NV1"
marketname = "Coolpad 大观 3 5G"
fingerprint = ""

[templates."coolpad_cpday3"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 锋尚 60 Lite"
device = "CPDAY3"
product = "CPDAY3"
marketname = "Coolpad 锋尚 60 Lite"
fingerprint = ""

[templates."coolpad_cp2fm1"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad Y70 Lite 5G"
device = "CP2FM1"
product = "CP2FM1"
marketname = "Coolpad Y70 Lite 5G"
fingerprint = ""

[templates."coolpad_cp23nv3"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 金世纪 Y60 5G"
device = "CP23NV3"
product = "CP23NV3"
marketname = "Coolpad 金世纪 Y60 5G"
fingerprint = ""

[templates."coolpad_cp2fm2"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad Y77 5G"
device = "CP2FM2"
product = "CP2FM2"
marketname = "Coolpad Y77 5G"
fingerprint = ""

[templates."coolpad_cpday6"]
manufacturer = "Coolpad"
brand = "Coolpad"
model = "Coolpad 锋尚 60 Pro"
device = "CPDAY6"
product = "CPDAY6"
marketname = "Coolpad 锋尚 60 Pro"
fingerprint = ""

[templates."oneplus_pad"]
manufacturer = "OPPO"
brand = "OnePlus"
model = "OnePlus Pad"
device = "aries-o"
product = "aries-o"
name = "aries-o"
marketname = "OnePlus Pad"
fingerprint = ""
characteristics = "tablet"


[templates."oneplus_pad_2"]
manufacturer = "OPPO"
brand = "OnePlus"
model = "OnePlus Pad 2"
device = "rainbow"
product = "rainbow"
name = "rainbow"
marketname = "OnePlus Pad 2"
fingerprint = ""
characteristics = "tablet"


[templates."oneplus_pad_2_pro"]
manufacturer = "OPPO"
brand = "OnePlus"
model = "OnePlus Pad 2 Pro"
device = "erhai-o"
product = "erhai-o"
name = "erhai-o"
marketname = "OnePlus Pad 2 Pro"
fingerprint = ""
characteristics = "tablet"


[templates."oneplus_pad_3"]
manufacturer = "OPPO"
brand = "OnePlus"
model = "OnePlus Pad 3"
device = "OPD2503"
product = "OPD2503"
marketname = "OnePlus Pad 3"
fingerprint = ""
characteristics = "tablet"


[templates."oneplus_pad_3_pro"]
manufacturer = "OPPO"
brand = "OnePlus"
model = "OnePlus Pad 3 Pro"
device = "iceland-o"
product = "iceland-o"
name = "iceland-o"
marketname = "OnePlus Pad 3 Pro"
fingerprint = ""
characteristics = "tablet"


[templates."oneplus_pad_go"]
manufacturer = "OPPO"
brand = "OnePlus"
model = "OnePlus Pad Go"
device = "bluey-o"
product = "bluey-o"
name = "bluey-o"
marketname = "OnePlus Pad Go"
fingerprint = ""
characteristics = "tablet"


[templates."oneplus_pad_lite"]
manufacturer = "OPPO"
brand = "OnePlus"
model = "OnePlus Pad Lite"
device = "rainbow"
product = "rainbow"
name = "rainbow"
marketname = "OnePlus Pad Lite"
fingerprint = ""
characteristics = "tablet"
YJ_LOCAL_TPL_EOF
  tr -d '\r' < "$_want" > "$_want.lf" 2>/dev/null && mv -f "$_want.lf" "$_want" 2>/dev/null
  if [ -s "$YJ_TL_FILE" ] && cmp -s "$_want" "$YJ_TL_FILE" 2>/dev/null; then
    rm -f "$_want" 2>/dev/null
    return 0
  fi
  mv -f "$_want" "$YJ_TL_FILE" 2>/dev/null
  chmod 0644 "$YJ_TL_FILE" 2>/dev/null
  return 0
}

yj_tl_count() {
  yj_tl_seed
  [ -f "$YJ_TL_FILE" ] || { echo 0; return; }
  grep -c '^\[templates\.' "$YJ_TL_FILE" 2>/dev/null || echo 0
}

yj_tl_status() {
  yj_tl_seed
  yj_tl_say "  内置模板：$(yj_tl_count) 个"
  yj_tl_say "  文件：$YJ_TL_FILE"
  return 0
}

yj_tl_list_all() {
  yj_tl_seed
  [ -f "$YJ_TL_FILE" ] || return 1
  yj_tl_say "  ── 内置模板 ──"
  tr -d '\r' < "$YJ_TL_FILE" 2>/dev/null | awk '
    /^\[templates\./ {
      if (name != "") printf "    %-28s %s\n", name, (mk != "" ? mk : name)
      name = $0; sub(/^\[templates\./,"",name); sub(/\]$/,"",name); gsub(/"/,"",name)
      mk = ""; next
    }
    /^\[/ { if (name != "") printf "    %-28s %s\n", name, (mk != "" ? mk : name); name=""; next }
    /^[ \t]*marketname *=/ { mk = $0; sub(/^[ \t]*marketname *= *"/,"",mk); sub(/"$/,"",mk) }
    END { if (name != "") printf "    %-28s %s\n", name, (mk != "" ? mk : name) }
  ' 2>/dev/null
  return 0
}

yj_tl_search() {
  _kw="$1"
  yj_tl_seed
  [ -n "$_kw" ] || return 1
  [ -f "$YJ_TL_FILE" ] || return 1

  tr -d '\r' < "$YJ_TL_FILE" 2>/dev/null | awk -v kw="$_kw" '
    function low(s) { return tolower(s) }
    BEGIN { K = low(kw); KL = length(K) }
    /^\[templates\./ {
      if (name != "" && hit) printf "    %-28s %s\n", name, (mk != "" ? mk : name)
      name = $0
      sub(/^\[templates\./, "", name)
      sub(/\]$/, "", name)
      gsub(/"/, "", name)
      mk = ""; hit = 0
      # 模板名匹配（不区分大小写）
      if (index(low(name), K) > 0) hit = 1
      next
    }
    /^\[/ {
      if (name != "" && hit) printf "    %-28s %s\n", name, (mk != "" ? mk : name)
      name = ""; hit = 0; next
    }
    /^[ \t]*marketname *=/ {
      mk = $0
      sub(/^[ \t]*marketname *= *"/, "", mk)
      sub(/"$/, "", mk)
      if (index(low(mk), K) > 0) hit = 1
    }
    /^[ \t]*brand *=/ {
      v = $0
      sub(/^[ \t]*brand *= *"/, "", v)
      sub(/"$/, "", v)
      # 双保险：小写比较 + 原始比较
      if (low(v) == K || v == kw) hit = 1
      if (index(low(v), K) > 0) hit = 1
    }
    /^[ \t]*model *=/ {
      v = $0
      sub(/^[ \t]*model *= *"/, "", v)
      sub(/"$/, "", v)
      if (index(low(v), K) > 0) hit = 1
    }
    END { if (name != "" && hit) printf "    %-28s %s\n", name, (mk != "" ? mk : name) }
  ' 2>/dev/null
  return 0
}

yj_tl_field() {
  _name="$1"; _f="$2"
  yj_tl_seed
  [ -f "$YJ_TL_FILE" ] || return 1
  tr -d '\r' < "$YJ_TL_FILE" 2>/dev/null | awk -v k="$_name" -v fld="$_f" '
    $0 ~ "^\\[templates\\.\"?"k"\"?\\]$" { inside=1; next }
    inside && /^\[/ { exit }
    inside && $0 ~ "^"fld" *=" {
      v = $0; sub("^"fld" *= *\"?", "", v); sub(/\"$/, "", v); print v; exit
    }
  ' 2>/dev/null
}
