#!/system/bin/sh
YJ_PREFIX="${YJ_PREFIX:-}"
YJ_HOME="${YJ_PREFIX}/data/adb/device_spoof"
YJ_DF_CONF="${YJ_PREFIX}/data/adb/knjw_spoof01/config/config.toml"

# resetprop 可能不在 PATH（KernelSU 在 /data/adb/ksu/bin）
for _d in /data/adb/ksu/bin /data/adb/ap/bin /data/adb/magisk /debug_ramdisk; do
  if [ -d "$_d" ]; then
    case ":$PATH:" in
      *":$_d:"*) ;;
      *) PATH="$PATH:$_d" ;;
    esac
  fi
done
export PATH

yj_init() {
  mkdir -p "$YJ_HOME" 2>/dev/null
  mkdir -p "${YJ_PREFIX}/data/adb/knjw_spoof01/config" 2>/dev/null
  return 0
}

yj_say() { echo "$*"; }
yj_warn() { echo "! $*"; }
yj_err() { echo "x $*"; }
yj_log() { echo "$*"; }
