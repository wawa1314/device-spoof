#!/system/bin/sh

YJ_SPOOF_HOME="${YJ_PREFIX}/data/adb/device_spoof"
YJ_SPOOF_CONF="${YJ_SPOOF_HOME}/spoof.conf"

YJ_DF_HOME="${YJ_PREFIX}/data/adb/knjw_spoof01"
YJ_DF_CONF="${YJ_DF_HOME}/config/config.toml"

yj_spoof_say() { command -v yj_say >/dev/null 2>&1 && yj_say "$*" || echo "$*"; }
yj_spoof_warn() { command -v yj_warn >/dev/null 2>&1 && yj_warn "$*" || echo "! $*"; }

# ============================================================
# 全局伪装（resetprop，改整机属性）
# ============================================================

yj_spoof_get() {
  _k="$1"
  [ -f "$YJ_SPOOF_CONF" ] || return 0
  sed -n "s/^${_k}=//p" "$YJ_SPOOF_CONF" 2>/dev/null | tail -n1
}

yj_spoof_save() {
  mkdir -p "$YJ_SPOOF_HOME" 2>/dev/null
  _t="${YJ_SPOOF_CONF}.tmp.$$"
  {
    printf 'manufacturer=%s\n' "$1"
    printf 'brand=%s\n' "$2"
    printf 'model=%s\n' "$3"
    printf 'device=%s\n' "$4"
    printf 'product=%s\n' "$5"
    printf 'fingerprint=%s\n' "$6"
    printf 'build_id=%s\n' "$7"
  } >"$_t" 2>/dev/null
  mv -f "$_t" "$YJ_SPOOF_CONF" 2>/dev/null
  chmod 0600 "$YJ_SPOOF_CONF" 2>/dev/null
  return 0
}

yj_spoof_prop() {
  _p="$1"; _v="$2"
  [ -n "$_v" ] || return 0
  resetprop -n "ro.product.${_p}" "$_v" 2>/dev/null
  for _part in system vendor odm product system_ext; do
    [ -n "$(getprop "ro.product.${_part}.${_p}" 2>/dev/null)" ] && \
      resetprop -n "ro.product.${_part}.${_p}" "$_v" 2>/dev/null
  done
  return 0
}

yj_spoof_fingerprint() {
  _v="$1"
  [ -n "$_v" ] || return 0
  resetprop -n ro.build.fingerprint "$_v" 2>/dev/null
  for _part in system vendor odm product system_ext bootimage; do
    [ -n "$(getprop "ro.${_part}.build.fingerprint" 2>/dev/null)" ] && \
      resetprop -n "ro.${_part}.build.fingerprint" "$_v" 2>/dev/null
  done
  return 0
}

yj_spoof_apply_quiet() {
  [ -f "$YJ_SPOOF_CONF" ] || return 1
  [ -n "${YJ_PREFIX}" ] && return 0
  command -v resetprop >/dev/null 2>&1 || return 1
  yj_spoof_prop manufacturer "$(yj_spoof_get manufacturer)"
  yj_spoof_prop brand "$(yj_spoof_get brand)"
  yj_spoof_prop model "$(yj_spoof_get model)"
  yj_spoof_prop device "$(yj_spoof_get device)"
  yj_spoof_prop name "$(yj_spoof_get product)"
  yj_spoof_fingerprint "$(yj_spoof_get fingerprint)"
  _bi="$(yj_spoof_get build_id)"
  [ -n "$_bi" ] && resetprop -n ro.build.id "$_bi" 2>/dev/null
  return 0
}

yj_spoof_apply() {
  if [ ! -f "$YJ_SPOOF_CONF" ]; then
    yj_spoof_warn "  还没保存过机型配置，先填好点「保存并应用」"
    return 1
  fi
  if ! command -v resetprop >/dev/null 2>&1 && [ -z "${YJ_PREFIX}" ]; then
    yj_spoof_warn "  没有 resetprop，这个功能需要 KernelSU / Magisk 提供"
    return 1
  fi

  yj_spoof_say "  【全局】整机属性"
  yj_spoof_say "  manufacturer : $(yj_spoof_get manufacturer)"
  yj_spoof_say "  brand        : $(yj_spoof_get brand)"
  yj_spoof_say "  model        : $(yj_spoof_get model)"
  yj_spoof_say "  device       : $(yj_spoof_get device)"
  yj_spoof_say "  product      : $(yj_spoof_get product)"
  yj_spoof_say "  fingerprint  : $(yj_spoof_get fingerprint)"
  yj_spoof_say "  build_id     : $(yj_spoof_get build_id)"

  yj_spoof_apply_quiet
  yj_spoof_say ""
  yj_spoof_say "  已写入。复查当前值："
  yj_spoof_say "    ro.product.model        = $(getprop ro.product.model)"
  yj_spoof_say "    ro.product.manufacturer = $(getprop ro.product.manufacturer)"
  yj_spoof_say "    ro.build.fingerprint    = $(getprop ro.build.fingerprint)"
  yj_spoof_say ""
  yj_spoof_say "  已启动的应用要退出重开才能看到新值（不用重启手机）"
  return 0
}

yj_spoof_save_and_apply() {
  _m="$1"; _b="$2"; _mo="$3"; _d="$4"; _pr="$5"; _f="$6"; _bi="$7"
  if [ -z "$_mo" ]; then
    yj_spoof_warn "  机型代号（model）不能为空"
    return 1
  fi
  yj_spoof_save "$_m" "$_b" "$_mo" "$_d" "$_pr" "$_f" "$_bi"
  yj_spoof_say "  ✓ 配置已保存：$YJ_SPOOF_CONF"
  yj_spoof_say ""
  yj_spoof_apply
  return $?
}

yj_spoof_status() {
  yj_spoof_say "  ── 当前系统值（真实机型）──"
  yj_spoof_say "  MANUFACTURER=$(getprop ro.product.manufacturer)"
  yj_spoof_say "  BRAND=$(getprop ro.product.brand)"
  yj_spoof_say "  MODEL=$(getprop ro.product.model)"
  yj_spoof_say "  DEVICE=$(getprop ro.product.device)"
  yj_spoof_say "  PRODUCT=$(getprop ro.product.name)"
  yj_spoof_say "  FINGERPRINT=$(getprop ro.build.fingerprint)"
  yj_spoof_say "  BUILD_ID=$(getprop ro.build.id)"
  yj_spoof_say ""
  if [ -s "$YJ_SPOOF_CONF" ]; then
    yj_spoof_say "  ── 全局伪装配置（开机自动应用）──"
    yj_spoof_say "  SAVED_MANUFACTURER=$(yj_spoof_get manufacturer)"
    yj_spoof_say "  SAVED_BRAND=$(yj_spoof_get brand)"
    yj_spoof_say "  SAVED_MODEL=$(yj_spoof_get model)"
    yj_spoof_say "  SAVED_DEVICE=$(yj_spoof_get device)"
    yj_spoof_say "  SAVED_PRODUCT=$(yj_spoof_get product)"
    yj_spoof_say "  SAVED_FINGERPRINT=$(yj_spoof_get fingerprint)"
    yj_spoof_say "  SAVED_BUILD_ID=$(yj_spoof_get build_id)"
  else
    yj_spoof_say "  ── 没有保存过全局伪装配置 ──"
  fi
  yj_spoof_say ""
  if [ -s "$YJ_DF_CONF" ]; then
    yj_spoof_say "  ── 按应用伪装：已配置 $(grep -c '^\[\[apps\]\]' "$YJ_DF_CONF" 2>/dev/null) 个应用 ──"
    awk '/^package *=/ {gsub(/^package *= *"|"$/,""); printf "    %s\n", $0}' "$YJ_DF_CONF" 2>/dev/null | head -30
  else
    yj_spoof_say "  ── 按应用伪装：还没配置 ──"
  fi
  return 0
}

yj_spoof_clear() {
  # 先删配置文件
  rm -f "$YJ_SPOOF_CONF" 2>/dev/null

  # 关键：真机值在 ro.product.bootimage.* 这组属性里（不被伪装污染），
  # 从那里读出真实值，回填到 ro.product.*，不用重启。
  if command -v resetprop >/dev/null 2>&1 && [ -z "${YJ_PREFIX}" ]; then
    for _k in manufacturer brand model device name; do
      _real="$(getprop "ro.product.bootimage.${_k}" 2>/dev/null)"
      if [ -n "$_real" ]; then
        resetprop -n "ro.product.${_k}" "$_real" 2>/dev/null
        for _part in system vendor odm product system_ext; do
          [ -n "$(getprop "ro.product.${_part}.${_k}" 2>/dev/null)" ] &&             resetprop -n "ro.product.${_part}.${_k}" "$_real" 2>/dev/null
        done
      else
        # bootimage 里也没有，就删掉覆盖层
        resetprop -d "ro.product.${_k}" 2>/dev/null
      fi
    done
    # build.id 和 fingerprint 也还原
    _realid="$(getprop ro.product.build.id 2>/dev/null)"
    [ -n "$_realid" ] && resetprop -n ro.build.id "$_realid" 2>/dev/null
    resetprop -d ro.build.fingerprint 2>/dev/null
    for _part in system vendor odm product system_ext bootimage; do
      resetprop -d "ro.${_part}.build.fingerprint" 2>/dev/null
    done
  fi

  yj_spoof_say "  ✓ 已清除全局伪装配置"
  yj_spoof_say "  属性已还原为真实机型，不用重启"
  return 0
}

# ============================================================
# 按应用伪装（写引擎读取的配置文件）
# ============================================================

yj_df_engine_ok() {
  _d="${MODDIR:-${0%/*}}"
  for _p in "$YJ_PREFIX/data/adb/modules/device_spoof/zygisk" \
            "$_d/zygisk"; do
    [ -f "$_p/arm64-v8a.so" ] && return 0
  done
  return 1
}

yj_df_toml_esc() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

yj_df_add() {
  _pkg="$1"; _mfr="$2"; _brand="$3"; _model="$4"; _dev="$5"; _prod="$6"; _fp="$7"; _mkt="$8"; _nm="$9"

  if [ -z "$_pkg" ]; then
    yj_spoof_warn "  包名不能为空"
    return 1
  fi
  case "$_pkg" in
    *[!a-zA-Z0-9._]*)
      yj_spoof_warn "  包名只能包含字母、数字、点：$_pkg"
      return 1 ;;
  esac
  case "$_pkg" in
    *.*.*|*.*) ;;
    *) yj_spoof_warn "  包名至少要有一个点，如 com.tencent.tmgp.sgame"
       return 1 ;;
  esac

  if [ -z "$_model" ] && [ -z "$_mfr" ] && [ -z "$_brand" ]; then
    yj_spoof_warn "  至少填一项机型信息（厂商 / 品牌 / 机型代号）"
    return 1
  fi

  if ! yj_df_engine_ok; then
    yj_spoof_warn "  没找到按应用伪装的引擎（zygisk/arm64-v8a.so）"
    yj_spoof_warn "  这个功能需要刷入本模块并重启一次"
    return 1
  fi

  mkdir -p "$(dirname "$YJ_DF_CONF")" 2>/dev/null
  chmod 755 "$YJ_DF_HOME" "$(dirname "$YJ_DF_CONF")" 2>/dev/null

  if [ -f "$YJ_DF_CONF" ] && grep -q "^package = \"${_pkg}\"" "$YJ_DF_CONF" 2>/dev/null; then
    _removed=0
    _tmp="$YJ_DF_CONF.tmp.$$"
    awk -v pkg="$_pkg" '
      BEGIN { buf=""; drop=0 }
      /^\[\[apps\]\]/ {
        if (buf != "" && drop == 0) printf "%s", buf
        buf=$0 "\n"; drop=0; next
      }
      /^\[/ { if (buf != "") { printf "%s", buf; buf="" } drop=0; print; next }
      {
        if (buf != "") {
          buf = buf $0 "\n"
          if ($0 ~ "^package *= *\"" pkg "\"") drop=1
        } else print
      }
      END { if (buf != "" && drop == 0) printf "%s", buf }
    ' "$YJ_DF_CONF" >"$_tmp" 2>/dev/null && mv -f "$_tmp" "$YJ_DF_CONF" 2>/dev/null
    _removed=1
    yj_spoof_say "  → 已删掉 $_pkg 的旧配置，重新写入"
  fi

  {
    printf '\n[[apps]]\n'
    printf 'package = "%s"\n' "$_pkg"
    [ -n "$_mfr" ]   && printf 'manufacturer = "%s"\n' "$(yj_df_toml_esc "$_mfr")"
    [ -n "$_brand" ] && printf 'brand = "%s"\n' "$(yj_df_toml_esc "$_brand")"
    [ -n "$_model" ] && printf 'model = "%s"\n' "$(yj_df_toml_esc "$_model")"
    [ -n "$_dev" ]   && printf 'device = "%s"\n' "$(yj_df_toml_esc "$_dev")"
    [ -n "$_prod" ]  && printf 'product = "%s"\n' "$(yj_df_toml_esc "$_prod")"
    [ -n "$_nm" ]    && printf 'name = "%s"\n' "$(yj_df_toml_esc "$_nm")"
    [ -n "$_mkt" ]   && printf 'marketname = "%s"\n' "$(yj_df_toml_esc "$_mkt")"
    [ -n "$_fp" ]    && printf 'fingerprint = "%s"\n' "$(yj_df_toml_esc "$_fp")"
  } >>"$YJ_DF_CONF" 2>/dev/null

  chmod 644 "$YJ_DF_CONF" 2>/dev/null

  yj_spoof_say "  ✓ 已写入 $_pkg"
  yj_spoof_say "     厂商=$( [ -n "$_mfr" ] && echo "$_mfr" || echo '-' )  品牌=$( [ -n "$_brand" ] && echo "$_brand" || echo '-' )  机型=$( [ -n "$_model" ] && echo "$_model" || echo '-' )"
  [ -n "$_mkt" ] && yj_spoof_say "     市场名=$_mkt"
  yj_spoof_say ""
  yj_spoof_say "  目标应用完全退出后重开才会生效（从最近任务里划掉，不用重启手机）"
  yj_spoof_say "  配置：$YJ_DF_CONF"
  return 0
}

yj_df_del() {
  _pkg="$1"
  if [ -z "$_pkg" ]; then
    yj_spoof_warn "  要删哪个应用？点按钮时请先在上面填包名"
    return 1
  fi
  if [ ! -f "$YJ_DF_CONF" ]; then
    yj_spoof_warn "  还没有按应用配置：$YJ_DF_CONF"
    return 1
  fi

  _tmp="$YJ_DF_CONF.tmp.$$"
  awk -v pkg="$_pkg" '
    BEGIN { buf=""; drop=0 }
    /^\[\[apps\]\]/ {
      if (buf != "" && drop == 0) printf "%s", buf
      buf=$0 "\n"; drop=0; next
    }
    /^\[/ { if (buf != "") { printf "%s", buf; buf="" } drop=0; print; next }
    {
      if (buf != "") {
        buf = buf $0 "\n"
        if ($0 ~ "^package *= *\"" pkg "\"") drop=1
      } else print
    }
    END { if (buf != "" && drop == 0) printf "%s", buf }
  ' "$YJ_DF_CONF" >"$_tmp" 2>/dev/null

  if cmp -s "$_tmp" "$YJ_DF_CONF" 2>/dev/null; then
    rm -f "$_tmp" 2>/dev/null
    yj_spoof_warn "  没找到 $_pkg 的配置，没改动"
    return 1
  fi
  mv -f "$_tmp" "$YJ_DF_CONF" 2>/dev/null
  chmod 644 "$YJ_DF_CONF" 2>/dev/null
  yj_spoof_say "  ✓ 已删除 $_pkg 的伪装配置"
  return 0
}

yj_df_list() {
  if [ ! -s "$YJ_DF_CONF" ]; then
    yj_spoof_say "  ── 按应用伪装：还没配置 ──"
    yj_spoof_say "  在上面填包名和机型，点「添加/更新」就会写进去"
    return 0
  fi
  yj_spoof_say "  ── 按应用伪装配置 ──"
  yj_spoof_say "  文件：$YJ_DF_CONF"
  yj_spoof_say ""
  awk '
    /^\[\[apps\]\]/ { if (pkg != "") printf "    %-42s %s / %s / %s\n", pkg, mfr, brand, model
                     pkg=""; mfr="-"; brand="-"; model="-"; next }
    /^package / { gsub(/^package *= *"|"$/,""); pkg=$0 }
    /^manufacturer / { gsub(/^manufacturer *= *"|"$/,""); mfr=$0 }
    /^brand / { gsub(/^brand *= *"|"$/,""); brand=$0 }
    /^model / { gsub(/^model *= *"|"$/,""); model=$0 }
    END { if (pkg != "") printf "    %-42s %s / %s / %s\n", pkg, mfr, brand, model }
  ' "$YJ_DF_CONF" 2>/dev/null
  yj_spoof_say ""
  yj_spoof_say "  共 $(grep -c '^\[\[apps\]\]' "$YJ_DF_CONF" 2>/dev/null) 个应用"
  return 0
}

yj_df_clear() {
  _had=0
  if [ -f "$YJ_DF_CONF" ]; then
    _had=1
    _bak="${YJ_DF_CONF}.bak.$(date +%Y%m%d_%H%M%S)"
    cp -f "$YJ_DF_CONF" "$_bak" 2>/dev/null
  fi
  # 关键：不能 rm 文件，否则引擎不热重载、旧伪装残留。
  # 写一个合法空 TOML 触发引擎内容监听，立即渲染 0 个 spec。
  mkdir -p "$(dirname "$YJ_DF_CONF")" 2>/dev/null
  printf '# 机型伪装配置（已清空）\n' > "$YJ_DF_CONF" 2>/dev/null
  chmod 644 "$YJ_DF_CONF" 2>/dev/null
  yj_spoof_say "  ✓ 已清空按应用伪装配置"
  if [ "$_had" = "1" ]; then
    [ -f "$_bak" ] && yj_spoof_say "  旧配置备份在：$_bak"
  fi
  yj_spoof_say "  目标应用完全退出后重开即回到真实机型（不用重启手机）"
  return 0
}

yj_df_list_apps() {
  _o="$(pm list packages -3 2>/dev/null)"
  _o="$(printf '%s\n' "$_o" | sed -n 's/^package:\([A-Za-z0-9_.]*\)$/\1/p' | sort -u)"
  if [ -n "$_o" ]; then
    printf '%s\n' "$_o"
    return 0
  fi
  _pl="${YJ_PREFIX}/data/system/packages.list"
  if [ -f "$_pl" ]; then
    awk '$2 + 0 >= 10000 { print $1 }' "$_pl" 2>/dev/null | sort -u
  fi
  return 0
}

yj_df_list_apps_all() {
  _pl="${YJ_PREFIX}/data/system/packages.list"
  if [ -f "$_pl" ]; then
    awk '{ print $1 }' "$_pl" 2>/dev/null | sort -u
    return 0
  fi
  { pm list packages -3 2>/dev/null; pm list packages -s 2>/dev/null; } \
    | sed -n 's/^package:\([A-Za-z0-9_.]*\)$/\1/p' | sort -u
  return 0
}
