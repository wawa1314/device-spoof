#!/system/bin/sh
rm -rf /data/adb/device_spoof 2>/dev/null
exit 0
